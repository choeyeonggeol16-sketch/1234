package l1j.server.server.model;
public class L1Character extends L1Object {
 public int hp=0;public boolean dead=true,shop;
 public int getCurrentHp(){return hp;} public boolean isDead(){return dead;}public boolean isPrivateShop(){return shop;}
}