package l1j.server.server.model.item.function;
import l1j.server.server.model.Instance.*;import l1j.server.server.model.L1World;
import l1j.server.server.model.network.core.cs.packet.CDB;
import l1j.server.server.model.network.core.sc.packet.*;
public class TestWorldEffects {
 static int cases; static void ok(boolean a,String msg){if(!a)throw new AssertionError(msg);cases++;}
 static ItemActionContext context(int id,L1PcInstance pc,L1ItemInstance item,int targetId){var ctx=new ItemActionContext();ctx.pc=pc;ctx.item=item;ctx.itemId=id;ctx.spellTargetId=targetId;return ctx;}
 static L1PcInstance p(L1ItemInstance item){var pc=new L1PcInstance();pc.id=33;pc.inv.items.put(item.id,item);return pc;}
 static void reset(){ItemReceiptOperations.pending=null;ItemReceiptOperations.defer=true;ItemReceiptOperations.submissions=0; CDB.pending=null;CDB.defer=true;SC_MessageYN.fail=false;SC_MessageYN.requests=0;TransformationItems.polyCount=0;CreatureItemActions.barriers=0;L1World.INSTANCE=new L1World();}
 public static void main(String[] args){
  reset();var item=new L1ItemInstance(1,40089,0);var pc=p(item);var target=new L1PcInstance();target.id=88;target.hp=0;target.dead=true;L1World.INSTANCE.target=target;
  ResurrectionConsumables.handleTeleportCompanions(context(40089,pc,item,88));
  ok(item.count==1&&ItemReceiptOperations.pending!=null&&SC_MessageYN.requests==0,"resurrection deferred");
  ItemReceiptOperations.pending.run();ok(item.count==0&&SC_MessageYN.requests==1,"resurrection commit");
  reset();item=new L1ItemInstance(2,40089,0);pc=p(item);target=new L1PcInstance();target.id=89;L1World.INSTANCE.target=target;
  ResurrectionConsumables.handleTeleportCompanions(context(40089,pc,item,89));
  ItemReceiptOperations.pending=null;ok(item.count==1&&SC_MessageYN.requests==0,"rollback leaves scroll and request unchanged");
  reset();item=new L1ItemInstance(3,40089,0);pc=p(item);target=new L1PcInstance();target.id=90;L1World.INSTANCE.target=target;SC_MessageYN.fail=true;
  ResurrectionConsumables.handleTeleportCompanions(context(40089,pc,item,90));ItemReceiptOperations.pending.run();
  ok(item.count==0&&SC_MessageYN.requests==1,"committed scroll survives output fault");
  reset();item=new L1ItemInstance(4,40089,0);pc=p(item);var npc=new L1NpcInstance();npc.id=100;L1World.INSTANCE.target=npc;
  ResurrectionConsumables.handleTeleportCompanions(context(40089,pc,item,100));
  ok(npc.resurrectCount==0&&item.count==1,"NPC resurrection deferred");ItemReceiptOperations.pending.run();
  ok(npc.resurrectCount==1&&npc.occupied==1&&item.count==0,"NPC resurrected after commit");
  reset();item=new L1ItemInstance(5,40008,2);pc=p(item);L1World.INSTANCE.target=pc;
  TargetPolymorphWands.handleResurrectionScroll(context(40008,pc,item,pc.id));
  ok(item.chargeCount==2&&TransformationItems.polyCount==0&&CDB.pending!=null,"charged wand deferred");
  CDB.pending.run();ok(item.chargeCount==1&&TransformationItems.polyCount==1,"charged wand commit");
  reset();item=new L1ItemInstance(6,40008,1);pc=p(item);L1World.INSTANCE.target=pc;
  TargetPolymorphWands.handleResurrectionScroll(context(40008,pc,item,pc.id));CDB.pending.run();
  ok(item.count==0&&pc.inv.items.isEmpty(),"last wand charge removes complete item");
  reset();item=new L1ItemInstance(7,40410,0);pc=p(item);L1World.INSTANCE.target=pc;
  TargetPolymorphWands.handleResurrectionScroll(context(40410,pc,item,pc.id));
  ok(item.count==1&&TransformationItems.polyCount==0,"ordinary scroll deferred");ItemReceiptOperations.pending.run();
  ok(item.count==0&&TransformationItems.polyCount==1,"ordinary scroll committed");
  reset();item=new L1ItemInstance(8,40008,0);pc=p(item);L1World.INSTANCE.target=pc;
  TargetPolymorphWands.handleResurrectionScroll(context(40008,pc,item,pc.id));
  ok(item.count==1&&CDB.pending==null,"empty-charge wand rejected");
  System.out.println("WORLD_RECEIPT_TESTS_PASSED="+cases);
 }
}