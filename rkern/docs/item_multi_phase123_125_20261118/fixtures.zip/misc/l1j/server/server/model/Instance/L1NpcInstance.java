package l1j.server.server.model.Instance;
public class L1NpcInstance extends l1j.server.server.model.L1Character {
 public int npcId=100,maxHp=100;public int resurrectCount,occupied;public boolean cannot;
 public int getNpcId(){return npcId;}public int getMaxHp(){return maxHp;}
 public Template getNpcTemplate(){return new Template(cannot);}
 public void resurrect(int hp){this.hp=hp;dead=false;resurrectCount++;}
 public void setResurrect(boolean b){}public void occupyNpcTileNow(){occupied++;}
 public static final class Template {boolean cannot;public Template(boolean b){cannot=b;}public boolean isCantResurrect(){return cannot;}}
}