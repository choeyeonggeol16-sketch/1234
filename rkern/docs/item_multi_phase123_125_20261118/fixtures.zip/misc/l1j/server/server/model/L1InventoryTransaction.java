package l1j.server.server.model;
import l1j.server.server.model.Instance.*;
public class L1InventoryTransaction implements AutoCloseable {
 public L1ItemInstance item;public int debitCount,newCharge=-1;public Runnable fail;
 public boolean debit(L1ItemInstance i,int n){if(i.count<n)return false;item=i;debitCount=n;return true;}
 public void changeChargeCount(L1ItemInstance i,int c){if(c<0)throw new IllegalArgumentException();item=i;newCharge=c;}
 public void onFailure(Runnable cb){fail=cb;}public void close(){}
}