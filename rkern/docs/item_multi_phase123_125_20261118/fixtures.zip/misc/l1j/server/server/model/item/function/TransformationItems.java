package l1j.server.server.model.item.function;
import l1j.server.server.model.*;import l1j.server.server.model.Instance.*;
public final class TransformationItems {public static int polyCount; public static void polyAction(L1PcInstance pc,L1Character target,int id,String s){polyCount++;}}
