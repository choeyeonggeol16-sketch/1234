package l1j.server.server.model.item.function;
import l1j.server.server.model.Instance.*;
public final class CreatureItemActions {
 public static final java.util.logging.Logger ITEM_USE2_LOG=java.util.logging.Logger.getLogger("item");
 public static int barriers;public static void cancelAbsoluteBarrier(L1PcInstance p){barriers++;}
}