package l1j.server.server.model.item.function;
import l1j.server.server.model.Instance.*;
public final class ItemReceiptOperations {
 public static boolean defer=true;public static Runnable pending; public static int submissions;
 public static void UseDurableConsume(L1PcInstance p,L1ItemInstance i,Runnable done) {
  if(p.getInventory().getItem(i.id)!=i||i.count<=0)return;
  submissions++;
  pending=()->{i.count--;if(i.count==0)p.getInventory().items.remove(i.id);if(done!=null)done.run();};
  if(!defer)pending.run();
 }
}