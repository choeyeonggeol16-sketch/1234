package l1j.server.server.model;
import l1j.server.server.model.Instance.*;import java.util.*;
public final class L1World {
 public static L1World INSTANCE=new L1World();public L1Object target; public boolean crowded;
 public static L1World getInstance(){return INSTANCE;}
 public L1Object findObject(int id){return target!=null&&target.id==id?target:null;}
 public java.util.List<L1PcInstance> getVisiblePlayer(L1Character c,int n){
  if(!crowded)return java.util.List.of();L1PcInstance p=new L1PcInstance();p.dead=false;return java.util.List.of(p);
 }
}