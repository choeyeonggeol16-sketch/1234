package l1j.server.server.model.Instance;
public class L1ItemInstance {public int id,itemId,count=1,chargeCount,dirty;
 public L1ItemInstance(int id,int itemId,int charge){this.id=id;this.itemId=itemId;this.chargeCount=charge;}
 public int getId(){return id;}public int getItemId(){return itemId;}
 public int getCount(){return count;}public int getChargeCount(){return chargeCount;}
 public int getRecordingColumns(){return dirty;}
}