package l1j.server.server.model.network.core.cs.packet;
import l1j.server.server.model.*;import l1j.server.server.model.Instance.*;
public class CDB {public static Runnable pending;public static boolean defer=true;
 public static void RequestUseItem(L1PcInstance p,L1InventoryTransaction tx,Runnable done) {
 pending=()->{if(tx.debitCount>0){tx.item.count-=tx.debitCount;if(tx.item.count==0)p.inv.items.remove(tx.item.id);}
 if(tx.newCharge>=0)tx.item.chargeCount=tx.newCharge;
 if(done!=null)done.run();};if(!defer)pending.run();
 }
}