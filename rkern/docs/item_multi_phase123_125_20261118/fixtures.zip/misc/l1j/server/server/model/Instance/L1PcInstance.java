package l1j.server.server.model.Instance;
import java.util.*;
public class L1PcInstance extends l1j.server.server.model.L1Character {
 public int mapId=1,sprite=1, clanId;public Inventory inv=new Inventory();public Map map=new Map();
 public int getMapId(){return mapId;}public int getCurrentSpriteId(){return sprite;}
 public Inventory getInventory(){return inv;}public Map getMap(){return map;}
 public void setTempID(int id){}public int getClanid(){return clanId;}public void sendPackets(String s){}
 public static final class Map{public boolean allow=true;public boolean isUseResurrection(){return allow;}}
 public static final class Inventory {public java.util.Map<Integer,L1ItemInstance> items=new HashMap<>();public int saved;
  public L1ItemInstance getItem(int id){return items.get(id);}public void saveItem(L1ItemInstance i,int c){saved++;}
 }
}