package l1j.server.server.model.network.core.cs.packet;
import l1j.server.server.model.*;import l1j.server.server.model.Instance.*;
public class User{public static L1InventoryTransaction CheckAndSetPendingUseETCItem(L1PcInstance p,int k){return new L1InventoryTransaction();}}