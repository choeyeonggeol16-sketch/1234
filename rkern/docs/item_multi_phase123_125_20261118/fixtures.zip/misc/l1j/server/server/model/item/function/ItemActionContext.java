package l1j.server.server.model.item.function;
import l1j.server.server.model.Instance.*;
public class ItemActionContext {
 public L1PcInstance pc;public L1ItemInstance item;public int itemId,spellTargetId;public String text="";
 public L1PcInstance player(){return pc;}public L1ItemInstance item(){return item;}
 public int itemId(){return itemId;}public int spellTargetId(){return spellTargetId;}
 public String text(){return text;}
}