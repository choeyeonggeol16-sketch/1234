package l1j.server.server.model.Instance;
import java.util.*;
public class L1PcInstance {
 public int id=42, elfAttr; public boolean gm; public java.util.Set<Integer> skills=new HashSet<>();
 public Inventory inventory=new Inventory();
 public int getId(){return id;} public boolean isGm(){return gm;}
 public int getElfAttr(){return elfAttr;}
 public boolean isSkillMastery(int id){return skills.contains(id);}
 public void setSkillMastery(int id){skills.add(id);}
 public Inventory getInventory(){return inventory;}
 public static final class Inventory {
  public java.util.HashMap<Integer,L1ItemInstance> items=new java.util.HashMap<>();public int saved;
  public L1ItemInstance getItem(int id){return items.get(id);}
  public void saveItem(L1ItemInstance i,int col){saved++;}
 }
}