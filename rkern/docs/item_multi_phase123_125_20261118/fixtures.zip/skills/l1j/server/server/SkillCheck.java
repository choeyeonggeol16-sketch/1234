package l1j.server.server;public final class SkillCheck {
 public static final SkillCheck INSTANCE=new SkillCheck(); public int called;
 public static SkillCheck getInstance(){return INSTANCE;}
 public void AddSkill(int id,int skill){called++;}
}