package l1j.server.server.templates; public class L1Item {
 private String name; public L1Item(String s){name=s;} public String getName(){return name;}
}