package l1j.server.server.model.item.function;
import java.sql.*;import java.lang.reflect.*;
public final class FakeSql {
 public static boolean existing=false,missingCharacter=false,failInsert=false;
 public static int inserts=0;
 public static Connection connection() {
  return (Connection)Proxy.newProxyInstance(FakeSql.class.getClassLoader(),new Class<?>[]{Connection.class}, (p,m,a)->{
    if(m.getName().equals("prepareStatement")){String q=(String)a[0];return prepared(q);}
    if(m.getName().equals("close"))return null;
    return defaultVal(m.getReturnType());
  });
 }
 private static PreparedStatement prepared(String sql) {
  return (PreparedStatement)Proxy.newProxyInstance(FakeSql.class.getClassLoader(),new Class<?>[]{PreparedStatement.class},(p,m,a)->{
   if(m.getName().startsWith("set"))return null;
   if(m.getName().equals("executeQuery")) {
     boolean exists=sql.contains("FROM characters") ? !missingCharacter : existing;
     return (ResultSet)Proxy.newProxyInstance(FakeSql.class.getClassLoader(),new Class<?>[]{ResultSet.class},new InvocationHandler(){boolean first=true;
       public Object invoke(Object p, Method m,Object[] a){if(m.getName().equals("next")){if(first){first=false;return exists;}return false;}return defaultVal(m.getReturnType());}
     });
   }
   if(m.getName().equals("executeUpdate")) {if(failInsert)throw new SQLException("injected SQL failure");inserts++; return 1;}
   return defaultVal(m.getReturnType());
  });
 }
 private static Object defaultVal(Class<?> t){if(t==boolean.class)return false;if(t==int.class)return 0;if(t==long.class)return 0L;return null;}
}