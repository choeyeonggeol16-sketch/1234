package l1j.server.server.model.network.core.cs.packet;
import l1j.server.server.model.*;import l1j.server.server.model.Instance.*;
import l1j.server.server.model.item.function.FakeSql;
public final class CDB {
 public static boolean defer=false;public static Runnable pending;
 public static void RequestUseItem(L1PcInstance pc,L1InventoryTransaction tx,Runnable callback){
   Runnable apply=()->{try{tx.sql.run(FakeSql.connection());tx.debitItem.count-=tx.debited;
     if(tx.debitItem.count==0)pc.getInventory().items.remove(tx.debitItem.id); if(callback!=null)callback.run();}
     catch(Exception ex){if(tx.fail!=null)tx.fail.run();}
   };
   if(defer)pending=apply; else apply.run();
 }
}