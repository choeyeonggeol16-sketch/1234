package l1j.server.server.model.item.function;
import l1j.server.server.model.Instance.*;
import l1j.server.server.templates.*;
import l1j.server.server.datatables.SkillsTable;
import l1j.server.server.model.network.core.sc.packet.*;
import l1j.server.server.model.network.core.cs.packet.CDB;
public final class TestBooks {
 static int passed;
 static void ok(boolean b,String m){if(!b)throw new AssertionError(m);passed++;}
 static L1PcInstance player(L1ItemInstance item){L1PcInstance p=new L1PcInstance();p.inventory.items.put(item.id,item);return p;}
 static void reset(){FakeSql.existing=false;FakeSql.missingCharacter=false;FakeSql.failInsert=false;FakeSql.inserts=0;SkillsTable.INSTANCE=new SkillsTable();CDB.pending=null;CDB.defer=false;SC_AddSkill.fail=false;SC_AddSkill.sendCount=0;SC_SkillSound.notifyCount=0;SC_SkillSound.broadcastCount=0;}
 public static void main(String[] args){
  reset();var sk=new L1Skills(97,197,1,"Dark Blast");SkillsTable.INSTANCE.byId.put(97,sk);var it=new L1ItemInstance(1,401,"흑정령의 수정 (Dark Blast)");var pc=player(it);
  CDB.defer=true;SkillBookLearning.learn(pc,it,SkillBookLearning.Kind.DARK_ELF);
  ok(pc.skills.isEmpty() && it.count==1,"precommit state unchanged");ok(CDB.pending!=null,"SQL admitted");CDB.pending.run();
  ok(pc.skills.contains(197) && it.count==0,"skill/consumption committed");ok(FakeSql.inserts==1,"SQL inserted");ok(SC_AddSkill.sendCount==1 && SC_SkillSound.notifyCount==1,"client notified");
  reset();SkillsTable.INSTANCE.byId.put(97,sk);it=new L1ItemInstance(2,401,"흑정령의 수정 (Dark Blast)");pc=player(it);FakeSql.failInsert=true;
  SkillBookLearning.learn(pc,it,SkillBookLearning.Kind.DARK_ELF);ok(it.count==1 && pc.skills.isEmpty(),"SQL rollback");
  reset();SkillsTable.INSTANCE.byId.put(97,sk);it=new L1ItemInstance(3,401,"흑정령의 수정 (Dark Blast)");pc=player(it);FakeSql.existing=true;
  SkillBookLearning.learn(pc,it,SkillBookLearning.Kind.DARK_ELF);ok(it.count==1 && pc.skills.isEmpty(),"duplicate rollback");
  reset();SkillsTable.INSTANCE.byId.put(97,sk);it=new L1ItemInstance(4,401,"흑정령의 수정 (Dark Blast)");pc=player(it);SC_AddSkill.fail=true;
  SkillBookLearning.learn(pc,it,SkillBookLearning.Kind.DARK_ELF);ok(it.count==0 && pc.skills.contains(197),"packet failure preserves economic commit");ok(SC_SkillSound.notifyCount==1,"sound independently attempted");
  reset();var spell=new L1Skills(1,1,1,"Magic Arrow");SkillsTable.INSTANCE.byId.put(1,spell);it=new L1ItemInstance(5,45000,"마법서 (Magic Arrow)");pc=player(it);
  GeneralSpellbookLearning.SpellBook(pc,it,true);ok(pc.skills.contains(1)&&it.count==0,"general book commits even with missing templates");
  reset();it=new L1ItemInstance(6,45000,"마법서 (Missing Spell)");pc=player(it);
  GeneralSpellbookLearning.SpellBook(pc,it,true);ok(pc.skills.isEmpty()&&it.count==1&&CDB.pending==null,"unknown skill not consumed");
  reset();sk=new L1Skills(181,181,8,"Warrior Strike");SkillsTable.INSTANCE.byItem.put(9101,sk);it=new L1ItemInstance(7,9101,"전사 기술서");pc=player(it);
  WarriorSkillBookItems.전사스킬(pc,it,false);ok(pc.skills.contains(181)&&it.count==0,"warrior book commit");
  reset();it=new L1ItemInstance(8,9102,"없는 스킬북");pc=player(it);
  WarriorSkillBookItems.전사스킬(pc,it,false);ok(pc.skills.isEmpty()&&it.count==1,"missing warrior skill not consumed");
  reset();sk=new L1Skills(97,197,1,"Dark Blast");SkillsTable.INSTANCE.byId.put(97,sk);it=new L1ItemInstance(9,401,"흑정령의 수정 (Dark Blast)");it.recordingColumns=3;pc=player(it);
  SkillBookLearning.learn(pc,it,SkillBookLearning.Kind.DARK_ELF);ok(pc.inventory.saved==1,"dirty book preflush");
  System.out.println("SKILL_RECEIPT_TESTS_PASSED="+passed);
 }
}