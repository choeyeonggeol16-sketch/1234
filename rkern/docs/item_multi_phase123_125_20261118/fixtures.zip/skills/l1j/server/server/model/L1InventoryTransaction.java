package l1j.server.server.model;
import java.sql.*;
import l1j.server.server.model.Instance.*;
import l1j.server.server.model.item.function.FakeSql;
public class L1InventoryTransaction implements AutoCloseable {
 @FunctionalInterface public interface Mutation{void run(Connection c) throws SQLException;}
 public Mutation sql;public Runnable fail;public L1ItemInstance debitItem;public int debited;
 public boolean debit(L1ItemInstance i,int count){if(i.count<count)return false;debitItem=i;debited=count;return true;}
 public void requireTables(String... tbls){}
 public void sql(Mutation mutation){sql=mutation;}
 public void onFailure(Runnable callback){fail=callback;}
 public void close(){}
}