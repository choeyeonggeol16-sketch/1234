package l1j.server.server.model.Instance;
public class L1ItemInstance {
  public int id, itemId, count=1, recordingColumns;
  public l1j.server.server.templates.L1Item def;
  public int getId(){return id;} public int getItemId(){return itemId;}
  public int getCount(){return count;}
  public int getRecordingColumns(){return recordingColumns;}
  public l1j.server.server.templates.L1Item getItem(){return def;}
  public L1ItemInstance(int id, int itemId, String name){this.id=id;this.itemId=itemId;this.def=new l1j.server.server.templates.L1Item(name);}
}