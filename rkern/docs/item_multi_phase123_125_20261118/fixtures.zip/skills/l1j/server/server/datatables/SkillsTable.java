package l1j.server.server.datatables;
import java.util.*;
import l1j.server.server.templates.L1Skills;
public class SkillsTable {
 public static SkillsTable INSTANCE=new SkillsTable();
 public final Map<Integer,L1Skills> byId=new HashMap<>(),byItem=new HashMap<>();
 public static SkillsTable getInstance(){return INSTANCE;}
 public L1Skills getTemplate(int id){return byId.get(id);}
 public L1Skills getTemplateByItem(int id){return byItem.get(id);}
}