package l1j.server.server.templates;public class L1Skills {
 public int id,skillId,skillLevel,attr; public String name;
 public L1Skills(int id,int sid,int level,String name){this.id=id;this.skillId=sid;this.skillLevel=level;this.name=name;}
 public String getName(){return name;} public int getId(){return id;}
 public int getSkillId(){return skillId;} public int getSkillLevel(){return skillLevel;}
 public int getAttr(){return attr;}
}