package l1j.server.server.model.network.core.cs.packet;
import l1j.server.server.model.*;import l1j.server.server.model.Instance.*;
public final class User {public static L1InventoryTransaction CheckAndSetPendingUseETCItem(L1PcInstance pc,int key){return new L1InventoryTransaction();}}