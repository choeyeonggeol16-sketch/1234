@echo off
color 0F
cd /d "%~dp0"
java -server -Xms256m -Xmx26g -XX:+UseZGC -XX:+ZGenerational -Dcom.sun.management.jmxremote -cp "l1jserver.jar;lib\xmlapi;lib\*" manager.SJManager
pause
