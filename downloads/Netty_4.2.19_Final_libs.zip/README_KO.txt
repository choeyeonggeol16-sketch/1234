Netty 4.2.19.Final 라이브러리 묶음

원본 Maven JAR 다섯 개를 수정 없이 포함합니다. lib/network-dependencies.json에 공식 URL과 SHA-256이 있습니다.

1. ZIP을 서버 폴더에 풀어서 lib 폴더에 JAR 다섯 개가 들어가게 합니다.
2. lib에 다른 버전의 Netty 또는 netty-all JAR이 있으면 버전을 정리합니다.
3. 기존 DB/Javolution/Gson/SWT/JAXB 라이브러리를 함께 유지합니다. lib\*는 lib 바로 아래의 모든 .jar를 읽으며 하위 폴더의 JAR까지 재귀적으로 읽지는 않습니다.
4. 수정된 서버 소스를 JDK 21로 빌드한 l1jserver.jar와 config/network42.properties도 적용해야 합니다.
5. 실행 예제는 64비트 JDK 21 기준입니다. JAVA_HOME 설정만으로 java 명령이 바뀌지는 않으므로 java -version도 확인하세요.

시작 배치 예제:

@echo off
color 0F
cd /d "%~dp0"
java -server -Xms256m -Xmx26g -XX:+UseZGC -XX:+ZGenerational -Dcom.sun.management.jmxremote -cp "l1jserver.jar;lib\xmlapi;lib\*" manager.SJManager
pause
