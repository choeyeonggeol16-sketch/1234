#!/usr/bin/env python3
"""Real sprite/action/frame/enum classes; decorator and actor boundaries are doubles.
Use a Java instrumentation agent for actual live action-array sizes (not guessed layout).
"""
from pathlib import Path
import argparse,re,subprocess,tempfile,zipfile
p=argparse.ArgumentParser();p.add_argument('--baseline-root',type=Path);args=p.parse_args()
root=Path(__file__).resolve().parents[2];source=(args.baseline_root or root)/'src/l1j/server'
def nested(path,name):
 text=(source/path).read_text();text=re.sub(r'(?m)^(package|import) [^\n]+\n','',text)
 return text.replace('public class '+name,'static class '+name).replace('public enum '+name,'enum '+name)
java=r'''
import java.sql.*;import java.util.*;import java.util.concurrent.*;import java.lang.reflect.*;
public class SpriteContract {
 static int passed,failed;static volatile Object sink;
 static void check(boolean b,String s){if(!b)throw new AssertionError(s);}
 static void run(String s,Runnable r){try{r.run();passed++;System.out.println("PASS "+s);}catch(Throwable e){failed++;System.out.println("FAIL "+s+": "+e);}}
 static class L1Character {double factor=1.0;}
 static class L1PcInstance extends L1Character {int level,sprite;int getLevel(){return level;}int getCurrentSpriteId(){return sprite;}}
 interface ActionIntervalDecorator<T> {double decoration(T c,double interval);}
 static class ActionIntervalDecoratorFactory {
  static final ActionIntervalDecorator<L1Character> CHA_WALK_DECORATOR=(c,i)->i*c.factor*2,CHA_ATT_DECORATOR=(c,i)->i*c.factor*3,NULL_DECORATOR=(c,i)->i;
  static final ActionIntervalDecorator<L1PcInstance> PC_WALK_DECORATOR=(c,i)->i*c.factor*5,PC_ATT_DECORATOR=(c,i)->i*c.factor*7;
 }
 static class SpriteInformationLoader {static int levelToIndex(int level,int spr){return Math.floorMod(level,3);}}
'''+''.join(nested(Path(path),name) for path,name in [('MJ3SEx/EActionConstruct.java','EActionConstruct'),('MJ3SEx/EActionCodes.java','EActionCodes'),('MJTemplate/Frame/MJFrameElement.java','MJFrameElement'),('MJ3SEx/ActionInformation.java','ActionInformation'),('MJ3SEx/SpriteInformation.java','SpriteInformation')])+r'''
 static SpriteInformation sprite(int id){
  ResultSet rs=(ResultSet)Proxy.newProxyInstance(SpriteContract.class.getClassLoader(),new Class<?>[]{ResultSet.class},(p,m,a)->switch(m.getName()){case "getInt"->switch((String)a[0]){case "spr_id"->id;case "width"->32;case "height"->48;case "action_count"->3;default->0;};default->throw new UnsupportedOperationException(m.getName());});
  try{return SpriteInformation.create(rs);}catch(SQLException e){throw new RuntimeException(e);}
 }
 static ActionInformation[] table(SpriteInformation s){try{Field f=SpriteInformation.class.getDeclaredField("actions");f.setAccessible(true);return (ActionInformation[])f.get(s);}catch(Exception e){throw new RuntimeException(e);}}
 static void exact(double a,double b){check(Double.doubleToLongBits(a)==Double.doubleToLongBits(b),"frame changed: "+a+" / "+b);}
 static EActionCodes remap(int spr,EActionCodes code){if(spr==12015||spr==5641||spr==11685||spr==14491){if(code.is_walk())return EActionCodes.walk;if(code.is_attack())return EActionCodes.attack;if(code.is_damage())return EActionCodes.damage;if(code.is_breath())return EActionCodes.breath;}return code;}
 public static void main(String[] args)throws Exception {
  run("metadata, empty/invalid IDs and ignored out-of-range writes",()->{var s=sprite(1120);check(s.getSpriteId()==1120&&s.getWidth()==32&&s.getHeight()==48&&s.getNumOfAction()==3,"metadata");for(int i=-2;i<258;i++)check(s.get(i)==null,"empty lookup");s.put(ActionInformation.create(-1,1,24));s.put(ActionInformation.create(256,1,24));check(s.get(-1)==null&&s.get(256)==null,"invalid ID accepted");});
  run("all 256 IDs, reverse insertion, holes and replacement identity",()->{var s=sprite(1120);ActionInformation[] expected=new ActionInformation[256];for(int i=255;i>=0;i--){expected[i]=ActionInformation.create(i,i+1,24);s.put(expected[i]);}for(int i=0;i<256;i++)check(s.get(i)==expected[i],"ID moved: "+i);var replacement=ActionInformation.create(8,100,20);s.put(replacement);check(s.get(8)==replacement,"replacement lost");s=sprite(1120);s.put(replacement);check(s.get(0)==null&&s.get(7)==null&&s.get(8)==replacement&&s.get(255)==null,"sparse holes");});
  run("all real enum default frame amounts and decorator routing",()->{var s=sprite(1120);var c=new L1Character();c.factor=1.25;Map<Integer,Double> frames=new HashMap<>();for(var code:EActionCodes.values()){double raw=frames.computeIfAbsent(code.toInt(),k->MJFrameElement.fromRate(code.getAmount(),24).getFramePerSeocnd());double expected=code.decoration(c,raw);exact(s.getInterval(c,code),expected);exact(s.getInterval(c,code.toInt()),EActionCodes.fromInt(code.toInt()).decoration(c,raw));exact(s.get(code.toInt()).getFramePerSecond(),raw);}});
  run("loaded frame rates and every special polymorph remap/level",()->{for(int id:new int[]{1120,12015,5641,11685,14491}){var s=sprite(id);var pc=new L1PcInstance();pc.sprite=id;pc.factor=1.3;for(var code:EActionCodes.values())s.put(ActionInformation.create(code.toInt(),code.toInt()+2,30));for(var code:EActionCodes.values())s.registerUserActions(code.toInt(),new Double[]{10.0,20.0,30.0});for(int level=0;level<6;level++){pc.level=level;for(var code:EActionCodes.values()){var mapped=remap(id,code);double expected=mapped.decorationForPc(pc,(mapped.toInt()+2)*(10.0*(level%3+1)));exact(s.getInterval(pc,code),expected);exact(s.getInterval(pc,code.toInt()),expected);}}}});
  run("user rates stay sprite-specific and retain existing custom ID 255",()->{var a=sprite(1);var b=sprite(2);a.registerUserActions(0,new Double[]{2.0,3.0,4.0});b.getInterval(new L1Character(),EActionCodes.walk);check(a.get(0)!=b.get(0)&&a.get(0).isUserFrames()&&!b.get(0).isUserFrames(),"shared fallback contaminated another sprite");var custom=ActionInformation.create(255,3,24);a.put(custom);a.registerUserActions(255,new Double[]{9.0,10.0,11.0});check(a.get(255)==custom,"custom loaded ID replaced");exact(custom.getFramePerSecond(0),27.0);});
  run("concurrent table growth/default lookup keeps all published entries",()->{var s=sprite(1120);var errors=new java.util.concurrent.atomic.AtomicReference<Throwable>();List<Thread> ts=new ArrayList<>();for(int n=0;n<4;n++){final int worker=n;var t=new Thread(()->{try{for(int i=worker;i<256;i+=4)s.put(ActionInformation.create(i,i+2,24));for(int j=0;j<10000;j++)s.get(j&255);}catch(Throwable e){errors.set(e);}});ts.add(t);t.start();}for(var t:ts)try{t.join(5000);check(!t.isAlive(),"writer hung");}catch(Exception e){throw new RuntimeException(e);}if(errors.get()!=null)throw new AssertionError(errors.get());for(int i=0;i<256;i++)check(s.get(i)!=null&&s.get(i).getActionId()==i,"lost entry "+i);});
  run("dispose contract remains unchanged",()->{var s=sprite(1);s.dispose();boolean refused=false;try{s.get(0);}catch(NullPointerException e){refused=true;}check(refused,"disposed sprite revived");});
  run("measured retained action-array memory for empty/low/high IDs",()->{
   boolean compact=true;for(int high:new int[]{-1,8,99,255}){Set<Object> arrays=Collections.newSetFromMap(new IdentityHashMap<>());long bytes=0;for(int n=0;n<10000;n++){var s=sprite(n+1);if(high>=0){s.put(ActionInformation.create(0,1,24));s.put(ActionInformation.create(1,2,24));s.put(ActionInformation.create(high,3,24));}Object a=table(s);if(arrays.add(a))bytes+=SizeAgent.instrumentation.getObjectSize(a);}System.out.println("ARRAY_MEMORY sprites=10000 highest_id="+high+" unique_arrays="+arrays.size()+" bytes="+bytes);if(high==-1)compact&=arrays.size()==1&&bytes<100;if(high==8)compact&=bytes<=560000;}
   check(compact,"empty/low-ID sprites still reserve private 256-entry tables");
  });
  var s=sprite(1);for(int i=0;i<100;i++)s.put(ActionInformation.create(i,1,24));for(int i=0;i<1000000;i++)sink=s.get(i%100);
  var mx=(com.sun.management.ThreadMXBean)java.lang.management.ManagementFactory.getThreadMXBean();long tid=Thread.currentThread().threadId();long before=mx.getThreadAllocatedBytes(tid),start=System.nanoTime();for(int i=0;i<1000000;i++)sink=s.get(i%100);long ns=System.nanoTime()-start,allocated=mx.getThreadAllocatedBytes(tid)-before;System.out.println("LOOKUP calls=1000000 allocated_bytes="+allocated+" ns_per_call="+(ns/1000000.0));check(allocated<4096,"lookup allocates per call");
  System.out.println("RESULT passed="+passed+" failed="+failed);if(failed!=0)throw new AssertionError("sprite regressions failed="+failed);
 }
}
'''
agent='public class SizeAgent {public static java.lang.instrument.Instrumentation instrumentation;public static void premain(String s,java.lang.instrument.Instrumentation i){instrumentation=i;}}'
with tempfile.TemporaryDirectory() as td:
 d=Path(td);(d/'SpriteContract.java').write_text(java);(d/'SizeAgent.java').write_text(agent)
 subprocess.run(['java','-m','jdk.compiler/com.sun.tools.javac.Main','-source','21','-target','21','-encoding','UTF-8','-d',td,str(d/'SpriteContract.java'),str(d/'SizeAgent.java')],check=True)
 with zipfile.ZipFile(d/'agent.jar','w') as z:z.writestr('META-INF/MANIFEST.MF','Manifest-Version: 1.0\nPremain-Class: SizeAgent\n\n');z.write(d/'SizeAgent.class','SizeAgent.class')
 subprocess.run(['java','-javaagent:'+str(d/'agent.jar'),'-ea','-cp',td,'SpriteContract'],check=True,timeout=60)
