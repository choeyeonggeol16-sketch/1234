package l1j.server.server.model.character.autohunt;

/** Bounded, lazily allocated state owned by one auto-hunt character.
 * Distinguishes new movement from standing still or short tile loops, and
 * prevents recently blocked targets from alternating on every wheel tick.
 * No actor references, timers, threads or global actor-ID hash slots.
 */
public final class AutoHuntChaseState {
    private static final int SIZE = 8;
    private final long[] positions = new long[SIZE];
    private final long[] blockedKeys = new long[SIZE];
    private final long[] blockedUntil = new long[SIZE];
    private int positionCount, positionCursor, blockedCursor;
    private int targetId, mapId;
    private long progressedAt, nextAlternativeAt, nextAttackableAt, nextSelectionAt;
    private long nextRetargetAt;

    public boolean hasStalled(int map, int target, long now, long delay) {
        return positionCount != 0 && mapId == map && targetId == target
                && now >= progressedAt && now - progressedAt >= delay;
    }

    public boolean canRetarget(long now) {
        return now >= nextRetargetAt;
    }

    public void didRetarget(long now) {
        nextRetargetAt = now + 1_000L;
    }

    public boolean observe(int map, int target, int x, int y, long now, long timeout) {
        if (targetId != target || mapId != map || positionCount == 0) {
            clearProgress();
            targetId = target;
            mapId = map;
            progressedAt = now;
        }
        long position = ((long) x << 32) ^ (y & 0xffffffffL);
        boolean visited = false;
        for (int i = 0; i < positionCount; i++) {
            if (positions[i] == position) { visited = true; break; }
        }
        if (!visited) {
            positions[positionCursor] = position;
            positionCursor = (positionCursor + 1) & (SIZE - 1);
            if (positionCount < SIZE) positionCount++;
            progressedAt = now;
        }
        if (now < progressedAt) progressedAt = now;
        return now - progressedAt < timeout;
    }

    public void clearProgress() {
        targetId = 0;
        positionCount = positionCursor = 0;
        progressedAt = 0L;
    }

    private static long key(int map, int id) {
        return ((long) map << 32) ^ (id & 0xffffffffL);
    }

    public void defer(int map, int id, long until) {
        long key = key(map, id);
        for (int i = 0; i < SIZE; i++) {
            if (blockedUntil[i] != 0L && blockedKeys[i] == key) {
                blockedUntil[i] = until;
                return;
            }
        }
        blockedKeys[blockedCursor] = key;
        blockedUntil[blockedCursor] = until;
        blockedCursor = (blockedCursor + 1) & (SIZE - 1);
    }

    public boolean isDeferred(int map, int id, long now) {
        long key = key(map, id);
        for (int i = 0; i < SIZE; i++) {
            if (blockedKeys[i] == key && now < blockedUntil[i]) return true;
        }
        return false;
    }

    public void allow(int map, int id) {
        long key = key(map, id);
        for (int i = 0; i < SIZE; i++) if (blockedKeys[i] == key) blockedUntil[i] = 0L;
    }

    public boolean reviewAlternatives(long now) {
        if (now < nextAlternativeAt) return false;
        nextAlternativeAt = now + 300L;
        return true;
    }

    public boolean reviewAttackable(long now) {
        if (now < nextAttackableAt) return false;
        nextAttackableAt = now + 300L;
        return true;
    }

    public boolean reviewSelection(long now) {
        if (now < nextSelectionAt) return false;
        nextSelectionAt = now + 300L;
        return true;
    }
}
