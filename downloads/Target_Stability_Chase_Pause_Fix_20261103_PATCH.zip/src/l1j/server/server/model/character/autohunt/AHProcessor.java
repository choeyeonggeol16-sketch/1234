package l1j.server.server.model.character.autohunt;

import java.util.List;
import l1j.server.Config;
import l1j.server.MJ3SEx.EActionCodes;
import l1j.server.server.ActionCodes;
import l1j.server.server.model.L1Character;
import l1j.server.server.model.L1GroundInventory;
import l1j.server.server.model.L1Inventory;
import l1j.server.server.model.L1Object;
import l1j.server.server.model.L1World;
import l1j.server.server.model.Instance.L1ItemInstance;
import l1j.server.server.model.Instance.L1MonsterInstance;
import l1j.server.server.model.Instance.L1PcInstance;
import l1j.server.server.model.character.autohunt.ai.AHSetMoving;
import l1j.server.server.model.character.autohunt.ai.action.AHController;
import l1j.server.server.model.character.skill.L1SkillId;
import l1j.server.server.model.network.core.sc.packet.SC_AttackStatus;
import l1j.server.server.utils.CommonUtil;

public class AHProcessor {

    private static final AHProcessor instance = new AHProcessor();

    public static AHProcessor getInstance() {
        return instance;
    }

    public static final int PICKUP_RANGE = 10;
    private static final long THREAT_SCAN_INTERVAL_MS = 300L;
    private static final int THREAT_SCAN_RANGE = 8;

    /*
     * 타겟 검색은 화면 범위까지 보되, 텔 가능한 맵에서는
     * 실제 공격 사거리 + 일정 시간 안에 접근 가능한 거리까지만 추격한다.
     * 고정 타일 수를 쓰지 않아 근접/활/법사 모두 같은 규칙을 사용한다.
     */
    private static final int TARGET_SCAN_RANGE = 20;
    private static final long TELEPORT_APPROACH_BUDGET_MS = 1_200L;
    private static final long TELEPORT_HUNT_DELAY_MS = 3_000L;

    /*
     * 자동사냥 coverage roaming.
     *
     * PathNodeWorld가 section lookup에 사용하는 것과 같은 16x16 단위로
     * 맵을 sector화한다. 현재 위치에서 1~2 sector 떨어진 frontier를 고르고,
     * 최근 방문 8개 sector는 우선 후보에서 제외한다.
     *
     * Roam은 "어디로 갈지"만 결정하고 실제 경로는 PcPathFinder가 담당한다.
     */
    private static final int ROAM_SECTOR_SHIFT = 4; // 16 tiles
    private static final int ROAM_FRONTIER_RADIUS = 2;
    private static final int ROAM_HISTORY_SIZE = 8;

    /* autoRoamState bit layout */
    private static final int ROAM_HISTORY_CURSOR_MASK = 0x07;
    private static final int ROAM_HISTORY_COUNT_SHIFT = 4;
    private static final int ROAM_HISTORY_COUNT_MASK = 0x0F;
    private static final int ROAM_DIR_SHIFT = 8;
    private static final int ROAM_DIR_MASK = 0x0F;

    /* sector 안에서 목적지 후보로 검사할 9개 interior point. */
    private static final byte[] ROAM_POINT_OX = { 8, 4, 12, 4, 12, 8, 12, 8, 4 };
    private static final byte[] ROAM_POINT_OY = { 8, 4, 4, 12, 12, 4, 8, 12, 8 };

    public void getSource(L1PcInstance pc) {
        if (pc == null) {
            return;
        }

        final long now = System.currentTimeMillis();

        if (now < pc.getAutoDelayTime()) {
            return;
        }

        if (pc.isDead()) {
            AHExecutor.getInstance().restart(pc);
            return;
        }

        if (pc.getInventory().getWeight100() > 95) {
            AHUseItem.getInstance().toUseScroll(pc, 301066);
            AHExecutor.getInstance().sendautomsg(pc, "아이템 무게가 " + 95 + "가 넘어 자동사냥을 종료합니다.");
            return;
        }

        /*
         * 법사 전투 중 실제 주변 몬스터 수 캐시.
         * AutoHuntSkill은 autoTargetList가 아니라 이 값을 사용한다.
         */
        updateNearbyMobCount(pc, now);

        AHController.tick(pc);
    }

    /**
     * 법사 이뮨 판단용 실제 주변 몬스터 수 갱신.
     *
     * - ATTACK 상태인 법사만 스캔
     * - 250ms 캐시
     * - 살아있고 visible 상태인 몬스터만 카운트
     * - 필요한 건 "임계치 도달 여부"이므로 Config 값에 도달하면 즉시 중단
     */
    private void updateNearbyMobCount(final L1PcInstance pc, final long now) {
        if (!pc.isWizard() || pc.getAutoStatus() != AHController.ACTION_ATTACK) {
            if (pc.getAutoNearbyMobCount() != 0) {
                pc.setAutoNearbyMobCount(0);
            }

            /*
             * 다음 ATTACK 진입 시 첫 tick에서 바로 스캔되게 한다.
             */
            if (pc.getAutoThreatScanTime() != 0L) {
                pc.setAutoThreatScanTime(0L);
            }
            return;
        }

        if (now < pc.getAutoThreatScanTime()) {
            return;
        }

        pc.setAutoThreatScanTime(now + THREAT_SCAN_INTERVAL_MS);

        final int required = Config.WIZ_IMMUNE_MOB_COUNT;

        if (required <= 0) {
            pc.setAutoNearbyMobCount(0);
            return;
        }

        final int myX = pc.getX();
        final int myY = pc.getY();
        final int mapId = pc.getMapId();

        int count = 0;

        final List<L1Object> nearby = L1World.getInstance().getClusterGrid().queryNearbyReusable(pc, THREAT_SCAN_RANGE);

        for (L1Object obj : nearby) {
            if (!(obj instanceof L1MonsterInstance)) {
                continue;
            }
            final L1MonsterInstance mon = (L1MonsterInstance) obj;
            
            if (!pc.glanceCheck(mon.getX(), mon.getY())) continue;

            if (mon.isDead() || mon.getCurrentHp() <= 0 || mon.getHiddenStatus() >= 1 || mon.getMapId() != mapId) {
                continue;
            }

            final int dist = getDistance(myX, myY, mon.getX(), mon.getY());

            if (dist > THREAT_SCAN_RANGE) {
                continue;
            }

            count++;
            if (count >= required) {
                break;
            }
        }

        pc.setAutoNearbyMobCount(count);
    }

    public void toReturnScroll(L1PcInstance pc) {
        if (pc.getCurrentHp() * 100 / pc.getMaxHp() < Config.AUTO_HUNT_RETURN_HP_PERCENT) {
            if (pc.getMapId() == 4) {
                return;
            }
            AHUseItem.getInstance().returnScroll(pc);
        }
    }

    /** 마을 HP/MP 통합 회복 및 정비 로직 */
    public void handleRegenState(L1PcInstance pc) {
        // 회복 도중에도 혹시 소모품이 비었는지 최우선 체크
        if (isNeedSupplies(pc)) {
            AHController.set(pc, AHController.ACTION_MOVE_SHOP);
            return;
        }

        int hpPercent = pc.getCurrentHp() * 100 / pc.getMaxHp();
        int mpPercent = pc.getCurrentMp() * 100 / pc.getMaxMp();

        boolean canReturn = false;

        // 클래스 판별에 따른 사냥터 복귀 조건 분기
        if (pc.isWizard() || pc.isElf()) {
            // 법사, 요정: HP와 MP 모두 90% 이상 찼을 때만 복귀
            if (hpPercent >= Config.AUTO_HUNT_WIZ_ELF_HP_RETURN && mpPercent >= Config.AUTO_HUNT_WIZ_ELF_MP_RETURN) {
                canReturn = true;
            }
        } else {
            // 기사, 전사, 군주 등 근접/기타 클래스: 마나 볼 필요 없이 HP만 0% 이상이면 즉시 복귀!
            if (hpPercent >= Config.AUTO_HUNT_OTHER_HP_RETURN) {
                canReturn = true;
            }
        }

        // 복귀 조건 만족 시 최종 검사 후 사냥터로 쏴주기
        if (canReturn) {
            if (hpPercent < 50) {
                pc.setAutoDelayTime(System.currentTimeMillis() + 1000);
                return;
            }
            AHReturnManager.getInstance().returnToHuntingGround(pc);
            return;
        }

        // --- 아래부터는 마나가 필요한 클래스들만의 MP 채우기 행동 ---
        if (pc.isWizard()) {
            if (!pc.hasSkillEffect(L1SkillId.MEDITATION)) {
                if (System.currentTimeMillis() >= pc.getAutoSkillDelay()) {
                    AHUseSkill.getInstance().executeSkill(pc, L1SkillId.MEDITATION, pc);
                }
            }
        } else if (pc.isElf()) {
            if (hpPercent >= 10 && mpPercent <= 95) {
                if (System.currentTimeMillis() >= pc.getAutoSkillDelay()) {
                    AHUseSkill.getInstance().executeSkill(pc, L1SkillId.BLOODY_SOUL, pc);
                }
            }
        }

        // 회복 대기 중 딜레이 부여
        pc.setAutoDelayTime(System.currentTimeMillis() + 1000);
    }

    public boolean isNeedSupplies(L1PcInstance pc) {
        int minScrollsToStart = 10;
        L1Inventory inv = pc.getInventory();
        if (!inv.hasItemDirect(pc.getAutoPotion(), minScrollsToStart)) return true;
        if (canUseTeleport(pc) && !inv.hasItemDirect(40100, minScrollsToStart)) return true;
        return false;
    }

    public boolean toPickupItem(L1PcInstance pc, int searchRange) {
        if (pc == null) {
            return false;
        }

        L1ItemInstance targetItem = pc.getAutoTargetItem();

        if (targetItem == null || !canLoot(pc, targetItem) || targetItem.getMapId() != pc.getMapId()
                || pc.getLocation().getTileDistance(targetItem.getLocation()) > searchRange) {
            pc.setAutoTargetItem(null);
            targetItem = searchNearestItem(pc, searchRange);
        }

        if (targetItem == null) {
            return false;
        }

        /*
         * target item 선택만 한다.
         * 상태 전환은 ThinkAction -> PcController가 담당한다.
         */
        pc.setAutoTeleportTime(System.currentTimeMillis());
        return true;
    }

    private L1ItemInstance searchNearestItem(L1PcInstance pc, int range) {
        L1ItemInstance nearest = null;
        double bestDist = Double.MAX_VALUE;
        final List<L1Object> nearby = L1World.getInstance().getClusterGrid().queryNearbyReusable(pc, range);

        for (L1Object obj : nearby) {
            if (obj instanceof L1GroundInventory) {
                L1GroundInventory gInv = (L1GroundInventory) obj;
                for (L1ItemInstance item : gInv.getItems()) {
                    if (item == null || !canLoot(pc, item)) continue;
                    final double dist = pc.getLocation().getTileDistance(item.getLocation());
                    if (dist > range || dist >= bestDist) continue;
                    if (pc.getInventory().checkAddItem(item, item.getCount()) != L1Inventory.OK) continue;
                    if (!pc.glanceCheck(item.getX(), item.getY())) continue;
                    bestDist = dist;
                    nearest = item;
                }
            } else if (obj instanceof L1ItemInstance) {
                final L1ItemInstance item = (L1ItemInstance) obj;
                if (!canLoot(pc, item)) continue;
                final double dist = pc.getLocation().getTileDistance(item.getLocation());
                if (dist > range || dist >= bestDist) continue;
                if (pc.getInventory().checkAddItem(item, item.getCount()) != L1Inventory.OK) continue;
                if (!pc.glanceCheck(item.getX(), item.getY())) continue;
                bestDist = dist;
                nearest = item;
            }
        }

        if (nearest != null) {
            pc.setAutoTargetItem(nearest);
        }
        return nearest;
    }

    public void pickupProcess(L1PcInstance pc, L1ItemInstance targetItem) {
        if (pc == null) {
            return;
        }

        if (targetItem == null || !canLoot(pc, targetItem)) {
            resetPickupStatus(pc);
            return;
        }

        final L1Inventory groundInv = L1World.getInstance().findGroundInventory(targetItem.getX(), targetItem.getY(), targetItem.getMapId());
        final L1ItemInstance item = groundInv != null ? groundInv.getItem(targetItem.getId()) : null;

        if (item != null) {
            groundInv.tradeItem(item, item.getCount(), pc.getInventory());
            SC_AttackStatus.send(pc, targetItem.getId(), ActionCodes.ACTION_Pickup);
            pc.setAutoDropTime(System.currentTimeMillis());
        }

        resetPickupStatus(pc);
    }

    /**
     * ATTACK action의 실제 공격 처리만 담당한다.
     *
     * 사거리 밖으로 벗어나면 여기서 이동하지 않고
     * PcMoveToTargetAction으로 상태만 전환한다.
     */
    public byte toAttackMonster(final L1PcInstance pc) {
        if (pc == null) {
            return AHController.RESULT_INVALID;
        }

        try {
            final L1Character target = pc.getAutoTarget();

            if (target == null) {
                return AHController.RESULT_INVALID;
            }

            if (!validateAutoCombatTarget(pc, target)) {
                return AHController.RESULT_DONE;
            }

            /*
             * 원본 일시 행동불가 semantics.
             */
            if (CommonUtil.isNonAction(pc)) {
                return AHController.RESULT_RUNNING;
            }

            pc.setAutoTeleportTime(
                    System.currentTimeMillis());

            /*
             * ATTACK에서는 절대 이동하지 않는다.
             * 사거리/LOS가 깨졌으면 MOVE_TO_TARGET으로 hand-off만 한다.
             */
            if (!isAutoAttackPosition(pc, target)) {
                AHController.moveToTarget(pc);
                return AHController.RESULT_RUNNING;
            }

            if (!isAutoAttackTime(pc)) {
                return AHController.RESULT_RUNNING;
            }

            return toAttack(pc)
                    ? AHController.RESULT_RUNNING
                    : AHController.RESULT_INVALID;

        } catch (Exception e) {
            tagertClear(pc);
            return AHController.RESULT_INVALID;
        }
    }

    /**
     * THINK가 combat target을 잡았을 때 최초 action을 고른다.
     * 이미 공격 위치면 ATTACK, 아니면 MOVE_TO_TARGET.
     */
    public void switchToAttack(final L1PcInstance pc) {
        if (pc == null) {
            return;
        }

        final L1Character target =
                pc.getAutoTarget();

        if (target == null) {
            return;
        }

        if (isAutoAttackPosition(pc, target)) {
            AHController.attack(pc);
        } else {
            AHController.moveToTarget(pc);
        }

        pc.setAutoTeleportTime(
                System.currentTimeMillis());
    }

    /**
     * MOVE_TO_TARGET / ATTACK 공통 target validation.
     * 이동 실패는 여기서 target을 버리지 않는다.
     * target 자체가 무효일 때만 clear한다.
     */
    public boolean validateAutoCombatTarget(
            final L1PcInstance pc,
            final L1Character target) {

        if (pc == null || target == null) {
            return false;
        }

        final boolean hiddenMonster =
                target instanceof L1MonsterInstance
                && ((L1MonsterInstance) target).getHiddenStatus() >= 1;

        if (hiddenMonster
                || target.isDead()
                || target.getCurrentHp() <= 0
                || target.getMapId() != pc.getMapId()) {

            if (hiddenMonster) {
                pc.setAutoIgnoreTarget(target.getId());
                pc.setAutoIgnoreTime(
                        System.currentTimeMillis() + 30000L);
            }

            tagertClear(pc);
            return false;
        }

        if (!isAttack(pc, target)) {
            tagertClear(pc);
            return false;
        }

        return true;
    }


    public boolean checkAutoMoveTime(L1PcInstance pc) {
        long temp = System.currentTimeMillis() - pc.getAutoTimeMove();
        long interval = pc.getCurrentSpriteInterval(EActionCodes.walk);
        return temp >= interval;
    }

    private boolean toAttack(final L1PcInstance pc) {
        if (pc == null) {
            return false;
        }

        try {
            final L1Character target = pc.getAutoTarget();

            if (target == null) {
                return false;
            }

            if (pc.hasSkillEffect(L1SkillId.MEDITATION)) {
                pc.killSkillEffectTimer(L1SkillId.MEDITATION);
            }

            pc.getRegenController().OnAttack(System.currentTimeMillis());
            pc.delInvis();
            target.onAction(pc);
            return true;

        } catch (Exception e) {
            tagertClear(pc);
            return false;
        }
    }

    /**
     * AOI SEE_CREATURE.
     *
     * 공간 검색은 하지 않는다.
     * PC 화면에 실제로 들어온 Monster만 retained candidate list에 넣는다.
     * 실제 target 선택은 THINK owner에서 selectTarget()이 담당한다.
     */
    public void onSeeCreature(
            final L1PcInstance pc,
            final L1MonsterInstance mon) {

        if (pc == null
                || mon == null
                || !pc.getAutoHunt()
                || mon.getMapId() != pc.getMapId()
                || mon.isDead()
                || mon.getCurrentHp() <= 0) {
            return;
        }

        pc.addAutoTargetList(mon);
        pc.setAutoTargetDirty(true);
    }

    /**
     * AOI OUT_OF_SIGHT.
     *
     * 화면에서 빠진 Monster는 candidate list에서 즉시 제거한다.
     * 현재 target이면 다음 THINK에서 다른 retained candidate를 고르게 비운다.
     */
    public void onOutOfSight(
            final L1PcInstance pc,
            final L1MonsterInstance mon) {

        if (pc == null || mon == null) {
            return;
        }

        pc.removeAutoTargetList(mon);
        pc.setAutoTargetDirty(true);

        if (pc.getAutoTarget() == mon) {
            pc.setAutoTarget(null);
        }
    }

    /**
     * 자동사냥 시작 및 이동 막힘 복구 시 이미 화면에 있던 known Monster seed.
     *
     * world / cluster query가 아니다.
     * 평상시에는 InSight / OutOfSight event로 candidate set을 유지한다.
     */
    public void seedKnownTargets(final L1PcInstance pc) {
        if (pc == null || !pc.getAutoHunt()) {
            return;
        }

        for (L1Object obj : pc.getKnownObjects()) {
            if (obj instanceof L1MonsterInstance) {
                onSeeCreature(
                        pc,
                        (L1MonsterInstance) obj);
            }
        }
    }

    /**
     * retained AOI candidate 중 현재 정책에 맞는 최적 target을 선택한다.
     *
     * 주기적인 queryNearby() 없음.
     * target이 필요할 때만 retained candidate를 한 번 검사한다.
     */
    public void selectTarget(final L1PcInstance pc) {
        if (pc == null) {
            return;
        }

        checkTarget(pc);

        final L1Character current = pc.getAutoTarget();
        if (current != null
                && !current.isDead()
                && current.getCurrentHp() > 0
                && current.getMapId() == pc.getMapId()) {

            return;
        }

        final long now = System.currentTimeMillis();

        final int ignoreId = pc.getAutoIgnoreTarget();
        final long ignoreUntil = pc.getAutoIgnoreTime();

        if (ignoreId != 0 && now >= ignoreUntil) {
            pc.setAutoIgnoreTarget(0);
            pc.setAutoIgnoreTime(0L);
            pc.setAutoTargetDirty(true);
        }

        // AOI membership can stay unchanged while monsters move into reach.
        // Revisit only retained candidates, at most once per 300ms when clean.
        final boolean review = pc.getAutoChaseState().reviewSelection(now);
        if (!pc.isAutoTargetDirty() && !review) {
            return;
        }

        pc.setAutoTargetDirty(false);

        if (pc.getAutoTargetList().isEmpty()) {
            return;
        }

        final boolean teleportHunt = canUseTeleport(pc);

        final int attackRange =
                Math.max(1, pc.getAttackRang());

        final long walkInterval =
                Math.max(
                        1L,
                        pc.getCurrentSpriteInterval(
                                EActionCodes.walk));

        final int approachSteps =
                teleportHunt
                        ? Math.max(
                                1,
                                (int) (TELEPORT_APPROACH_BUDGET_MS
                                        / walkInterval))
                        : TARGET_SCAN_RANGE;

        final int engageRange =
                teleportHunt
                        ? Math.min(
                                TARGET_SCAN_RANGE,
                                attackRange + approachSteps)
                        : TARGET_SCAN_RANGE;

        L1MonsterInstance closestMon = null;
        int bestDist = Integer.MAX_VALUE;
        int bestId = Integer.MAX_VALUE;

        final int myX = pc.getX();
        final int myY = pc.getY();
        final int mapId = pc.getMapId();

        /*
         * L1HateList가 retained candidate store다.
         * 이 copy는 target 재선택 순간에만 생기며 기존 80~250ms world scan은 완전히 없다.
         */
        final java.util.ArrayList<L1Character> candidates =
                pc.getAutoTargetList().toTargetArrayList();

        for (int i = 0, size = candidates.size(); i < size; i++) {
            final L1Character cha = candidates.get(i);

            if (!(cha instanceof L1MonsterInstance)) {
                if (cha != null) {
                    pc.removeAutoTargetList(cha);
                }
                continue;
            }

            final L1MonsterInstance mon =
                    (L1MonsterInstance) cha;

            if (mon.getMapId() != mapId
                    || mon.isDead()
                    || mon.getCurrentHp() <= 0
                    || !pc.canSeeObject(mon)) {

                pc.removeAutoTargetList(mon);
                continue;
            }

            /*
             * hidden은 candidate에는 남겨 둔다.
             * 다시 나타났을 때 새 world scan 없이 재사용 가능하다.
             */
            if (mon.getHiddenStatus() >= 1) {
                continue;
            }

            if (ignoreId == mon.getId()
                    && now < ignoreUntil) {
                continue;
            }

            if (isTemporarilyBlocked(pc, mon, now) || !isAttack(pc, mon)) {
                continue;
            }

            final int dist =
                    getDistance(
                            myX,
                            myY,
                            mon.getX(),
                            mon.getY());

            if (dist > TARGET_SCAN_RANGE) {
                continue;
            }

            if (teleportHunt
                    && dist > engageRange) {
                continue;
            }

            final int monId = mon.getId();

            if (dist > bestDist
                    || (dist == bestDist
                            && monId >= bestId)) {
                continue;
            }

            if (!pc.glanceCheck(
                    mon.getX(),
                    mon.getY())) {
                continue;
            }

            bestDist = dist;
            bestId = monId;
            closestMon = mon;
        }

        if (closestMon != null) {
            pc.setAutoTarget(closestMon);
            pc.setAutoTeleportTime(now);
        }
    }

    private static int roamSectorKey(final int x, final int y) {
        return ((x >> ROAM_SECTOR_SHIFT) << 16) | ((y >> ROAM_SECTOR_SHIFT) & 0xFFFF);
    }

    private int getRoamDir(final L1PcInstance pc) {
        final int code = (pc.getAutoRoamState() >>> ROAM_DIR_SHIFT) & ROAM_DIR_MASK;
        return code == 0 ? -1 : code - 1;
    }

    private void setRoamDir(final L1PcInstance pc, final int dir) {
        final int dirCode = dir < 0 ? 0 : (dir + 1);
        final int mask = ROAM_DIR_MASK << ROAM_DIR_SHIFT;
        final int state = pc.getAutoRoamState();
        pc.setAutoRoamState((state & ~mask) | (dirCode << ROAM_DIR_SHIFT));
    }

    private int getRoamHistoryCursor(final L1PcInstance pc) {
        return pc.getAutoRoamState() & ROAM_HISTORY_CURSOR_MASK;
    }

    private int getRoamHistoryCount(final L1PcInstance pc) {
        return (pc.getAutoRoamState() >>> ROAM_HISTORY_COUNT_SHIFT) & ROAM_HISTORY_COUNT_MASK;
    }

    private void setRoamHistoryMeta(final L1PcInstance pc, final int cursor, final int count) {
        final int metaMask = ROAM_HISTORY_CURSOR_MASK | (ROAM_HISTORY_COUNT_MASK << ROAM_HISTORY_COUNT_SHIFT);
        final int state = pc.getAutoRoamState();
        pc.setAutoRoamState((state & ~metaMask) | (cursor & ROAM_HISTORY_CURSOR_MASK) | ((count & ROAM_HISTORY_COUNT_MASK) << ROAM_HISTORY_COUNT_SHIFT));
    }

    private int getRoamHistorySlot(final L1PcInstance pc, final int slot) {
        final long pair;

        switch (slot >>> 1) {
            case 0: pair = pc.getAutoRoamHistory0(); break;
            case 1: pair = pc.getAutoRoamHistory1(); break;
            case 2: pair = pc.getAutoRoamHistory2(); break;
            default: pair = pc.getAutoRoamHistory3(); break;
        }

        return (slot & 1) == 0 ? (int) pair : (int) (pair >>> 32);
    }

    private void setRoamHistorySlot(final L1PcInstance pc, final int slot, final int key) {
        final int pairIndex = slot >>> 1;
        final boolean high = (slot & 1) != 0;
        long pair;

        switch (pairIndex) {
            case 0: pair = pc.getAutoRoamHistory0(); break;
            case 1: pair = pc.getAutoRoamHistory1(); break;
            case 2: pair = pc.getAutoRoamHistory2(); break;
            default: pair = pc.getAutoRoamHistory3(); break;
        }

        if (high) {
            pair = (pair & 0x00000000FFFFFFFFL) | ((long) key << 32);
        } else {
            pair = (pair & 0xFFFFFFFF00000000L) | (key & 0xFFFFFFFFL);
        }

        switch (pairIndex) {
            case 0: pc.setAutoRoamHistory0(pair); break;
            case 1: pc.setAutoRoamHistory1(pair); break;
            case 2: pc.setAutoRoamHistory2(pair); break;
            default: pc.setAutoRoamHistory3(pair); break;
        }
    }

    /**
     * -1 = 최근 8개 안에 없음
     *  0 = 가장 최근
     *  7 = 가장 오래된 recent entry
     */
    private int getRoamHistoryAge(final L1PcInstance pc, final int key) {
        final int count = getRoamHistoryCount(pc);
        final int cursor = getRoamHistoryCursor(pc);

        for (int age = 0; age < count; age++) {
            final int slot = (cursor - 1 - age + ROAM_HISTORY_SIZE) & (ROAM_HISTORY_SIZE - 1);
            if (getRoamHistorySlot(pc, slot) == key) {
                return age;
            }
        }

        return -1;
    }

    private void markRoamSectorVisited(final L1PcInstance pc, final int key) {
        if (key == 0 || getRoamHistoryAge(pc, key) >= 0) {
            return;
        }

        final int cursor = getRoamHistoryCursor(pc);
        final int count = getRoamHistoryCount(pc);

        setRoamHistorySlot(pc, cursor, key);
        setRoamHistoryMeta(pc, (cursor + 1) & (ROAM_HISTORY_SIZE - 1), Math.min(ROAM_HISTORY_SIZE, count + 1));
    }

    private void ensureRoamMap(final L1PcInstance pc) {
        final int mapId = pc.getMapId();

        if (pc.getAutoRoamMapId() == mapId) {
            return;
        }

        pc.resetAutoRoam();
        pc.setAutoRoamMapId(mapId);
        setRoamDir(pc, pc.getHeading() & 7);
    }

    private static int roamDirectionDiff(final int a, final int b) {
        int d = Math.abs((a & 7) - (b & 7));
        return d > 4 ? 8 - d : d;
    }

    private int roamDirectionScore(final int currentDir, final int candidateDir) {
        switch (roamDirectionDiff(currentDir, candidateDir)) {
            case 0: return 420;
            case 1: return 300;
            case 2: return 140;
            case 3: return -100;
            default: return -400;
        }
    }

    /**
     * sector 내부의 passable point 중 현재 위치에서 가장 가까운 점을 고른다.
     * 반환: x/y를 하나의 long으로 pack. 실패 시 Long.MIN_VALUE.
     */
    private long pickRoamPointInSector(final L1PcInstance pc, final int sectorX, final int sectorY) {
        final int baseX = sectorX << ROAM_SECTOR_SHIFT;
        final int baseY = sectorY << ROAM_SECTOR_SHIFT;

        int bestX = 0;
        int bestY = 0;
        int bestDist = Integer.MAX_VALUE;

        for (int i = 0; i < ROAM_POINT_OX.length; i++) {
            final int x = baseX + ROAM_POINT_OX[i];
            final int y = baseY + ROAM_POINT_OY[i];

            if (!pc.getMap().isInMap(x, y) || !pc.getMap().isPassable(x, y)) {
                continue;
            }

            final int dist = getDistance(pc.getX(), pc.getY(), x, y);

            if (dist < bestDist) {
                bestDist = dist;
                bestX = x;
                bestY = y;
            }
        }

        if (bestDist == Integer.MAX_VALUE) {
            return Long.MIN_VALUE;
        }

        return ((long) bestX << 32) | (bestY & 0xFFFFFFFFL);
    }

    /**
     * 최근 sector를 제외한 frontier를 우선 선택한다.
     * 모두 recent라면 두 번째 pass에서 가장 오래된 sector 쪽부터 재사용한다.
     */
    private boolean pickRoamFrontier(final L1PcInstance pc) {
        final int currentSectorX = pc.getX() >> ROAM_SECTOR_SHIFT;
        final int currentSectorY = pc.getY() >> ROAM_SECTOR_SHIFT;

        int currentDir = getRoamDir(pc);
        if (currentDir < 0) {
            currentDir = pc.getHeading() & 7;
        }

        for (int pass = 0; pass < 2; pass++) {
            int bestScore = Integer.MIN_VALUE;
            int bestKey = 0;
            int bestX = 0;
            int bestY = 0;
            int bestDir = -1;

            for (int sy = currentSectorY - ROAM_FRONTIER_RADIUS; sy <= currentSectorY + ROAM_FRONTIER_RADIUS; sy++) {
                for (int sx = currentSectorX - ROAM_FRONTIER_RADIUS; sx <= currentSectorX + ROAM_FRONTIER_RADIUS; sx++) {
                    final int dx = sx - currentSectorX;
                    final int dy = sy - currentSectorY;
                    final int ring = Math.max(Math.abs(dx), Math.abs(dy));

                    if (ring == 0 || ring > ROAM_FRONTIER_RADIUS) {
                        continue;
                    }

                    final int key = (sx << 16) | (sy & 0xFFFF);
                    final int historyAge = getRoamHistoryAge(pc, key);

                    if (pass == 0 && historyAge >= 0) {
                        continue;
                    }

                    final long point = pickRoamPointInSector(pc, sx, sy);

                    if (point == Long.MIN_VALUE) {
                        continue;
                    }

                    final int x = (int) (point >> 32);
                    final int y = (int) point;
                    final int dir = pc.targetDirection(x, y) & 7;

                    int score = ring == 2 ? 300 : 120;
                    score += roamDirectionScore(currentDir, dir);

                    if (historyAge >= 0) {
                        /* 최근일수록 강하게 감점, 오래된 entry는 다시 열어준다. */
                        score += -800 + (historyAge * 90);
                    }

                    /* 동일 score에서 PC들이 같은 점만 고르지 않게 allocation 없는 작은 분산. */
                    score += ((key * 0x9E3779B9) ^ pc.getId()) & 0x3F;

                    if (score <= bestScore) {
                        continue;
                    }

                    bestScore = score;
                    bestKey = key;
                    bestX = x;
                    bestY = y;
                    bestDir = dir;
                }
            }

            if (bestKey != 0) {
                pc.setAutoLocX(bestX);
                pc.setAutoLocY(bestY);
                setRoamDir(pc, bestDir);
                return true;
            }
        }

        return false;
    }

    /**
     * 매우 작은 방/섬처럼 주변 frontier sector 자체가 없는 경우만 쓰는 fallback.
     * 현재 sector 내부의 passable point 중 가장 먼 점으로 한 번 이동한다.
     */
    private boolean pickLocalRoamFallback(final L1PcInstance pc) {
        final int sectorX = pc.getX() >> ROAM_SECTOR_SHIFT;
        final int sectorY = pc.getY() >> ROAM_SECTOR_SHIFT;
        final int baseX = sectorX << ROAM_SECTOR_SHIFT;
        final int baseY = sectorY << ROAM_SECTOR_SHIFT;

        int bestX = 0;
        int bestY = 0;
        int bestDist = 1;

        for (int i = 0; i < ROAM_POINT_OX.length; i++) {
            final int x = baseX + ROAM_POINT_OX[i];
            final int y = baseY + ROAM_POINT_OY[i];

            if (!pc.getMap().isInMap(x, y) || !pc.getMap().isPassable(x, y)) {
                continue;
            }

            final int dist = getDistance(pc.getX(), pc.getY(), x, y);

            if (dist <= bestDist) {
                continue;
            }

            bestDist = dist;
            bestX = x;
            bestY = y;
        }

        if (bestX == 0 || bestY == 0) {
            return false;
        }

        pc.setAutoLocX(bestX);
        pc.setAutoLocY(bestY);
        setRoamDir(pc, pc.targetDirection(bestX, bestY) & 7);
        return true;
    }

    public boolean toRandomWalk(final L1PcInstance pc) {
        if (!checkAutoMoveTime(pc) || CommonUtil.isAutoNonActionSkill(pc)) {
            return true;
        }

        ensureRoamMap(pc);

        final int currentSector = roamSectorKey(pc.getX(), pc.getY());
        markRoamSectorVisited(pc, currentSector);

        final boolean invalid = pc.getAutoLocX() == 0 || pc.getAutoLocY() == 0;

        if (invalid) {
            if (!pickRoamFrontier(pc) && !pickLocalRoamFallback(pc)) {
                resetAutoWalk(pc);
                return true;
            }
        }

        final byte move =
                AHSetMoving.tickToPoint(
                        pc,
                        pc.getAutoLocX(),
                        pc.getAutoLocY());

        switch (move) {
        case AHSetMoving.RUNNING:
        case AHSetMoving.DYNAMIC_BLOCKED:
            return true;

        case AHSetMoving.AT_DISTANCE:
            markRoamSectorVisited(
                    pc,
                    roamSectorKey(
                            pc.getAutoLocX(),
                            pc.getAutoLocY()));
            resetAutoWalk(pc);
            AHSetMoving.clear(pc);
            return true;

        case AHSetMoving.PATH_FAILED:
        case AHSetMoving.INVALID:
        default:
            final int roamX = pc.getAutoLocX();
            final int roamY = pc.getAutoLocY();

            if (roamX != 0 && roamY != 0) {
                markRoamSectorVisited(
                        pc,
                        roamSectorKey(roamX, roamY));
            }

            resetAutoWalk(pc);
            AHSetMoving.clear(pc);
            return false;
        }
    }

    private boolean canUseTeleport(L1PcInstance pc) {
        return pc.getMap().isTeleportable() || AHUseItem.getInstance().canTeleportInSpecialMap(pc);
    }

    public boolean noTargetTeleport(L1PcInstance pc) {
        if (pc == null) {
            return true;
        }

        final long now = System.currentTimeMillis();

        if (pc.getMapId() == 4 || pc.getMap().isSafetyZone(pc.getLocation())) {
            pc.setAutoTeleportTime(now);
            return false;
        }

        if (!canUseTeleport(pc)) {
            pc.setAutoTeleportTime(now);
            return false;
        }

        if (pc.getAutoTarget() != null) {
            pc.setAutoTeleportTime(now);
            return false;
        }

        final long idleSince = pc.getAutoTeleportTime();

        /*
         * 최초 무타겟 진입에서는 타이머만 시작하고 MOVE를 허용한다.
         * 입구에서 서 있기만 하는 현상을 만들지 않는다.
         */
        if (idleSince == 0L) {
            pc.setAutoTeleportTime(now);
            return false;
        }

        if (now - idleSince < TELEPORT_HUNT_DELAY_MS) {
            return false;
        }

        /* 텔포 정책/스크롤 사용은 기존 그대로 둔다. */
        resetAutoWalk(pc);
        setRoamDir(pc, -1);

        AHUseItem.getInstance().toUseScroll(pc, 40100);
        pc.setAutoDelayTime(now + 1000L);
        pc.setAutoTeleportTime(now);
        return true;
    }
    
    public void resetAutoWalk(L1PcInstance pc) {
        if (pc == null) return;
        pc.setAutoLocX(0);
        pc.setAutoLocY(0);
    }

    public void checkTarget(L1PcInstance pc) {
        if (pc == null) {
            return;
        }

        final L1Character target = pc.getAutoTarget();

        if (target == null) {
            return;
        }

        final long now = System.currentTimeMillis();
        final int ignoreId = pc.getAutoIgnoreTarget();
        final long ignoreUntil = pc.getAutoIgnoreTime();

        /* 만료된 ignore 슬롯은 여기서 정리한다. */
        if (ignoreId != 0 && now >= ignoreUntil) {
            pc.setAutoIgnoreTarget(0);
            pc.setAutoIgnoreTime(0L);
        }

        if (target.getMapId() != pc.getMapId() || target.isDead() || target.getCurrentHp() <= 0 || target.isInvisble() || (ignoreId == target.getId() && now < ignoreUntil)
                || isTemporarilyBlocked(pc, target, now)) {
            tagertClear(pc);
        }
    }

    public void tagertClear(final L1PcInstance pc) {
        if (pc == null) {
            return;
        }
        pc.setAutoTarget(null);
        pc.setAutoTargetDirty(true);
    }

    public boolean isAttack(L1PcInstance pc, L1Character cha) {
        if (cha == null || cha.isDead() || cha.isInvisble()) return false;
        if (cha.getMap().isSafetyZone(cha.getLocation())) return false;
        if (!isDistance(pc.getX(), pc.getY(), pc.getMapId(), cha.getX(), cha.getY(), cha.getMapId(), 20)) return false;
        return true;
    }

    public boolean isAutoAttackPosition(
            final L1PcInstance pc,
            final L1Character target) {

        if (pc == null
                || target == null
                || target.getMapId() != pc.getMapId()) {

            return false;
        }

        final int range =
                Math.max(1, pc.getAttackRang());

        final int distance =
                getDistance(
                        pc.getX(),
                        pc.getY(),
                        target.getX(),
                        target.getY());

        if (distance > range) {
            return false;
        }

        return pc.glanceCheck(
                target.getX(),
                target.getY());
    }

    /**
     * Dynamic body/choke blockage fallback.
     *
     * Current target is excluded. Known AOI monsters and the direct blocker
     * repair missed candidates; no world/cluster scan is performed. Switch only
     * to an attackable monster or the nearer monster physically blocking us.
     */
    public boolean retargetWhenMoveBlocked(
            final L1PcInstance pc) {
        return selectAlternativeTarget(pc, true);
    }

    /** Check nearby attackable monsters only after pursuit stops progressing.
     * An ordinary moving chase keeps its target.
     */
    public boolean retargetToAttackable(final L1PcInstance pc) {
        return selectAlternativeTarget(pc, false);
    }

    public boolean isTemporarilyBlocked(final L1PcInstance pc,
            final L1Character target, final long now) {
        if (pc == null || target == null) return false;
        final AutoHuntChaseState state = pc.getAutoChaseState();
        if (!state.isDeferred(target.getMapId(), target.getId(), now)) return false;
        // A monster which walks into actual attack range is usable immediately.
        if (isAutoAttackPosition(pc, target)) {
            state.allow(target.getMapId(), target.getId());
            return false;
        }
        return true;
    }

    private void rememberBlockedTarget(final L1PcInstance pc,
            final L1Character target, final long now) {
        if (target == null) return;
        final long walk = Math.max(1L, pc.getCurrentSpriteInterval(EActionCodes.walk));
        final long defer = Math.max(2_000L, Math.min(1_500L, walk) * 4L);
        pc.getAutoChaseState().defer(target.getMapId(), target.getId(), now + defer);
    }

    public void abandonBlockedTarget(final L1PcInstance pc) {
        rememberBlockedTarget(pc, pc.getAutoTarget(), System.currentTimeMillis());
        pc.getAutoChaseState().clearProgress();
        pc.setAutoMoveFailCount(0);
        tagertClear(pc);
    }

    private boolean selectAlternativeTarget(final L1PcInstance pc,
            final boolean movementBlocked) {

        if (pc == null) {
            return false;
        }

        final L1Character current =
                pc.getAutoTarget();

        if (current == null) return false;

        final long now =
                System.currentTimeMillis();
        final AutoHuntChaseState state = pc.getAutoChaseState();
        if (!state.canRetarget(now) || isAutoAttackPosition(pc, current)) return false;
        if (!movementBlocked) {
            final long walk = Math.max(1L, pc.getCurrentSpriteInterval(EActionCodes.walk));
            final long delay = Math.max(600L, Math.min(1_500L, walk * 2L));
            if (!state.hasStalled(pc.getMapId(), current.getId(), now, delay)) return false;
        }
        if (!(movementBlocked ? state.reviewAlternatives(now) : state.reviewAttackable(now)))
            return false;

        if (movementBlocked) {
            // Repair missed/stale AOI membership on a bounded recovery path,
            // not with a global world scan on every auto-hunt wheel tick.
            seedKnownTargets(pc);
            final L1Object blocker = L1World.getInstance().findObject(AHSetMoving.lastBlockerId(pc));
            if (blocker instanceof L1MonsterInstance && pc.canSeeObject(blocker))
                onSeeCreature(pc, (L1MonsterInstance) blocker);
        }
        if (pc.getAutoTargetList().isEmpty()) return false;

        final int ignoreId =
                pc.getAutoIgnoreTarget();

        final long ignoreUntil =
                pc.getAutoIgnoreTime();

        final int mapId = pc.getMapId();
        final int myX = pc.getX();
        final int myY = pc.getY();

        final int currentDistance = getDistance(myX, myY, current.getX(), current.getY());
        final int blockerId = movementBlocked ? AHSetMoving.lastBlockerId(pc) : 0;

        L1MonsterInstance best = null;
        int bestAttackable = 2;
        int bestDistance = Integer.MAX_VALUE;
        int bestId = Integer.MAX_VALUE;

        final java.util.ArrayList<L1Character> candidates =
                pc.getAutoTargetList().toTargetArrayList();

        for (int i = 0, size = candidates.size();
             i < size;
             i++) {

            final L1Character candidate =
                    candidates.get(i);

            if (!(candidate instanceof L1MonsterInstance)) {
                continue;
            }

            final L1MonsterInstance mon =
                    (L1MonsterInstance) candidate;

            if (mon == current
                    || mon.getMapId() != mapId
                    || mon.isDead()
                    || mon.getCurrentHp() <= 0
                    || mon.getHiddenStatus() >= 1
                    || !pc.canSeeObject(mon)) {
                continue;
            }

            if (ignoreId == mon.getId()
                    && now < ignoreUntil) {
                continue;
            }

            if (!isAttack(pc, mon) || isTemporarilyBlocked(pc, mon, now)) {
                continue;
            }

            final int distance =
                    getDistance(
                            myX,
                            myY,
                            mon.getX(),
                            mon.getY());

            final int attackable =
                    isAutoAttackPosition(pc, mon)
                            ? 0
                            : 1;
            if (!movementBlocked && attackable != 0) continue;
            // Nearby does not mean reachable. Do not cycle through arbitrary
            // distant candidates on every transient collision or failed path.
            if (attackable != 0
                    && (mon.getId() != blockerId || distance >= currentDistance
                        || !pc.glanceCheck(mon.getX(), mon.getY()))) continue;

            final int monId = mon.getId();

            if (attackable > bestAttackable
                    || (attackable == bestAttackable
                        && distance > bestDistance)
                    || (attackable == bestAttackable
                        && distance == bestDistance
                        && monId >= bestId)) {
                continue;
            }

            best = mon;
            bestAttackable = attackable;
            bestDistance = distance;
            bestId = monId;
        }

        if (best == null) {
            return false;
        }

        if (movementBlocked) rememberBlockedTarget(pc, current, now);
        state.clearProgress();
        state.didRetarget(now);
        pc.setAutoTarget(best);
        pc.setAutoTargetDirty(false);
        pc.setAutoTeleportTime(now);
        return true;
    }

    private boolean isAutoAttackTime(L1PcInstance pc) {
        long temp = System.currentTimeMillis() - pc.getAutoTimeAttack();
        long interval = pc.getCurrentSpriteInterval(EActionCodes.fromInt(pc.getCurrentWeapon() + 1));
        if (temp >= interval) {
            pc.setAutoTimeAttack(System.currentTimeMillis());
            return true;
        }
        return false;
    }

    private boolean canLoot(L1PcInstance pc, L1ItemInstance item) {
        if (item == null) return false;
        L1PcInstance itemOwner = item.getItemOwner();
        if (itemOwner == null || itemOwner.getId() == pc.getId()) return true;
        return pc.getParty() != null && pc.getParty().isMember(itemOwner);
    }

    public void resetPickupStatus(L1PcInstance pc) {
        if (pc != null) pc.setAutoTargetItem(null);
    }

    private boolean isDistance(int x, int y, int m, int tx, int ty, int tm, int loc) {
        if (m != tm) return false;
        return getDistance(x, y, tx, ty) <= loc;
    }

    private int getDistance(int x, int y, int tx, int ty) {
        return Math.max(Math.abs(x - tx), Math.abs(y - ty));
    }
}
