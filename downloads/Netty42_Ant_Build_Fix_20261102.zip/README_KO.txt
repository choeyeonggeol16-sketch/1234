Ant 빌드 수정본 — 2026-11-02

원인: 기존 build.xml이 라이브러리 6개만 지정해서 Netty/JAXB JAR을 컴파일 클래스패스에 포함하지 않았습니다. lib 폴더 바로 아래 *.jar를 모두 포함하도록 바꿨습니다.

적용:
1. 프로젝트의 기존 build.xml을 백업합니다.
2. 이 ZIP의 build.xml을 프로젝트 폴더에 덮어씁니다. src, lib, build.xml이 같은 프로젝트 폴더 아래에 있어야 합니다.
3. Eclipse에서 프로젝트 새로 고침(F5) 후 build.xml을 우클릭해 Run As > Ant Build로 실행합니다. Ant는 JDK 21로 실행해야 합니다.
4. 성공하면 같은 프로젝트 폴더에 l1jserver.jar가 만들어집니다. 서버 실행 폴더에 복사하고 기존 lib 및 config 설정과 함께 사용합니다.

폴더 구조:
프로젝트/build.xml
프로젝트/src/
프로젝트/lib/ (기존 라이브러리 + Netty 다섯 JAR + JAXB)

변경점: 전체 JAR 클래스패스, --release 21, CP949(MS949) 소스 인코딩, Netty/JAXB 누락 시 명확한 오류 표시. 기존 all/clean/compile/jar/clean2 작업과 JAR 이름은 유지합니다.

검증: 실제 서버 소스 970개 전체를 스텁 없이 Ant 1.10.15/JDK 21로 컴파일하고 JAR 생성까지 완료했습니다. 오류 0개, 원본 소스의 폐기 예정 API 등 경고 45개. GUI/DB를 포함한 서버 기동은 미검증입니다. 검증에는 공식 Maven의 Javolution 5.5.1, Gson 2.8.4, c3p0 0.9.1.2, JAXB 2.3.1 및 SWT 3.126.0을 사용했습니다. 사용자 SWT 3.100.1 원본 JAR은 미제공입니다. 라이브러리 버전과 출처는 validation.json에 기록했습니다. 검증용 JAR로 사용자의 라이브러리를 교체하지 않습니다.
