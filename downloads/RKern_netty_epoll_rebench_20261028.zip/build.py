from pathlib import Path
import argparse,hashlib,json,subprocess,urllib.request

root=Path(__file__).resolve().parent
parser=argparse.ArgumentParser()
parser.add_argument('--fetch-deps',action='store_true')
args=parser.parse_args()
lib=root/'lib';lib.mkdir(exist_ok=True)
for row in json.loads((root/'dependencies.json').read_text()):
    target=lib/row['name']
    if not target.exists():
        if not args.fetch_deps:raise SystemExit('Missing '+str(target)+'; run build.py --fetch-deps')
        urllib.request.urlretrieve(row['url'],target)
    if hashlib.sha256(target.read_bytes()).hexdigest()!=row['sha256']:
        raise SystemExit('Dependency SHA-256 mismatch: '+row['name'])
cp=':'.join(str(p) for p in sorted(lib.glob('*.jar')))
for label in ['v5','optimized','client']:
    version='v5' if label=='client' else label
    manifest=json.loads((root/'sources'/(version+'-manifest.json')).read_text())
    source=root/'sources'/version
    for rel,sha in manifest['actual_sha256'].items():
        assert hashlib.sha256((source/rel).read_bytes()).hexdigest()==sha
    output=root/label/'classes';output.mkdir(parents=True,exist_ok=True)
    files=[source/rel for rel in manifest['actual_sha256']]
    files.extend(sorted((root/'stubs').rglob('*.java')))
    files.append(root/'harness'/('client' if label=='client' else 'server')/'NettyBench.java')
    subprocess.run(['java','com.sun.tools.javac.Main','-encoding','UTF-8','-cp',cp,'-d',str(output),*[str(p) for p in files]],check=True)
common=root/'common-cipher';common.mkdir(exist_ok=True)
subprocess.run(['java','com.sun.tools.javac.Main','-encoding','UTF-8','-cp',str(root/'v5/classes'),'-d',str(common),str(root/'sources/optimized/l1j/server/server/model/network/codec/Cryptor.java')],check=True)
print('Built v5, uploaded optimized transport, fixed v5 client, and common uploaded cipher for Netty.')
