# Build on Linux with JDK 21. Dependencies are pinned and SHA-256 checked.
python3 build.py --fetch-deps

# Main comparison: old RKern, uploaded defaults, Netty epoll.
python3 run.py --mode measure --rounds 3 --warmup 5 --seconds 5 --case latency-1 --case burst-128 --case many-1024 --case bulk-tx-64 --keep-going

# Supplemental A/B controls (reported separately).
python3 run.py --mode measure --rounds 3 --warmup 5 --seconds 5 --case burst-128 --case many-1024 --engine rkern-optimized --engine rkern-optimized-batch --engine rkern-optimized-no-fairness --engine netty-epoll --targeted-controls --keep-going --label controls

# Reproduce the uploaded default's ordering failure. Use a fresh label per run.
python3 run.py --mode smoke --warmup 2 --seconds 1 --case fairness-16 --engine rkern-optimized --label fairness-new

# Control settings which passed the same correctness workload.
python3 run.py --mode smoke --warmup 2 --seconds 1 --case fairness-16 --engine rkern-v5 --engine netty-epoll --engine rkern-optimized-no-fairness --label fairness-control-new
