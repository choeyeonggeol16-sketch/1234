#!/usr/bin/env python3
from pathlib import Path
import argparse,datetime,hashlib,json,os,selectors,statistics,subprocess,time,traceback

R=Path(__file__).resolve().parent
P=argparse.ArgumentParser()
P.add_argument('--mode',choices=['smoke','measure'],default='smoke')
P.add_argument('--rounds',type=int,default=3)
P.add_argument('--warmup',type=int,default=5)
P.add_argument('--seconds',type=int,default=5)
P.add_argument('--case',action='append')
P.add_argument('--engine',action='append')
P.add_argument('--label',default='')
P.add_argument('--keep-going',action='store_true')
P.add_argument('--targeted-controls',action='store_true')
A=P.parse_args()
JAVA=['java','-ea','-Xms256m','-Xmx256m','-XX:MaxDirectMemorySize=512m','-XX:ActiveProcessorCount=2','-XX:+UseG1GC',
      '-cp',str(R/'client/classes')+':'+str(R/'lib/*'),'l1j.server.server.model.network.core.NettyBench']
ENGINES=['rkern-v5','rkern-optimized','netty-epoll']
if A.engine:ENGINES=A.engine
CASES=[
 {'name':'latency-1','connections':1,'window':1,'client_threads':1,'request':32,'response':6,'replies':1},
 {'name':'burst-128','connections':128,'window':8,'client_threads':2,'request':32,'response':6,'replies':32},
 {'name':'bulk-64','connections':64,'window':4,'client_threads':2,'request':4096,'response':4096,'replies':1},
 {'name':'many-1024','connections':1024,'window':1,'client_threads':2,'request':32,'response':6,'replies':1},
 {'name':'bulk-tx-64','connections':64,'window':4,'client_threads':2,'request':32,'response':4096,'replies':1},
 {'name':'fairness-16','connections':16,'window':64,'client_threads':2,'request':32,'response':6,'replies':1},
]
if A.case:CASES=[c for c in CASES if c['name'] in A.case]
else:CASES=[c for c in CASES if c['name']!='fairness-16']
if A.mode=='smoke':CASES=[dict(c,connections=min(c['connections'],16)) for c in CASES if c['name']!='many-1024']
out=R/((A.label+'-') if A.label else '')/('smoke' if A.mode=='smoke' else 'results')
out.mkdir(parents=True,exist_ok=True)
manifest={'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'mode':A.mode,'warmup_s':A.warmup,
          'measurement_s':A.seconds,'rounds':A.rounds,'server_affinity':'0,1','client_affinity':'2,3','jvm_command':JAVA,
          'server_workers':2,'cases':CASES,'runs':[],
          'environment':{'uname':subprocess.check_output(['uname','-srmo'],text=True).strip(),
            'cpu_max':Path('/sys/fs/cgroup/cpu.max').read_text().strip(),
            'cpuset':Path('/sys/fs/cgroup/cpuset.cpus.effective').read_text().strip(),
            'java_version':subprocess.run(['java','-version'],capture_output=True,text=True).stderr.strip()}}

def read_json(prefix,line):
 return json.loads(line[len(prefix):])
def applicable(case,engine):
 if not A.targeted_controls:return True
 if engine=='rkern-optimized-batch':return case['name']=='burst-128'
 if engine=='rkern-optimized-no-fairness':return case['name']=='many-1024'
 return True
def rss(pid):
 try:
  data=Path(f'/proc/{pid}/status').read_text().splitlines()
  return {line.split(':')[0]:int(line.split()[1])*1024 for line in data if line.startswith(('VmRSS:','VmHWM:'))}
 except FileNotFoundError:return {}
def run(case,engine,round_id):
 ident=f"{case['name']}-{round_id}-{engine}"
 server_java=JAVA.copy()
 if engine.startswith('rkern-v5'):
  engine_cp=str(R/'v5/classes')
  if engine=='rkern-v5-common-cipher':engine_cp=str(R/'common-cipher')+':'+engine_cp
  actual_engine='rkern'
 elif engine.startswith('rkern-optimized'):
  engine_cp=str(R/'optimized/classes');actual_engine='rkern'
  if engine=='rkern-optimized-batch':server_java.insert(1,'-Dbench.actionBatch=true')
  if engine=='rkern-optimized-no-fairness':server_java.insert(1,'-Dcio.readFrameBudget=0')
 else:
  engine_cp=str(R/'common-cipher')+':'+str(R/'v5/classes');actual_engine='netty-epoll'
 server_java[server_java.index('-cp')+1]=engine_cp+':'+str(R/'lib/*')
 server_cmd=['taskset','-c','0,1',*server_java,'server',actual_engine,'2',str(case['connections']+max(256,case['connections']//8)),
             str(case['request']),str(case['response']),str(case['replies'])]
 stderr=open(out/(ident+'-server.err'),'w')
 server=subprocess.Popen(server_cmd,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=stderr,text=True,bufsize=1)
 client=None;logs=[];server_logs=[]
 try:
  selector=selectors.DefaultSelector();selector.register(server.stdout,selectors.EVENT_READ,'server')
  deadline=time.monotonic()+30
  ready=None
  while time.monotonic()<deadline and ready is None:
   for key,_ in selector.select(1):
    line=key.fileobj.readline()
    if not line:raise RuntimeError(f'server exited {server.poll()}')
    server_logs.append(line.rstrip())
    if line.startswith('READY '):ready=read_json('READY ',line)
  if ready is None:raise RuntimeError('server ready timeout')
  client_cmd=['taskset','-c','2,3',*JAVA,'client',str(ready['port']),str(case['connections']),str(case['window']),str(case['client_threads']),
              str(A.warmup),str(A.seconds),str(case['request']),str(case['response']),str(case['replies']),str(A.mode=='smoke').lower()]
  clienterr=open(out/(ident+'-client.err'),'w')
  client=subprocess.Popen(client_cmd,stdout=subprocess.PIPE,stderr=clienterr,text=True,bufsize=1)
  selector.register(client.stdout,selectors.EVENT_READ,'client')
  result={'case':case['name'],'engine':engine,'round':round_id,'server_command':server_cmd,'client_command':client_cmd,'ready':ready}
  deadline=time.monotonic()+A.warmup+A.seconds+65
  while time.monotonic()<deadline:
   client_error=(out/(ident+'-client.err')).read_text()
   if 'Exception in thread "main"' in client_error:
    raise RuntimeError('client correctness/runtime failure: '+client_error.splitlines()[0])
   if 'client' in result and 'server' in result:break
   for key,_ in selector.select(1):
    line=key.fileobj.readline()
    if not line:
     selector.unregister(key.fileobj)
     if key.data=='client' and 'client' not in result:raise RuntimeError(f'client exited {client.poll()}')
     continue
    line=line.rstrip()
    if key.data=='server':
     server_logs.append(line)
     if line.startswith('SERVER '):result['server']=read_json('SERVER ',line)
    else:
     logs.append(line)
     if line=='MEASURE_BEGIN':result['rss_start']=rss(server.pid);server.stdin.write('start\n');server.stdin.flush()
     elif line=='MEASURE_END':result['rss_end']=rss(server.pid);server.stdin.write('stop\n');server.stdin.flush()
     elif line.startswith('CLIENT '):result['client']=read_json('CLIENT ',line)
  if 'client' not in result or 'server' not in result:raise RuntimeError('measurement timeout')
  if client.wait(timeout=5)!=0:raise RuntimeError('nonzero client exit')
  if result['server']['failures'] or result['server']['send_rejections']:raise RuntimeError('server rejected or failed')
  if not result['client']['requests']:raise RuntimeError('no completed measured requests')
  result['server_cpu_us_per_request']=result['server']['cpu_s']*1e6/result['client']['requests']
  server.stdin.write('quit\n');server.stdin.flush()
  if server.wait(timeout=15)!=0:raise RuntimeError('nonzero server exit')
  return result
 finally:
  for process in [client,server]:
   if process is not None and process.poll() is None:
    process.terminate()
    try:process.wait(timeout=5)
    except subprocess.TimeoutExpired:process.kill();process.wait()
  stderr.close()
  if client is not None:clienterr.close()
  (out/(ident+'-server.log')).write_text('\n'.join(server_logs)+'\n')
  (out/(ident+'-client.log')).write_text('\n'.join(logs)+'\n')

try:
 rounds=1 if A.mode=='smoke' else A.rounds
 for k in range(rounds):
  for case in CASES:
   case_engines=[engine for engine in ENGINES if applicable(case,engine)]
   order=case_engines[k%len(case_engines):]+case_engines[:k%len(case_engines)]
   for engine in order:
    try:
     result=run(case,engine,k+1)
    except Exception:
     failure={'case':case['name'],'engine':engine,'round':k+1,'error':traceback.format_exc()}
     manifest.setdefault('failed_runs',[]).append(failure)
     (out/'raw.json').write_text(json.dumps(manifest,indent=2)+'\n')
     print(f"FAIL {case['name']} round={k+1} {engine}: {failure['error'].splitlines()[-1]}",flush=True)
     if not A.keep_going:raise
     continue
    manifest['runs'].append(result)
    (out/'raw.json').write_text(json.dumps(manifest,indent=2)+'\n')
    c=result['client'];s=result['server']
    print(f"DONE {case['name']} round={k+1} {engine}: {c['requests_per_s']:.0f} req/s, {c['response_packets_per_s']:.0f} response packets/s, p99={c['p99_us']:.1f}us, serverCPU={s['cpu_s']:.2f}s clientCPU={c['client_cpu_s']:.2f}s",flush=True)
 manifest['finished_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat()
except Exception:
 manifest['error']=traceback.format_exc();(out/'raw.json').write_text(json.dumps(manifest,indent=2)+'\n');raise
summary=[]
for case in CASES:
 for engine in ENGINES:
  if not applicable(case,engine):continue
  rows=[r for r in manifest['runs'] if r['case']==case['name'] and r['engine']==engine]
  if not rows:
   summary.append({'case':case['name'],'engine':engine,'runs':0,'valid':False})
   continue
  summary.append({'case':case['name'],'engine':engine,'runs':len(rows),
   **{key:statistics.median(r['client'][key] for r in rows) for key in ['requests_per_s','response_packets_per_s','wire_mib_per_s','p50_us','p95_us','p99_us','max_us','client_cpu_s']},
   'req_s_min':min(r['client']['requests_per_s'] for r in rows),'req_s_max':max(r['client']['requests_per_s'] for r in rows),
   'server_cpu_us_per_request':statistics.median(r['server_cpu_us_per_request'] for r in rows),
   'server_cpu_s':statistics.median(r['server']['cpu_s'] for r in rows),
   'rss_bytes':statistics.median(r['rss_end'].get('VmRSS',0) for r in rows),
   'direct_allocated_bytes':statistics.median(r['server']['direct_allocated_bytes'] for r in rows)})
manifest['summary']=summary
(out/'raw.json').write_text(json.dumps(manifest,indent=2)+'\n')
(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print('COMPLETE',out,flush=True)
