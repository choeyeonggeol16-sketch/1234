삭제 예정 생성자 경고 45곳 수정 패치 — 2026-11-02

적용 대상: 앞서 제공한 Netty 4.2.19.Final 서버 소스.

1. 기존 프로젝트를 백업합니다.
2. 이 ZIP의 src 폴더를 프로젝트 src에 병합하고 build.xml을 덮어씁니다. 변경된 Java 파일 26개만 포함합니다.
3. Eclipse에서 F5 후 JDK 21로 Run As > Ant Build를 실행합니다. lib 폴더는 build.xml 옆에 있어야 하며 기존 라이브러리와 Netty/JAXB JAR을 그대로 사용합니다.
4. 새 l1jserver.jar가 생성되면 서버 실행 폴더에 복사합니다.

수정: new Integer(...) 42곳, new Double(...) 3곳을 대응하는 valueOf(...)로 교체했습니다. 숫자 변환 및 Map 키의 값 비교를 유지합니다. 한글 소스 인코딩과 줄바꿈은 바꾸지 않았습니다. 네트워크 코어와 패킷 형식은 바꾸지 않았습니다.

검증: 실제 서버 Java 970개 전체를 Ant 1.10.15 / JDK 21로 컴파일하고 JAR을 생성했습니다. -Xlint:removal 및 -Werror를 추가한 검증 빌드도 성공했습니다. 오류 0개, warning 0개입니다. 일반적인 deprecated API 사용을 알리는 Note 두 줄은 남아 있습니다. 해당 안내까지 없애기 위한 경고 숨김 옵션은 추가하지 않았습니다.

GUI/DB 기동은 미검증입니다. 검증용 SWT 3.126.0과 Javolution 5.5.1 등 라이브러리는 validation.json에 기록했습니다. 사용자의 기존 런타임 라이브러리는 이 패치로 변경하지 않습니다.

WARNING_FIX.json: 파일별 변경 수와 적용 전/후 SHA-256.
ant-build.log: 이번 수정 후 실제 전체 빌드 로그.
