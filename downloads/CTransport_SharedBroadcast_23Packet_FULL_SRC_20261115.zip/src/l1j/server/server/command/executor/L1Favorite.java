/*
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2, or (at your option)
 * any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.   See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
 * 02111-1307, USA.
 *
 * http://www.gnu.org/copyleft/gpl.html
 */
package l1j.server.server.command.executor;

import java.util.HashMap;
import java.util.Map;
import java.util.StringTokenizer;

import l1j.server.server.GMCommands;
import l1j.server.server.model.Instance.L1PcInstance;
import l1j.server.server.model.network.core.sc.packet.SC_SystemMessage;

public class L1Favorite implements L1CommandExecutor {
	private static final Map<Integer, String> _faviCom = new HashMap<Integer, String>();

	private L1Favorite() {
	}

	public static L1CommandExecutor getInstance() {
		return new L1Favorite();
	}

	@Override
	public void execute(L1PcInstance pc, String cmdName, String arg) {
		try {
			if (!_faviCom.containsKey(pc.getId())) {
				_faviCom.put(pc.getId(), "");
			}
			String faviCom = _faviCom.get(pc.getId());
			if (arg.startsWith("셋팅")) {
				// 커멘드의 등록
				StringTokenizer st = new StringTokenizer(arg);
				st.nextToken();
				if (!st.hasMoreTokens()) {
					SC_SystemMessage.send(pc, "커멘드가 없습니다. ");
					return;
				}
				StringBuilder cmd = new StringBuilder();
				String temp = st.nextToken(); // 커멘드 타입
				if (temp.equalsIgnoreCase(cmdName)) {
					SC_SystemMessage.send(pc, cmdName + " 자신은 등록할 수 없습니다. ");
					return;
				}
				cmd.append(temp + " ");
				while (st.hasMoreTokens()) {
					cmd.append(st.nextToken() + " ");
				}
				faviCom = cmd.toString().trim();
				_faviCom.put(pc.getId(), faviCom);
				SC_SystemMessage.send(pc, faviCom + " 를 등록했습니다. ");
			} else if (arg.startsWith("보기")) {
				SC_SystemMessage.send(pc, "현재의 등록 커멘드: " + faviCom);
			} else if (faviCom.isEmpty()) {
				SC_SystemMessage.send(pc, "등록하고 있는 커멘드가 없습니다. ");
			} else {
				StringBuilder cmd = new StringBuilder();
				StringTokenizer st = new StringTokenizer(arg);
				StringTokenizer st2 = new StringTokenizer(faviCom);
				while (st2.hasMoreTokens()) {
					String temp = st2.nextToken();
					if (temp.startsWith("%")) {
						cmd.append(st.nextToken() + " ");
					} else {
						cmd.append(temp + " ");
					}
				}
				while (st.hasMoreTokens()) {
					cmd.append(st.nextToken() + " ");
				}
				SC_SystemMessage.send(pc, cmd + " 를 실행합니다. ");
				GMCommands.getInstance().handleCommands(pc, cmd.toString());
			}
		} catch (Exception e) {
			SC_SystemMessage.send(pc, cmdName + " 셋팅 [커멘드명] " + "| " + cmdName + " 보기 | " + cmdName
					+ " [인수] 라고 입력해 주세요. ");
			e.printStackTrace();
		}
	}
}
