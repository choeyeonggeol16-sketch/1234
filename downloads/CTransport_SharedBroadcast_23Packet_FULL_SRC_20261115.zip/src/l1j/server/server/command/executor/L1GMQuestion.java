/*
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2, or (at your option)
 * any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.   See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
 * 02111-1307, USA.
 *
 * http://www.gnu.org/copyleft/gpl.html
 */
package l1j.server.server.command.executor;

//import java.util.logging.Logger;
import l1j.server.server.model.L1Question;
import l1j.server.server.model.Instance.L1PcInstance;
import l1j.server.server.model.network.core.sc.packet.SC_SystemMessage;

public class L1GMQuestion implements L1CommandExecutor {
	//private static Logger _log = Logger.getLogger(L1GMQuestion.class.getName());

	private L1GMQuestion() {
	}

	public static L1CommandExecutor getInstance() {
		return new L1GMQuestion();
	}

	@Override
	public void execute(L1PcInstance pc, String cmdName, String arg) {
		try{
			if(L1Question.mainstart){
				SC_SystemMessage.send(pc, "현재 설문조사가 진행중입니다.");
				SC_SystemMessage.send(pc, "진행중인 설문 내용 : " + L1Question.maintext);
			}
			L1Question.getInstance(arg);
		}catch(Exception e){
			SC_SystemMessage.send(pc, ".설문 [설문내용] 을 입력 해주세요");
		}
	}
}
