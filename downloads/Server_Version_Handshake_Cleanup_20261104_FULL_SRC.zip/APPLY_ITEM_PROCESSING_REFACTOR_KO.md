# 아이템 처리 공통부 리팩토링 V2 — 2026-11-03

기준은 GitHub 18f7be5의 V6 + CacheD 장비 슬롯 수정본입니다.
리니지1의 아이템별 효과·사용 조건·소모량·확률·쿨타임을 유지하고,
공통 처리 책임과 임시 할당을 개선했습니다. 기존 슬롯 교체 수정도 포함합니다.

## 바뀐 구조

- InventoryTransactionOwners.java: 최대 2명의 참여자·세션·세션 번호·예약 수명을 전담합니다.
  매 사용의 ArrayList, LinkedHashMap 2개, 세션 번호 박싱 및 미사용 완료 플래그를 제거했습니다.
  참여자 순서는 기존 ID 오름차순을 보존하고 예약 반환은 원자적으로 한 번만 수행합니다.
  새로운 작업이 시작된 뒤 이전 실패 콜백이 다시 예약을 풀어버리지 않습니다.
- ItemUseTransactions.java: 1개/2개 재료의 소유권 확인, 준비, 실패 안내를 공통화했습니다.
  기존 UseDurableConsume API와 개별 효과 메서드는 유지합니다.
- CDB → User 완료 처리는 SQL 확정, 인벤토리 반영, 기존 FIFO 장벽 정리 이후 실행합니다.
  완료 효과의 장비 변경·추가 아이템 처리·캐릭터 저장이 이전 예약에 막히는 것을 방지합니다.
  SQL 실패에는 효과를 실행하지 않고, 불확정 결과/반영 실패에는 격리 처리를 유지합니다.
- 인벤토리 사전 상태 검증은 새 ItemSnapshot과 Timestamp 복사본을 만들지 않고 비교합니다.
  용량 검증의 중복 인벤토리 순회를 합쳤습니다.
- 새 지급의 중복 아이템 복사와 전체 소유권 이전 시 버려지는 복사본을 제거했습니다.
- Warehouse.transferCopy는 가변 Timestamp를 깊게 복사합니다. 준비 이미지나 제출 후 호출자의
  시간 변경이 원본 아이템/이미 제출된 이미지까지 바꾸던 공유 참조 결함을 수정했습니다.
- FIFO 키 생성 44곳에서 임시 문자열을 제거했습니다. 기존 해시와 정확히 같은 정수 키입니다.
- 일반 재사용 시간 검사에서 Calendar 생성 대신 한 번 읽은 현재 밀리초를 사용합니다.
  기존 초 단위 나눗셈, 경계의 <= 비교, 한국어 남은 시간 안내는 유지합니다.

새 스레드, 새 요청 큐, 플레이어별 대형 버퍼, 상시 ThreadLocal 캐시는 추가하지 않았습니다.

## 검증

- 전체 Java 타입 컴파일: 1,703개 성공. 기존 소스의 제거 예정 생성자 경고 5개는 그대로입니다.
- 공통 트랜잭션 회귀: 27개 시나리오 통과. 기존 소스는 공통 21개 중 16개 통과 / 5개 실패.
  실제 전체 L1InventoryTransaction, InventoryTransactionOwners, CDB와 소비 helper를 컴파일해
  실행했습니다. DB/소켓/게임 객체는 대체 객체를 사용했습니다.
- 무작위 인벤토리 계획 2,000건: 변경 전후 승인 432 / 거절 1,568과 최종 결과 해시 일치.
- FIFO 해시: 100,035건 비교. 0, 음수, Integer.MIN_VALUE/MAX_VALUE, 여러 접두어 포함.
- 기존 아이템 효과 코드 69개 파일: 검토된 공통 처리 변경을 제외한 본문과 문자열 보존 검사 통과.
- 기존 장비 슬롯 회귀 14개 및 NPC 우회·AI 동시 시야 갱신·자동사냥 대표 검사 통과.

## 임시 할당 측정

ThreadMXBean으로 JVM 3개씩, JVM당 10만 건 워밍업 후 10만 건 × 5개 표본을 측정했습니다.
소모 1개 영수증 처리의 표본 중앙값은 2,104 → 1,400바이트/건, 약 33.46% 감소했습니다.
이는 실제 트랜잭션 클래스를 게임/DB 대체 객체로 실행한 합성 측정입니다.
전체 서버 힙 사용량이 33% 감소했다는 뜻은 아닙니다. 원시 시간 값은 JIT/GC 편차가 있어
실서버 처리량 향상으로 단정하지 않습니다. 원시 로그와 JSON 요약은 validation에 있습니다.

## NC 실행 파일 참조 범위

사용자가 제공한 L2Server.exe의 SHA-256:
9940df15727ec88086cefc036d153fe18c153c9c26a5c90bafe1545de797b588

UseETCItem, RequestUseItem, OnUseItemPacket, OnReplyUseItemPacket 및 pending 관련
8개 추적 문자열의 코드 참조와 PE 예외 테이블 함수 범위를 확인했습니다.
예: OnUseItemPacket 0x973ff8, OnReplyUseItemPacket 0x957c64,
CheckAndSetPendingUseETCItem 0x999c64, CheckAndResetPendingUseETCItem 0x999d9c.
공통 역할과 요청/응답 경계의 참고 자료이며, 모든 가상 호출·실행 순서를 복원한 것은 아닙니다.
NC와의 동작/성능 동등성, 전체 아이템별 동작 완료를 주장하지 않습니다.
실행 파일 자체는 배포물에 포함하지 않았습니다.

## 적용과 재현

1. 기존 소스/JAR를 백업하고 검증 서버에서 적용합니다.
2. FULL_SRC의 src 전체를 사용하거나 PATCH의 모든 src 파일을 적용합니다.
   PATCH는 최초 사용자 V6 ZIP 기준 누적 30개 Java 파일(신규 2개 포함)입니다.
   일부 파일만 교체하면 새 helper와 호출부가 맞지 않으므로 모두 반영하세요.
3. 기존 lib, config, 데이터, DB를 보존합니다. 새 DB 마이그레이션은 없습니다.
4. JDK 21 / UTF-8로 Clean/Rebuild합니다. 기존 소스가 Java 21 Foreign Memory preview API를
   사용하므로 컴파일과 서버 실행에 --enable-preview가 필요합니다.
5. 기존 환경의 라이브러리를 임의로 바꾸지 마세요. 검증용 의존성은 tools/item_dependencies.json에
   고정되어 있고 tools/fetch_item_dependencies.py가 별도 디렉터리에 SHA-256 확인 후 받습니다.
6. 개발 환경에서:
   python3 tools/fetch_item_dependencies.py
   python3 tools/build_item_refactor.py
   python3 tests/item_processing/test_transactions.py
   python3 tests/equipment_transfer/test_equipment_transfer.py
   ITEM_DEPS_DIR로 별도 라이브러리 디렉터리를 지정할 수 있습니다.

실제 게임 데이터/실행 설정과 DB, 클라이언트가 없어 게임 기동·실 JDBC·아이템별 실제 사용은
미검증입니다. 소스 전체 컴파일과 공통부 회귀를 모든 아이템의 실게임 검증으로 대신하지 않습니다.
운영 적용 전 물약·변신·강화·상자·2재료 사용·창고·거래와 재접속 복구를 검증해야 합니다.
전면 개별 효과 재작성은 하지 않았으며, 이번 변경은 공통 구조와 확인한 공유 참조/완료 경계 결함을
개선한 버전입니다. 원본 효과 코드의 잠재 결함까지 모두 제거했다는 의미는 아닙니다.
