# 프로토콜 직접 송신 수정 적용

이 전체 소스는 아이템 사용 V3와 기존 NPC·자동사냥·스프라이트 수정에 프로토콜 직접 송신을 더한 버전입니다. PATCH 기준은 공개 V3(`afb051f`)이며 변경 Java 115개를 모두 적용해야 합니다.

기존 프로젝트 백업 → 서버 종료 → 소스 적용 → JDK 21 / UTF-8 / `--enable-preview`로 Clean/Rebuild → 같은 옵션으로 재시작하세요. DB 변경은 없습니다. 일부 class 파일만 섞으면 새 정적 API 호출에서 `NoSuchMethodError`가 날 수 있습니다.

변경 범위·측정값·검사 재현·실서버 미검증 범위는 `PROTOCOL_DIRECT_SEND_REFACTOR_20261104.md`를 확인하세요. 테스트용 대역은 `tests` 아래에만 두고 운영 소스에 복사하지 않습니다.
