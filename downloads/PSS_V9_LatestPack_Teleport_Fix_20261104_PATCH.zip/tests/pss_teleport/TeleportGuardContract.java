import l1j.server.server.model.character.pss.ClientAutomationSession;
public class TeleportGuardContract {
 static int checks;static void check(boolean ok,String why){checks++;if(!ok)throw new AssertionError(why);}
 static class Client {ClientAutomationSession session;boolean strict;boolean requiresPlayerTeleportRules(){return strict;}L1PcInstance pc;ClientAutomationSession getAutomationSession(){return session;}L1PcInstance getActiveChar(){return pc;}}
 static class CIOClient extends Client {}
 static class L1Map {boolean teleportable,escapable,ruler;boolean isTeleportable(){return teleportable;}boolean isEscapable(){return escapable;}boolean isRuler(){return ruler;}}
 static class L1ItemInstance {}
 static class Inventory {java.util.Set<Integer> ids=new java.util.HashSet<>();L1ItemInstance findItemId(int id){return ids.contains(id)?new L1ItemInstance():null;}boolean checkItem(int id){return ids.contains(id);}}
 static class L1PcInstance {boolean gm,pending,dead;int map=4,scheduled,ended;boolean allowTimer=true;final CIOClient client=new CIOClient();final L1Map loc=new L1Map();final Inventory inv=new Inventory();
  L1PcInstance(){client.pc=this;}boolean isGm(){return gm;}CIOClient getNetConnection(){return client;}int getMapId(){return map;}L1Map getMap(){return loc;}Inventory getInventory(){return inv;}
  void tpEndFinish(){ended++;pending=false;}boolean get_teleport(){return pending;}boolean tpThreadDelay(int delay){scheduled++;check(delay==200,"wrong ACK delay");return allowTimer;}
  boolean isDead(){return dead;}int get_teleport_x(){return 80;}int get_teleport_y(){return 90;}int get_teleport_map(){return 4;}
 }
 static class Config {static boolean PRISONTEL,PRISONTELS;}
 static class L1GameTimeClock {static long seconds=12*3600;static final L1GameTimeClock INSTANCE=new L1GameTimeClock();static L1GameTimeClock getInstance(){return INSTANCE;}L1GameTimeClock getGameTime(){return this;}long getSeconds(){return seconds;}}
 static class SC_ServerMessage {static int last;static void send(L1PcInstance pc,int message){last=message;}}
 static class MJRaidSpace {static final MJRaidSpace INSTANCE=new MJRaidSpace();static MJRaidSpace getInstance(){return INSTANCE;}boolean isInInstance(L1PcInstance pc){return false;}}
 static class MJInstanceSpace {static boolean isInInstance(L1PcInstance pc){return false;}}
 static class TeleportUseService {
  static final int[] TOWER_KEYS={830022,830023,830024,830025,830026,830027,830028,830029,830030,830031};
public static boolean canBypassMapRestrictions(L1PcInstance pc) {
        if (pc == null || !pc.isGm()) return false;
        final var client = pc.getNetConnection();
        final var session = client == null ? null : client.getAutomationSession();
        return client == null || !client.requiresPlayerTeleportRules()
                && (session == null || session == ClientAutomationSession.SERVER);
    }
private static boolean canRandomTeleportHere(L1PcInstance pc) {
        final int mapId = pc.getMapId();

        if (mapId >= 101 && mapId <= 110) {
            L1ItemInstance need = pc.getInventory().findItemId(TOWER_KEYS[mapId - 101]);
            L1ItemInstance alt  = pc.getInventory().findItemId(560028);
            if (need != null || alt != null) return true;
            SC_ServerMessage.send(pc, 276);
            pc.tpEndFinish();
            return false;
        }

        if (mapId >= 12852 && mapId <= 12861) {
            L1ItemInstance need = pc.getInventory().findItemId(TOWER_KEYS[mapId - 12852]);
            L1ItemInstance alt  = pc.getInventory().findItemId(4100135);
            if (need != null || alt != null) return true;
            SC_ServerMessage.send(pc, 276);
            pc.tpEndFinish();
            return false;
        }

        if (mapId == 54 && !TeleportUseService.canBypassMapRestrictions(pc)) {
            if (Config.PRISONTEL) {
                long t = L1GameTimeClock.getInstance().getGameTime().getSeconds() % 86400;
                if (t >= 60 * 60 * 20 || t <= 60 * 60 * 6) {
                    pc.tpEndFinish();
                    SC_ServerMessage.send(pc, 6648);
                    return false;
                }
                if (Config.PRISONTELS) return true;
                pc.tpEndFinish();
                SC_ServerMessage.send(pc, 276);
                return false;
            }

            if (Config.PRISONTELS) return true;

            pc.tpEndFinish();
            SC_ServerMessage.send(pc, 276);
            return false;
        }

        if (mapId >= 1708 && mapId <= 1709 && !TeleportUseService.canBypassMapRestrictions(pc)) {
            pc.tpEndFinish();
            SC_ServerMessage.send(pc, 276);
            return false;
        }

        L1Map map = pc.getMap();
        if (map.isTeleportable() || TeleportUseService.canBypassMapRestrictions(pc) || (pc.getInventory().checkItem(900111) && map.isRuler())) {
            return true;
        }
        pc.tpEndFinish();
        SC_ServerMessage.send(pc, 276);
        return false;
    }
 }
 static class CS_ReturnSummon {
public static void handle(CIOClient client) {

        if (client == null) {
            return;
        }

        final L1PcInstance pc = client.getActiveChar();

        // A late/unsolicited client ACK must not reuse an old teleport destination.
        if (pc == null || !pc.get_teleport()) {
            return;
        }

        if (!pc.tpThreadDelay(200)) {
            pc.tpEndFinish();
        }
    }
 }
 static class L1Teleport {int moves;void teleportInternal(L1PcInstance pc,int x,int y,int map){moves++;}
public void doTeleportation(L1PcInstance pc) {
		if (pc == null || !pc.get_teleport()) return;

		if (pc.isDead() && !MJRaidSpace.getInstance().isInInstance(pc) && !MJInstanceSpace.isInInstance(pc)) {
			return;
		}
		teleportInternal(pc, pc.get_teleport_x(), pc.get_teleport_y(), pc.get_teleport_map());
	}
 }
 static L1PcInstance pc(boolean gm,boolean nativePss,boolean serverAuto){L1PcInstance p=new L1PcInstance();p.gm=gm;p.client.session=nativePss?new ClientAutomationSession(2,7,4,Long.MAX_VALUE):serverAuto?ClientAutomationSession.SERVER:null;return p;}
 public static void main(String[] args){
  for(boolean gm:new boolean[]{false,true})for(boolean nativePss:new boolean[]{false,true})for(boolean server:new boolean[]{false,true})for(boolean allowed:new boolean[]{false,true}){
   L1PcInstance p=pc(gm,nativePss,server);p.loc.teleportable=allowed;boolean result=TeleportUseService.canRandomTeleportHere(p);check(result==(allowed||(gm&&!nativePss)),"GM/native map permission mismatch");check(p.ended==(result?0:1),"rejected teleport not released");
  }
  L1PcInstance late=pc(true,false,false);late.client.strict=true;check(!TeleportUseService.canRandomTeleportHere(late),"late post-stop request recovered GM bypass");
  L1PcInstance p=pc(true,true,false);p.map=54;Config.PRISONTEL=true;Config.PRISONTELS=true;L1GameTimeClock.seconds=21*3600;check(!TeleportUseService.canRandomTeleportHere(p)&&SC_ServerMessage.last==6648,"PSS bypassed prison time");L1GameTimeClock.seconds=12*3600;check(TeleportUseService.canRandomTeleportHere(p),"valid prison time denied");Config.PRISONTEL=false;Config.PRISONTELS=false;
  p=pc(true,true,false);p.map=1708;check(!TeleportUseService.canRandomTeleportHere(p),"PSS bypassed island rule");
  p=pc(true,true,false);p.map=101;check(!TeleportUseService.canRandomTeleportHere(p),"tower without key accepted");p.inv.ids.add(830022);check(TeleportUseService.canRandomTeleportHere(p),"legitimate tower key denied");
  p=pc(true,true,false);p.loc.ruler=true;p.inv.ids.add(900111);check(TeleportUseService.canRandomTeleportHere(p),"ruler-item exception changed");
  p=pc(true,true,false);CS_ReturnSummon.handle(p.client);check(p.scheduled==0&&p.ended==0,"unsolicited ACK scheduled stale destination");p.pending=true;CS_ReturnSummon.handle(p.client);check(p.scheduled==1,"valid ACK rejected");p.allowTimer=false;CS_ReturnSummon.handle(p.client);check(p.ended==1&&!p.pending,"failed timer not released");CS_ReturnSummon.handle(p.client);check(p.scheduled==2,"late ACK scheduled again");
  L1Teleport tele=new L1Teleport();tele.doTeleportation(p);check(tele.moves==0,"cancelled teleport moved");p.pending=true;tele.doTeleportation(p);check(tele.moves==1,"valid teleport did not move");p.pending=false;tele.doTeleportation(p);check(tele.moves==1,"duplicate commit reused destination");
  System.out.println("PASS teleport permission/ACK/commit guards; assertions="+checks);
 }
}
