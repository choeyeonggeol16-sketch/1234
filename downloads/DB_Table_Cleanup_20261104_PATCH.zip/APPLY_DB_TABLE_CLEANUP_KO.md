이 ZIP의 DB_TABLE_CLEANUP_20261104.md를 먼저 읽으세요.
FULL_SRC는 기존 src 폴더를 백업 후 교체하세요. 단순 덮어쓰기로는 삭제 파일이 남습니다.
PATCH는 63aca89 기준이며 deleted_files.txt 목록을 반드시 제거하세요.
JDK 21 / UTF-8 / --enable-preview로 전체 Clean/Rebuild 후 재시작하세요.
