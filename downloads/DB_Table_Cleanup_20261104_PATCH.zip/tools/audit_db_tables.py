#!/usr/bin/env python3
"""Check Java SQL table names against a schema-only manifest (never opens a DB).

Java's parser decodes Unicode escapes and constant expressions. Runtime table
families are resolved from their existing literal arrays/call sites below.
This is a table-name audit, not a SQL grammar, column or data compatibility test.
"""
from pathlib import Path
import argparse,json,re,subprocess,sys
ROOT=Path(__file__).resolve().parents[1]
START=re.compile(r'^\s*(?:select\b|(?:insert|replace)\s+(?:ignore\s+)?into\b|update\b.+\bset\b|delete\s+from\b|(?:create|alter|drop|truncate)\s+table\b|(?:from|join)\s+)',re.I|re.S)
IDENT=r'(?:`[^`]+`|[\w]+)(?:\s*\.\s*(?:`[^`]+`|[\w]+))?'
TABLE=re.compile(r'\b(?:from|join|(?:insert|replace)\s+(?:ignore\s+)?into|(?:create|alter|drop|truncate)\s+table(?:\s+if\s+(?:not\s+)?exists)?|^\s*update)\s+('+IDENT+r')',re.I)

def opaque(sql):
    expressions={}
    while '${' in sql:
        a=sql.index('${');depth=1;i=a+2
        while i<len(sql) and depth:
            if sql[i]=='{':depth+=1
            elif sql[i]=='}':depth-=1
            i+=1
        key='DYNAMIC_EXPRESSION_'+str(len(expressions))
        expressions[key]=sql[a+2:i-1];sql=sql[:a]+key+sql[i:]
    return re.sub(r"'(?:''|\\.|[^'])*'", "''",sql),expressions

def family(source,expression):
    rules={
      ('MJDogFightTicketIdManager.java','table'):r'ITEM_TABLES\s*=\s*\{([^}]+)\}',
      ('Warehouse.java','ROW_TABLE[type]'):r'ROW_TABLE\s*=\s*\{([^}]+)\}',
      ('L1BoardPost.java','table'):r'String\s+TABLE_\w+\s*=\s*("[^"\n]+")',
      ('NpcShopManager.java','table'):r'load(?:Table|Spawns)\(\w+,\s*("[^"\n]+")\)',
      ('SC_AttendanceBonusGroupInfo.java','table'):r'createAttendanceBonusGroup\(\w+,\s*("[^"\n]+")\)',
    }
    rule=rules.get((source.name,expression))
    if rule is None:return None
    values=[]
    for block in re.findall(rule,source.read_text()):values.extend(x for x in re.findall(r'"([^"\n]*)"',block) if x)
    return sorted(set(values)) or None

def audit(root,catalog,schema):
    known={x.casefold() for x in schema};references={};unresolved=[];system=set();families={}
    for row in catalog:
        sql,expressions=opaque(row['sql'])
        if not START.search(sql):continue
        matches=[m[1] for m in TABLE.finditer(sql)]
        # Also include legacy comma-separated FROM lists (with optional aliases).
        comma=re.compile(r'\bfrom\s+('+IDENT+r'(?:\s+(?:as\s+)?\w+)?(?:\s*,\s*'+IDENT+r'(?:\s+(?:as\s+)?\w+)?)+)',re.I)
        for group in comma.finditer(sql):
            matches.extend(re.findall(r'(?:^|,)\s*('+IDENT+r')',group[1]))
        for token in dict.fromkeys(matches):
            name=re.sub(r'[`\s]','',token);names=[name]
            where={'file':row['file'],'line':row['line']}
            if name in expressions:
                expr=expressions[name];names=family(root/row['file'],expr)
                if not names:unresolved.append(dict(where,expression=expr));continue
                families[row['file']+':'+expr]=names
            for name in names:
                if '.' in name and name.split('.')[0].casefold() in {'information_schema','mysql','performance_schema','sys'}:
                    system.add(name);continue
                if name.casefold()=='select':continue # FROM (SELECT...) subqueries
                references.setdefault(name.casefold(),[]).append(where)
    missing={name:places for name,places in references.items() if name not in known}
    return {'schema_table_count':len(known),'referenced_table_count':len(references),
            'missing':missing,'unresolved':unresolved,'dynamic_families':families,
            'system_tables':sorted(system),'references':references}

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--source-root',type=Path,default=ROOT)
    p.add_argument('--schema',type=Path,default=ROOT/'tools/db_schema/net_tables.json')
    p.add_argument('--output',type=Path,default=ROOT/'validation/db_table_audit.json')
    args=p.parse_args()
    result=subprocess.run(['java',str(ROOT/'tools/db_schema/SqlCatalog.java'),str(args.source_root.resolve())],capture_output=True,text=True,check=True)
    report=audit(args.source_root,json.loads(result.stdout),json.loads(args.schema.read_text()))
    args.output.parent.mkdir(parents=True,exist_ok=True)
    args.output.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
    print('Schema tables:',report['schema_table_count'],'Referenced tables:',report['referenced_table_count'],
          'Missing:',len(report['missing']),'Unresolved:',len(report['unresolved']))
    for name,places in report['missing'].items():print('MISSING',name,places[:2])
    for row in report['unresolved']:print('UNRESOLVED',row)
    if report['missing'] or report['unresolved']:return 1
    print('PASS static SQL, system-schema exclusions and',len(report['dynamic_families']),'runtime table families')
    return 0
if __name__=='__main__':sys.exit(main())
