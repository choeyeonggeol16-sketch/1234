import java.nio.file.*;import java.util.*;import javax.tools.*;import com.sun.source.tree.*;import com.sun.source.util.*;
class SqlCatalog {
 static Map<String,String> constants=new HashMap<>();static CompilationUnitTree unit;static SourcePositions pos;static String source,owner;
 static String q(Object x){return x==null?"null":"\""+x.toString().replace("\\","\\\\").replace("\"","\\\"").replace("\n","\\n").replace("\r","\\r").replace("\t","\\t")+"\"";}
 static String value(Tree t,Map<String,String> local){
  if(t==null)return "";
  if(t instanceof LiteralTree l)return String.valueOf(l.getValue());
  if(t instanceof ParenthesizedTree p)return value(p.getExpression(),local);
  if(t instanceof BinaryTree b&&b.getKind()==Tree.Kind.PLUS)return value(b.getLeftOperand(),local)+value(b.getRightOperand(),local);
  if(t instanceof IdentifierTree i)return local.getOrDefault(i.getName().toString(),constants.getOrDefault(owner+"."+i.getName(),"${"+i.getName()+"}"));
  if(t instanceof MemberSelectTree m)return constants.getOrDefault(m.toString(),"${"+m+"}");
  if(t instanceof NewClassTree n&&(n.getIdentifier().toString().contains("StringBuilder")||n.getIdentifier().toString().contains("StringBuffer")))return !n.getArguments().isEmpty()&&n.getArguments().getFirst() instanceof LiteralTree l&&l.getValue() instanceof String?value(n.getArguments().getFirst(),local):"";
  if(t instanceof MethodInvocationTree m&&m.getMethodSelect() instanceof MemberSelectTree s){
   if(s.getIdentifier().contentEquals("append"))return value(s.getExpression(),local)+value(m.getArguments().getFirst(),local);
   if(s.getIdentifier().contentEquals("toString"))return value(s.getExpression(),local);
   if(s.getIdentifier().contentEquals("format")&&m.getArguments().size()>0){String v=value(m.getArguments().getFirst(),local);for(int i=1;i<m.getArguments().size();i++)v=v.replaceFirst("%[sd]",java.util.regex.Matcher.quoteReplacement(value(m.getArguments().get(i),local)));return v;}
  }
  return "${"+t.toString().replace('\n',' ')+'}';
 }
 public static void main(String[] args)throws Exception{
  Path root=Path.of(args[0]);List<String> output=new ArrayList<>();List<CompilationUnitTree> units=new ArrayList<>();
  try(var fm=ToolProvider.getSystemJavaCompiler().getStandardFileManager(null,null,null)){
   var fs=Files.walk(root.resolve("src")).filter(p->p.toString().endsWith(".java")).map(Path::toFile).toList();
   var task=(JavacTask)ToolProvider.getSystemJavaCompiler().getTask(null,fm,null,List.of("-proc:none"),null,fm.getJavaFileObjectsFromFiles(fs));task.parse().forEach(units::add);pos=Trees.instance(task).getSourcePositions();
   for(int round=0;round<3;round++)for(var u:units){unit=u;new TreeScanner<Void,Void>(){String cls;@Override public Void visitClass(ClassTree c,Void x){String old=cls;cls=c.getSimpleName().toString();super.visitClass(c,x);cls=old;return null;}@Override public Void visitVariable(VariableTree v,Void x){if(v.getType()!=null&&v.getType().toString().equals("String")&&v.getInitializer()!=null){owner=cls;String val=value(v.getInitializer(),Map.of());if(!val.contains("${"))constants.put(cls+"."+v.getName(),val);}return super.visitVariable(v,x);}}.scan(u,null);}
   for(var u:units){unit=u;source=Files.readString(Path.of(u.getSourceFile().toUri()));String file=root.relativize(Path.of(u.getSourceFile().toUri())).toString();Set<String> seen=new HashSet<>();Map<String,String> local=new HashMap<>();
    new TreePathScanner<Void,Void>(){
     @Override public Void visitClass(ClassTree c,Void x){String old=owner;owner=c.getSimpleName().toString();super.visitClass(c,x);owner=old;return null;}
     @Override public Void visitMethod(MethodTree m,Void x){Map<String,String> prior=new HashMap<>(local);if(getCurrentPath().getParentPath().getLeaf() instanceof ClassTree c&&!c.getSimpleName().toString().isEmpty())local.clear();super.visitMethod(m,x);local.clear();local.putAll(prior);return null;}
     @Override public Void visitExpressionStatement(ExpressionStatementTree e,Void x){Tree t=e.getExpression();if(t instanceof MethodInvocationTree m&&m.getMethodSelect().toString().contains(".append")){Tree root=m;while(root instanceof MethodInvocationTree call&&call.getMethodSelect() instanceof MemberSelectTree sel)root=sel.getExpression();if(root instanceof IdentifierTree id&&local.containsKey(id.getName().toString()))local.put(id.getName().toString(),value(t,local));}return super.visitExpressionStatement(e,x);}
     @Override public Void visitVariable(VariableTree v,Void x){if(v.getType()!=null&&(v.getType().toString().equals("String")||v.getType().toString().equals("StringBuilder"))&&v.getInitializer()!=null)local.put(v.getName().toString(),value(v.getInitializer(),local));return super.visitVariable(v,x);}
     void add(Tree t){String sql=value(t,local);if(!sql.matches("(?is).*\\b(?:select|insert|replace|update|delete|from|join|create\\s+table|alter\\s+table|drop\\s+table|truncate)\\b.*"))return;long a=pos.getStartPosition(unit,t);String key=a+"|"+sql;if(!seen.add(key))return;output.add("{\"file\":"+q(file)+",\"line\":"+u.getLineMap().getLineNumber(a)+",\"sql\":"+q(sql)+"}");}
     @Override public Void visitLiteral(LiteralTree l,Void x){if(l.getValue() instanceof String){TreePath p=getCurrentPath();while(p.getParentPath()!=null&&p.getParentPath().getLeaf() instanceof BinaryTree b&&b.getKind()==Tree.Kind.PLUS)p=p.getParentPath();add(p.getLeaf());}return null;}
     @Override public Void visitMethodInvocation(MethodInvocationTree m,Void x){String name=m.getMethodSelect().toString();if(name.matches(".*(?:prepareStatement|executeQuery|executeUpdate|executeLargeUpdate|execute|format)$")&&!m.getArguments().isEmpty())add(m.getArguments().getFirst());return super.visitMethodInvocation(m,x);}
    }.scan(u,null);
   }
  }System.out.println("["+String.join(",",output)+"]");
 }
}
