package l1j.server.server.model.character.autohunt;

import java.util.concurrent.ThreadLocalRandom;

import l1j.server.MJDungeonTimer.DungeonTimeInformation;
import l1j.server.MJDungeonTimer.Loader.DungeonTimeInformationLoader;
import l1j.server.MJDungeonTimer.Progress.DungeonTimeProgress;
import l1j.server.server.model.Instance.L1PcInstance;
import l1j.server.server.model.character.autohunt.ai.action.AHController;

public class AHReturnManager {
	
    private static final AHReturnManager instance = new AHReturnManager();
    public static AHReturnManager getInstance() { return instance; }

    // 오만의 탑 (101~110) 층별 대표 좌표
    private static final int[][] OMAN_COORDS = {
        {0, 0},
        {32735, 32798}, {32726, 32803}, {32726, 32803}, {32613, 32863}, {32597, 32867},
        {32607, 32865}, {32618, 32866}, {32598, 32867}, {32609, 32866}, {32726, 32803}
    };

    // 지배의 탑 (12852~12862) 층별 대표 좌표 
    private static final int[][] DOMINION_COORDS = {
        {0, 0},
        {32728, 32800}, // 1층 (12852)
        {32728, 32800}, // 2층 (12853)
        {32728, 32803}, // 3층 (12854)
        {32596, 32863}, // 4층 (12855)
        {32593, 32866}, // 5층 (12856)
        {32602, 32865}, // 6층 (12857)
        {32603, 32866}, // 7층 (12858)
        {32593, 32866}, // 8층 (12859)
        {32602, 32866}, // 9층 (12860)
        {32732, 32802}, // 10층 (12861)
        {32639, 32796}  // 정상 (12862)
    };

    // [전층 영구 부적 정의]
    private static final int OMAN_ILLUSION_AMULET_ID = 560028;   
    private static final int DOMINION_ILLUSION_AMULET_ID = 4100135; 

    /**
     * 사냥터 복귀 메인 핸들러
     */
    public void returnToHuntingGround(L1PcInstance pc) {
        if (pc == null) return;

        // 사냥터 백업 맵 ID
        short mapId = (short) (pc.getAutoHuntMapId() > 0 ? pc.getAutoHuntMapId() : pc.getAutoMapId());

        // 던전 제한 및 이벤트 스폰 체크 
        if (!checkDungeonAvailability(pc, mapId)) return;

        int targetX, targetY;
        int rx = ThreadLocalRandom.current().nextInt(3);
        int ry = ThreadLocalRandom.current().nextInt(3);

        // --- 오만의 탑 (101 ~ 110) ---
        if (mapId >= 101 && mapId <= 110) {
            int floor = mapId - 100; // 1 ~ 10층
            int scrollId = 830000 + floor;
            int normalAmuletId = 830011 + floor;   // 오만의 탑 층별 이동 부적 (830012 ~ 830021)
            int dominantAmuletId = 830021 + floor; // 오만의 탑 층별 지배 부적 (830022 ~ 830031)

            // 환상 오만 부적 -> 2. 층별 일반 부적 -> 3. 층별 지배 부적 -> 4. 이동 주문서 차감
            if (!validateAndConsumeOmanItem(pc, normalAmuletId, dominantAmuletId, scrollId, "오만의 탑 " + floor + "층")) return;
            targetX = OMAN_COORDS[floor][0] + rx;
            targetY = OMAN_COORDS[floor][1] + ry;
        } 
        // ---  지배의 탑 (12852 ~ 12862) ---
        else if (mapId >= 12852 && mapId <= 12862) {
            int floor = mapId - 12851; // 1 ~ 11(정상)
            int scrollId = 4100165 + floor;

            // 환상 지배 부적 -> 2. 이동 주문서 차감
            if (!validateAndConsumeDominionItem(pc, scrollId, "지배의 탑 " + floor + "층")) return;

            targetX = DOMINION_COORDS[floor][0] + rx;
            targetY = DOMINION_COORDS[floor][1] + ry;
        }
        // --- 기란감옥 계열 (53 ~ 56) ---
        else if (mapId >= 53 && mapId <= 56) {
        	
        	  AHController.set(
                      pc,
                      AHController.ACTION_MOVE_GIRAN);
            return; 
        }
        else if (mapId >= 15403 && mapId <= 15404) {
        	  AHController.set(
                      pc,
                      AHController.ACTION_MOVE_DOMINION_BARRIER);
            return; 
        }
        // --- 기타 미등록 사냥터 ---
        else {
            exitAutoHunt(pc, "자동 복귀가 지원되지 않는 사냥터이므로 다시 설정바랍니다.");
            return;
        }
        // 최종 사출 실행
        pc.start_teleport(targetX, targetY, mapId, pc.getHeading(), 169, true, true);
        AHController.set(
                pc,
                AHController.ACTION_MOVE);
        pc.setAutoDelayTime(System.currentTimeMillis() + 3000);
    }

    /**
     * 던전 이용 가능 여부 검사
     */
    public boolean checkDungeonAvailability(L1PcInstance pc, short mapId) {
        if (!check_auto_dungeon(pc, mapId)) {
            exitAutoHunt(pc, "던전 이용시간이 다 되어 자동사냥을 종료합니다.");
            return false;
        }


        return true;
    }
    
    public static boolean check_auto_dungeon(L1PcInstance pc, int targetMapId) {
        DungeonTimeInformation dtInfo = DungeonTimeInformationLoader.getInstance().from_map_id(targetMapId);
        if (dtInfo != null) {
            DungeonTimeProgress<?> progress = pc.get_progress(dtInfo);
            if (progress != null && progress.get_remain_seconds() <= 0)
                return false;
        }
        return true;
    }

    /**
     * 오만의 탑 아이템 검사  환상 오만 부적 -> 2. 해당층 부적 -> 3. 해당층 지배 부적 -> 4. 이동 주문서
     */
    private boolean validateAndConsumeOmanItem(L1PcInstance pc, int normalAmuletId, int dominantAmuletId, int scrollId, String mapName) {
        // 환상의 오만 부적(560028) 영구 통과
        if (pc.getInventory().hasItemDirect(OMAN_ILLUSION_AMULET_ID)) {
            return true;
        }

        //  해당 층 일반 이동 부적 or 지배 부적 영구 통과
        if (pc.getInventory().hasItemDirect(normalAmuletId) || pc.getInventory().hasItemDirect(dominantAmuletId)) {
            return true;
        }

        // 부적이 전혀 없을 때 층별 이동 주문서 1개 소모
        if (pc.getInventory().consumeItem(scrollId, 1)) {
            return true;
        }

        // 아이템 부족 시 자사 종료
        exitAutoHunt(pc, mapName + " 이동 부적 또는 주문서가 없어 자동사냥을 종료합니다.");
        return false;
    }

    /**
     * 지배의 탑 아이템 검사 (1. 환상 지배 부적 -> 2. 이동 주문서)
     */
    private boolean validateAndConsumeDominionItem(L1PcInstance pc, int scrollId, String mapName) {
        //  환상의 지배 부적(4100135) 영구 통과
        if (pc.getInventory().hasItemDirect(DOMINION_ILLUSION_AMULET_ID)) {
            return true;
        }

        // 환상 지배 부적이 없을 때 층별 지배 주문서 1개 소모
        if (pc.getInventory().consumeItem(scrollId, 1)) {
            return true;
        }

        // 아이템 부족 시 자사 종료
        exitAutoHunt(pc, mapName + " 환상의 지배 부적 또는 주문서가 없어 자동사냥을 종료합니다.");
        return false;
    }

    /**
     * 자사 종료 및 메시지 발송 공통화
     */
    private void exitAutoHunt(L1PcInstance pc, String message) {
        AHExecutor.getInstance().sendautomsg(pc, message);
    }
}