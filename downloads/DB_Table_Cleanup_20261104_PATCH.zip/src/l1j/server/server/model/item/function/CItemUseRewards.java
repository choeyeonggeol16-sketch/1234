package l1j.server.server.model.item.function;

import java.sql.Timestamp;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import l1j.server.server.datatables.ExpTable;
import l1j.server.server.storage.CacheD;
import l1j.server.server.storage.mysql.MySqlCharacterStorage.CharacterSnapshot;
import l1j.server.server.model.L1Clan;
import l1j.server.server.model.network.core.sc.packet.SC_InventoryIcon;
import l1j.server.server.model.network.core.sc.packet.SC_SkillSound;

import l1j.server.server.model.Instance.L1DollInstance;
import l1j.server.server.model.network.core.sc.packet.SC_PacketBox;
import l1j.server.server.utils.CommonUtil;

import java.util.concurrent.ThreadLocalRandom;

import l1j.server.Config;
import l1j.server.server.IdFactory;
import l1j.server.server.datatables.ItemTable;
import l1j.server.server.datatables.ResolventTable;
import l1j.server.server.model.L1InventoryTransaction;
import l1j.server.server.model.L1Inventory;
import l1j.server.server.model.L1ItemDelay;
import l1j.server.server.model.network.core.sc.packet.SC_ServerMessage;
import l1j.server.server.templates.L1Item;
import l1j.server.server.templates.L1EtcItem;
import l1j.server.server.datatables.NpcTable;
import l1j.server.server.model.L1World;
import l1j.server.server.model.Instance.L1DoorInstance;
import l1j.server.server.model.Instance.L1ItemInstance;
import l1j.server.server.model.Instance.L1NpcInstance;
import l1j.server.server.model.Instance.L1PcInstance;
import l1j.server.server.model.character.skill.L1SkillId;
import l1j.server.server.model.character.skill.L1SkillUse;
import l1j.server.server.model.network.core.sc.packet.SC_SystemMessage;
import l1j.server.server.model.network.core.sc.packet.SC_PacketBox;
import l1j.server.server.utils.L1SpawnUtil;

import static l1j.server.server.model.item.function.CItemUse.*;
import l1j.server.server.model.item.function.CItemUse.Result;

final class CItemUseRewards {
    private CItemUseRewards() {}

    static void useRandomMoneyBox(L1PcInstance pc, L1ItemInstance box) {
        if (pc == null || box == null) return;
        final int id = box.getItemId();
        final int rewardId = id == 3000194 ? 40308 : 41302;
        final int roll = CommonUtil.random(100);
        final int count;
        switch (id) {
        case 3000194:
            count = roll <= 10 ? CommonUtil.random(10000, 15000)
                    : CommonUtil.random(15000, 20000);
            break;
        case 41299:
            count = roll <= 7 ? CommonUtil.random(500000, 600000)
                    : CommonUtil.random(300000, 400000);
            break;
        case 41300:
            count = roll <= 7 ? CommonUtil.random(5000000, 6000000)
                    : CommonUtil.random(3000000, 4000000);
            break;
        case 41303:
            count = roll <= 7 ? CommonUtil.random(600000, 700000)
                    : CommonUtil.random(400000, 500000);
            break;
        case 41304:
            count = roll <= 7 ? CommonUtil.random(6000000, 7000000)
                    : CommonUtil.random(4000000, 5000000);
            break;
        default: return;
        }
        // Preserve the original <=0.3 check against the integer 0..99 roll.
        final boolean attendanceBonus = id == 3000194 && CommonUtil.random(100) <= 0.3d;
        if (count <= 0) return;
        try (L1InventoryTransaction tx = L1InventoryTransaction.begin(pc, box.getId())) {
            if (!tx.debit(box, 1)) return;
            if (tx.grant(rewardId, count) == null) {
                SC_SystemMessage.send(pc, "보상을 소지할 수 없습니다.");
                return;
            }
            if (attendanceBonus && tx.grant(3000176, CommonUtil.random(1, 1)) == null) {
                SC_SystemMessage.send(pc, "보상을 소지할 수 없습니다.");
                return;
            }
            tx.onFailure(() -> SC_SystemMessage.send(pc, "상자 보상이 확정되지 않았습니다."));
            tx.commitAfterInventoryRelease(() -> { });
        } catch (RuntimeException failure) {
            SC_SystemMessage.send(pc, "아이템 처리가 진행 중이거나 상자 보상을 소지할 수 없습니다.");
        }
    }

    static void useLevelExpPotion(L1PcInstance pc, L1ItemInstance item) {
        if (pc == null || item == null || item.getItemId() != 111556
                || pc.getInventory().getItem(item.getId()) != item)
            return;
        final int level = pc.getLevel();
        if (Config.STANDBY_SERVER || level <= 0 || level >= Config.LIMITLEVEL
                || level >= ExpTable.MAX_LEVEL) {
            SC_SystemMessage.send(pc, "지금 레벨 구간에서는 사용할 수 없습니다.");
            return;
        }
        final int beforeExp = pc.getExp();
        final long calculated;
        if (level < 51) {
            final long level51 = (long) ExpTable.getExpByLevel(51) - 1L;
            calculated = level51 + level51 / 100L;
        } else {
            calculated = (long) ExpTable.getExpByLevel(level + 1) + 99L;
        }
        final int afterExp = (int) Math.min(ExpTable.MAX_EXP, calculated);
        if (afterExp <= beforeExp) return;
        final int difference = afterExp - beforeExp;
        try {
            // Same pre-receipt character snapshot ordering as the existing
            // experience-recovery path. No JDBC runs on the game owner.
            CacheD.getInstance().saveCharacter(new CharacterSnapshot(pc));
            try (L1InventoryTransaction tx = L1InventoryTransaction.begin(pc, item.getId())) {
                if (!tx.debit(item, 1)) return;
                tx.requireTables("characters");
                tx.sql(con -> {
                    try (PreparedStatement update = con.prepareStatement(
                            "UPDATE characters SET Exp=? WHERE objid=? AND level=? AND Exp=?")) {
                        update.setInt(1, afterExp);
                        update.setInt(2, pc.getId());
                        update.setInt(3, level);
                        update.setInt(4, beforeExp);
                        if (update.executeUpdate() != 1)
                            throw new SQLException("Level EXP potion preimage changed: " + pc.getId());
                    }
                });
                tx.onFailure(() -> SC_SystemMessage.send(pc, "경험치 물약 저장에 실패했습니다."));
                tx.commitAfterInventoryRelease(() -> {
                    if (pc.getExp() != beforeExp || pc.getLevel() != level)
                        throw new IllegalStateException("Level EXP potion live preimage changed");
                    pc.addExp(difference);
                });
            }
        } catch (RuntimeException failure) {
            SC_SystemMessage.send(pc, "경험치 물약 사용을 확정하지 못했습니다.");
        }
    }

    static void useFixedExpPotion(L1PcInstance pc, L1ItemInstance item, int expReward) {
        if (pc == null || item == null || expReward <= 0
                || (item.getItemId() != 700000 && item.getItemId() != 4100074
                    && item.getItemId() != 4100075)
                || pc.getInventory().getItem(item.getId()) != item) return;
        final int level = pc.getLevel();
        if (Config.STANDBY_SERVER || level <= 0 || level >= Config.LIMITLEVEL
                || level >= ExpTable.MAX_LEVEL) {
            SC_SystemMessage.send(pc, "지금 레벨 구간에서는 사용할 수 없습니다.");
            return;
        }
        // Re-evaluate the requested potion's access rule on the same CIO owner.
        if ((item.getItemId() == 700000 && level > Config.ExpPo2)
                || (item.getItemId() == 4100074 && level > Config.ExpPo)
                || (item.getItemId() == 4100075 && level < Config.ExpPo1)) return;
        final int beforeExp = pc.getExp();
        final int afterExp = (int) Math.min((long) ExpTable.MAX_EXP,
                (long) beforeExp + (long) expReward);
        if (afterExp <= beforeExp) return;
        final int difference = afterExp - beforeExp;
        try {
            CacheD.getInstance().saveCharacter(new CharacterSnapshot(pc));
            try (L1InventoryTransaction tx = L1InventoryTransaction.begin(pc, item.getId())) {
                if (!tx.debit(item, 1)) return;
                tx.requireTables("characters");
                tx.sql(con -> {
                    try (PreparedStatement update = con.prepareStatement(
                            "UPDATE characters SET Exp=? WHERE objid=? AND level=? AND Exp=?")) {
                        update.setInt(1, afterExp);
                        update.setInt(2, pc.getId());
                        update.setInt(3, level);
                        update.setInt(4, beforeExp);
                        if (update.executeUpdate() != 1)
                            throw new SQLException("Fixed EXP potion preimage changed: " + pc.getId());
                    }
                });
                tx.onFailure(() -> SC_SystemMessage.send(pc, "경험치 물약 저장에 실패했습니다."));
                tx.commitAfterInventoryRelease(() -> {
                    if (pc.getExp() != beforeExp || pc.getLevel() != level)
                        throw new IllegalStateException("Fixed EXP potion live preimage changed");
                    pc.addExp(difference);
                });
            }
        } catch (RuntimeException failure) {
            SC_SystemMessage.send(pc, "경험치 물약 사용을 확정하지 못했습니다.");
        }
    }

    static void useClassGiftBundle(L1PcInstance pc, L1ItemInstance voucher) {
        if (pc == null || voucher == null || voucher.getItemId() != 5922794
                || pc.getInventory().getItem(voucher.getId()) != voucher) return;
        final int classType = pc.getType();
        final int classReward;
        switch (classType) {
        case 0: case 1: case 4: case 5: case 7:
            classReward = 600209;
            break;
        case 2:
            classReward = pc.getAbility().getStr() < 40 ? 600210 : 600209;
            break;
        case 3: case 6:
            classReward = 600211;
            break;
        default:
            return;
        }
        try (L1InventoryTransaction tx = L1InventoryTransaction.begin(pc, voucher.getId())) {
            if (!tx.debit(voucher, 1)) return;
            if (tx.grant(classReward, 1) == null) {
                SC_SystemMessage.send(pc, "보상 아이템을 소지할 수 없습니다.");
                return;
            }
            for (int reward : CLASS_GIFT_COMMON) {
                if (tx.grant(reward, 1) == null) {
                    SC_SystemMessage.send(pc, "보상 아이템을 소지할 수 없습니다.");
                    return;
                }
            }
            tx.onFailure(() -> SC_SystemMessage.send(pc, "클래스 보상이 확정되지 않았습니다."));
            tx.commitAfterInventoryRelease(() -> { });
        } catch (RuntimeException failure) {
            SC_SystemMessage.send(pc, "아이템 처리가 진행 중이거나 클래스 보상을 받을 수 없습니다.");
        }
    }

    static void useGuardianFlute(L1PcInstance pc, L1ItemInstance flute) {
        if (pc == null || flute == null || flute.getItemId() != 40493
                || pc.getInventory().getItem(flute.getId()) != flute) return;
        boolean guardianPresent = false;
        for (l1j.server.server.model.L1Object visible : pc.getKnownObjects()) {
            if (visible instanceof l1j.server.server.model.Instance.L1GuardianInstance guardian
                    && guardian.getNpcTemplate() != null
                    && guardian.getNpcTemplate().get_npcId() == 70850) {
                guardianPresent = true;
                break;
            }
        }
        if (!guardianPresent) {
            l1j.server.server.model.network.core.sc.packet.SC_Sound.send(pc, 165);
            l1j.server.server.model.network.core.sc.packet.SC_Sound.broadcast(pc, 165);
            return;
        }
        try (L1InventoryTransaction tx = L1InventoryTransaction.begin(pc, flute.getId())) {
            if (!tx.debit(flute, 1)) return;
            if (tx.grant(88, 1) == null) {
                SC_SystemMessage.send(pc, "보상을 소지할 수 없습니다.");
                return;
            }
            tx.onFailure(() -> SC_SystemMessage.send(pc, "플룻 보상이 확정되지 않았습니다."));
            tx.commitAfterInventoryRelease(() -> {
                l1j.server.server.model.network.core.sc.packet.SC_Sound.send(pc, 165);
                l1j.server.server.model.network.core.sc.packet.SC_Sound.broadcast(pc, 165);
            });
        } catch (RuntimeException failure) {
            SC_SystemMessage.send(pc, "아이템 처리가 진행 중이거나 플룻 보상을 받을 수 없습니다.");
        }
    }

    static void useBurnedCharm(L1PcInstance pc, L1ItemInstance charm) {
        if (pc == null || charm == null || pc.getInventory().getItem(charm.getId()) != charm) return;
        final int id = charm.getItemId();
        final int min;
        final int max;
        if (id == 4100120) {
            min = Config.불멸가호아덴;
            max = Config.불멸가호아덴1;
        } else if (id == 4100119) {
            min = Config.불멸가호아덴2;
            max = Config.불멸가호아덴22;
        } else return;
        if (min <= 0 || max < min || max > L1Inventory.MAX_AMOUNT) {
            SC_SystemMessage.send(pc, "불멸의 가호 보상 설정을 확인해 주세요.");
            return;
        }
        try (L1InventoryTransaction tx = L1InventoryTransaction.begin(pc, charm.getId())) {
            if (!tx.debit(charm, 1)) return;
            final int reward = CommonUtil.random(min, max);
            if (tx.grant(40308, reward) == null) {
                SC_SystemMessage.send(pc, "아데나를 소지할 수 없습니다.");
                return;
            }
            tx.onFailure(() -> SC_SystemMessage.send(pc, "불멸의 가호 보상이 확정되지 않았습니다."));
            tx.commitAfterInventoryRelease(() -> { });
        } catch (RuntimeException failure) {
            SC_SystemMessage.send(pc, "아이템 처리가 진행 중이거나 보상을 소지할 수 없습니다.");
        }
    }

    static void useRandomEnchantBox(L1PcInstance pc, L1ItemInstance box) {
        if (pc == null || box == null || pc.getInventory().getItem(box.getId()) != box) return;
        final int[] rewards;
        final int[] enchants;
        final int boxId = box.getItemId();
        switch (boxId) {
        case 3000039:
            rewards = ENCHANT_BOX_3000039_REWARDS;
            enchants = ENCHANT_BOX_3000039_ENCHANTS;
            break;
        case 3000169:
            rewards = ENCHANT_BOX_3000169_REWARDS;
            enchants = ENCHANT_BOX_3000169_ENCHANTS;
            break;
        case 718:
            rewards = ENCHANT_BOX_718_REWARDS;
            enchants = ENCHANT_BOX_718_ENCHANTS;
            break;
        default:
            return;
        }
        try (L1InventoryTransaction tx = L1InventoryTransaction.begin(pc, box.getId())) {
            if (!tx.debit(box, 1)) return;
            final ThreadLocalRandom random = ThreadLocalRandom.current();
            final int itemId = rewards[random.nextInt(rewards.length)];
            final int enchant = enchants[random.nextInt(enchants.length)];
            final L1Item template = ItemTable.getInstance().getTemplate(itemId);
            if (template == null) {
                SC_SystemMessage.send(pc, "상자 보상 아이템 설정을 확인해 주세요.");
                return;
            }
            // Build the reward with its enchant before granting, so a stack
            // merge cannot be performed using a different enchant level.
            final L1ItemInstance rewardImage = new L1ItemInstance(template, 1);
            rewardImage.setId(IdFactory.getInstance().nextId());
            rewardImage.setBless(template.getBless());
            rewardImage.setIdentified(true);
            rewardImage.setEnchantLevel(enchant);
            final L1ItemInstance reward = tx.grant(rewardImage);
            if (reward == null) {
                SC_SystemMessage.send(pc, "보상을 소지할 수 없습니다.");
                return;
            }
            tx.onFailure(() -> SC_SystemMessage.send(pc, "상자 보상이 확정되지 않았습니다."));
            tx.commitAfterInventoryRelease(() -> {
                if (boxId == 3000039) {
                    SC_SystemMessage.send(pc, "아이템을 [획득] 하였습니다.");
                } else {
                    SC_SkillSound.send(pc, pc.getId(), 11308);
                }
            });
        } catch (RuntimeException failure) {
            SC_SystemMessage.send(pc, "아이템 처리가 진행 중이거나 상자 보상을 소지할 수 없습니다.");
        }
    }
}
