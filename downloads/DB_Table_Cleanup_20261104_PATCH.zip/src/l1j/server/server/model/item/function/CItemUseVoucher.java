package l1j.server.server.model.item.function;

import java.sql.Timestamp;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import l1j.server.server.datatables.ExpTable;
import l1j.server.server.storage.CacheD;
import l1j.server.server.storage.mysql.MySqlCharacterStorage.CharacterSnapshot;
import l1j.server.server.model.L1Clan;
import l1j.server.server.model.network.core.sc.packet.SC_InventoryIcon;
import l1j.server.server.model.network.core.sc.packet.SC_SkillSound;

import l1j.server.server.model.Instance.L1DollInstance;
import l1j.server.server.model.network.core.sc.packet.SC_PacketBox;
import l1j.server.server.utils.CommonUtil;

import java.util.concurrent.ThreadLocalRandom;

import l1j.server.Config;
import l1j.server.server.IdFactory;
import l1j.server.server.datatables.ItemTable;
import l1j.server.server.datatables.ResolventTable;
import l1j.server.server.model.L1InventoryTransaction;
import l1j.server.server.model.L1Inventory;
import l1j.server.server.model.L1ItemDelay;
import l1j.server.server.model.network.core.sc.packet.SC_ServerMessage;
import l1j.server.server.templates.L1Item;
import l1j.server.server.templates.L1EtcItem;
import l1j.server.server.datatables.NpcTable;
import l1j.server.server.model.L1World;
import l1j.server.server.model.Instance.L1DoorInstance;
import l1j.server.server.model.Instance.L1ItemInstance;
import l1j.server.server.model.Instance.L1NpcInstance;
import l1j.server.server.model.Instance.L1PcInstance;
import l1j.server.server.model.character.skill.L1SkillId;
import l1j.server.server.model.character.skill.L1SkillUse;
import l1j.server.server.model.network.core.sc.packet.SC_SystemMessage;
import l1j.server.server.model.network.core.sc.packet.SC_PacketBox;
import l1j.server.server.utils.L1SpawnUtil;

import static l1j.server.server.model.item.function.CItemUse.*;
import l1j.server.server.model.item.function.CItemUse.Result;

final class CItemUseVoucher {
    private CItemUseVoucher() {}

    static Result useAdenaVoucher(L1PcInstance pc, L1ItemInstance item) {
        final int itemId = item.getItemId();
        final int adena;
        final String success;
        switch (itemId) {
        case ITEM_ADENA_VOUCHER_100M:
            adena = 100_000_000;
            success = "1억 아데나로 환전 되었습니다.";
            if (item.getBless() >= 128) {
                SC_SystemMessage.send(pc, "봉인해제 후 아데나로 변환 가능합니다.");
                return Result.RETURN;
            }
            break;
        case ITEM_ADENA_VOUCHER_50M:
            adena = 50_000_000;
            success = "5천 아데나로 환전 되었습니다.";
            break;
        case ITEM_ADENA_VOUCHER_10M:
            adena = 10_000_000;
            success = "1천 아데나로 환전 되었습니다.";
            break;
        default:
            return Result.NOT_HANDLED;
        }

        // Enforce the original 2-billion warning as a real projected limit.
        // Using subtraction also avoids an int overflow near MAX_AMOUNT.
        final int heldAdena = pc.getInventory().countItems(ITEM_ADENA);
        if (heldAdena < 0 || heldAdena > ADENA_EXCHANGE_LIMIT - adena) {
            SC_ServerMessage.send(pc, 3369);
            SC_PacketBox.send(pc, SC_PacketBox.GREEN_MESSAGE,
                    "20억 아데나 초과시 무용지물됩니다.");
            return Result.RETURN;
        }

        try (L1InventoryTransaction tx = L1InventoryTransaction.begin(pc, item.getId())) {
            if (!tx.debit(item, 1)) {
                pc.sendPackets("수표가 부족합니다.");
                return Result.RETURN;
            }
            if (tx.grant(ITEM_ADENA, adena) == null) {
                SC_SystemMessage.send(pc, "아데나 환전 수량을 처리할 수 없습니다.");
                return Result.RETURN;
            }
            tx.onFailure(() -> SC_SystemMessage.send(pc,
                    "아데나 환전이 확정되지 않았습니다."));
            tx.commitAfterInventoryRelease(() -> {
                pc.sendPackets(success);
                SC_ServerMessage.send(pc, 3369);
                SC_PacketBox.send(pc, SC_PacketBox.GREEN_MESSAGE,
                        "20억 아데나 초과시 무용지물됩니다.");
                L1ItemDelay.onItemUse(pc, item);
            });
        } catch (IllegalStateException failure) {
            SC_SystemMessage.send(pc, "아이템 처리가 진행 중이거나 환전 한도를 초과했습니다.");
        }
        return Result.RETURN;
    }
}
