package l1j.server.server.model.item.function;

import java.sql.Timestamp;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import l1j.server.server.datatables.ExpTable;
import l1j.server.server.storage.CacheD;
import l1j.server.server.storage.mysql.MySqlCharacterStorage.CharacterSnapshot;
import l1j.server.server.model.L1Clan;
import l1j.server.server.model.network.core.sc.packet.SC_InventoryIcon;
import l1j.server.server.model.network.core.sc.packet.SC_SkillSound;

import l1j.server.server.model.Instance.L1DollInstance;
import l1j.server.server.model.network.core.sc.packet.SC_PacketBox;
import l1j.server.server.utils.CommonUtil;

import java.util.concurrent.ThreadLocalRandom;

import l1j.server.Config;
import l1j.server.server.IdFactory;
import l1j.server.server.datatables.ItemTable;
import l1j.server.server.datatables.ResolventTable;
import l1j.server.server.model.L1InventoryTransaction;
import l1j.server.server.model.L1Inventory;
import l1j.server.server.model.L1ItemDelay;
import l1j.server.server.model.network.core.sc.packet.SC_ServerMessage;
import l1j.server.server.templates.L1Item;
import l1j.server.server.templates.L1EtcItem;
import l1j.server.server.datatables.NpcTable;
import l1j.server.server.model.L1World;
import l1j.server.server.model.Instance.L1DoorInstance;
import l1j.server.server.model.Instance.L1ItemInstance;
import l1j.server.server.model.Instance.L1NpcInstance;
import l1j.server.server.model.Instance.L1PcInstance;
import l1j.server.server.model.character.skill.L1SkillId;
import l1j.server.server.model.character.skill.L1SkillUse;
import l1j.server.server.model.network.core.sc.packet.SC_SystemMessage;
import l1j.server.server.model.network.core.sc.packet.SC_PacketBox;
import l1j.server.server.utils.L1SpawnUtil;

import static l1j.server.server.model.item.function.CItemUse.*;
import l1j.server.server.model.item.function.CItemUse.Result;

final class CItemUseCraft {
    private CItemUseCraft() {}

    static void useRunePowerRemover(L1PcInstance pc, L1ItemInstance remover,
            L1ItemInstance rune) {
        if (pc == null || remover == null || rune == null || remover == rune
                || remover.getItemId() != 60035
                || pc.getInventory().getItem(remover.getId()) != remover
                || pc.getInventory().getItem(rune.getId()) != rune) return;
        final int runeId = rune.getItemId();
        final int rewardId;
        final String message;
        if (runeId >= 222295 && runeId <= 222299) {
            rewardId = 60034; message = " 마력을 잃은 룬으로 변경되었습니다.";
        } else if (runeId >= 222312 && runeId <= 222316) {
            rewardId = 68097; message = " 마력을 잃은 룬(70)으로 변경되었습니다.";
        } else if (runeId >= 900135 && runeId <= 900139) {
            rewardId = 68098; message = " 마력을 잃은 룬(80)으로 변경되었습니다.";
        } else if (runeId >= 900140 && runeId <= 900144) {
            rewardId = 68099; message = " 마력을 잃은 룬(85)으로 변경되었습니다.";
        } else if (runeId >= 900145 && runeId <= 900149) {
            rewardId = 68100; message = " 마력을 잃은 룬(90)으로 변경되었습니다.";
        } else {
            SC_SystemMessage.send(pc, "엘릭서 룬에 사용할 수 있습니다.");
            return;
        }
        try (L1InventoryTransaction tx = L1InventoryTransaction.begin(pc, remover.getId())) {
            if (!tx.debit(remover, 1) || !tx.debit(rune, 1)) return;
            if (tx.grant(rewardId, 1) == null) {
                SC_SystemMessage.send(pc, "마력을 잃은 룬을 소지할 수 없습니다.");
                return;
            }
            tx.onFailure(() -> SC_SystemMessage.send(pc, "룬 변환이 확정되지 않았습니다."));
            tx.commitAfterInventoryRelease(() -> SC_SystemMessage.send(pc, message));
        } catch (RuntimeException failure) {
            SC_SystemMessage.send(pc, "아이템 처리가 진행 중이거나 룬 변환을 완료할 수 없습니다.");
        }
    }

    static void useTargetedPurification(L1PcInstance pc, L1ItemInstance reagent,
            L1ItemInstance target) {
        if (pc == null) return;
        if (reagent == null || target == null || reagent == target
                || pc.getInventory().getItem(reagent.getId()) != reagent
                || pc.getInventory().getItem(target.getId()) != target) {
            SC_ServerMessage.send(pc, 79);
            return;
        }
        final int reagentId = reagent.getItemId();
        final int targetId = target.getItemId();
        final int resultId;
        final boolean success;
        final boolean destroyTargetOnFailure;
        final int failMessage;
        final ThreadLocalRandom random = ThreadLocalRandom.current();
        if (reagentId == 40925 && targetId >= 40987 && targetId <= 40989) {
            success = random.nextInt(100) < Config.CREATE_CHANCE_RECOLLECTION;
            resultId = targetId + 186;
            destroyTargetOnFailure = true;
            failMessage = 158;
        } else if (reagentId >= 40926 && reagentId <= 40929
                && targetId >= (41173 + (reagentId - 40926) * 3)
                && targetId <= (41175 + (reagentId - 40926) * 3)) {
            // The old roll was Random.nextInt(99) + 1 (1..99), strict '<'.
            success = random.nextInt(99) + 1 < Config.CREATE_CHANCE_MYSTERIOUS;
            resultId = targetId - 12;
            destroyTargetOnFailure = false;
            failMessage = 160;
        } else if (reagentId == 40964 && targetId >= 41011 && targetId <= 41018) {
            success = random.nextInt(99) + 1 <= Config.CREATE_CHANCE_HISTORY_BOOK;
            resultId = targetId + 8;
            destroyTargetOnFailure = true;
            failMessage = 158;
        } else if (reagentId == 41036 && targetId >= 41038 && targetId <= 41047) {
            success = random.nextInt(99) + 1 <= Config.CREATE_CHANCE_DIARY;
            resultId = targetId + 10;
            destroyTargetOnFailure = true;
            failMessage = 158;
        } else {
            SC_ServerMessage.send(pc, 79);
            return;
        }
        final String targetName = target.getName();
        try (L1InventoryTransaction tx = L1InventoryTransaction.begin(pc, reagent.getId())) {
            if (!tx.debit(reagent, 1)) return;
            if ((success || destroyTargetOnFailure) && !tx.debit(target, 1)) {
                SC_ServerMessage.send(pc, 79);
                return;
            }
            if (success && tx.grant(resultId, 1) == null) {
                SC_SystemMessage.send(pc, "정화 결과 아이템을 소지할 수 없습니다.");
                return;
            }
            tx.onFailure(() -> SC_SystemMessage.send(pc, "정화 결과가 확정되지 않았습니다."));
            tx.commitAfterInventoryRelease(() -> {
                if (!success) SC_ServerMessage.send(pc, failMessage, targetName);
            });
        } catch (RuntimeException failure) {
            SC_SystemMessage.send(pc, "아이템 처리가 진행 중이거나 정화를 완료할 수 없습니다.");
        }
    }

    static void useWeaponTransformation(L1PcInstance pc, L1ItemInstance scroll,
            L1ItemInstance weapon) {
        if (pc == null || scroll == null || weapon == null || scroll == weapon
                || pc.getInventory().getItem(scroll.getId()) != scroll
                || pc.getInventory().getItem(weapon.getId()) != weapon) return;
        final int scrollId = scroll.getItemId();
        final int weaponId = weapon.getItemId();
        final int[] rewards;
        if (scrollId == 698) {
            if (weaponId != 40346 && weaponId != 40370 && weaponId != 40362 && weaponId != 40354) {
                SC_ServerMessage.send(pc, 79);
                return;
            }
            rewards = TRANSFORM_WEAPON_698;
        } else if (scrollId == 776) {
            if (weaponId != 3000088 && weaponId != 3000352 && weaponId != 755
                    && weaponId != 756 && weaponId != 757 && weaponId != 745 && weaponId != 746) {
                SC_ServerMessage.send(pc, 79);
                return;
            }
            rewards = TRANSFORM_WEAPON_776;
        } else {
            return;
        }
        if (weapon.getBless() >= 128 || weapon.getCount() != 1 || weapon.isEquipped()) {
            SC_ServerMessage.send(pc, 79);
            return;
        }
        try (L1InventoryTransaction tx = L1InventoryTransaction.begin(pc, scroll.getId())) {
            if (!tx.debit(scroll, 1) || !tx.debit(weapon, 1)) {
                SC_ServerMessage.send(pc, 79);
                return;
            }
            final int resultId = rewards[ThreadLocalRandom.current().nextInt(rewards.length)];
            final L1Item template = ItemTable.getInstance().getTemplate(resultId);
            if (template == null) {
                SC_SystemMessage.send(pc, "무기 변환 결과 아이템 설정을 확인해 주세요.");
                return;
            }
            final L1ItemInstance image = new L1ItemInstance(template, 1);
            image.setId(IdFactory.getInstance().nextId());
            image.setBless(template.getBless());
            image.setIdentified(true);
            image.setEnchantLevel(weapon.getEnchantLevel());
            final L1ItemInstance reward = tx.grant(image);
            if (reward == null) {
                SC_SystemMessage.send(pc, "변환된 무기를 소지할 수 없습니다.");
                return;
            }
            final String name = reward.getLogName();
            tx.onFailure(() -> SC_SystemMessage.send(pc, "무기 변환이 확정되지 않았습니다."));
            tx.commitAfterInventoryRelease(() -> SC_SystemMessage.send(pc, name + " 을 얻었습니다."));
        } catch (RuntimeException failure) {
            SC_SystemMessage.send(pc, "아이템 처리가 진행 중이거나 무기 변환을 완료할 수 없습니다.");
        }
    }

    static void craftLifeEye(L1PcInstance pc, L1ItemInstance fragment) {
        if (pc == null || fragment == null || fragment.getItemId() != 3000150
                || pc.getInventory().getItem(fragment.getId()) != fragment) return;
        try (L1InventoryTransaction tx = L1InventoryTransaction.begin(pc, fragment.getId())) {
            if (!tx.debit(3000150, 100)) {
                SC_SystemMessage.send(pc, "생명의마안 조각 이 부족합니다.");
                return;
            }
            if (tx.grant(410038, 1) == null) {
                SC_SystemMessage.send(pc, "생명의 마안을 소지할 수 없습니다.");
                return;
            }
            tx.onFailure(() -> SC_SystemMessage.send(pc, "생명의 마안 제작이 확정되지 않았습니다."));
            tx.commitAfterInventoryRelease(() ->
                    l1j.server.server.model.network.core.sc.packet.SC_ChatPacket.sendDirect(
                            pc, pc, "생명의마안 이 제작되었습니다."));
        } catch (RuntimeException failure) {
            SC_SystemMessage.send(pc, "아이템 처리가 진행 중이거나 제작할 수 없습니다.");
        }
    }
}
