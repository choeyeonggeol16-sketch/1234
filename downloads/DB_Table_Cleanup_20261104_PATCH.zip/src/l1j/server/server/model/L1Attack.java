package l1j.server.server.model;


import java.util.Random;
import l1j.server.Config;
import l1j.server.DogFight.Instance.MJDogFightInstance;
import l1j.server.MJInstanceSystem.MJInstanceEnums.InstStatus;
import l1j.server.MJItemSkillSystem.MJItemSkillModelLoader;
import l1j.server.MJItemSkillSystem.Model.MJItemSkillModel;
import l1j.server.MJPassiveSkill.MJPassiveID;
import l1j.server.MJRaidSystem.Loader.MJRaidLoadManager;
import l1j.server.MJTemplate.MJRnd;
import l1j.server.MJTemplate.Chain.Action.MJAttackChain;
import l1j.server.MJWarSystem.MJCastleWarBusiness;
import l1j.server.server.ActionCodes;
import l1j.server.server.datatables.SkillsTable;
import l1j.server.server.datatables.UserProtectMonsterTable;
import l1j.server.server.model.Instance.L1CompanionInstance;
import l1j.server.server.model.Instance.L1DollInstance;
import l1j.server.server.model.Instance.L1ItemInstance;
import l1j.server.server.model.Instance.L1NpcInstance;
import l1j.server.server.model.Instance.L1MonsterInstance;
import l1j.server.server.model.Instance.L1PcInstance;
import l1j.server.server.model.Instance.L1PeopleInstance;
import l1j.server.server.model.Instance.L1PetInstance;
import l1j.server.server.model.Instance.L1SummonInstance;
import l1j.server.server.model.character.skill.L1SkillId;
import l1j.server.server.model.character.skill.helper.WeakExposeHelper;
import l1j.server.server.model.gametime.L1GameTimeClock;
import l1j.server.server.model.network.packet.ServerPacket;
import l1j.server.server.model.network.core.cs.packet.CS_ItemUse;
import l1j.server.server.model.poison.L1DamagePoison;
import l1j.server.server.model.poison.L1ParalysisPoison;
import l1j.server.server.model.poison.L1SilencePoison;
import l1j.server.server.model.network.core.sc.packet.SC_AttackCritical;
import l1j.server.server.model.network.core.sc.packet.SC_AttackMissPacket;
import l1j.server.server.model.network.core.sc.packet.SC_AttackPacket;
import l1j.server.server.model.network.core.sc.packet.SC_AttackPacketForNpc;
import l1j.server.server.model.network.core.sc.packet.SC_ChatPacket;
import l1j.server.server.model.network.core.sc.packet.SC_DoActionGFX;
import l1j.server.server.model.network.core.sc.packet.SC_InventoryIcon;
import l1j.server.server.model.network.core.sc.packet.SC_PacketBox;
import l1j.server.server.model.network.core.sc.packet.SC_ServerMessage;

import l1j.server.server.model.network.core.sc.packet.SC_SkillSound;
import l1j.server.server.model.network.core.sc.packet.SC_SystemMessage;
import l1j.server.server.model.network.core.sc.packet.SC_UseArrowSkill;
import l1j.server.server.model.network.core.sc.packet.SC_UseAttackSkill;
import l1j.server.server.templates.L1Skills;
import l1j.server.server.types.Point;
import l1j.server.server.utils.CalcStat;
import l1j.server.server.utils.CommonUtil;
import l1j.server.server.utils.MJCommons;

public class L1Attack {

	private L1PcInstance _pc = null;

	private L1Character _target = null;

	private L1PcInstance _targetPc = null;

	private L1NpcInstance _npc = null;

	private L1NpcInstance _targetNpc = null;

	private final int _targetId;

	private int _targetX;

	private int _targetY;

	private int _statusDamage = 0;

	private static final Random _random = new Random(System.nanoTime());

	private int _hitRate = 0;

	private int _calcType;

	private static final int PC_PC = 1;

	private static final int PC_NPC = 2;

	private static final int NPC_PC = 3;

	private static final int NPC_NPC = 4;

	public boolean _isHit = false;

	public boolean _isCritical = false;

	private int _damage = 0;
	private int _effex = 0;

	private int _attckGrfxId = 0;

	private int _attckActId = 0;

	// 공격자가 플레이어의 경우의 무기 정보
	private L1ItemInstance weapon = null;

	// 전사 쌍수
	private L1ItemInstance Sweapon = null;// 세컨웨폰
	private int _SweaponId = 0;
	private int _SweaponType = 0;
	private int _SweaponType1 = 0;
	private int _SweaponAddHit = 0;
	private int _SweaponAddDmg = 0;
	private int _SweaponSmall = 0;
	private int _SweaponLarge = 0;
	private int _SweaponRange = 1;
	private int _SweaponBless = 1;
	private int _SweaponEnchant = 0;
	private int _SweaponMaterial = 0;
	private int _SweaponAttrEnchantLevel = 0;

	private int _weaponId = 0;

	private int _weaponType = 0;

	private int _weaponType2 = 0;

	// private int _weaponType1 = 0;

	private int _weaponAddHit = 0;

	private int _weaponAddDmg = 0;

	private int _weaponSmall = 0;

	private int _weaponLarge = 0;

	private int _weaponBless = 1;

	private int _weaponEnchant = 0;

	private int _weapon_bless_level = 0;

	private int _weaponMaterial = 0;

	private int _weaponDoubleDmgChance = 0;

	private int _weaponAttrLevel = 0; // 속성 레벨

	private int _attackType = 0;

	private L1ItemInstance _arrow = null;

	private L1ItemInstance _sting = null;

	private int _leverage = 10; // 1/10배로 표현한다.

	public void setLeverage(int i) {
		_leverage = i;
	}

	private int getLeverage() {
		return _leverage;
	}

	private static final int[] strHit = new int[128];

	static {
		for (int str = 0; str <= 7; str++) {
			strHit[str] = -2;
		}
		strHit[8] = -1;
		strHit[9] = -1;
		strHit[10] = 0;
		strHit[11] = 0;
		strHit[12] = 1;
		strHit[13] = 1;
		strHit[14] = 2;
		strHit[15] = 2;
		strHit[16] = 3;
		strHit[17] = 3;
		strHit[18] = 4;
		strHit[19] = 4;
		strHit[20] = 4;
		strHit[21] = 5;
		strHit[22] = 5;
		strHit[23] = 5;
		strHit[24] = 6;
		strHit[25] = 6;
		strHit[26] = 6;
		strHit[27] = 7;
		strHit[28] = 7;
		strHit[29] = 7;
		strHit[30] = 8;
		strHit[31] = 8;
		strHit[32] = 8;
		strHit[33] = 9;
		strHit[34] = 9;
		strHit[35] = 9;
		strHit[36] = 10;
		strHit[37] = 10;
		strHit[38] = 10;
		strHit[39] = 11;
		strHit[40] = 11;
		strHit[41] = 11;
		strHit[42] = 12;
		strHit[43] = 12;
		strHit[44] = 12;
		strHit[45] = 13;
		strHit[46] = 13;
		strHit[47] = 13;
		strHit[48] = 14;
		strHit[49] = 14;
		strHit[50] = 14;
		strHit[51] = 15;
		strHit[52] = 15;
		strHit[53] = 15;
		strHit[54] = 16;
		strHit[55] = 16;
		strHit[56] = 16;
		strHit[57] = 17;
		strHit[57] = 17;
		strHit[58] = 17;
		int Hit = 18;
		for (int str = 59; str <= 127; str++) { // 59~127은 3마다＋1
			if (str % 3 == 1) {
				Hit++;
			}
			strHit[str] = Hit;
		}
	}

	private static final int[] dexHit = new int[128];

	static {
		// DEX 데미지 보정
		for (int dex = 0; dex <= 6; dex++) {
			// 0~11는 0
			dexHit[dex] = -2;
		}
		dexHit[7] = -1;
		dexHit[8] = -1;
		dexHit[9] = 0;
		dexHit[10] = 0;
		dexHit[11] = 1;
		dexHit[12] = 1;
		dexHit[13] = 2;
		dexHit[14] = 2;
		dexHit[15] = 3;
		dexHit[16] = 3;
		dexHit[17] = 4;
		dexHit[18] = 4;
		dexHit[19] = 5;
		dexHit[20] = 6;
		dexHit[21] = 7;
		dexHit[22] = 8;
		dexHit[23] = 9;
		dexHit[24] = 10;
		dexHit[25] = 11;
		dexHit[26] = 12;
		dexHit[27] = 13;
		dexHit[28] = 14;
		dexHit[29] = 15;
		dexHit[30] = 16;
		dexHit[31] = 17;
		dexHit[32] = 18;
		dexHit[33] = 19;
		dexHit[34] = 19;
		dexHit[35] = 19;
		dexHit[36] = 20;
		dexHit[37] = 20;
		dexHit[38] = 20;
		dexHit[39] = 21;
		dexHit[40] = 21;
		dexHit[41] = 21;
		dexHit[42] = 22;
		dexHit[43] = 22;
		dexHit[44] = 22;
		dexHit[45] = 23;
		dexHit[46] = 23;
		dexHit[47] = 23;
		dexHit[48] = 24;
		dexHit[49] = 24;
		dexHit[50] = 24;
		dexHit[51] = 25;
		dexHit[52] = 25;
		dexHit[53] = 25;
		dexHit[54] = 26;
		dexHit[55] = 26;
		dexHit[56] = 26;
		dexHit[57] = 27;
		dexHit[58] = 27;
		dexHit[59] = 27;
		dexHit[60] = 28;
		dexHit[61] = 28;
		dexHit[62] = 28;
		dexHit[63] = 29;
		dexHit[64] = 29;
		dexHit[65] = 29;
		dexHit[66] = 30;
		dexHit[67] = 30;
		dexHit[68] = 30;

		int hit = 31;
		for (int dex = 69; dex <= 127; dex++) { // 48~127은 3마다＋1 //#
			if (dex % 3 == 1) {
				hit++;
			}
			dexHit[dex] = hit;
		}
	}

	private static final int[] strDmg = new int[128];

	static {
		strDmg[7] = 2;
		strDmg[8] = 2;
		strDmg[9] = 2;
		strDmg[10] = 3;
		strDmg[11] = 3;
		strDmg[12] = 4;
		strDmg[13] = 4;
		strDmg[14] = 5;
		strDmg[15] = 5;
		strDmg[16] = 6;
		strDmg[17] = 6;
		strDmg[18] = 7;
		strDmg[19] = 7;
		strDmg[20] = 8;
		strDmg[21] = 8;
		strDmg[22] = 9;
		strDmg[23] = 9;
		strDmg[24] = 10;
		strDmg[25] = 10;
		strDmg[26] = 11;
		strDmg[27] = 11;
		strDmg[28] = 12;
		strDmg[29] = 12;
		strDmg[30] = 13;
		strDmg[31] = 13;
		strDmg[32] = 14;
		strDmg[33] = 14;
		strDmg[34] = 15;
		strDmg[35] = 15;
		strDmg[36] = 16;
		strDmg[37] = 16;
		strDmg[38] = 17;
		strDmg[39] = 17;
		strDmg[40] = 18;
		strDmg[41] = 18;
		strDmg[42] = 19;
		strDmg[43] = 19;
		strDmg[44] = 20;
		strDmg[45] = 20;
		strDmg[46] = 21;
		strDmg[47] = 21;
		strDmg[48] = 22;
		strDmg[49] = 22;
		strDmg[50] = 23;
		strDmg[51] = 23;
		strDmg[52] = 24;
		strDmg[53] = 24;
		strDmg[54] = 25;
		strDmg[55] = 25;
		strDmg[56] = 26;
		strDmg[57] = 26;
		strDmg[58] = 27;
		strDmg[59] = 28;
		strDmg[60] = 29;
		strDmg[61] = 30;
		strDmg[62] = 31;
		strDmg[63] = 32;
		strDmg[64] = 33;
		strDmg[65] = 34;
		strDmg[66] = 35;
		strDmg[67] = 36;
		strDmg[68] = 37;
		strDmg[69] = 38;
		strDmg[70] = 39;
		strDmg[71] = 40;
		strDmg[72] = 41;
		strDmg[73] = 43;
		strDmg[74] = 45;
		strDmg[75] = 47;
		strDmg[76] = 49;
		strDmg[77] = 51;
		strDmg[78] = 53;
		strDmg[79] = 55;
		strDmg[80] = 57;
		strDmg[81] = 58;
		strDmg[82] = 59;
		strDmg[83] = 60;
		strDmg[84] = 61;
		strDmg[85] = 62;
		strDmg[86] = 63;
		strDmg[87] = 64;
		strDmg[88] = 65;
		strDmg[89] = 66;
		strDmg[90] = 67;
		strDmg[91] = 68;
		strDmg[92] = 69;
		strDmg[93] = 70;
		strDmg[94] = 71;
		strDmg[95] = 72;
		strDmg[96] = 73;
		strDmg[97] = 74;
		strDmg[98] = 75;
		strDmg[99] = 76;
		strDmg[100] = 77;
		strDmg[101] = 78;
		strDmg[102] = 79;

	}

	private static final int[] dexDmg = new int[128];

	static {
		// DEX 데미지 보정
		dexDmg[7] = 1;
		dexDmg[8] = 1;
		dexDmg[9] = 2;
		dexDmg[10] = 2;
		dexDmg[11] = 2;
		dexDmg[12] = 3;
		dexDmg[13] = 3;
		dexDmg[14] = 3;
		dexDmg[15] = 4;
		dexDmg[16] = 4;
		dexDmg[17] = 4;
		dexDmg[18] = 5;
		dexDmg[19] = 5;
		dexDmg[20] = 5;
		dexDmg[21] = 6;
		dexDmg[22] = 6;
		dexDmg[23] = 6;
		dexDmg[24] = 7;
		dexDmg[25] = 7;
		dexDmg[26] = 7;
		dexDmg[27] = 8;
		dexDmg[28] = 8;
		dexDmg[29] = 8;
		dexDmg[30] = 9;
		dexDmg[31] = 9;
		dexDmg[32] = 9;
		dexDmg[33] = 10;
		dexDmg[34] = 10;
		dexDmg[35] = 11;
		dexDmg[36] = 11;
		dexDmg[37] = 12;
		dexDmg[38] = 12;
		dexDmg[39] = 13;
		dexDmg[40] = 13;
		dexDmg[41] = 14;
		dexDmg[42] = 14;
		dexDmg[43] = 15;
		dexDmg[44] = 15;
		dexDmg[45] = 16;
		dexDmg[46] = 16;
		dexDmg[47] = 17;
		dexDmg[48] = 17;
		dexDmg[49] = 18;
		dexDmg[50] = 18;
		dexDmg[51] = 19;
		dexDmg[52] = 20;
		dexDmg[53] = 21;
		dexDmg[54] = 22;
		dexDmg[55] = 23;
		dexDmg[56] = 24;
		dexDmg[57] = 25;
		dexDmg[58] = 26;
		dexDmg[59] = 27;
		dexDmg[60] = 28;
		dexDmg[61] = 29;
		dexDmg[62] = 30;
		dexDmg[63] = 31;
		dexDmg[64] = 32;
		dexDmg[65] = 33;
		dexDmg[66] = 34;
		dexDmg[67] = 35;
		dexDmg[68] = 36;
		dexDmg[69] = 37;
		dexDmg[70] = 38;
		dexDmg[71] = 39;
		dexDmg[72] = 40;
		dexDmg[73] = 42;
		dexDmg[74] = 43;
		dexDmg[75] = 44;
		dexDmg[76] = 45;
		dexDmg[77] = 46;
		dexDmg[78] = 47;
		dexDmg[79] = 48;
		dexDmg[80] = 49;
		dexDmg[81] = 50;
		dexDmg[82] = 51;
		dexDmg[83] = 52;
		dexDmg[84] = 53;
		dexDmg[85] = 54;
		dexDmg[86] = 55;
		dexDmg[87] = 56;
		dexDmg[88] = 57;
		dexDmg[89] = 58;
		dexDmg[90] = 59;
		dexDmg[91] = 60;
		dexDmg[92] = 61;
		dexDmg[93] = 62;
		dexDmg[94] = 63;
		dexDmg[95] = 64;
		dexDmg[96] = 65;
		dexDmg[97] = 66;
		dexDmg[98] = 67;
		dexDmg[99] = 68;
		dexDmg[100] = 69;
		dexDmg[101] = 70;
		dexDmg[102] = 71;
	}

	private static final int[] intDmg = new int[128];

	static {
		// int 대미지 보정
		for (int int1 = 0; int1 <= 14; int1++) {
			intDmg[int1] = 0;
		}
		intDmg[15] = 3;
		intDmg[16] = 4;
		intDmg[17] = 5;
		intDmg[18] = 6;
		intDmg[19] = 6;
		intDmg[20] = 7;
		intDmg[21] = 7;
		intDmg[22] = 8;
		intDmg[23] = 8;
		intDmg[24] = 9;
		intDmg[25] = 9;
		intDmg[26] = 9;
		intDmg[27] = 10;
		intDmg[28] = 10;
		intDmg[29] = 11;
		intDmg[30] = 11;
		intDmg[31] = 12;
		intDmg[32] = 12;
		intDmg[33] = 13;
		intDmg[34] = 13;
		intDmg[35] = 14;
		intDmg[36] = 15;
		intDmg[37] = 16;
		intDmg[38] = 17;
		intDmg[39] = 18;
		intDmg[40] = 19;
		intDmg[41] = 20;
		intDmg[42] = 21;
		intDmg[43] = 22;
		intDmg[44] = 23;
		intDmg[45] = 24;
		intDmg[46] = 25;
		intDmg[47] = 26;
		intDmg[48] = 27;
		intDmg[49] = 28;
		intDmg[50] = 29;
		intDmg[51] = 30;
		intDmg[52] = 31;
		intDmg[53] = 32;
		intDmg[54] = 33;
		intDmg[55] = 34;
		intDmg[56] = 35;
		intDmg[57] = 36;
		intDmg[58] = 37;
		intDmg[59] = 38;
		intDmg[60] = 39;
		intDmg[61] = 40;
		intDmg[62] = 41;
		intDmg[63] = 42;
		intDmg[64] = 43;
		intDmg[65] = 44;
		intDmg[66] = 45;
		intDmg[67] = 46;
		intDmg[68] = 47;
		intDmg[69] = 48;
		intDmg[70] = 49;
		intDmg[71] = 50;
		intDmg[72] = 51;
		intDmg[73] = 52;
		intDmg[74] = 53;
		intDmg[75] = 54;
		intDmg[76] = 55;
		intDmg[77] = 56;
		intDmg[78] = 57;
		intDmg[79] = 58;
		intDmg[80] = 59;
		intDmg[81] = 60;
		intDmg[82] = 61;
		intDmg[83] = 62;
		intDmg[84] = 63;
		intDmg[85] = 64;
		intDmg[86] = 65;
		intDmg[87] = 66;
		intDmg[88] = 67;
		intDmg[89] = 68;
		intDmg[90] = 69;
		intDmg[91] = 70;
		intDmg[92] = 71;
		intDmg[93] = 72;
		intDmg[94] = 73;
		intDmg[95] = 74;
		intDmg[96] = 75;
		intDmg[97] = 76;
		intDmg[98] = 77;
		intDmg[99] = 78;
		intDmg[100] = 79;
		intDmg[101] = 80;
		intDmg[102] = 81;
		/*
		 * int dmg = 25; for (int int1 = 35; int1 <= 127; int1++) { // 35~127은 1마다＋1 dmg
		 * += 1; intDmg[int1] = dmg; }
		 */
	}

	public void setActId(int actId) {
		_attckActId = actId;
	}

	public void setGfxId(int gfxId) {
		_attckGrfxId = gfxId;
	}

	public int getActId() {
		return _attckActId;
	}

	public int getGfxId() {
		return _attckGrfxId;
	}

	public L1Attack(L1Character attacker, L1Character target) {
		if (attacker instanceof L1PcInstance) {
			_pc = (L1PcInstance) attacker;
			if (target instanceof L1PcInstance) {
				_targetPc = (L1PcInstance) target;
				_calcType = PC_PC;
			} else if (target instanceof L1NpcInstance) {
				_targetNpc = (L1NpcInstance) target;
				_calcType = PC_NPC;
			}
			// 무기 정보의 취득
			weapon = _pc.getWeaponSwap();
			Sweapon = _pc.getSecondWeapon();
			if (Sweapon != null) {
				_SweaponId = Sweapon.getItem().getItemId();
				_SweaponType = Sweapon.getItem().getType1();
				_SweaponAddHit = Sweapon.getItem().getHitModifier();
				_SweaponAddDmg = Sweapon.getItem().getDmgModifier();
				if (CS_ItemUse.is_legend_weapon(_weaponId))
					_SweaponAddDmg *= 2;
				_SweaponType1 = Sweapon.getItem().getType();
				_SweaponSmall = Sweapon.getItem().getDmgSmall();
				_SweaponLarge = Sweapon.getItem().getDmgLarge();
				_SweaponBless = Sweapon.getItem().getBless();
				_SweaponEnchant = Sweapon.getEnchantLevel() - Sweapon.get_durability(); // 손상분
																						// 마이너스
				_SweaponMaterial = Sweapon.getItem().getMaterial();
				_SweaponAttrEnchantLevel = Sweapon.getAttrEnchantLevel();
			}
			if (weapon != null) {
				_weaponId = weapon.getItem().getItemId();
				_weaponType = weapon.getItem().getType1();
				_weaponType2 = weapon.getItem().getType();// 변경
				_weaponAddHit = weapon.getItem().getHitModifier();
				_weaponAddDmg = weapon.getItem().getDmgModifier();
				if (CS_ItemUse.is_legend_weapon(_weaponId))
					_weaponAddDmg *= 2;

				_weaponSmall = weapon.getItem().getDmgSmall();
				_weaponLarge = weapon.getItem().getDmgLarge();
				_weaponBless = weapon.getItem().getBless();
				if (_weaponType == 0) {
					_weaponEnchant = 0;
				}
				if (_weaponType != 20 && _weaponType != 62) {
					_weaponEnchant = weapon.getEnchantLevel() - weapon.get_durability(); // 손상분
																							// 마이너스
				} else {
					_weaponEnchant = weapon.getEnchantLevel();
				}
				_weapon_bless_level = weapon.get_bless_level();
				_weaponMaterial = weapon.getItem().getMaterial();
				if (_weaponType == 20) { // 아로의 취득
					_arrow = _pc.getInventory().getArrow();
					if (_arrow != null) {
						_weaponBless = _arrow.getItem().getBless();
						_weaponMaterial = _arrow.getItem().getMaterial();
					}
				}
				if (_weaponType == 62) { // 스팅의 취득
					_sting = _pc.getInventory().getSting();
					if (_sting != null) {
						_weaponBless = _sting.getItem().getBless();
						_weaponMaterial = _sting.getItem().getMaterial();
					}
				}
				_weaponDoubleDmgChance = weapon.getItem().getDoubleDmgChance();
				_weaponAttrLevel = weapon.getAttrEnchantLevel();
			}
			// 스테이터스에 의한 추가 대미지 보정
			if (_weaponType == 20) { // 활의 경우는 DEX치 참조
				_statusDamage = dexDmg[_pc.getAbility().getTotalDex()]
						+ CalcStat.calcBowDmgup(_pc.getAbility().getTotalDex());
			// 키링크는 인트영향
				_statusDamage = intDmg[_pc.getAbility().getTotalInt()]
						+ CalcStat.calcMagicDmg(_pc.getAbility().getTotalInt());
			} else {
				_statusDamage = strDmg[_pc.getAbility().getTotalStr()]
						+ CalcStat.calcDmgup(_pc.getAbility().getTotalStr());
			}
		} else if (attacker instanceof L1NpcInstance) {
			_npc = (L1NpcInstance) attacker;
			if (target instanceof L1PcInstance) {
				_targetPc = (L1PcInstance) target;
				_calcType = NPC_PC;
			} else if (target instanceof L1NpcInstance) {
				_targetNpc = (L1NpcInstance) target;
				_calcType = NPC_NPC;
			}
		}
		_target = target;
		_targetId = target.getId();
		_targetX = target.getX();
		_targetY = target.getY();
	}

	/* ■■■■■■■■■■■■■■■■ 명중 판정 ■■■■■■■■■■■■■■■■ */

	public boolean calcHit() {
		if (_calcType == PC_PC || _calcType == PC_NPC) {
			if (_pc == null || _target == null)
				return _isHit;

			if (_target != null && _target instanceof MJDogFightInstance)
				return _isHit;

			// 키링크 일경우 상대방 앱솔일경우 무시
			if (_weaponType2 == 17) {
				if (_target.hasSkillEffect(L1SkillId.ABSOLUTE_BARRIER) || MJCommons.isCounterMagic(_target)) {
					_isHit = false;
				} else {
					_isHit = true;
				}
				return _isHit;
			}

			/** 2016.11.26 MJ 앱센터 LFC **/
			if (_pc instanceof L1PcInstance) {
				/* lfc 게임인 래디중일때는 miss */
				if (_pc.getInstStatus() == InstStatus.INST_USERSTATUS_LFCINREADY)
					return false;
			}

			if (_calcType == PC_PC || _calcType == PC_NPC) {
				if (!_pc.glanceCheck(_targetX, _targetY) || !_target.glanceCheck(_pc.getX(), _pc.getY()))
					return _isHit = false; // 공격자가 플레이어의 경우는 장애물 판정
			} else {
				if (_npc.glanceCheck(_targetX, _targetY) || _target.glanceCheck(_npc.getX(), _npc.getY()))
					return _isHit = false; // 공격자가 플레이어의 경우는 장애물 판정
			}

			if ( _weaponType == 20 && _weaponId != 190 && _weaponId != 10000 && _weaponId != 202011 && _arrow == null) {
				_isHit = false; // 화살이 없는 경우는 미스
			} else if (_weaponType == 62 && _sting == null) {
				_isHit = false; // 스팅이 없는 경우는 미스
			} else if (_weaponId == 247 || _weaponId == 248 || _weaponId == 249) {
				_isHit = false; // 시련의 검B~C 공격 무효
			} else if (_calcType == PC_PC) {
				if (_pc.get_current_combat_id() == _targetPc.get_current_combat_team_id()
						&& _pc.get_current_combat_team_id() == _targetPc.get_current_combat_team_id()) {
					_isHit = false;
					return false;
				}

				_isHit = calcPcPcHit();
				if (_isHit == false) {
					if (!_pc.hasSkillEffect(L1SkillId.버닝샷)) {
						SC_SkillSound.send(_pc, _target.getId(), 13418);// 이펙트
						SC_SkillSound.send(_targetPc, _target.getId(), 13418);// 이펙트
					}
				}
			} else if (_calcType == PC_NPC) {
				
				/** 바포방 뚫어 방지 **/
				if (_pc.바포방 != true && _pc.getX() == 32758 && _pc.getY() == 32878 && _pc.getMapId() == 2) {
					return _isHit = false;
				} else if (_pc.바포방 != true && _pc.getX() == 32794 && _pc.getY() == 32790 && _pc.getMapId() == 2) {
					return _isHit = false;
				} else if (_pc.바포방 != true && _pc.getX() == 32781 && _pc.getY() == 32881 && _pc.getMapId() == 2) {
					return _isHit = false;
				} else if (_pc.바포방 != true && _pc.getX() == 32782 && _pc.getY() == 32881 && _pc.getMapId() == 2) {
					return _isHit = false;
				} else if (_pc.바포방 != true && _pc.getX() == 32781 && _pc.getY() == 32880 && _pc.getMapId() == 2) {
					return _isHit = false;
				} else if (_pc.바포방 != true && _pc.getX() == 32782 && _pc.getY() == 32880 && _pc.getMapId() == 2) {
					return _isHit = false;
				} else {
					_isHit = calcPcNpcHit();
				}
				if (_isHit == false) {
					if (!_pc.hasSkillEffect(L1SkillId.버닝샷)) {
						SC_SkillSound.send(_pc, _targetNpc.getId(), 13418);// 미스 이펙트
					}
				}
			}
		} else if (_calcType == NPC_PC) {
			if (_npc instanceof L1CompanionInstance || _npc instanceof MJDogFightInstance) {
				_isHit = do_calc_hit_companion(_npc);
			} else {
				_isHit = calcNpcPcHit();
			}
			if (_isHit == false) {
				SC_SkillSound.send(_targetPc, _target.getId(), 13418);// 이펙트
			}
		} else if (_calcType == NPC_NPC) {
			if ((_npc instanceof L1CompanionInstance || _npc instanceof MJDogFightInstance)) {
				_isHit = do_calc_hit_companion(_npc);
			} else {
				_isHit = calcNpcNpcHit();
			}
		} else if (_targetNpc.getNpcTemplate().get_gfxid() == 7684 && !_pc.hasSkillEffect(L1SkillId.PAP_FIVEPEARLBUFF)) {
			_isHit = false;
			return _isHit;
		} else if (_targetNpc.getNpcTemplate().get_gfxid() == 7805 && !_pc.hasSkillEffect(L1SkillId.PAP_MAGICALPEARLBUFF)) {
			_isHit = false;
			return _isHit;
		}
		return _isHit;
	}

	private boolean do_calc_hit_companion(L1Character attacker) {
		return MJAttackChain.getInstance().do_calculate_hit(this, attacker, _target);
	}

	private int do_calc_damage_companion(L1Character attacker) {
		int damage = MJAttackChain.getInstance().do_calculate_damage(this, attacker, _target);
		if (damage <= 0)
			_isHit = false;
		return damage;
	}

	// ●●●● 플레이어로부터 플레이어에의 명중 판정 ●●●●
	/*
	 * PC에의 명중율 =(PC의 Lv＋클래스 보정＋STR 보정＋DEX 보정＋무기 보정＋DAI의 매수/2＋마법 보정)×0.68－10 이것으로
	 * 산출된 수치는 자신이 최대 명중(95%)을 주는 일을 할 수 있는 상대측 PC의 AC 거기로부터 상대측 PC의 AC가 1좋아질 때마다
	 * 자명중율로부터 1당겨 간다 최소 명중율5% 최대 명중율95%
	 */
	private boolean calcPcPcHit() {
		if (_pc.hasSkillEffect(L1SkillId.ABSOLUTE_BLADE)) {
			if (_target.hasSkillEffect(L1SkillId.ABSOLUTE_BARRIER)) {
				int chance = _pc.getLevel() - 60;
				if (chance >= 8)
					chance = 8;
				if (chance >= _random.nextInt(100) + 1) {
					_targetPc.removeSkillEffect(L1SkillId.ABSOLUTE_BARRIER);
					SC_SkillSound.send(_targetPc, _targetPc.getId(), 14539);
					SC_SkillSound.broadcastFast(_targetPc, _targetPc.getId(), 14539);
				}
			}
		}
		if (_targetPc.hasSkillEffect(L1SkillId.ABSOLUTE_BARRIER) || _targetPc.hasSkillEffect(L1SkillId.ICE_LANCE))
			return false;

		if (_pc.hasSkillEffect(L1SkillId.이뮨투함블레이드)) {
			if (_target.hasSkillEffect(L1SkillId.IMMUNE_TO_HARM)) {

				이뮨투함블레이드();

			}

		}

		if (_calcType == PC_PC) {
			if (_pc.hasSkillEffect(L1SkillId.버닝샷)) {

				int diffLocX = Math.abs(_pc.getX() - _targetPc.getX());
				int diffLocY = Math.abs(_pc.getY() - _targetPc.getY());

				if (diffLocX > Config.버닝샷칸 || diffLocY > Config.버닝샷칸) {

					return false;
				}
			}
		}

		_hitRate = _pc.getLevel();

		/** 스탯 + 무기에 따른 공성 **/
		_hitRate += PchitAdd();
		if (_weaponType == 20 && _arrow != null) {
			_hitRate += _arrow.getItem().getHitModifier();
		}
		// 신화 무기 인챈트 비례 명중 (PC vs PC)
		if (_weaponEnchant > 0) {
			int mEnc = Math.min(_weaponEnchant, 15);
			switch (_weaponId) {
			case 123555: case 123777: case 123888: case 123666: case 123900:
			case 123444: case 124111:
				_hitRate += mEnc + (mEnc / 2); break;
			case 123800:
				if (_weaponType == 20) _hitRate += mEnc + (mEnc / 2); break;
			case 123333:
				_hitRate += mEnc / 2; break;
			default: break;
			}
		}

		/** 요정일경우 80부터 렙당 명중 상승 **/
		if (_pc.isElf() || _pc.isWarrior() || _pc.isCrown() || _pc.isKnight() || _pc.isWizard() || _pc.isDarkelf()
				|| _pc.isBlackwizard() || _pc.isDragonknight()) {
			_hitRate += Math.max(0, _pc.getLevel() - Config.Start_Char_Level);
		}

		/** 전사일경우 70부터 렙당 명중+1 상승 **/
		/*
		 * if (_pc.is전사()) { _hitRate += Math.max(0, _pc.getLevel() - 70) * 1; }
		 */

		int attackerDice = _random.nextInt(20) + 1 + _hitRate - 10;

		/** 타겟PC의 회피 스킬 연산 **/
		attackerDice -= toPcSkillHit() * 0.1D;

		int defenderValue = (int) (_targetPc.getAC().getAc() * 1.5) * -1;
		int levelDmg = (int) ((_targetPc.getLevel() - _pc.getLevel()) * 2.0);
		if (levelDmg <= 0)
			levelDmg = 0;

		defenderValue += levelDmg;

		/** DefenderDice 연산 **/
		int defenderDice = toPcDD(defenderValue);
//		if (Config.CHAR_BALANCE_USE) {
//		}
//		_hitRate -= WeaponBalanceTable.getInstance().getItemBalanceHit(_weaponId, _weaponEnchant);
		// 캐릭터 공성데이터 추가
//		try {
//			if (_pc.isCrown()) {
//			} else if (_pc.isKnight()) {
//			} else if (_pc.isElf()) {
//			} else if (_pc.isWizard()) {
//			} else if (_pc.isDarkelf()) {
//			} else if (_pc.isBlackwizard()) {
//			} else if (_pc.isDragonknight()) {
//			} else if (_pc.isWarrior()) {
//			}
//		} catch (Exception e) {
//			System.out.println("Character Add Damege Error");
//		}

		/** 히트 최종 연산 **/
		if (hitRateCal(attackerDice, defenderDice, _hitRate - 9, _hitRate + 10))
			return false;

		if (_pc.getLocation().getLineDistance(_targetPc.getLocation()) >= 3 && _weaponType != 20 && _weaponType != 62) { // 타겟과의
			_hitRate = 0;
		}
		int rnd = _random.nextInt(100) + 1;
		if (_weaponType == 20 && _hitRate > rnd) { // 활의 경우 , 히트 했을 경우에서도
													// ER에서의회피를 재차 실시한다.
			return calcErEvasion();
		}

		int _jX = _pc.getX() - _targetPc.getX();
		int _jY = _pc.getY() - _targetPc.getY();

		if (_weaponType == 24) { // 창
			if ((_jX > 3 || _jX < -3) && (_jY > 3 || _jY < -3)) {
				_hitRate = 0;
			}
		} else if (_weaponType == 20 || _weaponType == 62) {// 활
			if ((_jX > 15 || _jX < -15) && (_jY > 15 || _jY < -15)) {
				_hitRate = 0;
			}
		} else {
			if ((_jX > 2 || _jX < -2) && (_jY > 2 || _jY < -2)) {
				_hitRate = 0;
			}
		}
		if (_hitRate >= rnd) {
			return true;
		} else {

			SC_SkillSound.send(_pc, _targetPc.getId(), 13418);//
			SC_SkillSound.send(_targetPc, _targetPc.getId(), 13418);// 이펙트
			return false;
		}
	}

	// ●●●● 플레이어로부터 NPC 에의 명중 판정 ●●●●
	private boolean calcPcNpcHit() {
		if (_targetNpc.getNpcId() == MJRaidLoadManager.MRS_SP_VALAKAS_HPABSORB_ID
				|| _targetNpc.getNpcId() == MJRaidLoadManager.MRS_SP_VALAKAS_MPABSORB_ID) {
			if (!_pc.isValakasProduct())
				return false;
		}

		if (_targetNpc.getNpcTemplate().get_npcId() == 8500138)
			return false;

		if (_targetNpc.getHiddenStatus() != L1NpcInstance.HIDDEN_STATUS_NONE)
			return false;

		/** SPR체크 **/
		int npcId = _targetNpc.getNpcTemplate().get_npcId(); // 씨엠디오류나옴
		if (npcId >= 45912 && npcId <= 45915 && !_pc.hasSkillEffect(L1SkillId.STATUS_HOLY_WATER)) {
			_hitRate = 0;
			return false;
		}
		if (npcId == 45916 && !_pc.hasSkillEffect(L1SkillId.STATUS_HOLY_MITHRIL_POWDER)) {
			_hitRate = 0;
			return false;
		}
		if (npcId == 45941 && !_pc.hasSkillEffect(L1SkillId.STATUS_HOLY_WATER_OF_EVA)) {
			_hitRate = 0;
			return false;
		}
		// if (npcId == 45752 && !_pc.hasSkillEffect(STATUS_CURSE_BARLOG)) {
		// _hitRate = 0;
		// return false;
		// }
		// if (npcId == 45753 && !_pc.hasSkillEffect(STATUS_CURSE_BARLOG)) {
		// _hitRate = 0;
		// return false;
		// }
		// if (npcId == 45675 && !_pc.hasSkillEffect(STATUS_CURSE_YAHEE)) {
		// _hitRate = 0;
		// return false;
		// }
		// if (npcId == 81082 && !_pc.hasSkillEffect(STATUS_CURSE_YAHEE)) {
		// _hitRate = 0;
		// return false;
		// }
		// if (npcId == 45625 && !_pc.hasSkillEffect(STATUS_CURSE_YAHEE)) {
		// _hitRate = 0;
		// return false;
		// }
		/*
		 * if (npcId == 45674 && !_pc.hasSkillEffect(STATUS_CURSE_YAHEE)) { _hitRate =
		 * 0; return false; } if (npcId == 45685 &&
		 * !_pc.hasSkillEffect(STATUS_CURSE_YAHEE)) { _hitRate = 0; return false; }
		 */
		if (npcId >= 46068 && npcId <= 46091 && _pc.getCurrentSpriteId() == 6035) {
			_hitRate = 0;
			return false;
		}
		if (npcId >= 46092 && npcId <= 46106 && _pc.getCurrentSpriteId() == 6034) {
			_hitRate = 0;
			return false;
		}
		if (_targetNpc.getNpcTemplate().get_gfxid() == 7684 && !_pc.hasSkillEffect(L1SkillId.PAP_FIVEPEARLBUFF)) { // 오색진주
			_hitRate = 0;
			return false;
		}
		if (_targetNpc.getNpcTemplate().get_gfxid() == 7805 && !_pc.hasSkillEffect(L1SkillId.PAP_MAGICALPEARLBUFF)) { // 신비진주
			_hitRate = 0;
			return false;
		}
		if (_calcType == PC_NPC) {
			if (_pc.hasSkillEffect(L1SkillId.버닝샷)) {

				int diffLocX = Math.abs(_pc.getX() - _targetNpc.getX());
				int diffLocY = Math.abs(_pc.getY() - _targetNpc.getY());

				if (diffLocX > Config.버닝샷칸 || diffLocY > Config.버닝샷칸) {

					return false;
				}
			}
		}
		// NPC에의 명중율 =(PC의 Lv＋클래스 보정＋STR 보정＋DEX 보정＋무기 보정＋DAI의 매수/2＋마법
		// 보정)×5－{NPC의 AC×(-5)}
		_hitRate = _pc.getLevel();
//		_hitRate = ((int) (_hitRate
		/** 스탯 + 무기에 따른 공성 **/
		_hitRate += PchitAdd();
		if (_weaponType == 20 && _arrow != null) {
			_hitRate += _arrow.getItem().getHitModifier();
		}
		// 신화 무기 인챈트 비례 명중 (PC vs NPC)
		if (_weaponEnchant > 0) {
			int mEncN = Math.min(_weaponEnchant, 15);
			switch (_weaponId) {
			case 123555: case 123777: case 123888: case 123666: case 123900:
			case 123444: case 124111:
				_hitRate += mEncN + (mEncN / 2); break;
			case 123800:
				if (_weaponType == 20) _hitRate += mEncN + (mEncN / 2); break;
			case 123333:
				_hitRate += mEncN / 2; break;
			default: break;
			}
		}
		if (_targetNpc.getAC().getAc() < 0) {
			int acrate = _targetNpc.getAC().getAc() * -1;
			double aaaa = (_hitRate / 100) * (acrate / 2.5D);
			_hitRate -= (int) aaaa;
		}

		if (_pc.getLevel() < _targetNpc.getLevel()) {
			_hitRate -= _targetNpc.getLevel() - _pc.getLevel();
		}
		if (_hitRate > 95) {
			_hitRate = 95;
		} else if (_hitRate < 5) {
			_hitRate = 5;
		}

		int _jX = _pc.getX() - _targetNpc.getX();
		int _jY = _pc.getY() - _targetNpc.getY();

		if (_weaponType == 24) { // 창일때
			if ((_jX > 3 || _jX < -3) && (_jY > 3 || _jY < -3)) {
				_hitRate = 0;
			}
		} else if (_weaponType == 20 || _weaponType == 62) {// 활일때
			if ((_jX > 15 || _jX < -15) && (_jY > 15 || _jY < -15)) {
				_hitRate = 0;
			}
		} else {
			if ((_jX > 2 || _jX < -2) && (_jY > 2 || _jY < -2)) {
				_hitRate = 0;
			}
		}

//		try {
//			if (_pc.isCrown()) {
//			} else if (_pc.isKnight()) {
//			} else if (_pc.isElf()) {
//			} else if (_pc.isWizard()) {
//			} else if (_pc.isDarkelf()) {
//			} else if (_pc.isBlackwizard()) {
//			} else if (_pc.isDragonknight()) {
//			} else if (_pc.isWarrior()) {
//			}
//
//		} catch (Exception e) {
//			System.out.println("Character Add Damege Error");
//		}

//		if (Config.CHAR_BALANCE_USE) {
//		}
//		_hitRate += WeaponBalanceTable.getInstance().getItemBalanceHit(_weaponId, _weaponEnchant);
		// TODO 클라우디아 - 해당 맵에서는 무조건
		/*
		 * if (_targetNpc.getMapId() == 1 || _targetNpc.getMapId() == 2 ||
		 * _targetNpc.getMapId() == 3 || _targetNpc.getMapId() == 7 ||
		 * _targetNpc.getMapId() == 8 || _targetNpc.getMapId() == 10 ||
		 * _targetNpc.getMapId() == 11 || _targetNpc.getMapId() == 12 ||
		 * _targetNpc.getMapId() == 12146 || _targetNpc.getMapId() == 12147 ||
		 * _targetNpc.getMapId() == 9) { return true; }
		 */

		// 몬스터 ac
		// _hitRate -= 3;

		return _hitRate >= _random.nextInt(100) + 1;
	}

	// ●●●● NPC 로부터 플레이어에의 명중 판정 ●●●●
	private boolean calcNpcPcHit() {

		if (_targetPc.hasSkillEffect(L1SkillId.ABSOLUTE_BARRIER)) {
			return false;
		}
		_hitRate += _npc.getLevel() * 1.2;

		if (_npc instanceof L1PetInstance) { // 펫은 LV1마다 추가 명중+2
			_hitRate += _npc.getLevel() * 2;
			_hitRate += ((L1PetInstance) _npc).getHitByWeapon();
		}

		_hitRate += _npc.getHitup();

		/** 타겟PC의 회피 스킬 연산 **/
		_hitRate += toPcSkillHit();
		_hitRate += (_targetPc.getAC().getAc() * 0.01);
		/*
		 * if (_targetPc.getAC().getAc() < 0) _hitRate += (int) ((-10 +
		 * _targetPc.getAC().getAc()) * (Config.PER_AC_PC_TO_PC * 0.01)); else {
		 * _hitRate -= (int) ((10 - _targetPc.getAC().getAc()) * (Config.PER_AC_PC_TO_PC
		 * * 0.01)); }
		 */
//		if (Config.CHAR_BALANCE_USE) {
//		}

		if (_npc.getNpcTemplate().get_ranged() < 10) {
			int dg = _target.getDg();
			if (dg != 0) {
				dg = (int) (dg * (Config.PER_DODGE * 0.02D));
				_hitRate = (int) (_hitRate - _hitRate * dg * 0.01D);
			}
		} else {
			int er = _target.getTotalER();
			if (er > 0) {
				er = (int) (er * (Config.PER_EVASION * 0.03D));
				_hitRate = (int) (_hitRate - _hitRate * er * 0.01D);
			}
		}

		return _hitRate >= _random.nextInt(100) + 1;
	}

	// int attackerDice = _random.nextInt(20) + 1 + _hitRate - 1;
	//
	// /** 타겟PC의 회피 스킬 연산 **/
	// attackerDice -= toPcSkillHit() * 0.1D;
	//
	// int defenderValue = (_targetPc.getAC().getAc()) * -1;
	//
	// /** DefenderDice 연산 **/
	// int defenderDice = toPcDD(defenderValue);
	//
	// /** 히트 최종 연산 **/
	// if (hitRateCal(attackerDice, defenderDice, _hitRate, _hitRate + 19))
	// return false;
	//
	// int rnd = _random.nextInt(100) + 1;
	// NPC의 공격 레인지가 10이상의 경우로, 2이상 떨어져 있는 경우활공격으로 간주한다
	// if (_npc.getNpcTemplate().get_ranged() >= 10 && _hitRate > rnd
	// && _npc.getLocation().getTileLineDistance(new Point(_targetX, _targetY))
	// >= 2) {
	// return calcErEvasion();
	// }
	// return _hitRate >= rnd;
	// }

	// ●●●● NPC 로부터 NPC 에의 명중 판정 ●●●●
	private boolean calcNpcNpcHit() {
		if (_targetNpc.getHiddenStatus() != L1NpcInstance.HIDDEN_STATUS_NONE)
			return false;

		if (_targetNpc.getNpcTemplate().get_npcId() == 8500138)
			return false;

		int target_ac = 10 - _targetNpc.getAC().getAc();
		int attacker_lvl = _npc.getNpcTemplate().get_level();

		if (target_ac != 0) {
			_hitRate = (100 / target_ac * attacker_lvl); // 피공격자 AC = 공격자 Lv //
															// 의 때 명중율 100%
		} else {
			_hitRate = 100 / 1 * attacker_lvl;
		}

		if (_npc instanceof L1PetInstance) { // 펫은 LV1마다 추가 명중+2
			_hitRate += _npc.getLevel() * 2;
			_hitRate += ((L1PetInstance) _npc).getHitByWeapon();
		}

		if (_hitRate < attacker_lvl) {
			_hitRate = attacker_lvl; // 최저 명중율=Lｖ％
		}
		if (_hitRate > 95) {
			_hitRate = 95; // 최고 명중율은 95%
		}
		if (_hitRate < 5) {
			_hitRate = 5; // 공격자 Lv가 5 미만때는 명중율 5%
		}
//		if (Config.CHAR_BALANCE_USE) {
//		}

		int rnd = _random.nextInt(100) + 1;
		return _hitRate >= rnd;
	}

	// ●●●● ER에 의한 회피 판정 ●●●●
	private boolean calcErEvasion() {
		int er = _targetPc.getTotalER();

		int rnd = _random.nextInt(130) + 1;
		return er < rnd;
	}

	public int calcDamage() {
		return calcDamage(false);
	}
	

	public int calcDamage(boolean inferno) {
		try {
			switch (_calcType) {
			case PC_PC:
				_damage = calcPcPcDamage();
				_damage += _pc.get_lateral_damage();
				_damage -= _targetPc.get_lateral_reduction();
				if (_pc.getDamageReductionIgnore() > 0)
					_damage += (_pc.getDamageReductionIgnore() * Config.REDUCTION_IGNORE_DAMAGERATE);

				if (_weaponType == 20 || _weaponType == 62) {
					int Bowcritical = CalcStat.calcBowCritical(_pc.getAbility().getTotalDex()) + 1;
					if ((Bowcritical > 0 || _pc.get_missile_critical_rate() > 0)
							&& MJRnd.isWinning(100, Bowcritical + _pc.get_missile_critical_rate())) {
						_damage *= Config.MISSILE_CRITICAL_DAMAGE_RATE;
						if (_pc.getCurrentSpriteId() == 21209 || _pc.getCurrentSpriteId() == 21258
								|| _pc.getCurrentSpriteId() == 21405 || _pc.getCurrentSpriteId() == 21409
								|| _pc.getCurrentSpriteId() == 19514) {
							SC_SkillSound.send(_pc, _pc.getId(), 20540);
							SC_SkillSound.broadcast(_pc, _pc.getId(), 20540);
						}
						SC_AttackCritical.send(_pc.getNetConnection(), _pc, _targetId, _targetX, _targetY, _weaponType, _isHit);
						if (_effex != 1) {
							SC_SkillSound.send(_pc, _targetPc.getId(), 400);
						}

						SC_AttackCritical.broadcast(_pc, _targetId, _targetX, _targetY, _weaponType, _isHit);

						_isCritical = true;
					} else {
						int chance3 = _random.nextInt(100) + 1;
						if (chance3 < 40 && _effex != 1) {
							_damage += 10;
							SC_SkillSound.send(_pc, _targetPc.getId(), 402);
						}
					}
				} else if (_weaponType2 == 17) {
					int magiccritical = CalcStat.calcMagicCritical(_pc.getAbility().getTotalInt()) + 1;
					if ((magiccritical > 0 || _pc.get_magic_critical_rate() > 0)
							&& MJRnd.isWinning(100, magiccritical + _pc.get_magic_critical_rate())) {
						_damage *= Config.MAGIC_CRITICAL_DAMAGE_RATE;
						_isCritical = true;
						SC_AttackCritical.send(_pc.getNetConnection(), _pc, _targetId, 91, Sweapon != null);
						if (_effex != 1) {
							SC_SkillSound.send(_pc, _targetPc.getId(), 400);
						}
						SC_AttackCritical.broadcast(_pc, _targetId, 91, Sweapon != null);
					} else {
						int chance3 = _random.nextInt(100) + 1;
						if (chance3 < 40 && _effex != 1) {
							_damage += 10;
							SC_SkillSound.send(_pc, _targetPc.getId(), 402);
						}
					}
				} else {
					if (_weaponType2 != 0) {
						int Dmgcritical = CalcStat.calcDmgCritical(_pc.getAbility().getTotalStr()) + 1;
						if ((Dmgcritical > 0 || _pc.get_melee_critical_rate() > 0) && MJRnd.isWinning(100,
								Dmgcritical + _pc.get_melee_critical_rate() + _pc.get_final_burn_critical_rate())) {
							_damage *= Config.MELEE_CRITICAL_DAMAGE_RATE;
							_isCritical = true;
							SC_AttackCritical.send(_pc.getNetConnection(), _pc, _targetId, _weaponType, Sweapon != null);
							if (_effex != 1) {
								SC_SkillSound.send(_pc, _targetPc.getId(), 400);
							}
							SC_AttackCritical.broadcast(_pc, _targetId, _weaponType, Sweapon != null);
						} else {
							int chance3 = _random.nextInt(100) + 1;
							if (chance3 < 40 && _effex != 1) {
								_damage += 10;
								SC_SkillSound.send(_pc, _targetPc.getId(), 402);
							}
						}
					}
				}

				if (_pc.getRedKnightClanId() != 0)
					_pc.addRedKnightDamage(_targetPc.getRedKnightClanId() == 0 ? _damage : -_damage);

				// 타이탄 락 : HP가 40% 미만일때 근접공격을 확률적으로 반사.
				if (_weaponType != 20 && _weaponType != 62 && _weaponType2 != 17 && _weaponType2 != 19) {
					if (_targetPc.getPassive(MJPassiveID.TITAN_ROCK.toInt()) != null) {
						int percent = (int) Math
								.round(((double) _targetPc.getCurrentHp() / (double) _targetPc.getMaxHp()) * 100);
						int chance = _random.nextInt(100) + 1;
						int 락구간 = 0;
						if (_targetPc.hasSkillEffect(L1SkillId.SHOCK_STUN) || _targetPc.hasSkillEffect(L1SkillId.EMPIRE)
								|| _targetPc.hasSkillEffect(L1SkillId.EARTH_BIND)) {
							break;
						}
						L1ItemInstance item = _pc.getInventory().findEquippedItemId(123900);
						if (item != null) {
							SC_SystemMessage.send(_pc, "\\fI실렌의 결의: \\f3[타이탄:락] \\fI대미지반사를 무시하였습니다.");
							break;
						}
						if (_target.get락구간상승() != 0) {
							락구간 += _target.get락구간상승();
						}
						int titan = _targetPc.getInventory().checkEquippedcount(202014);
						락구간 += titan == 1 ? 5 : titan == 2 ? 10 : 0;
						if (!MJCommons.isUnbeatable(_targetPc) && percent <= (40 + 락구간 + _targetPc.getRisingUp())
								&& chance <= Config.TitanRock_probability) {
							if (_targetPc.getInventory().checkItem(41246, 10)) {
								_pc.receiveCounterBarrierDamage(_targetPc, 타이탄대미지());
								_damage = 0;
								SC_SkillSound.send(_targetPc, _targetPc.getId(), 12555);
								_targetPc.getInventory().consumeItem(41246, 10);
							} else {
								SC_SystemMessage.send(_targetPc, "타이탄 락: 촉매제가 부족합니다.");
							}
						}
					} else if (_targetPc.hasSkillEffect(L1SkillId.할파스)) {
						int chance0 = _random.nextInt(1000) + 1;
						if (_targetPc.hasSkillEffect(L1SkillId.SHOCK_STUN) || _targetPc.hasSkillEffect(L1SkillId.EMPIRE)
								|| _targetPc.hasSkillEffect(L1SkillId.EARTH_BIND)) {
							break;
						}

						if (!MJCommons.isUnbeatable(_targetPc) && chance0 <= Config.할파스확률) {
							_pc.receiveCounterBarrierDamage(_targetPc, 할파스대미지());

							_isHit = false;

							// _targetPc.sendPackets(new S_SkillSound(_targetPc.getId(), 16301));
							// _targetPc.broadcastPacket(new S_SkillSound(_targetPc.getId(), 16301));
							_pc.send_action(ActionCodes.ACTION_Damage);
							SC_SkillSound.send(_targetPc, _targetPc.getId(), 14456);
							SC_SkillSound.broadcast(_targetPc, _targetPc.getId(), 14456);

						}

					}

				} else {
					if (_weaponType2 != 17 && _weaponType2 != 19) {
						if (_targetPc.getPassive(MJPassiveID.TITAN_BLITZ.toInt()) != null) {
							int percent = (int) Math
									.round(((double) _targetPc.getCurrentHp() / (double) _targetPc.getMaxHp()) * 100);
							int chance = _random.nextInt(100) + 1;
							int 락구간 = 0;
							if (_targetPc.hasSkillEffect(L1SkillId.SHOCK_STUN)
									|| _targetPc.hasSkillEffect(L1SkillId.EMPIRE)
									|| _targetPc.hasSkillEffect(L1SkillId.EARTH_BIND)) {
								break;
							}
							if (_target.get락구간상승() != 0) {
								락구간 += _target.get락구간상승();
							}
							int titan = _targetPc.getInventory().checkEquippedcount(202014);
							락구간 += titan == 1 ? 5 : titan == 2 ? 10 : 0;
							if (!MJCommons.isUnbeatable(_targetPc) && percent <= (40 + 락구간 + _targetPc.getRisingUp())
									&& chance <= Config.Titanbullet_probability) {
								if (_targetPc.getInventory().checkItem(41246, 10)) {
									_pc.receiveCounterBarrierDamage(_targetPc, 타이탄대미지());
									_damage = 0;
									SC_SkillSound.send(_targetPc, _targetPc.getId(), 12557);
									_targetPc.getInventory().consumeItem(41246, 10);
								} else {
									SC_SystemMessage.send(_targetPc, "타이탄 블릿: 촉매제가 부족합니다.");
								}
							}
						}
					} else {
						if (_targetPc.getPassive(MJPassiveID.TITAN_MAGIC.toInt()) != null) {
							int percent = (int) Math
									.round(((double) _targetPc.getCurrentHp() / (double) _targetPc.getMaxHp()) * 100);
							int chance = _random.nextInt(100) + 1;
							int 락구간 = 0;
							if (_targetPc.hasSkillEffect(L1SkillId.SHOCK_STUN)
									|| _targetPc.hasSkillEffect(L1SkillId.EMPIRE)
									|| _targetPc.hasSkillEffect(L1SkillId.EARTH_BIND)) {
								break;
							}
							if (_target.get락구간상승() != 0) {
								락구간 += _target.get락구간상승();
							}
							int titan = _targetPc.getInventory().checkEquippedcount(202014);
							락구간 += titan == 1 ? 5 : titan == 2 ? 10 : 0;
							if (!MJCommons.isUnbeatable(_targetPc) && percent <= (40 + 락구간 + _targetPc.getRisingUp())
									&& chance <= Config.Titanmagic_probability) {
								if (this._targetPc.getInventory().checkItem(41246, 10)) {
									if (this._calcType == 1)
										this._pc.receiveCounterBarrierDamage(this._targetPc, 타이탄대미지());
									else if (this._calcType == 2)
										this._npc.receiveCounterBarrierDamage(this._targetPc, 타이탄대미지());
									_damage = 0;
									SC_SkillSound.send(this._targetPc, this._targetPc.getId(), 12559);
									this._targetPc.getInventory().consumeItem(41246, 10);
								} else {
									SC_SystemMessage.send(this._targetPc, "타이탄 매직: 촉매제가 부족합니다.");
								}
							}
						}
					}
				}
				break;
			case PC_NPC:
				try {
					_damage = calcPcNpcDamage();
					_damage += _pc.get_lateral_damage();

					if (_weaponType == 20 || _weaponType == 62) {
						int Bowcritical = CalcStat.calcBowCritical(_pc.getAbility().getTotalDex()) + 1;
						if ((Bowcritical > 0 || _pc.get_missile_critical_rate() > 0)
								&& MJRnd.isWinning(100, Bowcritical + _pc.get_missile_critical_rate())) {
							_damage *= Config.MISSILE_CRITICAL_DAMAGE_RATE;
							if (_pc.getCurrentSpriteId() == 21209 || _pc.getCurrentSpriteId() == 21258
									|| _pc.getCurrentSpriteId() == 21405 || _pc.getCurrentSpriteId() == 21409
									|| _pc.getCurrentSpriteId() == 19514) {
								SC_SkillSound.send(_pc, _pc.getId(), 20540);
								SC_SkillSound.broadcast(_pc, _pc.getId(), 20540);
							}
							SC_AttackCritical.send(_pc.getNetConnection(), _pc, _targetId, _targetX, _targetY, _weaponType, _isHit);
							if (_effex != 1) {
								SC_SkillSound.send(_pc, _targetNpc.getId(), 400);
							}
							SC_AttackCritical.broadcast(_pc, _targetId, _targetX, _targetY, _weaponType, _isHit);
							_isCritical = true;
						} else {
							int chance3 = _random.nextInt(100) + 1;
							if (chance3 < 40 && _effex != 1) {
								_damage += 10;
								SC_SkillSound.send(_pc, _targetNpc.getId(), 402);
							}
						}
					} else if (_weaponType2 == 17) {
						int magiccritical = CalcStat.calcMagicCritical(_pc.getAbility().getTotalInt()) + 1;
						if ((magiccritical > 0 || _pc.get_magic_critical_rate() > 0)
								&& MJRnd.isWinning(100, magiccritical + _pc.get_magic_critical_rate())) {
							_isCritical = true;
							_damage *= Config.MAGIC_CRITICAL_DAMAGE_RATE;
							SC_AttackCritical.send(_pc.getNetConnection(), _pc, _targetId, 91, Sweapon != null);
							if (_effex != 1) {
								SC_SkillSound.send(_pc, _targetNpc.getId(), 400);
							}
							SC_AttackCritical.broadcast(_pc, _targetId, 91, Sweapon != null);
						} else {
							int chance3 = _random.nextInt(100) + 1;
							if (chance3 < 40 && _effex != 1) {
								_damage += 10;
								SC_SkillSound.send(_pc, _targetNpc.getId(), 402);
							}
						}
					} else {
						if (_weaponType2 != 0) {
							int Dmgcritical = CalcStat.calcDmgCritical(_pc.getAbility().getTotalStr()) + 1;
							if ((Dmgcritical > 0 || _pc.get_melee_critical_rate() > 0) && MJRnd.isWinning(100,
									Dmgcritical + _pc.get_melee_critical_rate() + _pc.get_final_burn_critical_rate())) {
								_isCritical = true;
								_damage *= Config.MELEE_CRITICAL_DAMAGE_RATE;
								SC_AttackCritical.send(_pc.getNetConnection(), _pc, _targetId, _weaponType, Sweapon != null);
								if (_effex != 1) {
									SC_SkillSound.send(_pc, _targetNpc.getId(), 400);
								}
								SC_AttackCritical.broadcast(_pc, _targetId, _weaponType, Sweapon != null);
							} else {
								int chance3 = _random.nextInt(100) + 1;
								if (chance3 < 40 && _effex != 1) {
									_damage += 10;
									SC_SkillSound.send(_pc, _targetNpc.getId(), 402);
								}
							}
						}
					}

				} catch (Exception e) {
					e.printStackTrace();
				}
				break;
			case NPC_PC:
				if (_npc instanceof L1CompanionInstance || _npc instanceof MJDogFightInstance)
					_damage = do_calc_damage_companion(_npc);
				else
					_damage = calcNpcPcDamage();
				_damage -= _targetPc.get_lateral_reduction();
				// if (_targetPc.getDamageReductionIgnore() > 0)
				// _damage += (_targetPc.getDamageReductionIgnore() *
				// Config.REDUCTION_IGNORE_DAMAGERATE);

				// 타이탄 락 : HP가 40% 미만일때 근접 공격을 확률적으로 반사.
				int bowactid = _npc.getNpcTemplate().getBowActId();
				if (bowactid != 66) {
					if (_targetPc.getPassive(MJPassiveID.TITAN_ROCK.toInt()) != null) {
						int percent = (int) Math
								.round(((double) _targetPc.getCurrentHp() / (double) _targetPc.getMaxHp()) * 100);
						int chance = _random.nextInt(100) + 1;
						int 락구간 = 0;
						if (_target.get락구간상승() != 0) {
							락구간 += _target.get락구간상승();
						}
						int titan = _targetPc.getInventory().checkEquippedcount(202014);
						락구간 += titan == 1 ? 5 : titan == 2 ? 10 : 0;
						if (!MJCommons.isUnbeatable(_targetPc) && percent <= (40 + 락구간 + _targetPc.getRisingUp())
								&& chance <= Config.TitanRock_probability) {

							if (_targetPc.getInventory().checkItem(41246, 10)) {
								_npc.receiveCounterBarrierDamage(_targetPc, 타이탄대미지());
								_damage = 0;
								SC_SkillSound.send(_targetPc, _targetPc.getId(), 12555);
								_targetPc.getInventory().consumeItem(41246, 10);
							} else {
								SC_SystemMessage.send(_targetPc, "타이탄 락: 촉매제가 부족합니다.");
							}
						}
					} else if (_targetPc.hasSkillEffect(L1SkillId.할파스)) {
						int chance0 = _random.nextInt(1000) + 1;
						// if (_targetPc.hasSkillEffect(L1SkillId.SHOCK_STUN)
						// || _targetPc.hasSkillEffect(L1SkillId.EMPIRE)
						// || _targetPc.hasSkillEffect(L1SkillId.EARTH_BIND)) {
						// break;
						// }

						if (!MJCommons.isUnbeatable(_targetPc) && chance0 <= Config.할파스확률) {
							_npc.receiveCounterBarrierDamage(_targetPc, 할파스대미지());
							_isHit = false;
							// _targetPc.sendPackets(new S_SkillSound(_targetPc.getId(), 16301));
							// _targetPc.broadcastPacket(new S_SkillSound(_targetPc.getId(), 16301));
							SC_SkillSound.send(_targetPc, _targetPc.getId(), 14456);
							SC_SkillSound.broadcast(_targetPc, _targetPc.getId(), 14456);
						}

					}
				} else {
					// 타이탄 블릿 : HP가 40% 미만일때 원거리 공격을 확률적으로 반사.
					if (_targetPc.getPassive(MJPassiveID.TITAN_BLITZ.toInt()) != null) {
						int percent = (int) Math
								.round(((double) _targetPc.getCurrentHp() / (double) _targetPc.getMaxHp()) * 100);
						int chance = _random.nextInt(100) + 1;
						int 락구간 = 0;
						if (_target.get락구간상승() != 0) {
							락구간 += _target.get락구간상승();
						}
						int titan = _targetPc.getInventory().checkEquippedcount(202014);
						락구간 += titan == 1 ? 5 : titan == 2 ? 10 : 0;
						if (!MJCommons.isUnbeatable(_targetPc) && percent <= (40 + 락구간 + _targetPc.getRisingUp())
								&& chance <= Config.Titanbullet_probability) {
							if (_targetPc.getInventory().checkItem(41246, 10)) {
								_npc.receiveCounterBarrierDamage(_targetPc, 타이탄대미지());
								_damage = 0;
								SC_SkillSound.send(_targetPc, _targetPc.getId(), 12557);
								_targetPc.getInventory().consumeItem(41246, 10);
							} else {
								SC_SystemMessage.send(_targetPc, "타이탄 블릿: 촉매제가 부족합니다.");
							}
						}
					}
				}
				break;
			case NPC_NPC:
				if (_npc instanceof L1CompanionInstance || _npc instanceof MJDogFightInstance) {
					_damage = do_calc_damage_companion(_npc);

				} else {
					_damage = calcNpcNpcDamage();
				}
				break;
			default:
				break;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		if (_damage < 0) _damage = 0;
		
		
		// 인페르노의 데미지 감소 처리
		if(inferno) {
			_damage /= 2;
		}
		
		return _damage;
	}
	// ●●●● 플레이어로부터 플레이어에의 대미지 산출 ●●●●
	public int calcPcPcDamage() {

		int weaponMaxDamage = _weaponSmall; // + _weaponAddDmg;

		int weaponDamage = 0;

		if ((_pc.getZoneType() == 1 && _targetPc.getZoneType() == 0)
				|| (_pc.getZoneType() == 1 && _targetPc.getZoneType() == -1)) {
			_isHit = false;
			// 세이프티존에서 노멀/컴뱃존 공격 불가
		}

		/** 특정지역 PK금지 **/
		// if (_pc.getMapId() == 612 || _pc.getMapId() == 254 || _pc.getMapId() == 1930)
		// {
		if (_pc.getMapId() == 612) {
			weaponDamage = 0;
			_isHit = false;
			_pc.sendPackets("\\fY현재 사냥터에서는 PK가 불가능 합니다.");
			_targetPc.sendPackets("\\fY현재 사냥터에서는 PK가 불가능 합니다.");
			return (int) weaponDamage;
		}

		if (_pc.getClanid() != 0) {
			if (_pc.getClan().getEmblemId() == 0) {
				weaponDamage = 0;
				_isHit = false;
				_pc.sendPackets("\\fY혈맹에 마크가 없으면 대인 공격이 불가합니다.");
				_targetPc.sendPackets("\\fY[공격 무효:" + _pc.getName() + "][원인 : 혈맹 마크 부재]");
				return (int) weaponDamage;
			}
		}
		if (_pc.getMapId() == 63) {
			weaponDamage = 0;
			_isHit = false;
			_pc.sendPackets("\\fY현재 사냥터에서는 PK가 불가능 합니다.");
			_targetPc.sendPackets("\\fY현재 사냥터에서는 PK가 불가능 합니다.");
			return (int) weaponDamage;
		}
		if (_pc.getMapId() == Config.자동사냥맵번호) {
			weaponDamage = 0;
			_isHit = false;
			_pc.sendPackets("\\fY현재 자동사냥 사냥터에서는 PK가 불가능 합니다.");
			_targetPc.sendPackets("\\fY현재 자동사냥 사냥터에서는 PK가 불가능 합니다.");
			return (int) weaponDamage;
		}
		if (!_targetPc.hasSkillEffect(L1SkillId.COMBO_BUFF)) {
			_targetPc.setSkillEffect(L1SkillId.COMBO_BUFF, 3000);
		}
		if (_weaponType == 0) { // 맨손
			weaponDamage = 0;
		} else {
			if (weaponMaxDamage <= 0)
				weaponMaxDamage = 1;
			weaponDamage = _random.nextInt(weaponMaxDamage) + _weaponAddDmg;
		}

		if (_pc.hasSkillEffect(L1SkillId.SOUL_OF_FLAME)) {
			if (_weaponType != 20 && _weaponType != 62) {
				// weaponDamage = weaponMaxDamage + 5;
				weaponDamage = weaponMaxDamage + _weaponAddDmg + 5;
			}
		}
		if (_pc.hasSkillEffect(L1SkillId.잠재력소울스킬)) {
			// weaponDamage = weaponMaxDamage + 5;
			weaponDamage = weaponMaxDamage + _weaponAddDmg + 5;

		}
		if (_target != null) {
			int chance1 = _random.nextInt(100);
			for (L1ItemInstance item : _targetPc.getInventory().getItems()) {
				if (item.isEquipped()) {
					if (item.getItemId() == 123111 || item.getItemId() == 123112 || item.getItemId() == 123113) {
						int addchan = 5;
						if (addchan < 0)
							addchan = 0;
						if (chance1 < Config.할파스갑옷확률) {
							// 123456 일때 80~100
							// 파푸 가호 7일때 120~140 / 8일때 140~160 9일때 160~180
							int addhp = _random.nextInt(20) + 1;
							int addmp = _random.nextInt(30) + 1;
							int basehp = 70;
							int basemp = 8;
							if (item.getEnchantLevel() == 1) {
								basehp = 80;
								basemp = 11;
							}
							if (item.getEnchantLevel() == 2) {
								basehp = 90;
								basemp = 14;
							}
							if (item.getEnchantLevel() == 3) {
								basehp = 100;
								basemp = 17;
							}
							if (item.getEnchantLevel() == 4) {
								basehp = 110;
								basemp = 20;
							}
							if (item.getEnchantLevel() == 5) {
								basehp = 120;
								basemp = 23;
							}
							if (item.getEnchantLevel() == 6) {
								basehp = 130;
								basemp = 26;
							}
							if (item.getEnchantLevel() == 7) {
								basehp = 140;
								basemp = 29;
							}
							if (item.getEnchantLevel() == 8) {
								basehp = 150;
								basemp = 32;
							}
							if (item.getEnchantLevel() == 9) {
								basehp = 160;
								basemp = 35;
							}
							if (item.getEnchantLevel() == 10) {
								basehp = 170;
								basemp = 38;
							}

							_targetPc.setCurrentMp(_targetPc.getCurrentMp() + basemp + addmp);
							_targetPc.setCurrentHp(_targetPc.getCurrentHp() + basehp + addhp);
							SC_SkillSound.send(_targetPc, _targetPc.getId(), 7192);
							SC_SkillSound.broadcast(_targetPc, _targetPc.getId(), 7192);
						}
						break;
					}
				}
			}
		}
		int weaponTotalDamage = weaponDamage + _weaponEnchant + _weapon_bless_level;
		boolean secondw = false;
		if (_pc.isWarrior() && _pc.isPassive(MJPassiveID.SLAYER.toInt()) && _pc.getSecondWeapon() != null) {
			int ran = _random.nextInt(100);
			if (ran < 50) {
				secondw = true;
				weaponMaxDamage = _SweaponSmall + _SweaponAddDmg;
			}
		}
		int effcheck = 0;
		/** 포효의이도류 인첸당 발동확률증가 **/
		if (_weaponId == 203018) {
			_weaponDoubleDmgChance += _pc.getWeapon().getEnchantLevel();
		}
		/*
		 * if (_weaponType == 58 && (_random.nextInt(100) + 1) <=
		 * _weaponDoubleDmgChance) { // 크로우 weaponDamage = weaponMaxDamage +
		 * _weaponAddDmg; weaponTotalDamage += weaponDamage; _attackType = 2;
		 * _pc.sendPackets(new S_SkillSound(_targetPc.getId(), 13416));
		 * Broadcaster.broadcastPacket(_targetPc, new S_SkillSound(_targetPc.getId(),
		 * 13416), true); } if (_weaponType == 54 && (_random.nextInt(100) + 1) <=
		 * _weaponDoubleDmgChance) { // 이도류 // weaponDamage = weaponMaxDamage;
		 * weaponDamage = weaponMaxDamage*2; weaponTotalDamage += weaponDamage;
		 * _attackType = 2; _pc.sendPackets(new S_SkillSound(_targetPc.getId(), 13417));
		 * Broadcaster.broadcastPacket(_targetPc, new S_SkillSound(_targetPc.getId(),
		 * 13417), true); }
		 */
		// 더블브레이크 확률 50렙부터 5렙당 1%씩 상승
		if (_pc.hasSkillEffect(L1SkillId.DOUBLE_BRAKE) && (_weaponType == 54 || _weaponType == 58)) {
			int RealSteelLevel = _pc.getLevel();
			if (RealSteelLevel < 45) {
				RealSteelLevel = 45;
			}
			int RealSteelLevelChance = (int) ((RealSteelLevel - 45) / 5 + Config.DOUBLE_BREAK_CHANCE);

			for (L1ItemInstance item : _pc.getInventory().getItems()) {
				if (item.isEquipped()) {
					if (item.getItemId() == 86) {
						if (item.getEnchantLevel() >= 1) {
							RealSteelLevelChance += item.getEnchantLevel() * 2;
						}
					}
					if (item.getItemId() == 123004) {
						if (item.getEnchantLevel() >= 7) {
							RealSteelLevelChance += item.getEnchantLevel() * 2 - 12;
						}
					}
				}
			}
			if (_pc.isPassive(MJPassiveID.DOUBLE_BREAK_DESTINY.toInt())) {
				int lvl = _pc.getLevel();
				if (lvl >= 60)
					RealSteelLevelChance += (lvl - 59);
				if (RealSteelLevelChance >= 10) {
					RealSteelLevelChance = 10;
				}
			}
			if ((_random.nextInt(100) + 1) <= RealSteelLevelChance) {
				weaponTotalDamage += _statusDamage * Config.DOUBLE_BREAK_DESTINY_PC;
				if (_pc.isPassive(MJPassiveID.DOUBLE_BREAK_DESTINY.toInt())) {
					SC_SkillSound.send(_pc, _targetPc.getId(), 17223);
					SC_SkillSound.broadcast(_pc, _targetPc.getId(), 17223);
					SC_SkillSound.send(_pc, _targetPc.getId(), 410);
					effcheck = 1;
					_effex = 1;
				}
			}
			if ((_random.nextInt(100) + 1) <= RealSteelLevelChance) {
				weaponTotalDamage += _statusDamage * Config.BURNING_SPIRIT_PC;
				if (_pc.hasSkillEffect(L1SkillId.BURNING_SPIRIT) || _pc.hasSkillEffect(L1SkillId.버닝)) {
					SC_SkillSound.send(_pc, _targetPc.getId(), 6532);
					SC_SkillSound.broadcast(_pc, _targetPc.getId(), 6532);
					SC_SkillSound.send(_pc, _targetPc.getId(), 406);
					_effex = 1;
					effcheck = 1;
				}
			}
		}

		if (_weaponType != 20 && _weaponType != 62) { // 근거리
			int Dmgcritical = CalcStat.calcDmgCritical(_pc.getAbility().getTotalStr()) + 1;
			int chance = _random.nextInt(100) + 1;

			if (chance <= Dmgcritical) {
				weaponDamage = weaponMaxDamage + _weaponAddDmg + 1;
				weaponDamage += weaponDamage * 1.2;
				_isCritical = true;

			}
		} else {
			int Bowcritical = CalcStat.calcBowCritical(_pc.getAbility().getTotalDex()) + 1;
			int chance = _random.nextInt(100) + 1;
			if (chance <= Bowcritical) {
				weaponDamage = weaponMaxDamage + _weaponAddDmg + 10;
				weaponDamage += weaponDamage * 1.2;
				_isCritical = true;
			}

		}

		double dmg = weaponTotalDamage + _statusDamage;

		// if (_weaponType2 == 17) {
		// // dmg = L1WeaponSkill.키링크데미지(_pc, _target);
		// dmg = MJCommons.getMagicDamage(_pc, _targetPc, (int) dmg);
		// }
		// if (_weaponType != 20 && _weaponType != 62) {
		// // dmg = weaponTotalDamage + _statusDamage + _pc.getDmgup() +
		// // _pc.getDmgRate() + _pc.get_regist_PVPweaponTotalDamage();
		// dmg = weaponTotalDamage + _statusDamage + _pc.getDmgup() + _pc.getDmgRate();
		// } else {
		// // dmg = weaponTotalDamage + _statusDamage + _pc.getBowDmgup() +
		// // _pc.getBowDmgRate() + _pc.get_regist_PVPweaponTotalDamage() + 5;
		// dmg = weaponTotalDamage + _statusDamage + _pc.getBowDmgup() +
		// _pc.getBowDmgRate();
		// }

		if (_weaponType2 == 17 || _weaponType == 58) {

			dmg += (int) ((double) _pc.getAbility().getSp() * Config.키링크sp + weaponTotalDamage + _statusDamage);

			dmg = calcMrDefense(_target.getResistance().getEffectedMrBySkill(), dmg);

		}
		if (_weaponType2 == 17 || _weaponType == 58) {
			if (_pc.hasSkillEffect(L1SkillId.이뮨투함블레이드)) {
				if (_target.hasSkillEffect(L1SkillId.IMMUNE_TO_HARM)) {

					이뮨투함블레이드();

				}

			}

		}

		if (_weaponType != 20 && _weaponType != 62 && _weaponType != 58 && _weaponType2 != 17) { // [2026-07-30] 키링크(type17) 제외 - INT(SP) 데미지가 근접(STR)식으로 덮어써지던 문제 수정
			dmg = weaponTotalDamage + _statusDamage + _pc.getDmgup() + _pc.getDmgRate();
			// System.out.println("근거리");
		} else {
			if (_weaponType != 58) {
				dmg = weaponTotalDamage + _statusDamage + _pc.getBowDmgup() + _pc.getBowDmgRate();
				// System.out.println("원거리");
			}
		}

		if (_targetPc.hasSkillEffect(L1SkillId.에테리얼)) {
			int R = _random.nextInt(100) + 1;
			if (_targetPc.isstop() || _targetPc.hasSkillEffect(L1SkillId.DESPERADO)
					|| _targetPc.hasSkillEffect(L1SkillId.쉐도우제약) || _targetPc.hasSkillEffect(L1SkillId.이터디스)) {
				if (R <= Config.에테리얼랜덤) {
					SC_SkillSound.send(_targetPc, _targetPc.getId(), 12118);
					SC_SkillSound.broadcast(_targetPc, _targetPc.getId(), 12118);
					dmg /= Config.에테리얼수치;
				}
			}
		}

		// 클랜버프 pvp

		if (_pc.hasSkillEffect(L1SkillId.버서크)) {
			dmg += 20;
		}

		if (_pc.hasSkillEffect(L1SkillId.CLAN_BUFF3)) {
			dmg += 1;
		}
		if (_targetPc.hasSkillEffect(L1SkillId.CLAN_BUFF4)) {
			dmg -= 1;
		}
		if (_weaponType == 20) { // 활
			if (_arrow != null) {
				dmg += _arrow.getItem().getDmgModifier();
			} else {
				dmg += MJRnd.next(2) + 1;
			}
		} else if (_weaponType == 62) { // 암 토토 렛
			int add_dmg = _sting.getItem().getDmgSmall();
			if (add_dmg == 0) {
				add_dmg = 1;
			}
			dmg = dmg + _random.nextInt(add_dmg) + 1;
		}
		dmg = calcBuffDamage(dmg);

		if (_targetPc.hasSkillEffect(L1SkillId.STRIKER_GALE)) { // 게일 외부화
			if (_weaponType == 20) {
				dmg += Config.STRIKERGALEs;
			}
		}

		if (_targetPc.hasSkillEffect(L1SkillId.프라임85)) {
			dmg -= 5;
		}
		if (_targetPc.hasSkillEffect(L1SkillId.프라임90)) {
			dmg -= 10;
		}
		if (_targetPc.hasSkillEffect(L1SkillId.프라임95)) {
			dmg -= 15;
		}

		if (_pc.hasSkillEffect(L1SkillId.램페이지)) {
			if (_targetPc.hasSkillEffect(L1SkillId.SHOCK_STUN) || _targetPc.hasSkillEffect(L1SkillId.THUNDER_GRAB)
					|| _targetPc.hasSkillEffect(L1SkillId.BONE_BREAK) || _targetPc.hasSkillEffect(L1SkillId.EMPIRE)) {
				int ran = _random.nextInt(100) + 1;
				if (ran <= Config.램페이지확률) {
					dmg += (int) ((double) dmg * Config.램페이지데미지);
					SC_SkillSound.send(_pc, _pc.getId(), 5263);
					SC_SkillSound.broadcast(_pc, _pc.getId(), 5263);

				}
			}
		}

		if (_pc.hasSkillEffect(L1SkillId.버닝샷)) {
			if (_pc.getInventory().getTypeEquipped(1, 20) >= 1 || _pc.getInventory().getTypeEquipped(1, 4) >= 1) {
				// dmg += dmg * (Config.버닝샷대미지 / 100);
				dmg += dmg * Config.버닝샷대미지;
			}
		}
		if (_targetPc.hasSkillEffect(L1SkillId.버닝샷)) {
			dmg -= 8;
		}
		if (_targetPc.hasSkillEffect(L1SkillId.레이징포스)) {

			if (_targetPc.getLevel() >= 80 && _targetPc.getLevel() <= 84) {
				dmg -= 1;
			} else if (_targetPc.getLevel() >= 85 && _targetPc.getLevel() <= 88) {
				dmg -= 2;
			} else if (_targetPc.getLevel() >= 89 && _targetPc.getLevel() <= 92) {
				dmg -= 3;
			} else if (_targetPc.getLevel() >= 93 && _targetPc.getLevel() <= 96) {
				dmg -= 4;
			} else if (_targetPc.getLevel() >= 97) {
				dmg -= 5;
			}
		}
		if (_targetPc.hasSkillEffect(L1SkillId.할파스의신의PVP)) {
			for (L1ItemInstance item : _targetPc.getInventory().getItems()) {
				if (item.isEquipped()) {
					if (item.getItemId() == 123111 || item.getItemId() == 123112 || item.getItemId() == 123113) {
						if (item.getEnchantLevel() >= 0) {
							dmg -= item.getEnchantLevel() * 2 + Config.할파스신의PVP;
						}

						break;
					}
				}
			}
		}

		if (_targetPc.hasSkillEffect(L1SkillId.TOP_RANKER))
			dmg -= 8;
		if (_targetPc.hasSkillEffect(L1SkillId.CLAN_BUFF4))
			dmg -= 1;

		if (_targetPc.hasSkillEffect(L1SkillId.메티스정성스프))
			dmg -= 5;
		if (_targetPc.hasSkillEffect(L1SkillId.메티스정성요리))
			dmg -= 5;
		if (_targetPc.hasSkillEffect(L1SkillId.메티스축복주문서))
			dmg -= 3;

		// /** 본섭 10검이상 추타 +1 표기 효과 **/
		// if (_weaponType != 0 && _weaponType != 20) {
		// switch (weapon.getEnchantLevel()) {
		// case 10:
		// dmg += 1;
		// break;
		// case 11:
		// dmg += 2;
		// break;
		// case 12:
		// dmg += 3;
		// break;
		// case 13:
		// dmg += 4;
		// break;
		// case 14:
		// dmg += 5;
		// break;
		// case 15:
		// dmg += 6;
		// break;
		// default:
		// break;
		// }
		// }

		/** 인첸트에 따른 추타관련 **/
		if (_weaponType != 0 && _weaponType != 20) {
			switch (weapon.getEnchantLevel()) {
			case 8:
				dmg += 2;
				break;
			case 9:
				dmg += 4;
				break;
			case 10:
				dmg += 6;
				break;
			case 11:
				dmg += 8;
				break;
			case 12:
				dmg += 10;
				break;
			case 13:
				dmg += 12;
				break;
			case 14:
				dmg += 14;
				break;
			case 15:
				dmg += 17;
				break;
			default:
				break;
			}
		}
		if (_weaponType2 == 17) {
			// dmg = L1WeaponSkill.키링크데미지(_pc, _target);
		}

		if (_weaponType2 == 18)
			 dmg += WeakExposeHelper.applyPowExposeOnHit(_pc, _target, weapon, _weaponType2, (int) dmg);

		/** 특수 인챈트 시스템 **/
		if (_weaponType != 0) {
			switch (weapon.get_item_level()) {
			case 1:// 1단계
				WeaponLevelAttack(_pc, _target, 3740, _pc.getWeapon().getEnchantLevel(), weapon.get_item_level());
				break;
			case 2:// 2단계
				WeaponLevelAttack(_pc, _target, 16018, _pc.getWeapon().getEnchantLevel(), weapon.get_item_level());
				break;
			case 3:// 3단계
				WeaponLevelAttack(_pc, _target, 16024, _pc.getWeapon().getEnchantLevel(), weapon.get_item_level());
				break;
			case 4:// 4단계
				WeaponLevelAttack(_pc, _target, 4167, _pc.getWeapon().getEnchantLevel(), weapon.get_item_level());
				break;
			default:
				break;
			}
		}
		/** 특수 인챈트 시스템 **/

		/** 아이템 스킬 적용 **/
		MJItemSkillModel model = MJItemSkillModelLoader.getInstance().getAtk(_weaponId);
		if (model != null && weapon.get_item_level() == 0) {
			dmg += model.get(_pc, _targetPc, weapon, dmg);
		}

		for (L1ItemInstance item : _pc.getEquipSlot().getArmors()) {
			model = MJItemSkillModelLoader.getInstance().getAtk(item.getItemId());
			if (model != null)
				dmg += model.get(_pc, _targetPc, item, dmg);
		}
		/** 아이템 스킬 적용 **/
//		if (Config.CHAR_BALANCE_USE) {
//		}
	//	dmg += WeaponBalanceTable.getInstance().getItemBalanceDmg(_weaponId, _weaponEnchant);
		if (_weaponType == 0) { // 맨손
			dmg = (_random.nextInt(5) + 4) / 4;
		}

//		try {
//			dmg += WeaponAddDamage.getInstance().getWeaponAddDamage(_weaponId);
//		} catch (Exception e) {
//			System.out.println("무기추가대미지에러");
//		}
		// 신화 무기 인챈트 비례 추가 대미지 (PC vs PC)
		if (_weaponEnchant > 0) {
			int mDmg = Math.min(_weaponEnchant, 15);
			switch (_weaponId) {
			case 123555: case 123777: case 123888: case 123666: case 123900:
			case 123444: case 124111:
				if (_weaponType != 20) dmg += mDmg * 5; break;
			case 123800:
				if (_weaponType == 20) dmg += mDmg * 5; break;
			case 123333:
				dmg += mDmg * 2; break;
			default: break;
			}
		}

		Object[] dollList = _pc.getDollList().values().toArray(); // 매직 돌 인형에 의한
		// 추가 대미지
		for (Object dollObject : dollList) {
			L1DollInstance doll = (L1DollInstance) dollObject;
			if (dollList == null)
				continue;
			if (_weaponType != 20 && _weaponType != 62) {
				dmg += doll.getDamageByDoll();

			}

			/** 특수 마법인형 인챈트 시스템 **/
			// dmg += doll.magic_doll_enchant_dmg(_pc, _targetPc);
			dmg += doll.attackPixieDamage(_pc, _targetPc);
			doll.getPixieGreg(_pc, _targetPc);
		}
		if (_targetPc != null) {
			if (_targetPc.hasSkillEffect(L1SkillId.TRUE_TARGET)) {
				if (_pc != null) {
					if (_targetPc.tt_clanid == _pc.getClanid() || _targetPc.tt_partyid == _pc.getPartyID()) {
						if (_targetPc.tt_level >= 90) {
							dmg += dmg * 0.06;
						} else if (_targetPc.tt_level >= 75) {
							dmg += dmg * 0.05;
						} else if (_targetPc.tt_level >= 60) {
							dmg += dmg * 0.04;
						} else if (_targetPc.tt_level >= 45) {
							dmg += dmg * 0.03;
						} else if (_targetPc.tt_level >= 30) {
							dmg += dmg * 0.02;
						} else if (_targetPc.tt_level >= 15) {
							dmg += dmg * 0.01;
						}
					}

				}
			}
		}
		// 전사 스킬 PC - PC
		// 크래쉬 : 공격자에 레벨에 50% 정도를 데미지에 반영한다.
		if (_pc.getPassive(MJPassiveID.CRASH.toInt()) != null) {
			int chance = _random.nextInt(100) + 1;
			if (Config.crashFo >= chance) { // 크래쉬 : 레벨 나누기 2의 데미지
				// int crashdmg = (int) (_pc.getLevel() + 2 / Config.crashdmg); //원본
				int crashdmg = (int) dmg / 2;

				int furydmg = 0;
				// 퓨리 : 크래쉬에서 나온 데미지에 2배
				if (_pc.getPassive(MJPassiveID.FURY.toInt()) != null) {
					chance = _random.nextInt(100) + 1;
					if (Config.furyFo >= chance) { // 퓨리 확률
						// furydmg += crashdmg / Config.furydmg; //원본
						furydmg += dmg * 2;
						crashdmg = 0;
						// 성공시 이팩 2개 나가는거
						SC_SkillSound.send(_targetPc, _targetPc.getId(), 12489);
						SC_SkillSound.broadcast(_targetPc, _targetPc.getId(), 12489);
						SC_SkillSound.send(_pc, _targetPc.getId(), 372);
						effcheck = 1;
						_effex = 1;
					}
				}
				dmg += crashdmg + furydmg;
				// 크래쉬는 크래쉬 이팩트 그대로 처리.
				SC_SkillSound.send(_targetPc, _targetPc.getId(), 12487);
				SC_SkillSound.broadcast(_targetPc, _targetPc.getId(), 12487);
				if (furydmg == 0) {
					SC_SkillSound.send(_pc, _targetPc.getId(), 406);
					effcheck = 1;
					_effex = 1;
				}
			}
		}

		if (_pc.hasSkillEffect(L1SkillId.주군의버프)) {
			if (_pc.getClanRank() >= L1Clan.수호)
				dmg += 30;
		}
		if ((_pc.getCurrentSpriteId() == 21140 || _pc.getCurrentSpriteId() == 19514) && _pc != null) {
			int chance2 = _random.nextInt(100) + 1;
			int chance3 = _random.nextInt(100) + 1;
			if (chance2 < 3) {
				dmg += 50;
				SC_SkillSound.send(_pc, _targetPc.getId(), 5151);
				SC_SkillSound.broadcast(_pc, _targetPc.getId(), 5151);
			}
			if (chance3 < 3) {
				dmg += 30;
				SC_SkillSound.send(_pc, _targetPc.getId(), 21144);
				SC_SkillSound.broadcast(_pc, _targetPc.getId(), 21144);
			}

		}

		if (_pc.getDollskill() == 1) {
			dmg += 30;
			SC_SkillSound.send(_pc, _targetPc.getId(), 21161);
			SC_SkillSound.broadcast(_pc, _targetPc.getId(), 21161);
			_pc.setDollskill(0);
		}
		if (_pc.getDollskill() == 2) {
			dmg += 20;
			SC_SkillSound.send(_pc, _targetPc.getId(), 374);
			SC_SkillSound.broadcast(_pc, _targetPc.getId(), 374);
			_pc.setDollskill(0);
		}
		/** 대상 속성인첸트에따른 대미지연산 **/
		dmg += 피시속성인첸트효과();

		/** 캐릭별 추가데미지, 추가리덕션, 확률 **/
		if (_calcType == PC_PC) {

			if (_pc.getAddDamageRate() >= CommonUtil.random(100)) {
				dmg += _pc.getAddDamage();
			}
			if (_targetPc.getAddReductionRate() >= CommonUtil.random(100)) {
				dmg -= _targetPc.getAddReduction();
			}
			if (Config.품질시스템사용) {
				if (weapon != null) {
					if (weapon.get_bless_level2() != 0) {
						int level = weapon.get_bless_level2();
						double dmg100 = (level * 1.0) / 1000;
						dmg += dmg * dmg100;
					} else {

					}
				}
			}
		}

		/** 70레벨부터 추가타격 + 1 **/
		dmg += Math.max(0, _pc.getLevel() - 70) * 1;

		/** 케릭터별 PVP대미지 감소 리뉴얼 **/ // pvp데미지
		if ((_targetPc.isCrown() || _targetPc.isElf() || _targetPc.isWizard()) && _targetPc.getLevel() >= 60) {
			dmg -= (_targetPc.getLevel() - Config.Start_Char_Level) / 4;
		} else if ((_targetPc.isKnight()) && _targetPc.getLevel() >= 60) {
			dmg -= (_targetPc.getLevel() - Config.Start_Char_Level) / 2;
		} else if ((_targetPc.isDarkelf() || _targetPc.isDragonknight() || _targetPc.isBlackwizard()
				|| _targetPc.isWarrior()) && _targetPc.getLevel() >= 60) {
			dmg -= (_targetPc.getLevel() - Config.Start_Char_Level) / 3;
		}

		/** 아머브레이크 */
		if (_targetPc.hasSkillEffect(L1SkillId.ARMOR_BRAKE)) { // 아머브레이크
			if (_weaponType != 20 && _weaponType != 62) {
				if (_pc.hasSkillEffect(L1SkillId.ARMOR_BRAKE_ATTACKER)) { // 시전자
					dmg *= Config.아머데미지;
				} else {
					dmg *= Config.아머데미지타인;
				}
			}
		}

		/** 보스 아머브레이크 */
		if (_targetPc.hasSkillEffect(L1SkillId.WIDE_ARMORBREAK)) { // 보스 아머브레이크
			if (_weaponType != 20 && _weaponType != 62) {
				dmg *= 1.58;
			}
		}

		if (_targetPc.hasSkillEffect(L1SkillId.CUBE_AVATAR)) { // 큐브 아바타
			dmg *= 1.05;
		}

		/** 트루타켓 **/
		final int tt = _targetPc.getTrueTarget();
		if (tt > 0) {
			dmg = (int) (dmg * (1.0 + (tt / 100.0)));
		}


		/*** 신규레벨보호 ***/
		// if (_calcType == PC_PC) {
		// int castle_id = L1CastleLocation.getCastleIdByArea(_pc);
		// if (castle_id == 0) {
		// if (_targetPc.getLevel() < Config.AUTO_REMOVELEVEL || _pc.getLevel()
		// < Config.AUTO_REMOVELEVEL && !_pc.isPinkName()) {
		// dmg /= 2;
		// _pc.sendPackets(new SC_SystemMessage("신규유저는 대미지의 50%만 가해집니다."));
		// _targetPc.sendPackets(new SC_SystemMessage("신규유저는 대미지를 50%만 받습니다."));
		// }
		// }
		// }

		/** 신규혈맹 공격안되게 **/
		if (_calcType == PC_PC) {
			int castle_id = L1CastleLocation.getCastleIdByArea(_pc);
			if (castle_id == 0) {
				if (!(_pc.is_combat_field() || _targetPc.is_combat_field())) {
					if (Config.신규혈맹보호처리) {
						boolean attack_ok = false;
						for (L1Object obj : L1World.getInstance().getVisibleObjects(_targetPc)) {
							if (!(obj instanceof L1MonsterInstance)) {
								continue;
							}

							if (obj instanceof L1MonsterInstance) {
								L1MonsterInstance mon = (L1MonsterInstance) obj;
								if (!mon.isDead()) {
									int monid = UserProtectMonsterTable.getInstance()
											.getUserProtectMonsterId(mon.getNpcId());
									if (monid != 0) {
										attack_ok = true;
										break;
									}
								}
							}
						}

						if (!attack_ok) {
							if (_pc.getClanid() == Config.신규혈맹클랜 || _targetPc.getClanid() == Config.신규혈맹클랜) {
								SC_SystemMessage.send(_pc, "\\fY상호간의 중립이 있을 경우 대미지 무효");
								SC_SystemMessage.send(_targetPc, "\\fY상호간의 중립이 있을 경우 대미지 무효");
								return 0;
							}
						}
					} else {
						if (_pc.getClanid() == Config.신규혈맹클랜 || _targetPc.getClanid() == Config.신규혈맹클랜) {
							dmg /= 2;
							SC_SystemMessage.send(_pc, "\\fY상호간의 중립이 있을 경우 대미지 50% 감소");
							SC_SystemMessage.send(_targetPc, "\\fY상호간의 중립이 있을 경우 대미지 50% 감소");
						}
					}
				}
			}
		}

		if (_pc.hasSkillEffect(L1SkillId.BURNING_SLASH)) {
			if (_weaponType != 20) {
				dmg += 30;
				SC_SkillSound.send(_pc, _targetPc.getId(), 6591);
				SC_SkillSound.broadcast(_pc, _targetPc.getId(), 6591);
				_pc.removeSkillEffect(L1SkillId.BURNING_SLASH);
			}
		}
//		try {
//			if (_targetPc.isCrown()) {
//			} else if (_targetPc.isKnight()) {
//			} else if (_targetPc.isElf()) {
//			} else if (_targetPc.isWizard()) {
//			} else if (_targetPc.isDarkelf()) {
//			} else if (_targetPc.isBlackwizard()) {
//			} else if (_targetPc.isDragonknight()) {
//			} else if (_targetPc.isWarrior()) {
//			}
//		} catch (Exception e) {
//			System.out.println("Character Add Reduction Error");
//		}
//
//		try {
//			if (_pc.isCrown() && _weaponType != 0) {
//			} else if (_pc.isKnight() && _weaponType != 0) {
//			} else if (_pc.isElf() && _weaponType != 0) {
//			} else if (_pc.isWizard() && _weaponType != 0) {
//			} else if (_pc.isDarkelf() && _weaponType != 0) {
//			} else if (_pc.isBlackwizard() && _weaponType != 0) {
//			} else if (_pc.isDragonknight() && _weaponType != 0) {
//			} else if (_pc.isWarrior() && _weaponType != 0) {
//			}
//		} catch (Exception e) {
//			System.out.println("Character Add Damege Error");
//		}

		/** 버닝스피릿츠, 엘리멘탈파이어, 브레이브멘탈 1.5배 스킬이펙트 및 추타 부분 **/
		int chance41 = _random.nextInt(100) + 1;
		if (_weaponType != 20 && _weaponType != 62 && _weaponType2 != 17) {
			if ((_pc.hasSkillEffect(L1SkillId.BURNING_SPIRIT) && !_pc.hasSkillEffect(L1SkillId.DOUBLE_BRAKE))
					|| (_pc.hasSkillEffect(L1SkillId.버닝) && !_pc.hasSkillEffect(L1SkillId.DOUBLE_BRAKE))
					|| _pc.hasSkillEffect(L1SkillId.ELEMENTAL_FIRE) || _pc.hasSkillEffect(L1SkillId.QUAKE)
					|| _pc.hasSkillEffect(L1SkillId.BRAVE_AURA)) {
				if (chance41 <= 15) {
					if (_pc.isDarkelf()) {
						dmg *= Config.BURNING_SPIRIT_PC;
						if (_targetPc != null) {
							long ss = SC_SkillSound.pack(_targetPc.getId(), 7727);
							SC_SkillSound.sendPacked(_targetPc, ss);
							SC_SkillSound.broadcastPacked(_targetPc, ss);
						}
					} else {
						dmg *= 1.5;
						if (_targetPc != null) {
							long ss = SC_SkillSound.pack(_targetPc.getId(), 7727);
							SC_SkillSound.sendPacked(_targetPc, ss);
							SC_SkillSound.broadcastPacked(_targetPc, ss);
							if (_pc.isCrown()) {
								SC_SkillSound.send(_pc, _targetPc.getId(), 5749);
								_effex = 1;
							} else {
								SC_SkillSound.send(_pc, _targetPc.getId(), 406);
								_effex = 1;
							}
							effcheck = 1;
						}
					}
				}
			}
		}

		/*
		 * if (_pc.hasSkillEffect(L1SkillId.BLOW_ATTACK)) { if (chance41 <=
		 * Config.BLOW_ATTACKPR) ; _targetPc.broadcastPacket(new
		 * S_SkillSound(_targetPc.getId(), 7727)); dmg *= Config.BLOW_ATTACKDMG; }
		 */

		// 캐릭터 간 대미지 외부화 처리
		if (_calcType == PC_PC) {
			if (_pc.isCrown()) {
				dmg += Config.PRINCE_ADD_DAMAGEPC;
			} else if (_pc.isKnight()) {
				dmg += Config.KNIGHT_ADD_DAMAGEPC;
			} else if (_pc.isElf()) {
				dmg += Config.ELF_ADD_DAMAGEPC;
			} else if (_pc.isDarkelf()) {
				dmg += Config.DARKELF_ADD_DAMAGEPC;
			} else if (_pc.isWizard()) {
				dmg += Config.WIZARD_ADD_DAMAGEPC;
			} else if (_pc.isDragonknight()) {
				dmg += Config.DRAGONKNIGHT_ADD_DAMAGEPC;
			} else if (_pc.isBlackwizard()) {
				dmg += Config.BLACKWIZARD_ADD_DAMAGEPC;
			} else if (_pc.isWarrior()) {
				dmg += Config.전사_ADD_DAMAGEPC;
			}
		}

		// -- PVP 에 대한 대미지 판정 처리
		if (_pc.getResistance().getPVPweaponTotalDamage() > 0) {
			dmg += _pc.getResistance().getPVPweaponTotalDamage() + 1;
		}
		dmg -= _targetPc.getResistance().getcalcPcDefense();

		/*
		 * if (_weaponId == 7000224 || _weaponId == 7000225 || _weaponId == 7000226 ||
		 * _weaponId == 7000227 || _weaponId == 7000228 || _weaponId == 7000229 ||
		 * _weaponId == 7000230) { //기본무기 데미지 하향 dmg -= Config.NEWDMG; }
		 */
		if (_weaponId == 7000224) { // 기본무기 데미지 하향
			dmg += Config.기사이도류1;
		}
		if (_weaponId == 7000225) { // 기본무기 데미지 하향
			dmg += Config.기사체인소드1;
		}
		if (_weaponId == 7000226) { // 기본무기 데미지 하향
			dmg += Config.기사키링크1;
		}
		if (_weaponId == 7000227) { // 기본무기 데미지 하향
			dmg += Config.기사지팡이1;
		}
		if (_weaponId == 7000228) { // 기본무기 데미지 하향
			dmg += Config.기사단검1;
		}
		if (_weaponId == 7000229) { // 기본무기 데미지 하향
			dmg += Config.기사활1;
		}
		if (_weaponId == 7000230) { // 기본무기 데미지 하향
			dmg += Config.기사도끼1;
		}

		if (_weaponType == 20 || _weaponType == 62) {
			if (_pc.hasSkillEffect(L1SkillId.CYCLONE)) {
				// if (MJRnd.isWinning(1000000, Config.CYCLONE_PROBABILITY)) {
				if (chance41 < 8) {
					dmg *= 1.5;
					_targetPc.send_effect(17557);
					SC_SkillSound.send(_pc, _targetPc.getId(), 406);
					effcheck = 1;
					_effex = 1;
				}
			}
		}
		if (_pc.getInventory().checkEquipped(123777)) {
			if (_targetPc.getResistance().getcalcPcDefense() > 0
					&& _targetPc.getResistance().getcalcPcDefense() <= 10) {
				dmg += _targetPc.getResistance().getcalcPcDefense();

			} else if (_targetPc.getResistance().getcalcPcDefense() > 10) {
				dmg += 10;

			}

		}

		if (_targetPc != null) {

			for (L1ItemInstance item : _pc.getInventory().getItems()) {
				if (item.isEquipped()) {
					if (item.getItemId() == 123003) {
						if (item.getEnchantLevel() >= 0 && item.getEnchantLevel() <= 8) {
							if (_targetPc.getDamageReductionByArmor() == 1) {
								dmg += 1;
							} else if (_targetPc.getDamageReductionByArmor() >= 2) {
								dmg += 2;
							}

						} else if (item.getEnchantLevel() == 9) {
							if (_targetPc.getDamageReductionByArmor() == 1) {
								dmg += 1;
							} else if (_targetPc.getDamageReductionByArmor() == 2) {
								dmg += 2;
							} else if (_targetPc.getDamageReductionByArmor() >= 3) {
								dmg += 3;
							}
						} else if (item.getEnchantLevel() == 10) {
							if (_targetPc.getDamageReductionByArmor() == 1) {
								dmg += 1;
							} else if (_targetPc.getDamageReductionByArmor() == 2) {
								dmg += 2;
							} else if (_targetPc.getDamageReductionByArmor() == 3) {
								dmg += 3;
							} else if (_targetPc.getDamageReductionByArmor() >= 4) {
								dmg += 4;
							}
						} else if (item.getEnchantLevel() >= 11) {
							if (_targetPc.getDamageReductionByArmor() == 1) {
								dmg += 1;
							} else if (_targetPc.getDamageReductionByArmor() == 2) {
								dmg += 2;
							} else if (_targetPc.getDamageReductionByArmor() == 3) {
								dmg += 3;
							} else if (_targetPc.getDamageReductionByArmor() == 4) {
								dmg += 4;
							} else if (_targetPc.getDamageReductionByArmor() >= 5) {
								dmg += 5;
							}
						}

						break;
					}
				}
			}
		}
		if (_pc.getInventory().checkEquipped(123111) || _pc.getInventory().checkEquipped(123112)
				|| _pc.getInventory().checkEquipped(123113)) {
			if (_targetPc.getDamageReductionByArmor() == 1) {
				dmg += 1;
			}
			if (_targetPc.getDamageReductionByArmor() == 2) {
				dmg += 2;
			}
			if (_targetPc.getDamageReductionByArmor() == 3) {
				dmg += 3;
			}
			if (_targetPc.getDamageReductionByArmor() == 4) {
				dmg += 4;
			}
			if (_targetPc.getDamageReductionByArmor() >= 5) {
				dmg += 5;
			}
		}
		// if (_pc.getInventory().checkItem(400254)) {
		// dmg += 1000;
		// }
		/** 대상 Buff에 따른 대미지 연산 **/

		if (Config.잠재력활성화) {
			if (_pc.hasSkillEffect(L1SkillId.잠재력저지먼트)) {
				저지먼트(_pc, _targetPc);
				// L1WeaponSkill.저지먼트(_pc, _targetPc);
			}

			if (_pc.hasSkillEffect(L1SkillId.잠재력pvp감소무시)) {
				if (_targetPc.getResistance().getcalcPcDefense() > 0) {
					dmg += getitemlevel(_pc, _targetPc);
				}
			}
			if (_pc.hasSkillEffect(L1SkillId.잠재력pvp감소무시1)) {
				if (_targetPc.getResistance().getcalcPcDefense() > 0) {
					dmg += getitemlevel1(_pc, _targetPc);
				}
			}

			if (_pc.hasSkillEffect(L1SkillId.잠재력이뮨무시)) {
				if (_targetPc.hasSkillEffect(L1SkillId.IMMUNE_TO_HARM)) {
					// dmg -= doll.getimmun();
					dmg += (_targetPc.getImmuneReduction() * Config.잠재력이뮨 * dmg);

				}
			}
			if (_pc.hasSkillEffect(L1SkillId.잠재력디케이)) {
				디케이포(_pc, _targetPc);
			}
			if (_pc.hasSkillEffect(L1SkillId.잠재력소울)) {
				소울오브(_pc, _targetPc);
			}

			if (Config.잠재력흡수유무) {
				// int aa = _random.nextInt(1000)+ 1 ;
				// if (_pc.hasSkillEffect(L1SkillId.잠재력영웅마나)) {
				// if (aa <= Config.잠재력흡수) {
				// managet(_pc, _targetPc);
				// }
				// }
				// if (_pc.hasSkillEffect(L1SkillId.잠재력전설마나)) {
				// if (aa <= Config.잠재력흡수) {
				// managet1(_pc, _targetPc);
				// }
				// }
				// if (_pc.hasSkillEffect(L1SkillId.잠재력전설피)) {
				// if (aa <= Config.잠재력흡수) {
				// hpget(_pc, _targetPc);
				// }
				// }
				//
				if (_pc.hasSkillEffect(L1SkillId.잠재력영웅마나)) {

					managet(_pc, _targetPc);
				}

				if (_pc.hasSkillEffect(L1SkillId.잠재력전설마나)) {

					managet1(_pc, _targetPc);
				}

				if (_pc.hasSkillEffect(L1SkillId.잠재력전설피)) {

					hpget(_pc, _targetPc);

				}
			}
		}

		double total_reduction = 0;
		total_reduction += _targetPc.getDamageReductionByArmor(); // 방어구에 의한 대미지 감소
		total_reduction += _targetPc.getDamageReduction(); // 방어구에 의한 대미지 감소
		total_reduction *= Config.PHYSICAL_REDUCTION_RATION;
		// 신화 무기 인챈트 비례 이뮨/감소 무시 (PC vs PC)
		switch (_weaponId) {
		case 123555: case 123777: case 123888: case 123666: case 123900:
		case 123800: case 123444: case 123333: case 124111:
			int mIgnore = 20 + (Math.min(_weaponEnchant, 15) * 2);
			total_reduction = Math.max(total_reduction - mIgnore, 0);
			break;
		default:
			break;
		}

		dmg = Math.max(dmg - total_reduction, 0);
		if (dmg <= 0) {
			_isHit = false;
		}

		switch (_weaponId) {
		case 123800:
			dmg += L1WeaponSkill.사이하의집념(_pc, _targetPc, _weaponEnchant);
			break;
		case 123777:
			dmg += L1WeaponSkill.아인하사드의섬광(_pc, _targetPc, _weaponEnchant);
			break;
		case 123888:
			dmg += L1WeaponSkill.그랑카인의심판(_pc, _targetPc, _weaponEnchant);
			break;
		case 123666:
			dmg += L1WeaponSkill.에바의서약(_pc, _targetPc, _weaponEnchant);
			break;
		case 123900:
			dmg += L1WeaponSkill.실렌의결의(_pc, _targetPc, _weaponEnchant);
			break;
		case 123555:
			dmg += L1WeaponSkill.파아그리오공포(_pc, _targetPc, _weaponEnchant);
			break;
		case 123444:
			dmg += L1WeaponSkill.단테스일격(_pc, _targetPc, _weaponEnchant);
			break;
		case 123333:
			dmg += L1WeaponSkill.아인하사드고독(_pc, _targetPc, _weaponEnchant);
			break;
		case 124111:
			dmg += L1WeaponSkill.아우라키아의초월(_pc, _targetPc, _weaponEnchant);
			break;
		default:
			// dmg += L1WeaponSkill.getWeaponSkillDamage(_pc, _targetPc, _weaponId);
			break;

		}
		int spid = _pc.getCurrentSpriteId();
		int awakeeff1 = 0;
		int awakeeff2 = 0;
		if (spid == 19094 || spid == 19168 || spid == 19995 || spid == 19955 || spid == 18291 || spid == 18273
				|| spid == 18269 || spid == 19510 || spid == 18295) {
			awakeeff1 = 362;
			awakeeff2 = 4585;
		}
		if (spid >= 21258 && spid <= 21310) {
			awakeeff1 = 362;
			awakeeff2 = 4585;
		}
		if (spid == 21082 || spid == 21086 || spid == 19082 || spid == 18942 || spid == 21070 || spid == 21066
				|| spid == 21049 || spid == 21053 || spid == 21074 || spid == 21078 || spid == 21090 || spid == 21094
				|| spid == 19086 || spid == 19090 || spid == 21132 || spid == 21136 || spid == 21404 || spid == 21409
				|| spid == 21413 || spid == 21417) {
			awakeeff1 = 21165;
			awakeeff2 = 4177;
		}
		if (spid >= 15254 && spid <= 15300) {
			awakeeff1 = 362;
			awakeeff2 = 4585;
		}
		/*
		 * case 134: // 수정 결정체 지팡이 dmg += L1WeaponSkill.수정결정체지팡이(_pc, _target,
		 * _weaponEnchant, 10405); break;
		 */

		/*
		 * case 202003: // 제로스의 지팡이 dmg += L1WeaponSkill.제로스의지팡이(_pc, _target,
		 * _weaponEnchant, 11760); break;
		 */

		/** AC에 의한 데미지 감소 수정본 **/
		// 0908
		if (_calcType == PC_PC) {
			if (_targetPc.isKnight()) { // 기사/
				dmg -= Config.기사;
			} else if (_targetPc.isDragonknight()) {// 용기사
				dmg -= Config.용기사;
			} else if (_targetPc.isElf()) { // 요정
				dmg -= Config.요정;
			} else if (_targetPc.isCrown()) { // 군주/
				dmg -= Config.군주;
			} else if (_targetPc.isWizard()) { // 법사/
				dmg -= Config.법사;
			} else if (_targetPc.isDarkelf()) { // 다엘/
				dmg -= Config.다엘;
			} else if (_targetPc.isBlackwizard()) { // 환술사/
				dmg -= Config.환술사;
			} else if (_targetPc.isWarrior()) { // 전사/
				dmg -= Config.전사;
			}
		}

		if (_targetPc.hasSkillEffect(L1SkillId.MOEBIUS)) {
			if (_weaponType == 20 || _weaponType == 62) {
				if (_targetPc.getLevel() == 85) {
					dmg -= dmg * 0.2;
				} else if (_targetPc.getLevel() == 86) {
					dmg -= dmg * 0.21;
				} else if (_targetPc.getLevel() == 87) {
					dmg -= dmg * 0.22;
				} else if (_targetPc.getLevel() == 88) {
					dmg -= dmg * 0.23;
				} else if (_targetPc.getLevel() == 89) {
					dmg -= dmg * 0.24;
				} else if (_targetPc.getLevel() == 90) {
					dmg -= dmg * 0.25;
				} else if (_targetPc.getLevel() == 91) {
					dmg -= dmg * 0.26;
				} else if (_targetPc.getLevel() == 92) {
					dmg -= dmg * 0.27;
				} else if (_targetPc.getLevel() == 93) {
					dmg -= dmg * 0.28;
				} else if (_targetPc.getLevel() == 94) {
					dmg -= dmg * 0.29;
				} else if (_targetPc.getLevel() >= 95) {
					dmg -= dmg * 0.3;
				}
			}
		}

		dmg = toPcBuffDmg(dmg);
		if (dmg > 0 && _targetPc.hasSkillEffect(L1SkillId.IMMUNE_TO_HARM)) {

			if (_targetPc.hasSkillEffect(L1SkillId.세인트)) {
				if (_targetPc.getLevel() == 80 && _targetPc.getLevel() == 81) {
					dmg -= dmg * 0.01;
				} else if (_targetPc.getLevel() == 82 && _targetPc.getLevel() == 83) {
					dmg -= dmg * 0.02;
				} else if (_targetPc.getLevel() == 84 && _targetPc.getLevel() == 85) {
					dmg -= dmg * 0.03;
				} else if (_targetPc.getLevel() == 86 && _targetPc.getLevel() == 87) {
					dmg -= dmg * 0.04;
				} else if (_targetPc.getLevel() == 88 && _targetPc.getLevel() == 89) {
					dmg -= dmg * 0.05;
				} else if (_targetPc.getLevel() == 90) {
					dmg -= dmg * 0.06;
				} else if (_targetPc.getLevel() == 91) {
					dmg -= dmg * 0.07;
				} else if (_targetPc.getLevel() == 92) {
					dmg -= dmg * 0.08;
				} else if (_targetPc.getLevel() == 93) {
					dmg -= dmg * 0.09;
				} else if (_targetPc.getLevel() >= 94) {
					dmg -= dmg * 0.1;
				}
			}
			L1ItemInstance item = _pc.getInventory().findEquippedItemId(123777);
			L1ItemInstance item1 = _pc.getInventory().findEquippedItemId(123888);
			L1ItemInstance item2 = _pc.getInventory().findEquippedItemId(123666);
			L1ItemInstance item3 = _pc.getInventory().findEquippedItemId(123800);
			L1ItemInstance item4 = _pc.getInventory().findEquippedItemId(123900);
			L1ItemInstance item5 = _pc.getInventory().findEquippedItemId(123555);
			L1ItemInstance item6 = _pc.getInventory().findEquippedItemId(123444);
			L1ItemInstance item7 = _pc.getInventory().findEquippedItemId(123333);
			L1ItemInstance item8 = _pc.getInventory().findEquippedItemId(124111);

			// 현재 착용 중인 신화 무기가 무엇인지 하나만 찾아냅니다.
			L1ItemInstance equippedMythic = null;
			if (item != null)
				equippedMythic = item;
			else if (item1 != null)
				equippedMythic = item1;
			else if (item2 != null)
				equippedMythic = item2;
			else if (item3 != null)
				equippedMythic = item3;
			else if (item4 != null)
				equippedMythic = item4;
			else if (item5 != null)
				equippedMythic = item5;
			else if (item6 != null)
				equippedMythic = item6;
			else if (item7 != null)
				equippedMythic = item7;
			else if (item8 != null)
				equippedMythic = item8;

			if (equippedMythic != null) {
				// 인챈트별 뮨 무시 공식 적용: 0.8에서 인챈트 1당 0.05씩 차감
				int enchant = equippedMythic.getEnchantLevel();
				double multiplier = 0.8 - (enchant * 0.05);

				// 인챈트가 너무 높아져서 마이너스가 되는 것을 방지 (최소 0.0 고정)
				if (multiplier < 0.0) {
					multiplier = 0.0;
				}

				dmg -= (_targetPc.getImmuneReduction() * multiplier * dmg);
			} else {
				// 신화 무기가 아닐 경우 기본 이뮨 적용
				dmg -= (dmg * _targetPc.getImmuneReduction());
			}
			if (_isHit) {
				int chance3 = _random.nextInt(100) + 1;
				// int per = 0;
				// if(_pc.getLevel() < 60){per = 30;}else{per = _pc.getLevel() - 30;}
				if (weapon != null && _weaponAttrLevel != 0 && chance3 <= 8) {
					if (_weaponAttrLevel == 5) {
						SC_SkillSound.send(_pc, _targetPc.getId(), 416);
						dmg += 15;
					} else if (_weaponAttrLevel == 10) {
						SC_SkillSound.send(_pc, _targetPc.getId(), 418);
						dmg += 15;
					} else if (_weaponAttrLevel == 15) {
						SC_SkillSound.send(_pc, _targetPc.getId(), 414);
						dmg += 15;
					} else if (_weaponAttrLevel == 20) {
						SC_SkillSound.send(_pc, _targetPc.getId(), 412);
						dmg += 15;
					}
				}
				/** 포효의이도류 인첸당 발동확률증가 **/
				if (_weaponId == 203018) {
					_weaponDoubleDmgChance += _pc.getWeapon().getEnchantLevel();
				}
				if (_weaponType == 58 && (_random.nextInt(100) + 1) <= _weaponDoubleDmgChance) { // 크로우
					// weaponDamage = weaponMaxDamage;
					weaponDamage = weaponMaxDamage;
					dmg += weaponDamage;
					SC_SkillSound.send(_pc, _targetPc.getId(), 13416);
					SC_SkillSound.broadcast(_pc, _targetPc.getId(), 13416);
				}
				if (_weaponType == 54 && (_random.nextInt(100) + 1) <= _weaponDoubleDmgChance) { // 이도류
					// weaponDamage = weaponMaxDamage;
					weaponDamage = (weaponMaxDamage * 2) + _weaponAddDmg + 10;
					dmg += weaponDamage;
					SC_SkillSound.send(_pc, _targetPc.getId(), 13417);
					SC_SkillSound.broadcast(_pc, _targetPc.getId(), 13417);
				}
				if (_pc.getAccount().getTree_select() != 0) {
					int chancet = _random.nextInt(100) + 1;
					int s = _pc.getAccount().getTree_select();
					if (chancet < 3) {
						if (_pc.getLinMeff() != 2) {
							SC_SkillSound.send(_pc, _targetPc.getId(), s);
						}
						SC_SkillSound.broadcastM(_pc, _targetPc.getId(), s);
						switch (s) {
						case 569:
							dmg += 15;
							break;
						case 580:
							dmg += 15;
							break;
						case 600:
							dmg += 20;
							break;
						case 589:
							dmg += 20;
							break;
						case 562:
							dmg += 30;
							break;
						default:
							break;
						}
					}
				}
				if (_pc.getAccount().getTree_select2() != 0) {
					int chancet = _random.nextInt(100) + 1;
					int s = _pc.getAccount().getTree_select2();
					if (chancet < 3) {
						if (_pc.getLinMeff() != 2) {
							SC_SkillSound.send(_pc, _targetPc.getId(), s);
						}
						SC_SkillSound.broadcastM(_pc, _targetPc.getId(), s);
						switch (s) {
						case 379:
							dmg += 15;
							break;
						case 394:
							dmg += 25;
							break;
						case 605:
							dmg += 30;
							break;
						default:
							break;
						}

					}
				}
				if (_pc.getAccount().getTree_select3() != 0) {
					int chancet = _random.nextInt(100) + 1;
					int s = _pc.getAccount().getTree_select3();
					if (chancet < 3) {
						if (_pc.getLinMeff() != 2) {
							SC_SkillSound.send(_pc, _targetPc.getId(), s);
						}
						SC_SkillSound.broadcastM(_pc, _targetPc.getId(), s);
						switch (s) {
						case 420:
							dmg += 15;
							break;
						case 422:
							dmg += 25;
							break;
						case 426:
							dmg += 30;
							break;
						default:
							break;
						}
					}
				}
				if (awakeeff1 != 0) {
					if (chance3 <= 3) {
						dmg += 20;
						SC_SkillSound.send(_pc, _pc.getId(), awakeeff1);
						SC_SkillSound.broadcast(_pc, _pc.getId(), awakeeff1);
						SC_SkillSound.send(_pc, _targetPc.getId(), awakeeff2);
						SC_SkillSound.broadcast(_pc, _targetPc.getId(), awakeeff2);
					}

				}
				effcheck = 0;

				if (_weaponId == 602) { // 마단 대미지 너프
					dmg -= 30;
					if (dmg < 0) {
						dmg = 0;
					}
				}
			}
		}
		return (int) dmg;
	}

	// ●●●● 플레이어로부터 NPC 에의 대미지 산출 ●●●●
	private int calcPcNpcDamage() {
		if (_targetNpc == null || _pc == null) {
			_isHit = false;
			return 0;
		}
		int weaponMaxDamage = 0;
		boolean secondw = false;

		if (_targetNpc.getNpcTemplate().get_size().equalsIgnoreCase("small") && _weaponSmall > 0) {
			weaponMaxDamage = _weaponSmall;
		} else if (_targetNpc.getNpcTemplate().get_size().equalsIgnoreCase("large") && _weaponLarge > 0) {
			weaponMaxDamage = _weaponLarge;
		} else if (_targetNpc instanceof L1PeopleInstance) {
			weaponMaxDamage = _weaponSmall;
		}

		// weaponMaxDamage += _weaponAddDmg;
		int weaponDamage = 0;

		if (_weaponType == 0) { // 맨손, 활, 암 토토 렛_weaponType == 0 ||
			weaponDamage = 0;
		} else {
			if (weaponMaxDamage <= 0)
				weaponMaxDamage = 1;
			weaponDamage = _random.nextInt(weaponMaxDamage) + 1;
			weaponDamage = _random.nextInt(weaponMaxDamage) + _weaponAddDmg;
			// System.out.println(weaponDamage);
		}

		if (_pc.hasSkillEffect(L1SkillId.SOUL_OF_FLAME)) {
			if (_weaponType != 20 && _weaponType != 62) {
				// weaponDamage = weaponMaxDamage;
				weaponDamage = weaponMaxDamage + _weaponAddDmg + 3;
			}
		}
		if (_pc.hasSkillEffect(L1SkillId.잠재력소울스킬)) {

			// weaponDamage = weaponMaxDamage + 5;
			weaponDamage = weaponMaxDamage + _weaponAddDmg + 3;

		}
		int weaponTotalDamage = weaponDamage + _weaponEnchant + _weapon_bless_level;

		if (_pc.isWarrior() && _pc.isPassive(MJPassiveID.SLAYER.toInt()) && _pc.getSecondWeapon() != null) {
			int ran = _random.nextInt(100);
			if (ran < 50) {
				secondw = true;
				if (_targetNpc.getNpcTemplate().get_size().equalsIgnoreCase("small") && _SweaponSmall > 0) {
					weaponMaxDamage = _SweaponSmall + _SweaponAddDmg;
				} else if (_targetNpc.getNpcTemplate().get_size().equalsIgnoreCase("large") && _SweaponLarge > 0) {
					weaponMaxDamage = _SweaponLarge + _SweaponAddDmg;
				} else {
					weaponMaxDamage = _SweaponSmall + _SweaponAddDmg;
				}
			}
		}

		weaponTotalDamage += calcMaterialBlessDmg(); // 은축복 대미지 보너스

		/*
		 * if (_weaponType == 54 && (_random.nextInt(100) + 1) <=
		 * (_weaponDoubleDmgChance - weapon.get_durability()) && _pc.isDarkelf()) { //
		 * 이도류 weaponTotalDamage *= Config.DOUBLE_DMG; _isCritical = true;
		 * _pc.sendPackets(new S_AttackCritical(_pc, _targetId, 54, Sweapon != null));//
		 * 땁 Broadcaster.broadcastPacket(_pc, new S_AttackCritical(_pc, _targetId, 54,
		 * Sweapon != null));// 땁 }
		 */
		int effcheck = 0;
		/** 포효의이도류 인첸당 발동확률증가 **/
		if (_weaponId == 203018) {
			_weaponDoubleDmgChance += _pc.getWeapon().getEnchantLevel();
		}
		/*
		 * if (_weaponType == 58 && (_random.nextInt(100) + 1) <=
		 * _weaponDoubleDmgChance) { // 크로우 // weaponDamage = weaponMaxDamage;
		 * weaponDamage = weaponMaxDamage + _weaponAddDmg; weaponTotalDamage +=
		 * weaponDamage; _pc.sendPackets(new S_AttackCritical(_pc, _targetId, 58,
		 * Sweapon != null));// 땁 //_pc.sendPackets(new S_SkillSound(_targetId, 400));
		 * Broadcaster.broadcastPacket(_pc, new S_AttackCritical(_pc, _targetId, 58,
		 * Sweapon != null));// 땁 //다엘 이팩트 뭐지? //_pc.sendPackets(new
		 * S_SkillSound(_pc.getId(), 18328)); //Broadcaster.broadcastPacket(_pc, new
		 * S_SkillSound(_pc.getId() , 18328)); _isCritical = true; } if (_weaponType ==
		 * 54 && (_random.nextInt(100) + 1) <= _weaponDoubleDmgChance) { // 이도류 //
		 * weaponDamage = weaponMaxDamage; weaponDamage = weaponMaxDamage*2;
		 * weaponTotalDamage += weaponDamage; _pc.sendPackets(new S_AttackCritical(_pc,
		 * _targetId, 54, Sweapon != null));// 땁 //_pc.sendPackets(new
		 * S_SkillSound(_targetId, 400)); Broadcaster.broadcastPacket(_pc, new
		 * S_AttackCritical(_pc, _targetId, 54, Sweapon != null));// 땁 _isCritical =
		 * true; }
		 */
		// 더블브레이크 확률 50렙부터 5렙당 1%씩 상승
		if (_pc.hasSkillEffect(L1SkillId.DOUBLE_BRAKE) && (_weaponType == 54 || _weaponType == 58)) {
			int RealSteelLevel = _pc.getLevel();
			if (RealSteelLevel < 45) {
				RealSteelLevel = 45;
			}
			int RealSteelLevelChance = (int) ((RealSteelLevel - 45) / 5 + Config.DOUBLE_BREAK_CHANCE);
			for (L1ItemInstance item : _pc.getInventory().getItems()) {
				if (item.isEquipped()) {
					if (item.getItemId() == 86) {
						if (item.getEnchantLevel() >= 1) {
							RealSteelLevelChance += item.getEnchantLevel() * 2;
						}
					}
					if (item.getItemId() == 123004) {
						if (item.getEnchantLevel() >= 7) {
							RealSteelLevelChance += item.getEnchantLevel() * 2 - 12;
						}
					}
				}
			}
			if (_pc.isPassive(MJPassiveID.DOUBLE_BREAK_DESTINY.toInt())) {
				int lvl = _pc.getLevel();
				if (lvl >= 60)
					RealSteelLevelChance += (lvl - 59);
				if (RealSteelLevelChance >= 15) {
					RealSteelLevelChance = 15;
				}
			}
			if ((_random.nextInt(100) + 1) <= RealSteelLevelChance) {
				weaponTotalDamage += _statusDamage * Config.DOUBLE_BREAK_DESTINY_NPC;
				if (_pc.isPassive(MJPassiveID.DOUBLE_BREAK_DESTINY.toInt())) {
					SC_SkillSound.send(_pc, _targetNpc.getId(), 17223);
					SC_SkillSound.broadcast(_pc, _targetNpc.getId(), 17223);
					SC_SkillSound.send(_pc, _targetNpc.getId(), 410);
					effcheck = 1;
					_effex = 1;
				}
			}
			if ((_random.nextInt(100) + 1) <= RealSteelLevelChance) {
				weaponTotalDamage += _statusDamage * Config.BURNING_SPIRIT_NPC;
				if (_pc.hasSkillEffect(L1SkillId.BURNING_SPIRIT) || _pc.hasSkillEffect(L1SkillId.버닝)) {
					SC_SkillSound.send(_pc, _targetNpc.getId(), 6532);
					SC_SkillSound.broadcast(_pc, _targetNpc.getId(), 6532);
					SC_SkillSound.send(_pc, _targetNpc.getId(), 406);
					effcheck = 1;
					_effex = 1;
				}
			}
		}

		if (_weaponType != 20 && _weaponType != 62) { // 근거리
			int Dmgcritical = CalcStat.calcDmgCritical(_pc.getAbility().getTotalStr()) + 1;
			int chance = _random.nextInt(100) + 1;
			if (chance <= Dmgcritical) {
				weaponDamage = weaponMaxDamage + _weaponAddDmg + 1;
				weaponDamage += weaponDamage * 1.2;
				_isCritical = true;
			}
		} else {
			int Bowcritical = CalcStat.calcBowCritical(_pc.getAbility().getTotalDex()) + 1;
			int chance = _random.nextInt(100) + 1;
			if (chance <= Bowcritical) {
				weaponDamage = weaponMaxDamage + _weaponAddDmg + 11;
				weaponDamage += weaponDamage * 1.2;
				_isCritical = true;
			}
		}

		double dmg = weaponTotalDamage + _statusDamage;
		// if (_weaponType2 == 17) {
		// dmg = MJCommons.getMagicDamage(_pc, _targetNpc, (int) dmg);
		// // dmg = L1WeaponSkill.키링크데미지(_pc, _target);
		// }
		// if (_weaponType != 20 && _weaponType != 62) {
		// dmg = weaponTotalDamage + _statusDamage + _pc.getDmgup() + _pc.getDmgRate();
		// } else {
		// dmg = weaponTotalDamage + _statusDamage + _pc.getBowDmgup() +
		// _pc.getBowDmgRate() + 5;
		// }
		if (_weaponType2 == 17 || _weaponType == 58) {

			dmg += (int) ((double) _pc.getAbility().getSp() * Config.키링크sp몬스터 + weaponTotalDamage + _statusDamage);

			dmg = calcMrDefense(_target.getResistance().getEffectedMrBySkill(), dmg);

		}

		if (_weaponType != 20 && _weaponType != 62 && _weaponType != 58 && _weaponType2 != 17) { // [2026-07-30] 키링크(type17) 제외 - INT(SP) 데미지가 근접(STR)식으로 덮어써지던 문제 수정
			dmg = weaponTotalDamage + _statusDamage + _pc.getDmgup() + _pc.getDmgRate();
			// System.out.println("근거리");
		} else {
			if (_weaponType != 58) {
				dmg = weaponTotalDamage + _statusDamage + _pc.getBowDmgup() + _pc.getBowDmgRate();
				// System.out.println("원거리");
			}
		}
		if (_pc.isWizard() && _weaponId == 202003) { // 제로스
			dmg += 30;
		}
		if (_pc.isElf() && _weaponId == 7000229 || _weaponId == 1122 || _weaponId == 189 || _weaponId == 1136) { // 요정 활
			dmg -= 10;
		}

		dmg += 몬스터속성인첸트효과(); // 속성 대미지

		if (_weaponType == 20) { // 활
			if (_arrow != null) {
				dmg += _arrow.getItem().getDmgModifier();
			} else {
				dmg += MJRnd.next(2) + 1;
			}
			if (_targetNpc.getNpcTemplate().is_hard()) {
				dmg /= 2;
			}
		} else if (_weaponType == 62) { // 암 토토 렛 건틀렛
			int add_dmg = 0;
			if (_targetNpc.getNpcTemplate().get_size().equalsIgnoreCase("large")) {
				add_dmg = _sting.getItem().getDmgLarge();
			} else {
				add_dmg = _sting.getItem().getDmgSmall();
			}
			if (add_dmg == 0) {
				add_dmg = 1;
			}
			// System.out.println(weaponDamage);
			dmg = dmg + _random.nextInt(add_dmg) + 1;
		}

		/** 본섭 10검이상 추타 +1 표기 효과 **/
		if (_weaponType != 0 && _weaponType != 20) {
			switch (weapon.getEnchantLevel()) {
			case 10:
				dmg += 1;
				break;
			case 11:
				dmg += 2;
				break;
			case 12:
				dmg += 3;
				break;
			case 13:
				dmg += 4;
				break;
			case 14:
				dmg += 5;
				break;
			case 15:
				dmg += 6;
				break;
			default:
				break;
			}
		}

		/** 인첸트에 따른 추타관련 **/
		if (_weaponType != 0 && _weaponType != 20) {
			switch (weapon.getEnchantLevel()) {
			case 8:
				dmg += 2;
				break;
			case 9:
				dmg += 4;
				break;
			case 10:
				dmg += 6;
				break;
			case 11:
				dmg += 8;
				break;
			case 12:
				dmg += 10;
				break;
			case 13:
				dmg += 12;
				break;
			case 14:
				dmg += 14;
				break;
			case 15:
				dmg += 17;
				break;
			default:
				break;
			}
		}

		if (_weaponType2 == 18)	
			 dmg += WeakExposeHelper.applyPowExposeOnHit(_pc, _target, weapon, _weaponType2, (int) dmg);

		/** 특수 인챈트 시스템 **/
		if (_weaponType != 0) {
			switch (weapon.get_item_level()) {
			case 1:// 1단계
				WeaponLevelAttack(_pc, _target, 3740, _pc.getWeapon().getEnchantLevel(), weapon.get_item_level());
				break;
			case 2:// 2단계
				WeaponLevelAttack(_pc, _target, 16018, _pc.getWeapon().getEnchantLevel(), weapon.get_item_level());
				break;
			case 3:// 3단계
				WeaponLevelAttack(_pc, _target, 16024, _pc.getWeapon().getEnchantLevel(), weapon.get_item_level());
				break;
			case 4:// 4단계
				WeaponLevelAttack(_pc, _target, 4167, _pc.getWeapon().getEnchantLevel(), weapon.get_item_level());
				break;
			default:
				break;
			}
		}
		/** 특수 인챈트 시스템 **/

		/** 아이템 스킬 적용 **/
		MJItemSkillModel model = MJItemSkillModelLoader.getInstance().getAtk(_weaponId);
		if (model != null && weapon.get_item_level() == 0) {
			dmg += model.get(_pc, _targetNpc, weapon, dmg);
		}

		for (L1ItemInstance item : _pc.getEquipSlot().getArmors()) {
			model = MJItemSkillModelLoader.getInstance().getAtk(item.getItemId());
			if (model != null)
				dmg += model.get(_pc, _targetNpc, item, dmg);
		}


		if (_weaponType == 0) { // 맨손
			dmg = (_random.nextInt(5) + 4) / 4;
		}

//		try {
//			dmg += WeaponAddDamage.getInstance().getWeaponAddDamage(_weaponId);
//		} catch (Exception e) {
//			System.out.println("Weapon Add Damege Error");
//		}
		// 신화 무기 인챈트 비례 추가 대미지 (PC vs NPC)
		if (_weaponEnchant > 0) {
			int mDmgN = Math.min(_weaponEnchant, 15);
			switch (_weaponId) {
			case 123555: case 123777: case 123888: case 123666: case 123900:
			case 123444: case 124111:
				if (_weaponType != 20) dmg += mDmgN * 5; break;
			case 123800:
				if (_weaponType == 20) dmg += mDmgN * 5; break;
			case 123333:
				dmg += mDmgN * 2; break;
			default: break;
			}
		}

		if (_pc.hasSkillEffect(L1SkillId.버서크)) {
			dmg += 20;
		}

		if (_pc.hasSkillEffect(L1SkillId.램페이지)) {
			if (_targetNpc.hasSkillEffect(L1SkillId.SHOCK_STUN) || _targetNpc.hasSkillEffect(L1SkillId.THUNDER_GRAB)
					|| _targetNpc.hasSkillEffect(L1SkillId.BONE_BREAK) || _targetNpc.hasSkillEffect(L1SkillId.EMPIRE)) {
				int ran = _random.nextInt(100) + 1;
				if (ran <= Config.램페이지확률) {
					dmg += (int) ((double) dmg * Config.램페이지데미지);
					SC_SkillSound.send(_pc, _pc.getId(), 5263);
					SC_SkillSound.broadcast(_pc, _pc.getId(), 5263);

				}
			}
		}
		if ((_pc.getCurrentSpriteId() == 21140 || _pc.getCurrentSpriteId() == 19514) && _pc != null) {
			int chance2 = _random.nextInt(100) + 1;
			int chance3 = _random.nextInt(100) + 1;

			if (chance2 < 3) {
				dmg += dmg + 50;
				SC_SkillSound.send(_pc, _targetNpc.getId(), 5151);
				SC_SkillSound.broadcast(_pc, _targetNpc.getId(), 5151);
			}
			if (chance3 < 3) {
				dmg += dmg + 30;
				SC_SkillSound.send(_pc, _targetNpc.getId(), 21144);
				SC_SkillSound.broadcast(_pc, _targetNpc.getId(), 21144);
			}

		}
		if (_pc.getDollskill() == 1) {
			dmg += 30;
			SC_SkillSound.send(_pc, _targetNpc.getId(), 21161);
			SC_SkillSound.broadcast(_pc, _targetNpc.getId(), 21161);
			_pc.setDollskill(0);
		}
		if (_pc.getDollskill() == 2) {
			dmg += 20;
			SC_SkillSound.send(_pc, _targetNpc.getId(), 374);
			SC_SkillSound.broadcast(_pc, _targetNpc.getId(), 374);
			_pc.setDollskill(0);
		}
		if (_pc.hasSkillEffect(L1SkillId.BURNING_SLASH)) {
			if (_weaponType != 20 && _weaponType != 62) {
				dmg += 20;
				SC_SkillSound.send(_pc, _targetNpc.getId(), 6591);
				SC_SkillSound.broadcast(_pc, _targetNpc.getId(), 6591);
				_pc.removeSkillEffect(L1SkillId.BURNING_SLASH);
			}
		}
		Object[] dollList = _pc.getDollList().values().toArray(); // 매직 돌 인형에 의한
		int aa = _random.nextInt(1000) + 1; // 추가 대미지
		for (Object dollObject : dollList) {
			L1DollInstance doll = (L1DollInstance) dollObject;

			if (dollList == null)
				continue;

			if (_weaponType != 20 && _weaponType != 62) {
				dmg += doll.getDamageByDoll();

			}

			/** 특수 마법인형 인챈트 시스템 **/
			dmg += doll.attackPixieDamage(_pc, _targetNpc);
			doll.getPixieGreg(_pc, _targetNpc);

		}

		// 전사 스킬 PC - NPC
		// 크래쉬 : 공격자에 레벨에 50% 정도를 데미지에 반영한다.
		if (_pc.getPassive(MJPassiveID.CRASH.toInt()) != null) {
			int chance = _random.nextInt(100) + 1;
			if (Config.crashFo >= chance) { // 크래쉬 확률
				// int crashdmg = (int) (_pc.getLevel() + 2 / Config.crashdmg);
				int crashdmg = (int) dmg / 2;
				int furydmg = 0;
				// 퓨리 : 크래쉬에서 나온 뎀지에 2배.
				if (_pc.getPassive(MJPassiveID.FURY.toInt()) != null) {
					chance = _random.nextInt(100) + 1;
					if (Config.furyFo >= chance) { // 퓨리 확률
						// furydmg += crashdmg / Config.furydmg;
						furydmg += dmg * 2;
						crashdmg = 0;
						// 성공시 이팩 2개 나가는거
						SC_SkillSound.broadcast(_targetNpc, _targetNpc.getId(), 12489);
						SC_SkillSound.send(_pc, _targetNpc.getId(), 372);
						effcheck = 1;
						_effex = 1;
					}
				}
				dmg += crashdmg + furydmg;
				// 크래쉬는 크래쉬 이팩트 그대로 처리.
				SC_SkillSound.broadcast(_targetNpc, _targetNpc.getId(), 12487);
				if (furydmg == 0) {
					SC_SkillSound.send(_pc, _targetNpc.getId(), 406);
					effcheck = 1;
					_effex = 1;
				}
			}
		}

		/** 버닝스피릿츠, 엘리멘탈파이어, 브레이브멘탈 1.5배 스킬이펙트 및 추타 부분 **/
		int chance41 = _random.nextInt(100) + 1;
		if (_weaponType != 20 && _weaponType != 62 && _weaponType2 != 17) {
			if ((_pc.hasSkillEffect(L1SkillId.BURNING_SPIRIT) && !_pc.hasSkillEffect(L1SkillId.DOUBLE_BRAKE))
					|| (_pc.hasSkillEffect(L1SkillId.버닝) && !_pc.hasSkillEffect(L1SkillId.DOUBLE_BRAKE))
					|| _pc.hasSkillEffect(L1SkillId.ELEMENTAL_FIRE) || _pc.hasSkillEffect(L1SkillId.QUAKE)
					|| _pc.hasSkillEffect(L1SkillId.BRAVE_AURA)) {
				if (chance41 <= 15) {
					if (_pc.isDarkelf()) {
						dmg *= Config.BURNING_SPIRIT_NPC;
						SC_SkillSound.broadcast(_targetNpc, _targetNpc.getId(), 7727);
						SC_SkillSound.send(_pc, _targetNpc.getId(), 406);
						effcheck = 1;
						_effex = 1;
					} else {
						dmg *= 1.5;
						SC_SkillSound.broadcast(_targetNpc, _targetNpc.getId(), 7727);
						if (_pc.isCrown()) {
							SC_SkillSound.send(_pc, _targetNpc.getId(), 5749);
						} else {
							SC_SkillSound.send(_pc, _targetNpc.getId(), 406);
							_effex = 1;
						}
						effcheck = 1;

					}
				}
			}
		}

		/*
		 * if (_pc.hasSkillEffect(L1SkillId.BLOW_ATTACK)) { if (chance41 <=
		 * Config.BLOW_ATTACKPR) _targetNpc.broadcastPacket(new
		 * S_SkillSound(_targetNpc.getId(), 7727)); dmg *= Config.BLOW_ATTACKDMG; }
		 */

		if (_weaponType == 20 || _weaponType == 62) {
			if (_pc.hasSkillEffect(L1SkillId.CYCLONE)) {
				if (chance41 < 8) {
					dmg *= 1.5;
					_targetNpc.send_effect(17557);
					SC_SkillSound.send(_pc, _targetNpc.getId(), 406);
					effcheck = 1;
				}
			}
		}

//		try {
//			if (_pc.isCrown() && _weaponType != 0) {
//			} else if (_pc.isKnight() && _weaponType != 0) {
//			} else if (_pc.isElf() && _weaponType != 0) {
//			} else if (_pc.isWizard() && _weaponType != 0) {
//			} else if (_pc.isDarkelf() && _weaponType != 0) {
//			} else if (_pc.isBlackwizard() && _weaponType != 0) {
//			} else if (_pc.isDragonknight() && _weaponType != 0) {
//			} else if (_pc.isWarrior() && _weaponType != 0) {
//			}
//		} catch (Exception e) {
//			System.out.println("Character Add Damege Error");
//		}


		// 신화 무기 인챈트 비례 이뮨/감소 무시 (PC vs NPC)
		int npcReduction = calcNpcDamageReduction();
		int ignoreReductionN = 0;
		switch (_weaponId) {
		case 123555: case 123777: case 123888: case 123666: case 123900:
		case 123800: case 123444: case 123333: case 124111:
			ignoreReductionN = 20 + (Math.min(_weaponEnchant, 15) * 2);
			break;
		default:
			break;
		}
		npcReduction = Math.max(0, npcReduction - ignoreReductionN);
		dmg -= npcReduction;

		boolean isNowWar = false;
		int castleId = L1CastleLocation.getCastleIdByArea(_targetNpc);
		if (castleId > 0) {
			isNowWar = MJCastleWarBusiness.getInstance().isNowWar(castleId);
		}
		int spid = _pc.getCurrentSpriteId();
		int awakeeff1 = 0;
		int awakeeff2 = 0;
		if (spid == 19094 || spid == 19168 || spid == 19995 || spid == 19955 || spid == 18291 || spid == 18273
				|| spid == 18269 || spid == 19510 || spid == 18295) {
			awakeeff1 = 362;
			awakeeff2 = 4585;
		}
		if (spid >= 21258 && spid <= 21310) {
			awakeeff1 = 362;
			awakeeff2 = 4585;
		}
		if (spid == 21082 || spid == 21086 || spid == 19082 || spid == 18942 || spid == 21070 || spid == 21066
				|| spid == 21049 || spid == 21053 || spid == 21074 || spid == 21078 || spid == 21090 || spid == 21094
				|| spid == 19086 || spid == 19090 || spid == 21132 || spid == 21136 || spid == 21404 || spid == 21409
				|| spid == 21413 || spid == 21417) {
			awakeeff1 = 21165;
			awakeeff2 = 4177;
		}
		if (spid >= 15254 && spid <= 15300) {
			awakeeff1 = 362;
			awakeeff2 = 4585;
		}
		// TODO 펫 대미지
		if (!isNowWar) {
			if (_targetNpc instanceof L1PetInstance) {
				dmg /= 8;
			}
			// TODO 서먼몬스터 대미지
			if (_targetNpc instanceof L1SummonInstance) {
				L1SummonInstance summon = (L1SummonInstance) _targetNpc;
				if (summon.isExsistMaster()) {
					dmg /= 5;// 8
				}
			}
		}

		if (_targetNpc.hasSkillEffect(L1SkillId.ICE_LANCE)) {
			dmg = 0;
		}
		if (_targetNpc.hasSkillEffect(L1SkillId.EARTH_BIND)) {
			dmg = 0;
		}
		if (_targetNpc.hasSkillEffect(L1SkillId.PHANTASM)) {
			_targetNpc.removeSkillEffect(L1SkillId.PHANTASM);
		}

		boolean isCounterBarrier = false;
		L1Magic magic = null;
		if (_targetNpc.hasSkillEffect(L1SkillId.BOSS_COUNTER_BARRIER) && dmg > 0) {
			magic = new L1Magic(_targetNpc, _pc);
			boolean isProbability = magic.calcProbabilityMagic(L1SkillId.COUNTER_BARRIER);
			if (isProbability) {
				isCounterBarrier = true;
			}
		}
		if (isCounterBarrier) {
			NpcactionCounterBarrier(_target, _pc);
			commitBossCounterBarrier(_target, _pc);
		}
		if (Config.잠재력활성화) {
			if (_pc.hasSkillEffect(L1SkillId.잠재력디케이)) {
				디케이포(_pc, _targetNpc);
			}
			if (_pc.hasSkillEffect(L1SkillId.잠재력소울)) {
				소울오브(_pc, _targetNpc);
			}

			// if (_pc.hasSkillEffect(L1SkillId.잠재력영웅마나)) {
			// if (aa <= Config.잠재력흡수) {
			// managet(_pc, _targetNpc);
			// }
			// }
			// if (_pc.hasSkillEffect(L1SkillId.잠재력전설마나)) {
			// if (aa <= Config.잠재력흡수) {
			//
			// managet1(_pc, _targetNpc);
			// }
			// }
			// if (_pc.hasSkillEffect(L1SkillId.잠재력전설피)) {
			// if (aa <= Config.잠재력흡수) {
			//
			// hpget(_pc, _targetNpc);
			// }
			// }

			if (_pc.hasSkillEffect(L1SkillId.잠재력영웅마나)) {

				managet(_pc, _targetNpc);
			}

			if (_pc.hasSkillEffect(L1SkillId.잠재력전설마나)) {

				managet1(_pc, _targetNpc);
			}

			if (_pc.hasSkillEffect(L1SkillId.잠재력전설피)) {

				hpget(_pc, _targetNpc);
			}
		}

		if (_weaponId == 7000224) { // 기본무기 데미지 하향
			dmg += Config.기사이도류;
		}
		if (_weaponId == 7000225) { // 기본무기 데미지 하향
			dmg += Config.기사체인소드;
		}
		if (_weaponId == 7000226) { // 기본무기 데미지 하향
			dmg += Config.기사키링크;
		}
		if (_weaponId == 7000227) { // 기본무기 데미지 하향
			dmg += Config.기사지팡이;
		}
		if (_weaponId == 7000228) { // 기본무기 데미지 하향
			dmg += Config.기사단검;
		}
		if (_weaponId == 7000229) { // 기본무기 데미지 하향
			dmg += Config.기사활;
		}
		if (_weaponId == 7000230) { // 기본무기 데미지 하향
			dmg += Config.기사도끼;
		}

		if (dmg <= 0) {
			_isHit = false;
		}


//		if (Config.CHAR_BALANCE_USE) {
//		}
		dmg = calcBuffDamage(dmg);

		switch (_weaponId) {

		/*
		 * case 134: // 수정 결정체 지팡이 dmg += L1WeaponSkill.수정결정체지팡이(_pc, _target,
		 * _weaponEnchant, 10405); break;
		 */

		/*
		 * case 202003: // 제로스의 지팡이 dmg += L1WeaponSkill.제로스의지팡이(_pc, _target,
		 * _weaponEnchant, 11760); break;
		 */
		case 603:
			L1WeaponSkill.천사의지팡이(_pc, _target, _weaponEnchant);
			break;
		case 123800:
			dmg += L1WeaponSkill.사이하의집념(_pc, _target, _weaponEnchant);
			break;
		case 123777:
			dmg += L1WeaponSkill.아인하사드의섬광(_pc, _target, _weaponEnchant);
			break;
		case 123888:
			dmg += L1WeaponSkill.그랑카인의심판(_pc, _target, _weaponEnchant);
			break;
		case 123666:
			dmg += L1WeaponSkill.에바의서약(_pc, _target, _weaponEnchant);
			break;
		case 123900:
			dmg += L1WeaponSkill.실렌의결의(_pc, _target, _weaponEnchant);
			break;
		case 123555:
			dmg += L1WeaponSkill.파아그리오공포(_pc, _target, _weaponEnchant);
			break;
		case 123444:
			dmg += L1WeaponSkill.단테스일격(_pc, _target, _weaponEnchant);
			break;
		case 123333:
			dmg += L1WeaponSkill.아인하사드고독(_pc, _target, _weaponEnchant);
			break;
		case 124111:
			dmg += L1WeaponSkill.아우라키아의초월(_pc, _target, _weaponEnchant);
			break;
		default:
			// dmg += L1WeaponSkill.getWeaponSkillDamage(_pc, _targetPc, _weaponId);
			break;

		}
		/*
		 * case 134: // 수정 결정체 지팡이 dmg += L1WeaponSkill.수정결정체지팡이(_pc, _target,
		 * _weaponEnchant, 10405); break;
		 */

		/*
		 * case 202003: // 제로스의 지팡이 dmg += L1WeaponSkill.제로스의지팡이1(_pc, _target,
		 * _weaponEnchant, 11760); break;
		 */
		if (_isHit) {
			int chance3 = _random.nextInt(100) + 1;

			if (weapon != null && _weaponAttrLevel != 0 && chance3 <= 8) {
				if (_weaponAttrLevel == 5) {
					SC_SkillSound.send(_pc, _targetNpc.getId(), 416);
					dmg += 15;
				} else if (_weaponAttrLevel == 10) {
					SC_SkillSound.send(_pc, _targetNpc.getId(), 418);
					dmg += 15;
				} else if (_weaponAttrLevel == 15) {
					SC_SkillSound.send(_pc, _targetNpc.getId(), 414);
					dmg += 15;
				} else if (_weaponAttrLevel == 20) {
					SC_SkillSound.send(_pc, _targetNpc.getId(), 412);
					dmg += 15;
				}
			}
			/** 포효의이도류 인첸당 발동확률증가 **/
			if (_weaponId == 203018) {
				_weaponDoubleDmgChance += _pc.getWeapon().getEnchantLevel();
			}
			if (_weaponType == 58 && (_random.nextInt(100) + 1) <= _weaponDoubleDmgChance) { // 크로우
				// weaponDamage = weaponMaxDamage;
				weaponDamage = weaponMaxDamage;
				dmg += weaponDamage;
				SC_SkillSound.send(_pc, _targetNpc.getId(), 13416);
				SC_SkillSound.broadcast(_pc, _targetNpc.getId(), 13416);
				// 다엘 이팩트 뭐지?
				// _pc.sendPackets(new S_SkillSound(_pc.getId(), 18328));
				// Broadcaster.broadcastPacket(_pc, new S_SkillSound(_pc.getId() , 18328));
			}
			if (_weaponType == 54 && (_random.nextInt(100) + 1) <= _weaponDoubleDmgChance) { // 이도류
				// weaponDamage = weaponMaxDamage;
				weaponDamage = (weaponMaxDamage * 2) + _weaponAddDmg + 10;
				dmg += weaponDamage;
				SC_SkillSound.send(_pc, _targetNpc.getId(), 13417);
				SC_SkillSound.broadcast(_pc, _targetNpc.getId(), 13417);
			}
			if (_pc.getAccount().getTree_select() != 0) {
				int chancet = _random.nextInt(100) + 1;
				int s = _pc.getAccount().getTree_select();
				if (chancet < 3) {
					if (_pc.getLinMeff() != 2) {
						SC_SkillSound.send(_pc, _targetNpc.getId(), s);
					}
					SC_SkillSound.broadcastM(_pc, _targetNpc.getId(), s);
					switch (s) {
					case 569:
						dmg += 15;
						break;
					case 580:
						dmg += 15;
						break;
					case 600:
						dmg += 20;
						break;
					case 589:
						dmg += 20;
						break;
					case 562:
						dmg += 30;
						break;
					default:
						break;
					}
				}
			}
			if (_pc.getAccount().getTree_select2() != 0) {
				int chancet = _random.nextInt(100) + 1;
				int s = _pc.getAccount().getTree_select2();
				if (chancet < 3) {
					if (_pc.getLinMeff() != 2) {
						SC_SkillSound.send(_pc, _targetNpc.getId(), s);
					}
					SC_SkillSound.broadcastM(_pc, _targetNpc.getId(), s);
					switch (s) {
					case 379:
						dmg += 15;
						break;
					case 394:
						dmg += 25;
						break;
					case 605:
						dmg += 30;
						break;
					default:
						break;
					}
				}
			}
			if (_pc.getAccount().getTree_select3() != 0) {
				int chancet = _random.nextInt(100) + 1;
				int s = _pc.getAccount().getTree_select3();
				if (chancet < 3) {
					if (_pc.getLinMeff() != 2) {
						SC_SkillSound.send(_pc, _targetNpc.getId(), s);
					}
					SC_SkillSound.broadcastM(_pc, _targetNpc.getId(), s);
					switch (s) {
					case 420:
						dmg += 15;
						break;
					case 422:
						dmg += 25;
						break;
					case 426:
						dmg += 30;
						break;
					default:
						break;
					}
				}
			}
			if (awakeeff1 != 0) {
				if (chance3 <= 3) {
					dmg += 20;
					SC_SkillSound.send(_pc, _pc.getId(), awakeeff1);
					SC_SkillSound.broadcast(_pc, _pc.getId(), awakeeff1);
					SC_SkillSound.send(_pc, _targetNpc.getId(), awakeeff2);
					SC_SkillSound.broadcast(_pc, _targetNpc.getId(), awakeeff2);
				}
			}
		}
	//	dmg += WeaponBalanceTable.getInstance().getItemBalanceDmg(_weaponId, _weaponEnchant);


		return (int) dmg;
	}

	// ●●●● NPC 로부터 플레이어에의 대미지 산출 ●●●●
	private int calcNpcPcDamage() {
		if (_npc == null || _targetPc == null)
			return 0;

		int lvl = this._npc.getLevel();
		double dmg = 0.0D;
		int status = 0;
		// 공격거리가 10이하이면 근거리로 인식
		if (this._npc.getNpcTemplate().get_ranged() < 10)
			status = this._npc.getAbility().getTotalStr();
		else {
			// 공격거리가 10이상이면 원거리로 인식
			status = this._npc.getAbility().getTotalDex();
		}

		// 스텟40이상
		/*
		 * if (status >= 40) { if (status < 80)// 스텟 80이하 status = (int) (status *
		 * 1.5D);// 대미지 else if (status < 120)// 스텟120이상 status *= 2;// 스텟 곱2배 else
		 * status = (int) (status * 2.5D); }
		 */

		dmg = status + _random.nextInt(lvl / 2) + 1;

		if (_npc instanceof L1PetInstance) {
			dmg += (lvl / 15); // 펫은 LV16마다 추가 타격
			dmg += ((L1PetInstance) _npc).getDamageByWeapon();
		}
		dmg += _npc.getDmgup();

		if (isUndeadDamage()) {
			dmg *= 1.2;
		}


		// TODO 월드 전체 몬스터 대미지 조정 상세
		dmg *= getLeverage() * 0.1D;// 올리면 쌔진다.
		if (_targetPc.getLevel() >= 1 && _targetPc.getLevel() <= 69) {
			dmg *= Config.npcdmg1 * 0.01D;// 올리면 쌔진다.
		} else if (_targetPc.getLevel() >= 70 && _targetPc.getLevel() <= 79) {
			dmg *= Config.npcdmg2 * 0.01D;// 올리면 쌔진다.
		} else if (_targetPc.getLevel() >= 80 && _targetPc.getLevel() <= 90) {
			dmg *= Config.npcdmg3 * 0.01D;// 올리면 쌔진다.
		} else {
			dmg *= Config.npcdmg4 * 0.01D;// 올리면 쌔진다.
		}

		/** 0908원본 */
		// TODO 월드 전체 몬스터 대미지 관련
		dmg = dmg * getLeverage() / 15;// 몬스터 물리데미지 올리면 약해진다.
		// dmg -= calcPcDefense();//몬스터때릴때 PC ac에따라서 대미지가 깎임 본섭은 안깎임

		// /**0908수저*/
		// // TODO 월드 전체 몬스터 대미지 관련
		// dmg = dmg * getLeverage() / 15;// 몬스터 물리데미지 올리면 약해진다.
		// // dmg -= calcPcDefense();//몬스터때릴때 PC ac에따라서 대미지가 깎임 본섭은 안깎임
		//
		//

		if (_npc.isWeaponBreaked()) { // NPC가 웨폰브레이크중.
			dmg *= 0.5;
		}

		if (_targetPc.hasSkillEffect(L1SkillId.메티스정성스프))
			dmg -= 5;
		if (_targetPc.hasSkillEffect(L1SkillId.메티스정성요리))
			dmg -= 5;
		if (_targetPc.hasSkillEffect(L1SkillId.메티스축복주문서))
			dmg -= 3;

//		try {
//			if (_targetPc.isCrown()) {
//			} else if (_targetPc.isKnight()) {
//			} else if (_targetPc.isElf()) {
//			} else if (_targetPc.isWizard()) {
//			} else if (_targetPc.isDarkelf()) {
//			} else if (_targetPc.isBlackwizard()) {
//			} else if (_targetPc.isDragonknight()) {
//			} else if (_targetPc.isWarrior()) {
//			}
//		} catch (Exception e) {
//			System.out.println("Character Add Reduction Error");
	//	}

		// 애완동물, 사몬으로부터 플레이어에 공격
		boolean isNowWar = false;
		int castleId = L1CastleLocation.getCastleIdByArea(_targetPc);
		if (castleId > 0) {
			isNowWar = MJCastleWarBusiness.getInstance().isNowWar(castleId);
		}
		// TODO 펫 대미지
		if (!isNowWar) {
			if (_npc instanceof L1PetInstance) {
				dmg /= 8;
			}
			// TODO 서먼몬스터 대미지
			if (_npc instanceof L1SummonInstance) {
				L1SummonInstance summon = (L1SummonInstance) _npc;
				if (summon.isExsistMaster()) {
					dmg /= 5; // 8
				}
			}
		}

		addNpcPoisonAttack(_npc, _targetPc);

		if (_npc instanceof L1PetInstance || _npc instanceof L1SummonInstance || _npc instanceof L1CompanionInstance) {
			if (_targetPc.getZoneType() == 1) {
				_isHit = false;
			}
		}

		/** 보스 아머브레이크 */
		if (_targetPc.hasSkillEffect(L1SkillId.WIDE_ARMORBREAK)) { // 보스 아머브레이크
			if (_weaponType != 20 && _weaponType != 62) {
				dmg *= 1.58;
			}
		}

		if (_targetPc.hasSkillEffect(L1SkillId.MOEBIUS)) {
			int bowactid = _npc.getNpcTemplate().getBowActId();
			if (bowactid == 66) {
				// if (_weaponType == 20 || _weaponType == 62) {
				if (_targetPc.getLevel() == 85) {
					dmg -= dmg * 0.2;
				} else if (_targetPc.getLevel() == 86) {
					dmg -= dmg * 0.21;
				} else if (_targetPc.getLevel() == 87) {
					dmg -= dmg * 0.22;
				} else if (_targetPc.getLevel() == 88) {
					dmg -= dmg * 0.23;
				} else if (_targetPc.getLevel() == 89) {
					dmg -= dmg * 0.24;
				} else if (_targetPc.getLevel() == 90) {
					dmg -= dmg * 0.25;
				} else if (_targetPc.getLevel() == 91) {
					dmg -= dmg * 0.26;
				} else if (_targetPc.getLevel() == 92) {
					dmg -= dmg * 0.27;
				} else if (_targetPc.getLevel() == 93) {
					dmg -= dmg * 0.28;
				} else if (_targetPc.getLevel() == 94) {
					dmg -= dmg * 0.29;
				} else if (_targetPc.getLevel() >= 95) {
					dmg -= dmg * 0.3;
				}
			}
		}

		if (_targetPc.hasSkillEffect(L1SkillId.세인트)) {
			if (_targetPc.getLevel() == 80 && _targetPc.getLevel() == 81) {
				dmg -= dmg * 0.01;
			} else if (_targetPc.getLevel() == 82 && _targetPc.getLevel() == 83) {
				dmg -= dmg * 0.02;
			} else if (_targetPc.getLevel() == 84 && _targetPc.getLevel() == 85) {
				dmg -= dmg * 0.03;
			} else if (_targetPc.getLevel() == 86 && _targetPc.getLevel() == 87) {
				dmg -= dmg * 0.04;
			} else if (_targetPc.getLevel() == 88 && _targetPc.getLevel() == 89) {
				dmg -= dmg * 0.05;
			} else if (_targetPc.getLevel() == 90) {
				dmg -= dmg * 0.06;
			} else if (_targetPc.getLevel() == 91) {
				dmg -= dmg * 0.07;
			} else if (_targetPc.getLevel() == 92) {
				dmg -= dmg * 0.08;
			} else if (_targetPc.getLevel() == 93) {
				dmg -= dmg * 0.09;
			} else if (_targetPc.getLevel() >= 94) {
				dmg -= dmg * 0.1;
			}
		}
		/** 대상 Buff에 따른 대미지 연산 **/
		dmg = toPcBuffDmg(dmg);
		if (dmg > 0 && _targetPc.hasSkillEffect(L1SkillId.IMMUNE_TO_HARM)) {
			dmg -= (dmg * _targetPc.getImmuneReduction());
			// dmg = IntRange.ensure(dmg, 0, high);
		}
		
		double total_reduction = 0;

		total_reduction += _targetPc.getDamageReductionByArmor(); // 방어구에 의한 대미지 감소
		total_reduction += _targetPc.getDamageReduction(); // 방어구에 의한 대미지 감소
		total_reduction *= Config.PHYSICAL_REDUCTION_RATION;

		if (_target != null) {
			int chance1 = _random.nextInt(100);
			for (L1ItemInstance item : _targetPc.getInventory().getItems()) {
				if (item.isEquipped()) {
					if (item.getItemId() == 123111 || item.getItemId() == 123112 || item.getItemId() == 123113) {
						int addchan = 5;
						if (addchan < 0)
							addchan = 0;
						if (chance1 < Config.할파스갑옷확률) {
							// 123456 일때 80~100
							// 파푸 가호 7일때 120~140 / 8일때 140~160 9일때 160~180
							int addhp = _random.nextInt(20) + 1;
							int addmp = _random.nextInt(30) + 1;
							int basehp = 70;
							int basemp = 8;
							if (item.getEnchantLevel() == 1) {
								basehp = 80;
								basemp = 11;
							}
							if (item.getEnchantLevel() == 2) {
								basehp = 90;
								basemp = 14;
							}
							if (item.getEnchantLevel() == 3) {
								basehp = 100;
								basemp = 17;
							}
							if (item.getEnchantLevel() == 4) {
								basehp = 110;
								basemp = 20;
							}
							if (item.getEnchantLevel() == 5) {
								basehp = 120;
								basemp = 23;
							}
							if (item.getEnchantLevel() == 6) {
								basehp = 130;
								basemp = 26;
							}
							if (item.getEnchantLevel() == 7) {
								basehp = 140;
								basemp = 29;
							}
							if (item.getEnchantLevel() == 8) {
								basehp = 150;
								basemp = 32;
							}
							if (item.getEnchantLevel() == 9) {
								basehp = 160;
								basemp = 35;
							}
							if (item.getEnchantLevel() == 10) {
								basehp = 170;
								basemp = 38;
							}

							_targetPc.setCurrentMp(_targetPc.getCurrentMp() + basemp + addmp);
							_targetPc.setCurrentHp(_targetPc.getCurrentHp() + basehp + addhp);

							SC_SkillSound.send(_targetPc, _targetPc.getId(), 7192);

							SC_SkillSound.broadcast(_targetPc, _targetPc.getId(), 7192);
						}
						break;
					}
				}
			}
		}
//		if (Config.CHAR_BALANCE_USE) {
//		}

		if (_targetPc.getMapId() == 624 && _targetPc.isWizard()) {
			dmg += 30;
		}
		dmg = Math.max(dmg - total_reduction, 0);
		if (dmg <= 0) {
			_isHit = false;
		}

		return (int) dmg;
	}

	// ●●●● NPC 로부터 NPC 에의 대미지 산출 ●●●●
	private int calcNpcNpcDamage() {
		if (_targetNpc == null || _npc == null)
			return 0;

		int lvl = _npc.getLevel();
		double dmg = 0;

		if (_npc.getNpcId() >= 7320138 && _npc.getNpcId() <= 7320147) {
			if (_npc.getCurrentHp() < _npc.getMaxHp()) {
				int adddmg = (_npc.getMaxHp() - _npc.getCurrentHp()) / Config.summon_hpdmg;
				if (adddmg < 0) {
					adddmg = 1;
				}
				dmg += adddmg;

				// System.out.println(Config.summon_hpdmg);
				// System.out.println("dmg: "+dmg);
				// System.out.println("adddmg: "+adddmg);
			}
		}
		if (_npc instanceof L1PetInstance) {
			dmg = _random.nextInt(_npc.getNpcTemplate().get_level()) + _npc.getAbility().getTotalStr() / 2 + 1;
			dmg += (lvl / 16); // 펫은 LV16마다 추가 타격
			dmg += ((L1PetInstance) _npc).getDamageByWeapon();
		} else if (_npc instanceof L1SummonInstance) {
			dmg = _random.nextInt(lvl) + _npc.getAbility().getTotalStr() + 5;
		} else {
			dmg = _random.nextInt(lvl) + _npc.getAbility().getTotalStr() / 2 + 1;
		}

		if (isUndeadDamage()) {
			dmg *= 1.1;
		}

		dmg = dmg * getLeverage() / 10;

		dmg -= calcNpcDamageReduction();

		if (_npc.isWeaponBreaked()) { // NPC가 웨폰브레이크중.
			dmg /= 2;
		}

		addNpcPoisonAttack(_npc, _targetNpc);

		if (_targetNpc.hasSkillEffect(L1SkillId.ICE_LANCE)) {
			dmg = 0;
		}
		if (_targetNpc.hasSkillEffect(L1SkillId.EARTH_BIND)) {
			dmg = 0;
		}

		if (dmg <= 0) {
			_isHit = false;
		}
//		if (Config.CHAR_BALANCE_USE) {
//		}

		return (int) dmg;
	}

	// ●●●● 플레이어의 대미지 강화 마법 ●●●●
	private double calcBuffDamage(double dmg) {

		if (_pc.hasSkillEffect(L1SkillId.BLOW_ATTACK)) { // 기사 블로우 어택
			int chance = Config.BLOW_ATTACKPR; // 기본 30퍼 80레벨에 35퍼 85레벨에 40퍼
			if (_pc.getLevel() > 75) {
				chance = chance + (_pc.getLevel() - 75); // 75레벨이상일때 1퍼씩 추가됨
			}
			if (chance >= 45) { // 최대 확률 수정하세요
				chance = 45;
			}
			if ((_random.nextInt(100) + 1) <= chance) {
				double tempDmg = dmg;
				double diffDmg = dmg - tempDmg;
				dmg = tempDmg * Config.BLOW_ATTACKDMG + diffDmg;

				if (_calcType == PC_PC) {
					SC_SkillSound.send(_pc, _targetPc.getId(), 7727);
					SC_SkillSound.broadcast(_pc, _targetPc.getId(), 7727);
					SC_SkillSound.send(_pc, _targetPc.getId(), 406);
					_effex = 1;
				} else if (_calcType == PC_NPC) {
					SC_SkillSound.send(_pc, _targetNpc.getId(), 7727);
					SC_SkillSound.broadcast(_pc, _targetNpc.getId(), 7727);
					SC_SkillSound.send(_pc, _targetNpc.getId(), 406);
					_effex = 1;
				}

				// _pc.sendPackets(new SC_SystemMessage("블로우 어택 발동!"));
			}
		}
		return dmg;
	}

	/** 무기 속성 인챈에 따른 효과 부여(PC-PC) **/
	private double 피시속성인첸트효과() {
		int Attr = _weaponAttrLevel;
		double AttrDmg = 0;
		switch (_weaponAttrLevel) {
		case 1:
		case 2:
		case 3:
		case 4:
		case 5:
			// AttrDmg += (Attr - 1) * 2+1;
			AttrDmg += (Attr - 1) + 1;
			if (_arrow != null && _arrow.getItemId() == 3000516) {
				AttrDmg += 3;
			}
			AttrDmg -= AttrDmg * _targetPc.getResistance().getFire() / 100;
			break;
		case 6:
		case 7:
		case 8:
		case 9:
		case 10:
			// AttrDmg += (Attr - 6) * 2+1;
			AttrDmg += (Attr - 6) + 1;
			if (_arrow != null && _arrow.getItemId() == 3000516) {
				AttrDmg += 3;
			}
			AttrDmg -= AttrDmg * _targetPc.getResistance().getWater() / 100;

			break;
		case 11:
		case 12:
		case 13:
		case 14:
		case 15:
			// AttrDmg += (Attr - 11) * 2+1;
			AttrDmg += (Attr - 11) + 1;
			if (_arrow != null && _arrow.getItemId() == 3000516) {
				AttrDmg += 3;
			}
			AttrDmg -= AttrDmg * _targetPc.getResistance().getWind() / 100;
			break;
		case 16:
		case 17:
		case 18:
		case 19:
		case 20:
			// AttrDmg += (Attr - 16) * 2+1;
			AttrDmg += (Attr - 16) + 1;
			if (_arrow != null && _arrow.getItemId() == 3000516) {
				AttrDmg += 3;
			}
			AttrDmg -= AttrDmg * _targetPc.getResistance().getEarth() / 100;
			break;
		default:
			AttrDmg = 0;
			break;
		}
		return AttrDmg;
	}

	/** 무기 속성 인챈에 따른 효과 부여(PC-NPC) **/
	private int 몬스터속성인첸트효과() {
		int AttrDmg = 0;
		int Attr = _weaponAttrLevel;
		int NpcWeakAttr = _targetNpc.getNpcTemplate().get_weakAttr();
		switch (NpcWeakAttr) {
		case 1: // 땅 취약 몬스터
			if (Attr >= 15 && Attr <= 20) {
				// AttrDmg += 1 + (Attr - 15) * 2;
				AttrDmg += 1 + (Attr - 15);
				if (_arrow != null && _arrow.getItemId() == 3000516) {
					AttrDmg += 3;
				}
			}
			break;
		case 2: // 물 취약 몬스터
			if (Attr >= 6 && Attr <= 10) {
				// AttrDmg += 1 + (Attr - 6) * 2;
				AttrDmg += 1 + (Attr - 6);
				if (_arrow != null && _arrow.getItemId() == 3000516) {
					AttrDmg += 3;
				}
			}
			break;
		case 4: // 불 취약 몬스터
			if (Attr >= 1 && Attr <= 5) {
				// AttrDmg += (Attr - 1) * 2 + 1;
				AttrDmg += 1 + (Attr - 1);
				if (_arrow != null && _arrow.getItemId() == 3000516) {
					AttrDmg += 3;
				}
			}
			break;
		case 8: // 바람 취약 몬스터
			if (Attr >= 11 && Attr <= 15) {
				// AttrDmg += 1 + (Attr - 11) * 2;
				AttrDmg += 1 + (Attr - 11);
				if (_arrow != null && _arrow.getItemId() == 3000516) {
					AttrDmg += 3;
				}
			}
			break;
		default:
			AttrDmg = 0;
			break;
		}
		return AttrDmg;
	}

	// ●●●● 플레이어의 AC에 의한 대미지 경감 ●●●●
	private int calcPcDefense() {
		// int ac = Math.max(0, 5 - _targetPc.getAC().getAc());
		int ac = Math.max(0, 10 - _targetPc.getAC().getAc());
		int acDefMax = _targetPc.getClassFeature().getAcDefenseMax(ac);
		return _random.nextInt(acDefMax + 1);
	}

	// ●●●● NPC의 대미지 축소에 의한 경감 ●●●●
	private int calcNpcDamageReduction() {
		return _targetNpc.getNpcTemplate().get_damagereduction();
	}

	// ●●●● 무기의 재질과 축복에 의한 추가 대미지 산출 ●●●●
	private int calcMaterialBlessDmg() {
		int damage = 0;
		int undead = _targetNpc.getNpcTemplate().get_undead();
		if ((_weaponMaterial == 14 || _weaponMaterial == 17 || _weaponMaterial == 22) && (undead == 1 || undead == 3)) { // 은·미스릴·오리하르콘,
			damage += _random.nextInt(20) + 1;
		}
		if (_weaponBless == 0 && (undead == 1 || undead == 2 || undead == 3)) { // 축복
			damage += _random.nextInt(4) + 1;
		}
		return damage;
	}

	// ●●●● NPC의 안 데드의 야간 공격력의 변화 ●●●●
	private boolean isUndeadDamage() {
		boolean flag = false;
		int undead = _npc.getNpcTemplate().get_undead();
		boolean isNight = L1GameTimeClock.getInstance().getGameTime().isNight();
		if (isNight && (undead == 1 || undead == 3)) {
			flag = true;
		}
		return flag;
	}

	// TODO ●●●● NPC의 독공격을 부가 ●●●●
	private void addNpcPoisonAttack(L1Character attacker, L1Character target) {
		if (_npc.getNpcTemplate().get_poisonatk() != 0) { // 독공격 있어
			if (15 >= _random.nextInt(100) + 1) { // 15%의 확률로 독공격
				if (_npc.getNpcTemplate().get_poisonatk() == 1) { // 통상독 3초 주기에
																	// 대미지 5
					L1DamagePoison.doInfection(attacker, target, 3000, 5, false, 30000);
				} else if (_npc.getNpcTemplate().get_poisonatk() == 2) { // 침묵독
					L1SilencePoison.doInfection(target);
				} else if (_npc.getNpcTemplate().get_poisonatk() == 4) { // 마비독
																			// 20초
																			// 후에
																			// 16초간

					L1ParalysisPoison.doInfection(target, 9999);
				}
			}
		} else if (_npc.getNpcTemplate().get_paralysisatk() != 0) { // / 마비 공격
																	// 있어
		}
	}

	// ■■■■ PC의 독공격을 부가 ■■■■
	public void addPcPoisonAttack(L1Character attacker, L1Character target) {
		int chance = _random.nextInt(100) + 1;
		if ((_weaponId == 13 || _weaponId == 44 // FOD, 고대의 다크 에르프 소도
				|| (_weaponId != 0 && _pc.hasSkillEffect(L1SkillId.ENCHANT_VENOM))) // 인챈트
																			// 베놈
				&& chance <= 10) {
			L1DamagePoison.doInfection(attacker, target, 3000, 30, false, 30000);
		}
	}

	/* ■■■■■■■■■■■■■■ 공격 모션 송신 ■■■■■■■■■■■■■■ */

	public void action() {
		try {
			if (_calcType == PC_PC || _calcType == PC_NPC) {
				actionPc();
			} else if (_calcType == NPC_PC || _calcType == NPC_NPC) {
				actionNpc();
			}
		} catch (Exception e) {
		}
	}
	
    // ●●●● 플레이어의 공격 모션 송신 ●●●●
    private void actionPc() {
        if (_pc.hasSkillEffect(L1SkillId.버닝샷)) {
            int diffLocX = Math.abs(_pc.getX() - _target.getX());
            int diffLocY = Math.abs(_pc.getY() - _target.getY());

            if (diffLocX > Config.버닝샷칸 || diffLocY > Config.버닝샷칸) {
                SC_SystemMessage.send(_pc, "\\f3버닝샷: 사정거리 밖이여서 공격할 수 없습니다.");
                return;
            }
        }

        int spriteId = _pc.getCurrentSpriteId();
        _pc.setHeading(_pc.targetDirection(_targetX, _targetY)); // 방향 세트


        // ── 활 (weaponType 20) ──
        if (_weaponType == 20) {
            if (!_pc.glanceCheck(_targetX, _targetY) || !_target.glanceCheck(_pc.getX(), _pc.getY())) {
            	
                SC_UseArrowSkill.sendAndBroadcast(_pc, _targetId, ActionCodes.ACTION_BowAttack, _targetX, _targetY, _isHit);
                _isHit = false;
                return;
            }

            if (_arrow != null) { // 화살 소모 + 변신별 화살 이미지
                if (!_pc.noPlayerCK) {
                    _pc.getInventory().removeItem(_arrow, 1);
                }
                SC_UseArrowSkill.sendAndBroadcast(_pc, _targetId, getArrowGfxId(spriteId), _targetX, _targetY, _isHit);

                if (_isHit && spriteId == 21226) {
                	long sam = SC_SkillSound.pack(_targetId, 20004);
                 	SC_SkillSound.sendPacked(_pc, sam);
                    SC_SkillSound.broadcastFastPacked(_pc, sam);
                }
            } else { // 화살 없음 — 무기별 고정 이미지
                int gfx = 2349;                       // 기본(190)
                if (_weaponId == 202011) gfx = 8916;  // 가이아의 격노
                else if (_weaponId == 10000) gfx = 8771;
                else if (_weaponId != 190) {
                    SC_UseArrowSkill.sendAndBroadcast(_pc, _targetId, ActionCodes.ACTION_BowAttack, _targetX, _targetY, _isHit);
                    return;
                }
                SC_UseArrowSkill.sendAndBroadcast(_pc, _targetId, gfx, _targetX, _targetY, _isHit);
            }
            return;
        }

        // ── 키링크 (weaponType2 17) ──
        if (_weaponType2 == 17) {
            if (_isHit) {
                if (!_isCritical) {
                    int gfx = (_weaponId == 283 || _weaponId == 1120 || _weaponId == 202012
                            || _weaponId == 7000223 || _weaponId == 123008) ? 13923 : 7049;
                    CommonUtil.sendKeyLinkTo(_pc, _targetId, gfx, _damage, _pc.getHeading(), _targetX, _targetY);
                }
            } else {
                if (_targetId > 0) {
                 	SC_AttackMissPacket.send(_pc.getNetConnection(), _pc, _targetId);
                 	SC_AttackMissPacket.broadcast(_pc, _targetId);
                } else {
                	SC_AttackPacket.send(_pc.getNetConnection(), _pc, 0, ActionCodes.ACTION_Attack);
                	SC_AttackPacket.broadcast(_pc, 0, ActionCodes.ACTION_Attack);
                }
            }
            return;
        }

        // ── 근접 일반 공격 ──
        if (_isHit) {
            if (!_isCritical) {
              	SC_AttackPacket.send(_pc.getNetConnection(), _pc, _targetId, ActionCodes.ACTION_Attack, _attackType);
              	SC_AttackPacket.broadcast(_pc, _targetId, ActionCodes.ACTION_Attack, _attackType);
            }
        } else {
            if (_targetId > 0) {
            	SC_AttackMissPacket.send(_pc.getNetConnection(), _pc, _targetId);
            	SC_AttackMissPacket.broadcast(_pc, _targetId);
            } else {
            	SC_AttackPacket.send(_pc.getNetConnection(), _pc, 0, ActionCodes.ACTION_Attack);
            	SC_AttackPacket.broadcast(_pc, 0, ActionCodes.ACTION_Attack);
            }
        }
    }

    /** 변신 스프라이트별 화살 그래픽 ID (활 + 스트링 공용) */
    private static int getArrowGfxId(int spriteId) {
        switch (spriteId) {
        case 21132: case 21136: return 21427;
        case 21233:             return 20003;
        case 19514: case 21209: case 21258: case 21405: case 21409: return 20542;
        case 20528:             return 20005;
        case 18398:             return 8904;
        case 18391:             return 8916;
        case 18394:             return 13656;
        case 21140:             return 19999;
        case 21226:             return 20001;
        case 7967:              return 7972;
        case 11402: case 8900:  return 8904;
        case 11406: case 8913:  return 8916;
        case 13631:             return 13656;
        case 13635:             return 13658;
        case 15814:             return 12243;
        case 16002: case 16074: return 16078;
        default:                return 2989;
        }
    }
    
	// ●●●● NPC의 공격 모션 송신 ●●●●
    private void actionNpc() {
    	int _npcObjectId = _npc.getId();
    	int bowActId = 0;
    	int actId = 0;
    	int heading = _npc.targetDirection(_targetX, _targetY);

    	if (_npc.getHeading() != heading) {
    		_npc.setHeading(heading);
    	}

    	boolean isLongRange =
    			_npc.getLocation()
    				.getTileLineDistance(_target.getLocation()) > 1;

    	bowActId = _npc.getNpcTemplate().getBowActId();

    	actId = (getActId() > 0)
    			? getActId()
    			: ActionCodes.ACTION_Attack;

    	if (isLongRange && bowActId > 0) {
    		SC_UseArrowSkill.broadcast(
    				_npc,
    				_targetId,
    				bowActId,
    				_targetX,
    				_targetY,
    				_isHit);
    		return;
    	}

    	if (_isHit) {
    		if (getGfxId() > 0) {
    			SC_UseAttackSkill.broadcast(
    					_npc,
    					_target,
    					_npcObjectId,
    					getGfxId(),
    					_targetX,
    					_targetY,
    					actId);
    		} else {
    			SC_AttackPacketForNpc.broadcast(
    					_npc,
    					_target,
    					_npcObjectId,
    					actId);
    		}
    	} else {
    		if (getGfxId() > 0) {
    			SC_UseAttackSkill.broadcast(
    					_npc,
    					_target,
    					_npcObjectId,
    					getGfxId(),
    					_targetX,
    					_targetY,
    					actId);
    		} else {
    			SC_AttackPacketForNpc.broadcast(
    					_npc,
    					_target,
    					_npcObjectId,
    					actId);
    		}
    	}
    }
    
	// 나는 일 도구(화살, 스팅)가 미스였다고 나무의 궤도를 계산
	public void calcOrbit(int cx, int cy, int head) // 기점 X 기점 Y 지금 향하고 있는 방향
	{
		float dis_x = Math.abs(cx - _targetX); // X방향의 타겟까지의 거리
		float dis_y = Math.abs(cy - _targetY); // Y방향의 타겟까지의 거리
		float dis = Math.max(dis_x, dis_y); // 타겟까지의 거리
		float avg_x = 0;
		float avg_y = 0;
		if (dis == 0) { // 목표와 같은 위치라면 향하고 있는 방향에 진곧
			switch (head) {
			case 1:
				avg_x = 1;
				avg_y = -1;
				break;
			case 2:
				avg_x = 1;
				avg_y = 0;
				break;
			case 3:
				avg_x = 1;
				avg_y = 1;
				break;
			case 4:
				avg_x = 0;
				avg_y = 1;
				break;
			case 5:
				avg_x = -1;
				avg_y = 1;
				break;
			case 6:
				avg_x = -1;
				avg_y = 0;
				break;
			case 7:
				avg_x = -1;
				avg_y = -1;
				break;
			case 0:
				avg_x = 0;
				avg_y = -1;
				break;
			default:
				break;
			}
		} else {
			avg_x = dis_x / dis;
			avg_y = dis_y / dis;
		}

		int add_x = (int) Math.floor((avg_x * 15) + 0.59f); // 상하 좌우가 조금 우선인 둥근
		int add_y = (int) Math.floor((avg_y * 15) + 0.59f); // 상하 좌우가 조금 우선인 둥근

		if (cx > _targetX) {
			add_x *= -1;
		}
		if (cy > _targetY) {
			add_y *= -1;
		}

		_targetX = _targetX + add_x;
		_targetY = _targetY + add_y;
	}

	/* ■■■■■■■■■■■■■■■ 계산 결과 반영 ■■■■■■■■■■■■■■■ */
	public void commit(int damage) {
		if (damage > 0) {
			try {
				if (_calcType == PC_PC || _calcType == NPC_PC) {
					commitPc(damage);
				} else if (_calcType == PC_NPC || _calcType == NPC_NPC) {
					commitNpc(damage);
				}
			} catch (Exception e) {
			}
		}
		// 대미지치 및 명중율 확인용 메세지
		if (!Config.ALT_ATKMSG) {
			return;
		}
		if (_target == null)
			return;
		if (_pc != null && _pc.isGm()) {
			StringBuffer sb = new StringBuffer();

			sb.append("\\fT<데미지> [").append(damage).append(" DMG ==][HP ").append(_target.getCurrentHp()).append("]");

			SC_SystemMessage.send(_pc, sb.toString());
			sb = null;
		}
		if (_targetPc != null && _targetPc.isGm()) {
			StringBuffer sb = new StringBuffer();
			sb.append("\\fY<데미지> [").append(damage).append(" DMG ==][HP ").append(_target.getCurrentHp()).append("]");
			SC_SystemMessage.send(_targetPc, sb.toString());
			sb = null;
		}
	}

	public void commit() {
		if (_isHit) {
			try {
				if (_calcType == PC_PC || _calcType == NPC_PC) {
					commitPc();
				} else if (_calcType == PC_NPC || _calcType == NPC_NPC) {
					commitNpc();
				}
			} catch (Exception e) {
			}
		}

		// 대미지치 및 명중율 확인용 메세지
		if (!Config.ALT_ATKMSG) {
			return;
		}
		if (_target == null)
			return;
		if (_pc != null && _pc.isGm()) {
			StringBuffer sb = new StringBuffer();
			sb.append("\\fT[").append(_pc.getName()).append("] ==> [").append(_target.getName()).append("][== ")
					.append(_damage).append(" DMG ==][HP ").append(_target.getCurrentHp()).append("]");
			SC_SystemMessage.send(_pc, sb.toString());
			sb = null;
		}
		if (_targetPc != null && _targetPc.isGm()) {
			StringBuffer sb = new StringBuffer();
			sb.append("\\fY[").append(_target.getName()).append("] <== [")
					.append((_pc == null ? _npc.getName() : _pc.getName())).append("][== ").append(_damage)
					.append(" DMG ==][HP ").append(_target.getCurrentHp()).append("]");
			SC_SystemMessage.send(_targetPc, sb.toString());
			sb = null;
		}
	}

	// ●●●● 플레이어에 계산 결과를 반영 ●●●●
	private void commitPc(int dmg) {
		if (_calcType == PC_PC) {
			if (MJCommons.isUnbeatable(_targetPc))
				_damage = 0;
			_targetPc.receiveDamage(_pc, _damage + dmg);
		} else if (_calcType == NPC_PC) {
			if (MJCommons.isUnbeatable(_targetPc))
				_damage = 0;
			_targetPc.receiveDamage(_npc, _damage + dmg);
		}
	}

	private void commitNpc(int dmg) {
		if (_calcType == PC_NPC) {
			if (MJCommons.isUnbeatable(_targetNpc))
				_damage = 0;
			damageNpcWeaponDurability(); // 무기를 손상시킨다.
			_targetNpc.receiveDamage(_pc, _damage + dmg);
		} else if (_calcType == NPC_NPC) {
			if (MJCommons.isUnbeatable(_targetNpc))
				_damage = 0;
			_targetNpc.receiveDamage(_npc, _damage + dmg);
		}
	}

	private void commitPc() {
		if (_calcType == PC_PC) {
			if (MJCommons.isUnbeatable(_targetPc))
				_damage = 0;
			_targetPc.receiveDamage(_pc, _damage);
		} else if (_calcType == NPC_PC) {
			if (MJCommons.isUnbeatable(_targetPc))
				_damage = 0;
			_targetPc.receiveDamage(_npc, _damage);
		}
	}

	// ●●●● NPC에 계산 결과를 반영 ●●●●
	private void commitNpc() {
		if (_calcType == PC_NPC) {
			if (MJCommons.isUnbeatable(_targetNpc))
				_damage = 0;
			damageNpcWeaponDurability(); // 무기를 손상시킨다.
			_targetNpc.receiveDamage(_pc, _damage);
		} else if (_calcType == NPC_NPC) {
			if (MJCommons.isUnbeatable(_targetNpc))
				_damage = 0;
			_targetNpc.receiveDamage(_npc, _damage);
		}
	}

	/* ■■■■■■■■■■■■■■■ 카운터 배리어 ■■■■■■■■■■■■■■■ */
	// ■■■■ 카운터 배리어시의 공격 모션 송신 ■■■■
	public void actionCounterBarrier() {
		if (_calcType == PC_PC) {
			if (_pc == null)
				return;
			if (_targetPc.hasSkillEffect(L1SkillId.SHOCK_STUN) || _targetPc.hasSkillEffect(L1SkillId.EMPIRE)
					|| _targetPc.hasSkillEffect(L1SkillId.EARTH_BIND)) {
				return;
			}
			L1ItemInstance item = _pc.getInventory().findEquippedItemId(123900);
			if (item == null) {
				_pc.setHeading(_pc.targetDirection(_targetX, _targetY)); // 방향세트
				SC_AttackMissPacket.send(_pc.getNetConnection(), _pc, _targetId);
				SC_AttackMissPacket.broadcast(_pc, _targetId);
				SC_DoActionGFX.send(_pc.getNetConnection(), _pc.getId(), ActionCodes.ACTION_Damage);
				SC_DoActionGFX.broadcast(_pc, ActionCodes.ACTION_Damage);

			} else {
				int actid = ActionCodes.ACTION_Attack;
				SC_AttackPacket.send(_pc.getNetConnection(), _pc, _targetId, actid, _attackType);
				SC_AttackPacket.broadcast(_pc, _targetId, actid, _attackType);

				_pc.setHeading(_pc.targetDirection(_targetX, _targetY)); // 방향세트
			}

			if (_targetPc.isPassive(MJPassiveID.COUNTER_BARRIER_VETERAN.toInt())) {

				if (item == null) {
					_targetPc.send_effect(17220);
				}
			} else {
				if (item == null) {
					_targetPc.send_effect(10710);
				}
			}
		} else if (_calcType == NPC_PC) {
			if (_npc == null || _target == null)
				return;
			int actId = 0;
			_npc.setHeading(_npc.targetDirection(_targetX, _targetY)); // 방향세트
			if (getActId() > 0) {
				actId = getActId();
			} else {
				actId = ActionCodes.ACTION_Attack;
			}
			if (getGfxId() > 0) {
				SC_UseAttackSkill.broadcast(_npc, _target, _npc.getId(), getGfxId(), _targetX, _targetY, actId, 0);
			} else {
				SC_AttackMissPacket.broadcast(_npc, _targetId, actId);
			}
			SC_DoActionGFX.broadcast(_npc, ActionCodes.ACTION_Damage);
			if (_targetPc.isPassive(MJPassiveID.COUNTER_BARRIER_VETERAN.toInt())) {
				_targetPc.send_effect(17220);
			} else {
				_targetPc.send_effect(10710);
			}
		}
	}

	public void NpcactionCounterBarrier(L1Character attacker, L1PcInstance pc) {
		if (pc == null || _target == null)
			return;
		int actId = 0;
		pc.setHeading(pc.targetDirection(_targetX, _targetY)); // 방향세트
		if (getActId() > 0) {
			actId = getActId();
		} else {
			actId = ActionCodes.ACTION_Attack;
		}
		if (getGfxId() > 0) {
			SC_UseAttackSkill.broadcast(pc, _target, pc.getId(), getGfxId(), _targetX, _targetY, actId, 0);
		} else {
			SC_AttackMissPacket.broadcast(pc, _targetId, actId);
		}
		SC_DoActionGFX.broadcast(pc, ActionCodes.ACTION_Damage);
		attacker.send_effect(17220);
	}

	// ■■■■ 모탈바디 발동시의 공격 모션 송신 ■■■■
	public void actionMortalBody() {
		if (_calcType == PC_PC) {
			if (_pc == null || _target == null)
				return;
			L1ItemInstance item = _pc.getInventory().findEquippedItemId(123900);
			if (item == null) {
				// _pc.sendPackets(new SC_SystemMessage("\\fI실렌의 결의: \\f3[모탈바디] \\fI대미지반사를
				// 무시하였습니다."));

				_pc.setHeading(_pc.targetDirection(_targetX, _targetY)); // 방향세트
				SC_UseAttackSkill.sendAndBroadcast(
						_pc,
						_target.getId(),
						6519,
						_targetX,
						_targetY,
						ActionCodes.ACTION_Attack,
						false);
				SC_DoActionGFX.send(_pc.getNetConnection(), _pc.getId(), ActionCodes.ACTION_Damage);

				SC_DoActionGFX.broadcast(_pc, ActionCodes.ACTION_Damage);
			} else {

				int actid = ActionCodes.ACTION_Attack;
				SC_AttackPacket.send(_pc.getNetConnection(), _pc, _targetId, actid, _attackType);
				SC_AttackPacket.broadcast(_pc, _targetId, actid, _attackType);

				_pc.setHeading(_pc.targetDirection(_targetX, _targetY)); // 방향세트

			}
		} else if (_calcType == NPC_PC) {
			if (_npc == null || _target == null)
				return;
			_npc.setHeading(_npc.targetDirection(_targetX, _targetY)); // 방향세트
			SC_SkillSound.broadcastFast(_npc, _target.getId(), 6519);
			SC_DoActionGFX.broadcast(_npc, ActionCodes.ACTION_Damage);
		}
	}

	// ■■■■ 상대의 공격에 대해서 모탈바디가 유효한가를 판별 ■■■■
	public boolean isShortDistance1() {
		boolean isShortDistance1 = true;
		/*
		 * if (_calcType == PC_PC) { if (_weaponType == 20 || _weaponType == 62) { //
		 * 활이나 간트렛트 isShortDistance1 = false; }
		 */
		if (_calcType == NPC_PC) {
			boolean isLongRange = (_npc.getLocation().getTileLineDistance(new Point(_targetX, _targetY)) <= 0);
			int bowActId = _npc.getNpcTemplate().getBowActId();
			// 거리가 2이상, 공격자의 활의 액션 ID가 있는 경우는 원공격
			if (isLongRange && bowActId > 0) {
				isShortDistance1 = false;
			}
		}
		return isShortDistance1;
	}

	// ■■■■ 상대의 공격에 대해서 카운터 배리어가 유효한가를 판별 ■■■■
	public boolean isShortDistance() {
		boolean isShortDistance = true;
		if (_calcType == PC_PC) {
			if (_weaponType == 20 || _weaponType == 62 || _weaponType2 == 17 || _weaponType2 == 19
					|| _pc.hasSkillEffect(L1SkillId.ARMOR_BRAKE)) {
				isShortDistance = false;
			}
		} else if (_calcType == NPC_PC) {
			if (_npc == null)
				return false;
			boolean isLongRange = (_npc.getLocation().getTileLineDistance(new Point(_targetX, _targetY)) > 1);
			int bowActId = _npc.getNpcTemplate().getBowActId();
			// 거리가 2이상, 공격자의 활의 액션 ID가 있는 경우는 원공격
			if (isLongRange && bowActId > 0) {
				isShortDistance = false;
			}
		}
		return isShortDistance;
	}

	// ■■■■ 카운터 배리어의 대미지를 반영 ■■■■
	public void commitCounterBarrier() {
		int damage = calcCounterBarrierDamage();

		if (damage == 0) {
			return;
		}
		if (_calcType == PC_PC) {
			L1ItemInstance item = _pc.getInventory().findEquippedItemId(123900);
			if (item != null) {
				SC_SystemMessage.send(_pc, "\\fI실렌의 결의:\\f3[카운터배리어]\\fI대미지반사를 무시하였습니다");
				_targetPc.receiveDamage(_targetPc, damage);
				return;
			} else {
				_pc.receiveCounterBarrierDamage(_targetPc, damage);
			}

		} else if (_calcType == NPC_PC) {
			_npc.receiveCounterBarrierDamage(_targetPc, damage);
		} else if (_calcType == PC_NPC) {
			_pc.receiveCounterBarrierDamage(_targetPc, damage);
		}
	}

	public void commitBossCounterBarrier(L1Character attacker, L1PcInstance pc) {
		int damage = 0;
		L1ItemInstance weapon = null;
		weapon = pc.getWeapon();
		if (weapon == null)
			damage = 10;
		else
			damage = (int) Math.round(
					(weapon.getItem().getDmgLarge() + weapon.getEnchantLevel() + weapon.getItem().getDmgModifier())
							* Config.Counter);
		pc.receiveCounterBarrierDamage(pc, damage);
	}

	// ■■■■ 모탈바디의 대미지를 반영 ■■■■
	public void commitMortalBody() {
		// int damage = 40;
		// if (damage == 0) {
		// return;
		// }
		int ac = Math.max(0, 10 - _targetPc.getAC().getAc());
		int damage = ac / 2;

		if (damage == 0) {
			return;
		}

		if (_calcType == PC_PC) {
			L1ItemInstance item = _pc.getInventory().findEquippedItemId(123900);
			if (item != null) {
				SC_SystemMessage.send(_pc, "\\fI실렌의 결의: \\f3[모탈바디] \\fI대미지반사를 무시하였습니다.");
				return;
			}
		}
		// if ()
		if (damage <= 40) {
			damage = 40;
		}
		if (_calcType == PC_PC) {
			_pc.receiveDamage(_targetPc, damage);
		} else if (_calcType == NPC_PC) {
			_npc.receiveDamage(_targetPc, damage);
		}
	}

	// ●●●● 카운터 배리어의 대미지를 산출 ●●●●
	private int calcCounterBarrierDamage() {
		double damage = 0;
		L1ItemInstance weapon = null;
		weapon = _targetPc.getWeapon();

		if (weapon != null) {
			if (weapon.getItem().getType() == 3) {
				damage = Math.round(
						(weapon.getItem().getDmgLarge() + weapon.getEnchantLevel() + weapon.getItem().getDmgModifier())
								* Config.Counter);
			}

		}

		if (_targetPc.hasSkillEffect(L1SkillId.카배마스터)) {

			int 회복 = (int) ((double) Math.round(
					(weapon.getItem().getDmgLarge() + weapon.getEnchantLevel() + weapon.getItem().getDmgModifier())
							* Config.카배회복량));
			int 최종회복 = _random.nextInt(30) + 회복;
			_targetPc.setCurrentHp(_targetPc.getCurrentHp() + 최종회복);
			SC_SkillSound.send(_targetPc, _targetPc.getId(), 6590);
			SC_SkillSound.broadcastFast(_targetPc, _targetPc.getId(), 6590);
			if (_targetPc.마스터 = true) {
				SC_SystemMessage.send(_targetPc, "\\f9카운터배리어(마스터): HP \\f3" + 최종회복 + "\\f9을 회복하였습니다.");
			}

		}
		return (int) damage;
	}

	// ●●●● 전사 타이탄 대미지를 산출 ●●●●
	private int 타이탄대미지() {
		double damage = 0;
		L1ItemInstance weapon = null;
		weapon = _targetPc.getWeapon();
		if (weapon != null) {
			damage = Math.round(
					(weapon.getItem().getDmgLarge() + weapon.getEnchantLevel() + weapon.getItem().getDmgModifier())
							* Config.RockDMG);
		}
		return (int) damage;
	}

	private int 할파스대미지() {
		double damage = 0;
		L1ItemInstance weapon = null;
		weapon = _targetPc.getWeapon();
		if (weapon != null) {
			damage = Math.round(
					(weapon.getItem().getDmgSmall() + weapon.getEnchantLevel() + weapon.getItem().getDmgModifier())
							* Config.할파스데미지);
		}
		return (int) damage;
	}

	/*
	 * 무기를 손상시킨다. 대NPC의 경우, 손상 확률은10%로 한다. 축복 무기는3%로 한다.
	 */
	private void damageNpcWeaponDurability() {
		int chance = 3; // 일반 무기
		int bchance = 1; // 축복 받은 무기 손상확률

		/*
		 * 손상하지 않는 NPC, 맨손, 손상하지 않는 무기 사용, SOF중의 경우 아무것도 하지 않는다.
		 */
		if (_calcType != PC_NPC || _targetNpc.getNpcTemplate().is_hard() == false || _weaponType == 0
				|| weapon.getItem().get_canbedmg() == 0 || _pc.hasSkillEffect(L1SkillId.SOUL_OF_FLAME)) {
			return;
		}
		// 통상의 무기·저주해진 무기
		if ((_weaponBless == 1 || _weaponBless == 2) && ((_random.nextInt(100) + 1) < chance)) {
			// \f1당신의%0가 손상했습니다.
			SC_ServerMessage.send(_pc, 268, weapon.getLogName());
			_pc.getInventory().receiveDamage(weapon);
		}
		// 축복된 무기
		if (_weaponBless == 0 && ((_random.nextInt(100) + 1) < bchance)) {
			// \f1당신의%0가 손상했습니다.
			SC_ServerMessage.send(_pc, 268, weapon.getLogName());
			_pc.getInventory().receiveDamage(weapon);
		}
	}

	private void 물약충전(int 물약번호, int 물약갯수, int 용기번호, int 용기갯수, int 음식1번호, int 음식1갯수, int 음식2번호, int 음식2갯수, int 촐기번호,
			int 촐기갯수) {

		if (물약갯수 < 500) {
			if (물약갯수 == 0) {
				물약갯수 = 1;
			}
			_pc.getInventory().storeItem(물약번호, 5000 - 물약갯수);
		}
		if (용기갯수 < 100) {
			if (용기갯수 == 0) {
				용기갯수 = 1;
			}
			_pc.getInventory().storeItem(용기번호, 100 - 용기갯수);
		}
		if (음식1갯수 < 10) {
			if (음식1갯수 == 0) {
				음식1갯수 = 1;
			}
			_pc.getInventory().storeItem(음식1번호, 100 - 음식1갯수);
		}
		if (음식2갯수 < 10) {
			if (음식2갯수 == 0) {
				음식2갯수 = 1;
			}
			_pc.getInventory().storeItem(음식2번호, 100 - 음식2갯수);
		}
		if (촐기갯수 < 10) {
			if (촐기갯수 == 0) {
				촐기갯수 = 1;
			}
			_pc.getInventory().storeItem(촐기번호, 100 - 촐기갯수);
		}
		SC_PacketBox.send(_pc, SC_PacketBox.GREEN_MESSAGE, "\\f:VIP인증석효과로 물약,용기,음식이 충전되었습니다.");
	}

	/** 스탯 + 무기에 따른 공성 **/
	private int PchitAdd() {

		int value = 0;
		if ((_weaponType != 20) && (_weaponType != 62)) {
			value += _pc.getHitup() + _pc.getHitRate();
			value += CalcStat.calcHitup(_pc.getAbility().getTotalStr());
		} else {
			value += _pc.getBowHitup() + _pc.getBowHitRate();
			value += CalcStat.calcBowHitup(_pc.getAbility().getTotalDex());
		}
		if (Sweapon != null) {
			value += _SweaponAddHit + _SweaponEnchant / 2;
		}
		return value;
	}

	/** 타겟PC 회피 스킬에 대한 연산 **/
	private int toPcSkillHit() {

		int value = _target.getDg();
		if (_targetPc.hasSkillEffect(L1SkillId.UNCANNY_DODGE)) {
			if (_targetPc.getAC().getAc() >= -79) {
				value += 0;
			} else if (_targetPc.getAC().getAc() >= -89) {
				value += Config.UNCANNYDODGE1;
			} else if (_targetPc.getAC().getAc() >= -99) {
				value += Config.UNCANNYDODGE2;
			} else if (_targetPc.getAC().getAc() >= -110) {
				value += Config.UNCANNYDODGE3;
			} else if (_targetPc.getAC().getAc() >= -120) {
				value += Config.UNCANNYDODGE4;
			} else if (_targetPc.getAC().getAc() >= -130) {
				value += Config.UNCANNYDODGE5;
			} else if (_targetPc.getAC().getAc() >= -140) {
				value += Config.UNCANNYDODGE6;
			} else if (_targetPc.getAC().getAc() >= -150) {
				value += Config.UNCANNYDODGE7;
			} else if (_targetPc.getAC().getAc() >= -160) {
				value += Config.UNCANNYDODGE8;
			} else if (_targetPc.getAC().getAc() >= -170) {
				value += Config.UNCANNYDODGE9;
			} else if (_targetPc.getAC().getAc() >= -180) {
				value += Config.UNCANNYDODGE10;
			} else if (_targetPc.getAC().getAc() >= -190) {
				value += Config.UNCANNYDODGE11;
			} else if (_targetPc.getAC().getAc() >= -200) {
				value += Config.UNCANNYDODGE12;
			} else if (_targetPc.getAC().getAc() >= -210) {
				value += Config.UNCANNYDODGE13;
			} else if (_targetPc.getAC().getAc() >= -220) {
				value += Config.UNCANNYDODGE14;
			} else if (_targetPc.getAC().getAc() >= -230) {
				value += Config.UNCANNYDODGE15;
			} else if (_targetPc.getAC().getAc() >= -240) {
				value += Config.UNCANNYDODGE16;
			} else if (_targetPc.getAC().getAc() >= -250) {
				value += Config.UNCANNYDODGE17;
			} else if (_targetPc.getAC().getAc() >= -260) {
				value += Config.UNCANNYDODGE18;
			} else if (_targetPc.getAC().getAc() <= -261) {
				value += Config.UNCANNYDODGE19;
			}

		}
		if (_targetPc.hasSkillEffect(L1SkillId.MIRROR_IMAGE)) {

			value += Config.MIRRORIMAGE;
		}

		if (_targetPc.hasSkillEffect(L1SkillId.ANTA_MAAN) || _targetPc.hasSkillEffect(L1SkillId.BIRTH_MAAN)
				|| _targetPc.hasSkillEffect(L1SkillId.SHAPE_MAAN)) {
			int chance = _random.nextInt(100);
			if (chance < 15) {
				value -= 5;
			}
		}
		return value;
	}

	/** Hit 최종 연산 **/
	private boolean hitRateCal(double AD, double DD, double fumble, double critical) {
		if (AD <= fumble) {
			_hitRate = 0;
			return true;
		} else if (AD >= critical) {
			_hitRate = 100;
		} else {
			if (AD > DD) {
				_hitRate = 100;
			} else if (AD <= DD) {
				_hitRate = 0;
				return true;
			}
		}
		return false;
	}

	/** 타겟PC DD 연산 **/
	private int toPcDD(int dv) {
		if (_targetPc.getAC().getAc() >= 0) {
			return 10 - _targetPc.getAC().getAc();
		} else {
			return 10 + _random.nextInt(dv) + 1;
		}
	}

	public static double calcMrDefense(int MagicResistance, double dmg) {
		double cc = 0;
		if (MagicResistance <= 19) {
			cc = 0.05;
		} else if (MagicResistance <= 29) {
			cc = 0.07;
		} else if (MagicResistance <= 39) {
			cc = 0.1;
		} else if (MagicResistance <= 49) {
			cc = 0.12;
		} else if (MagicResistance <= 59) {
			cc = 0.17;
		} else if (MagicResistance <= 69) {
			cc = 0.20;
		} else if (MagicResistance <= 79) {
			cc = 0.22;
		} else if (MagicResistance <= 89) {
			cc = 0.25;
		} else if (MagicResistance <= 99) {
			cc = 0.27;
		} else if (MagicResistance <= 110) {
			cc = 0.31;
		} else if (MagicResistance <= 120) {
			cc = 0.32;
		} else if (MagicResistance <= 130) {
			cc = 0.34;
		} else if (MagicResistance <= 140) {
			cc = 0.36;
		} else if (MagicResistance <= 150) {
			cc = 0.38;
		} else if (MagicResistance <= 160) {
			cc = 0.40;
		} else if (MagicResistance <= 170) {
			cc = 0.42;
		} else if (MagicResistance <= 180) {
			cc = 0.44;
		} else if (MagicResistance <= 190) {
			cc = 0.46;
		} else if (MagicResistance <= 200) {
			cc = 0.48;
		} else if (MagicResistance <= 220) {
			cc = 0.49;
		} else {
			cc = 0.51;
		}

		dmg -= dmg * cc;

		if (dmg < 0) {
			dmg = 0;
		}

		return dmg;
	}


	public double managet(L1PcInstance pc, L1Character cha) {
		int dmg = _random.nextInt(Config.영웅엠피1 - Config.영웅엠피) + Config.영웅엠피;
		int ran = _random.nextInt(1000) + 1;

		if (pc.isKnight() || pc.isCrown() || pc.isWarrior()) {
			if (ran <= Config.잠재력흡수) {
				if (cha.getCurrentMp() < dmg) {
					dmg = cha.getCurrentMp();
					cha.setCurrentMp((int) (cha.getCurrentMp() - dmg));
					pc.setCurrentMp((int) (pc.getCurrentMp() + dmg));
				} else {

					cha.setCurrentMp((int) (cha.getCurrentMp() - dmg));
					pc.setCurrentMp((int) (pc.getCurrentMp() + dmg));

				}
			}
		}
		if (pc.isWizard()) {
			if (ran <= Config.잠재력흡수1) {
				if (cha.getCurrentMp() < dmg) {
					dmg = cha.getCurrentMp();
					cha.setCurrentMp((int) (cha.getCurrentMp() - dmg));
					pc.setCurrentMp((int) (pc.getCurrentMp() + dmg));
				} else {

					cha.setCurrentMp((int) (cha.getCurrentMp() - dmg));
					pc.setCurrentMp((int) (pc.getCurrentMp() + dmg));

				}
			}
		}
		if (pc.isBlackwizard()) {
			if (ran <= Config.잠재력흡수2) {
				if (cha.getCurrentMp() < dmg) {
					dmg = cha.getCurrentMp();
					cha.setCurrentMp((int) (cha.getCurrentMp() - dmg));
					pc.setCurrentMp((int) (pc.getCurrentMp() + dmg));
				} else {

					cha.setCurrentMp((int) (cha.getCurrentMp() - dmg));
					pc.setCurrentMp((int) (pc.getCurrentMp() + dmg));

				}
			}
		}
		if (pc.isElf()) {
			if (ran <= Config.잠재력흡수3) {
				if (cha.getCurrentMp() < dmg) {
					dmg = cha.getCurrentMp();
					cha.setCurrentMp((int) (cha.getCurrentMp() - dmg));
					pc.setCurrentMp((int) (pc.getCurrentMp() + dmg));
				} else {

					cha.setCurrentMp((int) (cha.getCurrentMp() - dmg));
					pc.setCurrentMp((int) (pc.getCurrentMp() + dmg));

				}
			}
		}
		if (pc.isDarkelf()) {
			if (ran <= Config.잠재력흡수4) {
				if (cha.getCurrentMp() < dmg) {
					dmg = cha.getCurrentMp();
					cha.setCurrentMp((int) (cha.getCurrentMp() - dmg));
					pc.setCurrentMp((int) (pc.getCurrentMp() + dmg));
				} else {

					cha.setCurrentMp((int) (cha.getCurrentMp() - dmg));
					pc.setCurrentMp((int) (pc.getCurrentMp() + dmg));

				}
			}
		}
		if (pc.isDragonknight()) {
			if (ran <= Config.잠재력흡수5) {
				if (cha.getCurrentMp() < dmg) {
					dmg = cha.getCurrentMp();
					cha.setCurrentMp((int) (cha.getCurrentMp() - dmg));
					pc.setCurrentMp((int) (pc.getCurrentMp() + dmg));
				} else {

					cha.setCurrentMp((int) (cha.getCurrentMp() - dmg));
					pc.setCurrentMp((int) (pc.getCurrentMp() + dmg));

				}
			}
		}

		return dmg;
	}

    private static void deductDrainHp(L1PcInstance attacker, L1Character target, int damage) {
        if (target instanceof L1MonsterInstance) {
            target.receiveDamage(attacker, damage);
        } else if (target instanceof L1NpcInstance) {
            ((L1NpcInstance) target).applyNpcHpDelta(-(long) damage);
        } else {
            target.setCurrentHp(target.getCurrentHp() - damage);
        }
    }

	public double hpget(L1PcInstance pc, L1Character cha) {
		int dmg = _random.nextInt(Config.전설피1 - Config.전설피) + Config.전설피;
		int ran = _random.nextInt(1000) + 1;

		if (pc.isKnight() || pc.isCrown() || pc.isWarrior()) {
			if (ran <= Config.잠재력흡수) {
				if (cha.getCurrentHp() < dmg) {
					dmg = cha.getCurrentHp();
					deductDrainHp(pc, cha, dmg);
					pc.setCurrentHp((int) (pc.getCurrentHp() + dmg));
				} else {

					deductDrainHp(pc, cha, dmg);
					pc.setCurrentHp((int) (pc.getCurrentHp() + dmg));
				}
			}
		}
		if (pc.isWizard()) {
			if (ran <= Config.잠재력흡수1) {
				if (cha.getCurrentHp() < dmg) {
					dmg = cha.getCurrentHp();
					deductDrainHp(pc, cha, dmg);
					pc.setCurrentHp((int) (pc.getCurrentHp() + dmg));
				} else {

					deductDrainHp(pc, cha, dmg);
					pc.setCurrentHp((int) (pc.getCurrentHp() + dmg));
				}
			}
		}
		if (pc.isBlackwizard()) {
			if (ran <= Config.잠재력흡수2) {
				if (cha.getCurrentHp() < dmg) {
					dmg = cha.getCurrentHp();
					deductDrainHp(pc, cha, dmg);
					pc.setCurrentHp((int) (pc.getCurrentHp() + dmg));
				} else {

					deductDrainHp(pc, cha, dmg);
					pc.setCurrentHp((int) (pc.getCurrentHp() + dmg));
				}
			}
		}
		if (pc.isElf()) {
			if (ran <= Config.잠재력흡수3) {
				if (cha.getCurrentHp() < dmg) {
					dmg = cha.getCurrentHp();
					deductDrainHp(pc, cha, dmg);
					pc.setCurrentHp((int) (pc.getCurrentHp() + dmg));
				} else {

					deductDrainHp(pc, cha, dmg);
					pc.setCurrentHp((int) (pc.getCurrentHp() + dmg));
				}
			}
		}
		if (pc.isDarkelf()) {
			if (ran <= Config.잠재력흡수4) {
				if (cha.getCurrentHp() < dmg) {
					dmg = cha.getCurrentHp();
					deductDrainHp(pc, cha, dmg);
					pc.setCurrentHp((int) (pc.getCurrentHp() + dmg));
				} else {

					deductDrainHp(pc, cha, dmg);
					pc.setCurrentHp((int) (pc.getCurrentHp() + dmg));
				}
			}
		}
		if (pc.isDragonknight()) {
			if (ran <= Config.잠재력흡수5) {
				if (cha.getCurrentHp() < dmg) {
					dmg = cha.getCurrentHp();
					deductDrainHp(pc, cha, dmg);
					pc.setCurrentHp((int) (pc.getCurrentHp() + dmg));
				} else {

					deductDrainHp(pc, cha, dmg);
					pc.setCurrentHp((int) (pc.getCurrentHp() + dmg));
				}
			}
		}

		return dmg;
	}

	public double managet1(L1PcInstance pc, L1Character cha) {
		int dmg = _random.nextInt(Config.전설엠피1 - Config.전설엠피) + Config.전설엠피;
		int ran = _random.nextInt(1000) + 1;

		if (pc.isKnight() || pc.isCrown() || pc.isWarrior()) {
			if (ran <= Config.잠재력흡수) {
				if (cha.getCurrentMp() < dmg) {
					dmg = cha.getCurrentMp();
					cha.setCurrentMp((int) (cha.getCurrentMp() - dmg));
					pc.setCurrentMp((int) (pc.getCurrentMp() + dmg));
				} else {

					cha.setCurrentMp((int) (cha.getCurrentMp() - dmg));
					pc.setCurrentMp((int) (pc.getCurrentMp() + dmg));

				}
			}
		}
		if (pc.isWizard()) {
			if (ran <= Config.잠재력흡수1) {
				if (cha.getCurrentMp() < dmg) {
					dmg = cha.getCurrentMp();
					cha.setCurrentMp((int) (cha.getCurrentMp() - dmg));
					pc.setCurrentMp((int) (pc.getCurrentMp() + dmg));
				} else {

					cha.setCurrentMp((int) (cha.getCurrentMp() - dmg));
					pc.setCurrentMp((int) (pc.getCurrentMp() + dmg));

				}
			}
		}
		if (pc.isBlackwizard()) {
			if (ran <= Config.잠재력흡수2) {
				if (cha.getCurrentMp() < dmg) {
					dmg = cha.getCurrentMp();
					cha.setCurrentMp((int) (cha.getCurrentMp() - dmg));
					pc.setCurrentMp((int) (pc.getCurrentMp() + dmg));
				} else {

					cha.setCurrentMp((int) (cha.getCurrentMp() - dmg));
					pc.setCurrentMp((int) (pc.getCurrentMp() + dmg));

				}
			}
		}
		if (pc.isElf()) {
			if (ran <= Config.잠재력흡수3) {
				if (cha.getCurrentMp() < dmg) {
					dmg = cha.getCurrentMp();
					cha.setCurrentMp((int) (cha.getCurrentMp() - dmg));
					pc.setCurrentMp((int) (pc.getCurrentMp() + dmg));
				} else {

					cha.setCurrentMp((int) (cha.getCurrentMp() - dmg));
					pc.setCurrentMp((int) (pc.getCurrentMp() + dmg));

				}
			}
		}
		if (pc.isDarkelf()) {
			if (ran <= Config.잠재력흡수4) {
				if (cha.getCurrentMp() < dmg) {
					dmg = cha.getCurrentMp();
					cha.setCurrentMp((int) (cha.getCurrentMp() - dmg));
					pc.setCurrentMp((int) (pc.getCurrentMp() + dmg));
				} else {

					cha.setCurrentMp((int) (cha.getCurrentMp() - dmg));
					pc.setCurrentMp((int) (pc.getCurrentMp() + dmg));

				}
			}
		}
		if (pc.isDragonknight()) {
			if (ran <= Config.잠재력흡수5) {
				if (cha.getCurrentMp() < dmg) {
					dmg = cha.getCurrentMp();
					cha.setCurrentMp((int) (cha.getCurrentMp() - dmg));
					pc.setCurrentMp((int) (pc.getCurrentMp() + dmg));
				} else {

					cha.setCurrentMp((int) (cha.getCurrentMp() - dmg));
					pc.setCurrentMp((int) (pc.getCurrentMp() + dmg));

				}
			}
		}

		return dmg;
	}

	public int 디케이포(L1PcInstance pc, L1Character cha) {
		int dmg = 0;
		int ran = _random.nextInt(1000) + 1;

		if (pc.isKnight() || pc.isCrown() || pc.isWarrior()) {
			if (ran <= Config.잠재력디케이) {
				if (cha.hasSkillEffect(L1SkillId.DECAY_POTION)) {
					cha.removeSkillEffect(L1SkillId.DECAY_POTION);
				}

				cha.setSkillEffect(L1SkillId.DECAY_POTION, 5 * 1000);
				if (pc.isInParty()) {
					for (L1PcInstance partymember : pc.getParty().getMembers()) {
						SC_SkillSound.send(partymember, cha.getId(), 2232);
					}
				} else {
					SC_SkillSound.send(pc, cha.getId(), 2232);
				}

			}
		}

		if (pc.isWizard()) {
			if (ran <= Config.잠재력디케이1) {
				if (cha.hasSkillEffect(L1SkillId.DECAY_POTION)) {
					cha.removeSkillEffect(L1SkillId.DECAY_POTION);
				}

				cha.setSkillEffect(L1SkillId.DECAY_POTION, 5 * 1000);
				if (pc.isInParty()) {
					for (L1PcInstance partymember : pc.getParty().getMembers()) {
						SC_SkillSound.send(partymember, cha.getId(), 2232);
					}
				} else {
					SC_SkillSound.send(pc, cha.getId(), 2232);
				}

			}
		}

		if (pc.isBlackwizard()) {
			if (ran <= Config.잠재력디케이2) {
				if (cha.hasSkillEffect(L1SkillId.DECAY_POTION)) {
					cha.removeSkillEffect(L1SkillId.DECAY_POTION);
				}

				cha.setSkillEffect(L1SkillId.DECAY_POTION, 5 * 1000);
				if (pc.isInParty()) {
					for (L1PcInstance partymember : pc.getParty().getMembers()) {
						SC_SkillSound.send(partymember, cha.getId(), 2232);
					}
				} else {
					SC_SkillSound.send(pc, cha.getId(), 2232);
				}

			}
		}
		if (pc.isElf()) {
			if (ran <= Config.잠재력디케이3) {
				if (cha.hasSkillEffect(L1SkillId.DECAY_POTION)) {
					cha.removeSkillEffect(L1SkillId.DECAY_POTION);
				}

				cha.setSkillEffect(L1SkillId.DECAY_POTION, 5 * 1000);
				if (pc.isInParty()) {
					for (L1PcInstance partymember : pc.getParty().getMembers()) {
						SC_SkillSound.send(partymember, cha.getId(), 2232);
					}
				} else {
					SC_SkillSound.send(pc, cha.getId(), 2232);
				}

			}
		}

		if (pc.isDarkelf()) {
			if (ran <= Config.잠재력디케이4) {
				if (cha.hasSkillEffect(L1SkillId.DECAY_POTION)) {
					cha.removeSkillEffect(L1SkillId.DECAY_POTION);
				}

				cha.setSkillEffect(L1SkillId.DECAY_POTION, 5 * 1000);
				if (pc.isInParty()) {
					for (L1PcInstance partymember : pc.getParty().getMembers()) {
						SC_SkillSound.send(partymember, cha.getId(), 2232);
					}
				} else {
					SC_SkillSound.send(pc, cha.getId(), 2232);
				}

			}
		}

		if (pc.isDragonknight()) {
			if (ran <= Config.잠재력디케이5) {
				if (cha.hasSkillEffect(L1SkillId.DECAY_POTION)) {
					cha.removeSkillEffect(L1SkillId.DECAY_POTION);
				}

				cha.setSkillEffect(L1SkillId.DECAY_POTION, 5 * 1000);
				if (pc.isInParty()) {
					for (L1PcInstance partymember : pc.getParty().getMembers()) {
						SC_SkillSound.send(partymember, cha.getId(), 2232);
					}
				} else {
					SC_SkillSound.send(pc, cha.getId(), 2232);
				}

			}
		}
		return dmg;

	}

	public int 소울오브(L1PcInstance pc, L1Character cha) {
		int dmg = 0;
		int ran = _random.nextInt(1000) + 1;
		
		if (pc.isKnight() || pc.isCrown() || pc.isWarrior()) {
			if (ran <= Config.잠재력흡수0) {
				if (pc.hasSkillEffect(L1SkillId.잠재력소울스킬)) {
					pc.removeSkillEffect(L1SkillId.잠재력소울스킬);
				}

				pc.setSkillEffect(L1SkillId.잠재력소울스킬, 8 * 1000);
				SC_SystemMessage.send(pc, "\\f4소울오브프레임(마법인형) 발동되었습니다.(지속시간 8초)");
				SC_InventoryIcon.icoNew(pc, L1SkillId.소프, 3879, 8, true);
				SC_SkillSound.send(pc, pc.getId(), 16422);
				SC_SkillSound.broadcast(pc, pc.getId(), 16422);
			}
		}
		if (pc.isWizard()) {
			if (ran <= Config.잠재력흡수00) {
				if (pc.hasSkillEffect(L1SkillId.잠재력소울스킬)) {
					pc.removeSkillEffect(L1SkillId.잠재력소울스킬);
				}

				pc.setSkillEffect(L1SkillId.잠재력소울스킬, 8 * 1000);
				SC_SystemMessage.send(pc, "\\f4소울오브프레임(마법인형) 발동되었습니다.(지속시간 8초)");
				SC_InventoryIcon.icoNew(pc, L1SkillId.소프, 3879, 8, true);
				SC_SkillSound.send(pc, pc.getId(), 16422);
				SC_SkillSound.broadcast(pc, pc.getId(), 16422);
			}
		}
		if (pc.isBlackwizard()) {
			if (ran <= Config.잠재력흡수000) {
				if (pc.hasSkillEffect(L1SkillId.잠재력소울스킬)) {
					pc.removeSkillEffect(L1SkillId.잠재력소울스킬);
				}

				pc.setSkillEffect(L1SkillId.잠재력소울스킬, 8 * 1000);
				SC_SystemMessage.send(pc, "\\f4소울오브프레임(마법인형) 발동되었습니다.(지속시간 8초)");
				SC_InventoryIcon.icoNew(pc, L1SkillId.소프, 3879, 8, true);
				SC_SkillSound.send(pc, pc.getId(), 16422);
				SC_SkillSound.broadcast(pc, pc.getId(), 16422);
			}
		}
		if (pc.isElf()) {
			if (ran <= Config.잠재력흡수0000) {
				if (pc.hasSkillEffect(L1SkillId.잠재력소울스킬)) {
					pc.removeSkillEffect(L1SkillId.잠재력소울스킬);
				}

				pc.setSkillEffect(L1SkillId.잠재력소울스킬, 8 * 1000);
				SC_SystemMessage.send(pc, "\\f4소울오브프레임(마법인형) 발동되었습니다.(지속시간 8초)");
				SC_InventoryIcon.icoNew(pc, L1SkillId.소프, 3879, 8, true);
				SC_SkillSound.send(pc, pc.getId(), 16422);
				SC_SkillSound.broadcast(pc, pc.getId(), 16422);
			}
		}
		if (pc.isDarkelf()) {
			if (ran <= Config.잠재력흡수00000) {
				if (pc.hasSkillEffect(L1SkillId.잠재력소울스킬)) {
					pc.removeSkillEffect(L1SkillId.잠재력소울스킬);
				}

				pc.setSkillEffect(L1SkillId.잠재력소울스킬, 8 * 1000);
				SC_SystemMessage.send(pc, "\\f4소울오브프레임(마법인형) 발동되었습니다.(지속시간 8초)");
				SC_InventoryIcon.icoNew(pc, L1SkillId.소프, 3879, 8, true);
				SC_SkillSound.send(pc, pc.getId(), 16422);
				SC_SkillSound.broadcast(pc, pc.getId(), 16422);
			}
		}
		if (pc.isDragonknight()) {
			if (ran <= Config.잠재력흡수000000) {
				if (pc.hasSkillEffect(L1SkillId.잠재력소울스킬)) {
					pc.removeSkillEffect(L1SkillId.잠재력소울스킬);
				}

				pc.setSkillEffect(L1SkillId.잠재력소울스킬, 8 * 1000);
				SC_SystemMessage.send(pc, "\\f4소울오브프레임(마법인형) 발동되었습니다.(지속시간 8초)");
				SC_InventoryIcon.icoNew(pc, L1SkillId.소프, 3879, 8, true);
				SC_SkillSound.send(pc, pc.getId(), 16422);
				SC_SkillSound.broadcast(pc, pc.getId(), 16422);
			}
		}

		return dmg;
	}

	public void 이뮨투함블레이드() {

		int 블레이드확률 = _random.nextInt(1000) + 1;
		int 렙차 = _pc.getLevel() - _target.getLevel();
		int 양군주 = 렙차 * Config.이뮨투함블레이드양 + Config.이뮨투함블레이드군주확률;
		int 양기사 = 렙차 * Config.이뮨투함블레이드양 + Config.이뮨투함블레이드기사확률;
		int 양요정검 = 렙차 * Config.이뮨투함블레이드양 + Config.이뮨투함블레이드요정검확률;
		int 양요정활 = 렙차 * Config.이뮨투함블레이드양 + Config.이뮨투함블레이드요정활확률;
		int 양법사 = 렙차 * Config.이뮨투함블레이드양 + Config.이뮨투함블레이드법사확률;
		int 양다엘 = 렙차 * Config.이뮨투함블레이드양 + Config.이뮨투함블레이드다엘확률;
		int 양용기사 = 렙차 * Config.이뮨투함블레이드양 + Config.이뮨투함블레이드용기사확률;
		int 양환술 = 렙차 * Config.이뮨투함블레이드양 + Config.이뮨투함블레이드환술확률;
		int 양전사 = 렙차 * Config.이뮨투함블레이드양 + Config.이뮨투함블레이드전사확률;

		int 음군주 = 렙차 * Config.이뮨투함블레이드음 + Config.이뮨투함블레이드군주확률;
		int 음기사 = 렙차 * Config.이뮨투함블레이드음 + Config.이뮨투함블레이드기사확률;
		int 음요정검 = 렙차 * Config.이뮨투함블레이드음 + Config.이뮨투함블레이드요정검확률;
		int 음요정활 = 렙차 * Config.이뮨투함블레이드음 + Config.이뮨투함블레이드요정활확률;
		int 음법사 = 렙차 * Config.이뮨투함블레이드음 + Config.이뮨투함블레이드법사확률;
		int 음다엘 = 렙차 * Config.이뮨투함블레이드음 + Config.이뮨투함블레이드다엘확률;
		int 음용기사 = 렙차 * Config.이뮨투함블레이드음 + Config.이뮨투함블레이드용기사확률;
		int 음환술 = 렙차 * Config.이뮨투함블레이드음 + Config.이뮨투함블레이드환술확률;
		int 음전사 = 렙차 * Config.이뮨투함블레이드음 + Config.이뮨투함블레이드전사확률;
		if (렙차 >= 0) {

			if (양군주 > 1000) {
				양군주 = 1000;
			}
			if (양기사 > 1000) {
				양기사 = 1000;
			}
			if (양요정활 > 1000) {
				양요정활 = 1000;
			}
			if (양요정검 > 1000) {
				양요정검 = 1000;
			}
			if (양법사 > 1000) {
				양법사 = 1000;
			}
			if (양다엘 > 1000) {
				양다엘 = 1000;
			}
			if (양용기사 > 1000) {
				양용기사 = 1000;
			}
			if (양환술 > 1000) {
				양환술 = 1000;
			}
			if (양전사 > 1000) {
				양전사 = 1000;
			}

			if (_pc.getType() == 0) {
				if (블레이드확률 <= 양군주) {

					_targetPc.removeSkillEffect(L1SkillId.IMMUNE_TO_HARM);
					_pc.removeSkillEffect(L1SkillId.이뮨투함블레이드);
					SC_SkillSound.send(_targetPc, _targetPc.getId(), 15961);
					SC_SkillSound.broadcast(_targetPc, _targetPc.getId(), 15961);
					SC_PacketBox.send(_targetPc, SC_PacketBox.GREEN_MESSAGE, "\\f:이뮨 투 함이 상대방에 의해 제거되었습니다");
					SC_PacketBox.send(_pc, SC_PacketBox.GREEN_MESSAGE, "\\f:[" + _target.getName() + "]님의 이뮨 투 함을 제거시켰습니다 (버프종료)");
				}
			}

			if (_pc.getType() == 1) {
				if (블레이드확률 <= 양기사) {

					_targetPc.removeSkillEffect(L1SkillId.IMMUNE_TO_HARM);
					_pc.removeSkillEffect(L1SkillId.이뮨투함블레이드);
					SC_SkillSound.send(_targetPc, _targetPc.getId(), 15961);
					SC_SkillSound.broadcast(_targetPc, _targetPc.getId(), 15961);
					SC_PacketBox.send(_targetPc, SC_PacketBox.GREEN_MESSAGE, "\\f:이뮨 투 함이 상대방에 의해 제거되었습니다");
					SC_PacketBox.send(_pc, SC_PacketBox.GREEN_MESSAGE, "\\f:[" + _target.getName() + "]님의 이뮨 투 함을 제거시켰습니다 (버프종료)");
				}
			}

			if (_pc.getType() == 2) {
				if (_weaponType == 20 || _weaponType == 62) {
					if (블레이드확률 <= 양요정활) {

						_targetPc.removeSkillEffect(L1SkillId.IMMUNE_TO_HARM);
						_pc.removeSkillEffect(L1SkillId.이뮨투함블레이드);
						SC_SkillSound.send(_targetPc, _targetPc.getId(), 15961);
						SC_SkillSound.broadcast(_targetPc, _targetPc.getId(), 15961);
						SC_PacketBox.send(_targetPc, SC_PacketBox.GREEN_MESSAGE, "\\f:이뮨 투 함이 상대방에 의해 제거되었습니다");
						SC_PacketBox.send(_pc, SC_PacketBox.GREEN_MESSAGE, "\\f:[" + _target.getName() + "]님의 이뮨 투 함을 제거시켰습니다 (버프종료)");

					}
				} else {
					if (블레이드확률 <= 양요정검) {

						_targetPc.removeSkillEffect(L1SkillId.IMMUNE_TO_HARM);
						_pc.removeSkillEffect(L1SkillId.이뮨투함블레이드);
						SC_SkillSound.send(_targetPc, _targetPc.getId(), 15961);
						SC_SkillSound.broadcast(_targetPc, _targetPc.getId(), 15961);
						SC_PacketBox.send(_targetPc, SC_PacketBox.GREEN_MESSAGE, "\\f:이뮨 투 함이 상대방에 의해 제거되었습니다");
						SC_PacketBox.send(_pc, SC_PacketBox.GREEN_MESSAGE, "\\f:[" + _target.getName() + "]님의 이뮨 투 함을 제거시켰습니다 (버프종료)");
					}

				}
			}
			if (_pc.getType() == 3) {
				if (블레이드확률 <= 양법사) {

					_targetPc.removeSkillEffect(L1SkillId.IMMUNE_TO_HARM);
					_pc.removeSkillEffect(L1SkillId.이뮨투함블레이드);
					SC_SkillSound.send(_targetPc, _targetPc.getId(), 15961);
					SC_SkillSound.broadcast(_targetPc, _targetPc.getId(), 15961);
					SC_PacketBox.send(_targetPc, SC_PacketBox.GREEN_MESSAGE, "\\f:이뮨 투 함이 상대방에 의해 제거되었습니다");
					SC_PacketBox.send(_pc, SC_PacketBox.GREEN_MESSAGE, "\\f:[" + _target.getName() + "]님의 이뮨 투 함을 제거시켰습니다 (버프종료)");
				}
			}
			if (_pc.getType() == 4) {
				if (블레이드확률 <= 양다엘) {

					_targetPc.removeSkillEffect(L1SkillId.IMMUNE_TO_HARM);
					_pc.removeSkillEffect(L1SkillId.이뮨투함블레이드);
					SC_SkillSound.send(_targetPc, _targetPc.getId(), 15961);
					SC_SkillSound.broadcast(_targetPc, _targetPc.getId(), 15961);
					SC_PacketBox.send(_targetPc, SC_PacketBox.GREEN_MESSAGE, "\\f:이뮨 투 함이 상대방에 의해 제거되었습니다");
					SC_PacketBox.send(_pc, SC_PacketBox.GREEN_MESSAGE, "\\f:[" + _target.getName() + "]님의 이뮨 투 함을 제거시켰습니다 (버프종료)");
				}
			}
			if (_pc.getType() == 5) {
				if (블레이드확률 <= 양용기사) {

					_targetPc.removeSkillEffect(L1SkillId.IMMUNE_TO_HARM);
					_pc.removeSkillEffect(L1SkillId.이뮨투함블레이드);
					SC_SkillSound.send(_targetPc, _targetPc.getId(), 15961);
					SC_SkillSound.broadcast(_targetPc, _targetPc.getId(), 15961);
					SC_PacketBox.send(_targetPc, SC_PacketBox.GREEN_MESSAGE, "\\f:이뮨 투 함이 상대방에 의해 제거되었습니다");
					SC_PacketBox.send(_pc, SC_PacketBox.GREEN_MESSAGE, "\\f:[" + _target.getName() + "]님의 이뮨 투 함을 제거시켰습니다 (버프종료)");
				}
			}
			if (_pc.getType() == 6) {
				if (블레이드확률 <= 양환술) {

					_targetPc.removeSkillEffect(L1SkillId.IMMUNE_TO_HARM);
					_pc.removeSkillEffect(L1SkillId.이뮨투함블레이드);
					SC_SkillSound.send(_targetPc, _targetPc.getId(), 15961);
					SC_SkillSound.broadcast(_targetPc, _targetPc.getId(), 15961);
					SC_PacketBox.send(_targetPc, SC_PacketBox.GREEN_MESSAGE, "\\f:이뮨 투 함이 상대방에 의해 제거되었습니다");
					SC_PacketBox.send(_pc, SC_PacketBox.GREEN_MESSAGE, "\\f:[" + _target.getName() + "]님의 이뮨 투 함을 제거시켰습니다 (버프종료)");
				}
			}
			if (_pc.getType() == 7) {
				if (블레이드확률 <= 양전사) {

					_targetPc.removeSkillEffect(L1SkillId.IMMUNE_TO_HARM);
					_pc.removeSkillEffect(L1SkillId.이뮨투함블레이드);
					SC_SkillSound.send(_targetPc, _targetPc.getId(), 15961);
					SC_SkillSound.broadcast(_targetPc, _targetPc.getId(), 15961);
					SC_PacketBox.send(_targetPc, SC_PacketBox.GREEN_MESSAGE, "\\f:이뮨 투 함이 상대방에 의해 제거되었습니다");
					SC_PacketBox.send(_pc, SC_PacketBox.GREEN_MESSAGE, "\\f:[" + _target.getName() + "]님의 이뮨 투 함을 제거시켰습니다 (버프종료)");
				}
			}

			if (_pc.isGm()) {
				if (_pc.getType() == 0) {
					_pc.sendPackets("확률[" + 블레이드확률 + "]   렙차[+" + 렙차 + "*" + Config.이뮨투함블레이드양 + "+군주확률 "
							+ Config.이뮨투함블레이드군주확률 + "] = 확률범위[1~" + 양군주 + "]");
				}
				if (_pc.getType() == 1) {
					_pc.sendPackets("확률[" + 블레이드확률 + "]   렙차[+" + 렙차 + "*" + Config.이뮨투함블레이드양 + "+기사확률 "
							+ Config.이뮨투함블레이드기사확률 + "] = 확률범위[1~" + 양기사 + "]");
				}
				if (_pc.getType() == 2) {
					if (_weaponType == 20 || _weaponType == 62) {
						_pc.sendPackets("확률[" + 블레이드확률 + "]   렙차[+" + 렙차 + "*" + Config.이뮨투함블레이드양 + "+요정활확률 "
								+ Config.이뮨투함블레이드요정활확률 + "] = 확률범위[1~" + 양요정활 + "]");
					} else {
						_pc.sendPackets("확률[" + 블레이드확률 + "]   렙차[+" + 렙차 + "*" + Config.이뮨투함블레이드양 + "+요정검확률 "
								+ Config.이뮨투함블레이드요정검확률 + "] = 확률범위[1~" + 양요정검 + "]");

					}
				}

				if (_pc.getType() == 3) {
					_pc.sendPackets("확률[" + 블레이드확률 + "]   렙차[+" + 렙차 + "*" + Config.이뮨투함블레이드양 + "+법사확률 "
							+ Config.이뮨투함블레이드법사확률 + "] = 확률범위[1~" + 양법사 + "]");
				}

				if (_pc.getType() == 4) {
					_pc.sendPackets("확률[" + 블레이드확률 + "]   렙차[+" + 렙차 + "*" + Config.이뮨투함블레이드양 + "+다엘확률 "
							+ Config.이뮨투함블레이드다엘확률 + "] = 확률범위[1~" + 양다엘 + "]");
				}

				if (_pc.getType() == 5) {
					_pc.sendPackets("확률[" + 블레이드확률 + "]   렙차[+" + 렙차 + "*" + Config.이뮨투함블레이드양 + "+용기사확률 "
							+ Config.이뮨투함블레이드용기사확률 + "] = 확률범위[1~" + 양용기사 + "]");
				}
				if (_pc.getType() == 6) {
					_pc.sendPackets("확률[" + 블레이드확률 + "]   렙차[+" + 렙차 + "*" + Config.이뮨투함블레이드양 + "+환술확률 "
							+ Config.이뮨투함블레이드환술확률 + "] = 확률범위[1~" + 양환술 + "]");
				}
				if (_pc.getType() == 7) {
					_pc.sendPackets("확률[" + 블레이드확률 + "]   렙차[+" + 렙차 + "*" + Config.이뮨투함블레이드양 + "+전사확률 "
							+ Config.이뮨투함블레이드전사확률 + "] = 확률범위[1~" + 양전사 + "]");
				}
			}

		} else {

			if (음군주 < 10) {
				음군주 = 10;
			}
			if (음기사 < 10) {
				음기사 = 10;
			}
			if (음요정활 < 10) {
				음요정활 = 10;
			}
			if (음요정검 < 10) {
				음요정검 = 10;
			}
			if (음법사 < 10) {
				음법사 = 10;
			}
			if (음다엘 < 10) {
				음다엘 = 10;
			}
			if (음용기사 < 10) {
				음용기사 = 10;
			}
			if (음환술 < 10) {
				음환술 = 10;
			}
			if (음전사 < 10) {
				음전사 = 10;
			}

			if (_pc.getType() == 0) {
				if (블레이드확률 <= 음군주) {

					_targetPc.removeSkillEffect(L1SkillId.IMMUNE_TO_HARM);
					_pc.removeSkillEffect(L1SkillId.이뮨투함블레이드);
					SC_SkillSound.send(_targetPc, _targetPc.getId(), 15961);
					SC_SkillSound.broadcast(_targetPc, _targetPc.getId(), 15961);
					SC_PacketBox.send(_targetPc, SC_PacketBox.GREEN_MESSAGE, "\\f:이뮨 투 함이 상대방에 의해 제거되었습니다");
					SC_PacketBox.send(_pc, SC_PacketBox.GREEN_MESSAGE, "\\f:[" + _target.getName() + "]님의 이뮨 투 함을 제거시켰습니다 (버프종료)");
				}
			}

			if (_pc.getType() == 1) {
				if (블레이드확률 <= 음기사) {

					_targetPc.removeSkillEffect(L1SkillId.IMMUNE_TO_HARM);
					_pc.removeSkillEffect(L1SkillId.이뮨투함블레이드);
					SC_SkillSound.send(_targetPc, _targetPc.getId(), 15961);
					SC_SkillSound.broadcast(_targetPc, _targetPc.getId(), 15961);
					SC_PacketBox.send(_targetPc, SC_PacketBox.GREEN_MESSAGE, "\\f:이뮨 투 함이 상대방에 의해 제거되었습니다");
					SC_PacketBox.send(_pc, SC_PacketBox.GREEN_MESSAGE, "\\f:[" + _target.getName() + "]님의 이뮨 투 함을 제거시켰습니다 (버프종료)");
				}
			}

			if (_pc.getType() == 2) {
				if (_weaponType == 20 || _weaponType == 62) {
					if (블레이드확률 <= 음요정활) {

						_targetPc.removeSkillEffect(L1SkillId.IMMUNE_TO_HARM);
						_pc.removeSkillEffect(L1SkillId.이뮨투함블레이드);
						SC_SkillSound.send(_targetPc, _targetPc.getId(), 15961);
						SC_SkillSound.broadcast(_targetPc, _targetPc.getId(), 15961);
						SC_PacketBox.send(_targetPc, SC_PacketBox.GREEN_MESSAGE, "\\f:이뮨 투 함이 상대방에 의해 제거되었습니다");
						SC_PacketBox.send(_pc, SC_PacketBox.GREEN_MESSAGE, "\\f:[" + _target.getName() + "]님의 이뮨 투 함을 제거시켰습니다 (버프종료)");
					}
				} else {
					if (블레이드확률 <= 음요정검) {

						_targetPc.removeSkillEffect(L1SkillId.IMMUNE_TO_HARM);
						_pc.removeSkillEffect(L1SkillId.이뮨투함블레이드);
						SC_SkillSound.send(_targetPc, _targetPc.getId(), 15961);
						SC_SkillSound.broadcast(_targetPc, _targetPc.getId(), 15961);
						SC_PacketBox.send(_targetPc, SC_PacketBox.GREEN_MESSAGE, "\\f:이뮨 투 함이 상대방에 의해 제거되었습니다");
						SC_PacketBox.send(_pc, SC_PacketBox.GREEN_MESSAGE, "\\f:[" + _target.getName() + "]님의 이뮨 투 함을 제거시켰습니다 (버프종료)");
					}
				}
			}
			if (_pc.getType() == 3) {
				if (블레이드확률 <= 음법사) {

					_targetPc.removeSkillEffect(L1SkillId.IMMUNE_TO_HARM);
					_pc.removeSkillEffect(L1SkillId.이뮨투함블레이드);
					SC_SkillSound.send(_targetPc, _targetPc.getId(), 15961);
					SC_SkillSound.broadcast(_targetPc, _targetPc.getId(), 15961);
					SC_PacketBox.send(_targetPc, SC_PacketBox.GREEN_MESSAGE, "\\f:이뮨 투 함이 상대방에 의해 제거되었습니다");
					SC_PacketBox.send(_pc, SC_PacketBox.GREEN_MESSAGE, "\\f:[" + _target.getName() + "]님의 이뮨 투 함을 제거시켰습니다 (버프종료)");
				}
			}
			if (_pc.getType() == 4) {
				if (블레이드확률 <= 음다엘) {

					_targetPc.removeSkillEffect(L1SkillId.IMMUNE_TO_HARM);
					_pc.removeSkillEffect(L1SkillId.이뮨투함블레이드);
					SC_SkillSound.send(_targetPc, _targetPc.getId(), 15961);
					SC_SkillSound.broadcast(_targetPc, _targetPc.getId(), 15961);
					SC_PacketBox.send(_targetPc, SC_PacketBox.GREEN_MESSAGE, "\\f:이뮨 투 함이 상대방에 의해 제거되었습니다");
					SC_PacketBox.send(_pc, SC_PacketBox.GREEN_MESSAGE, "\\f:[" + _target.getName() + "]님의 이뮨 투 함을 제거시켰습니다 (버프종료)");
				}
			}
			if (_pc.getType() == 5) {
				if (블레이드확률 <= 음용기사) {

					_targetPc.removeSkillEffect(L1SkillId.IMMUNE_TO_HARM);
					_pc.removeSkillEffect(L1SkillId.이뮨투함블레이드);
					SC_SkillSound.send(_targetPc, _targetPc.getId(), 15961);
					SC_SkillSound.broadcast(_targetPc, _targetPc.getId(), 15961);
					SC_PacketBox.send(_targetPc, SC_PacketBox.GREEN_MESSAGE, "\\f:이뮨 투 함이 상대방에 의해 제거되었습니다");
					SC_PacketBox.send(_pc, SC_PacketBox.GREEN_MESSAGE, "\\f:[" + _target.getName() + "]님의 이뮨 투 함을 제거시켰습니다 (버프종료)");
				}
			}
			if (_pc.getType() == 6) {
				if (블레이드확률 <= 음환술) {

					_targetPc.removeSkillEffect(L1SkillId.IMMUNE_TO_HARM);
					_pc.removeSkillEffect(L1SkillId.이뮨투함블레이드);
					SC_SkillSound.send(_targetPc, _targetPc.getId(), 15961);
					SC_SkillSound.broadcast(_targetPc, _targetPc.getId(), 15961);
					SC_PacketBox.send(_targetPc, SC_PacketBox.GREEN_MESSAGE, "\\f:이뮨 투 함이 상대방에 의해 제거되었습니다");
					SC_PacketBox.send(_pc, SC_PacketBox.GREEN_MESSAGE, "\\f:[" + _target.getName() + "]님의 이뮨 투 함을 제거시켰습니다 (버프종료)");
				}
			}
			if (_pc.getType() == 7) {
				if (블레이드확률 <= 음전사) {

					_targetPc.removeSkillEffect(L1SkillId.IMMUNE_TO_HARM);
					_pc.removeSkillEffect(L1SkillId.이뮨투함블레이드);
					SC_SkillSound.send(_targetPc, _targetPc.getId(), 15961);
					SC_SkillSound.broadcast(_targetPc, _targetPc.getId(), 15961);
					SC_PacketBox.send(_targetPc, SC_PacketBox.GREEN_MESSAGE, "\\f:이뮨 투 함이 상대방에 의해 제거되었습니다");
					SC_PacketBox.send(_pc, SC_PacketBox.GREEN_MESSAGE, "\\f:[" + _target.getName() + "]님의 이뮨 투 함을 제거시켰습니다 (버프종료)");
				}
			}

			if (_pc.isGm()) {
				if (_pc.getType() == 0) {
					_pc.sendPackets("확률[" + 블레이드확률 + "]   렙차[+" + 렙차 + "*" + Config.이뮨투함블레이드음 + "+군주확률 "
							+ Config.이뮨투함블레이드군주확률 + "] = 확률범위[1~" + 음군주 + "]");
				}
				if (_pc.getType() == 1) {
					_pc.sendPackets("확률[" + 블레이드확률 + "]   렙차[+" + 렙차 + "*" + Config.이뮨투함블레이드음 + "+기사확률 "
							+ Config.이뮨투함블레이드기사확률 + "] = 확률범위[1~" + 음기사 + "]");
				}
				if (_pc.getType() == 2) {
					if (_weaponType == 20 || _weaponType == 62) {
						_pc.sendPackets("확률[" + 블레이드확률 + "]   렙차[-" + 렙차 + "*" + Config.이뮨투함블레이드음 + "+요정활확률 "
								+ Config.이뮨투함블레이드요정활확률 + "] = 확률범위[1~" + 음요정활 + "]");
					} else {
						_pc.sendPackets("확률[" + 블레이드확률 + "]   렙차[-" + 렙차 + "*" + Config.이뮨투함블레이드음 + "+요정검확률 "
								+ Config.이뮨투함블레이드요정검확률 + "] = 확률범위[1~" + 음요정검 + "]");

					}
				}

				if (_pc.getType() == 3) {
					_pc.sendPackets("확률[" + 블레이드확률 + "]   렙차[-" + 렙차 + "*" + Config.이뮨투함블레이드음 + "+법사확률 "
							+ Config.이뮨투함블레이드법사확률 + "] = 확률범위[1~" + 음법사 + "]");
				}

				if (_pc.getType() == 4) {
					_pc.sendPackets("확률[" + 블레이드확률 + "]   렙차[-" + 렙차 + "*" + Config.이뮨투함블레이드음 + "+다엘확률 "
							+ Config.이뮨투함블레이드다엘확률 + "] = 확률범위[1~" + 음다엘 + "]");
				}

				if (_pc.getType() == 5) {
					_pc.sendPackets("확률[" + 블레이드확률 + "]   렙차[-" + 렙차 + "*" + Config.이뮨투함블레이드음 + "+용기사확률 "
							+ Config.이뮨투함블레이드용기사확률 + "] = 확률범위[1~" + 음용기사 + "]");
				}
				if (_pc.getType() == 6) {
					_pc.sendPackets("확률[" + 블레이드확률 + "]   렙차[-" + 렙차 + "*" + Config.이뮨투함블레이드음 + "+환술확률 "
							+ Config.이뮨투함블레이드환술확률 + "] = 확률범위[1~" + 음환술 + "]");
				}
				if (_pc.getType() == 7) {
					_pc.sendPackets("확률[" + 블레이드확률 + "]   렙차[-" + 렙차 + "*" + Config.이뮨투함블레이드음 + "+전사확률 "
							+ Config.이뮨투함블레이드전사확률 + "] = 확률범위[1~" + 음전사 + "]");
				}
			}

		}

	}

	public int 저지먼트(L1PcInstance pc, L1Character cha) {
		int dmg = 0;
		int ran = _random.nextInt(1000) + 1;

		if (pc.isKnight() || pc.isCrown()) {
			if (ran <= Config.잠재력저지먼트) {
				if (cha.hasSkillEffect(L1SkillId.잠재력저지먼트1) || cha.hasSkillEffect(L1SkillId.잠재력저지먼트2)
						|| cha.hasSkillEffect(L1SkillId.잠재력저지먼트3) || cha.hasSkillEffect(L1SkillId.잠재력저지먼트4)
						|| cha.hasSkillEffect(L1SkillId.잠재력저지먼트5)) {
					cha.removeSkillEffect(L1SkillId.잠재력저지먼트1);
					cha.removeSkillEffect(L1SkillId.잠재력저지먼트2);
					cha.removeSkillEffect(L1SkillId.잠재력저지먼트3);
					cha.removeSkillEffect(L1SkillId.잠재력저지먼트4);
					cha.removeSkillEffect(L1SkillId.잠재력저지먼트5);
				}

				L1PcInstance targetPc = (L1PcInstance) cha;
				targetPc.setSkillEffect(L1SkillId.잠재력저지먼트1, 8 * 1000);
				targetPc.저지먼트1();

				SC_SystemMessage.send(pc, "\\f4저지먼트 발동: 상대 기술내성 -15 (지속시간 8초)");
				SC_SystemMessage.send(targetPc, "\\f4저지먼트 발동: 기술내성 -15 (지속시간 8초)");
				// targetPc.sendPackets(new S_SkillSound(targetPc.getId(), 4630));
				// Broadcaster.broadcastPacket(targetPc, new S_SkillSound(targetPc.getId(),
				// 4630));
				SC_SkillSound.send(targetPc, targetPc.getId(), 16018);
				SC_SkillSound.broadcast(targetPc, targetPc.getId(), 16018);
			}
		}
		if (pc.isElf()) {
			if (ran <= Config.잠재력저지먼트3) {
				if (cha.hasSkillEffect(L1SkillId.잠재력저지먼트1) || cha.hasSkillEffect(L1SkillId.잠재력저지먼트2)
						|| cha.hasSkillEffect(L1SkillId.잠재력저지먼트3) || cha.hasSkillEffect(L1SkillId.잠재력저지먼트4)
						|| cha.hasSkillEffect(L1SkillId.잠재력저지먼트5)) {
					cha.removeSkillEffect(L1SkillId.잠재력저지먼트1);
					cha.removeSkillEffect(L1SkillId.잠재력저지먼트2);
					cha.removeSkillEffect(L1SkillId.잠재력저지먼트3);
					cha.removeSkillEffect(L1SkillId.잠재력저지먼트4);
					cha.removeSkillEffect(L1SkillId.잠재력저지먼트5);
				}
				L1PcInstance targetPc = (L1PcInstance) cha;
				targetPc.setSkillEffect(L1SkillId.잠재력저지먼트2, 8 * 1000);
				targetPc.저지먼트2();

				SC_SystemMessage.send(pc, "\\f4저지먼트 발동: 상대 정령내성 -15 (지속시간 8초)");
				SC_SystemMessage.send(targetPc, "\\f4저지먼트 발동: 정령내성 -15 (지속시간 8초)");

				// targetPc.sendPackets(new S_SkillSound(targetPc.getId(), 4630));
				// Broadcaster.broadcastPacket(targetPc, new S_SkillSound(targetPc.getId(),
				// 4630));
				SC_SkillSound.send(targetPc, targetPc.getId(), 16018);
				SC_SkillSound.broadcast(targetPc, targetPc.getId(), 16018);
			}
		}
		if (pc.isDarkelf()) {
			if (ran <= Config.잠재력저지먼트4) {
				if (cha.hasSkillEffect(L1SkillId.잠재력저지먼트1) || cha.hasSkillEffect(L1SkillId.잠재력저지먼트2)
						|| cha.hasSkillEffect(L1SkillId.잠재력저지먼트3) || cha.hasSkillEffect(L1SkillId.잠재력저지먼트4)
						|| cha.hasSkillEffect(L1SkillId.잠재력저지먼트5)) {
					cha.removeSkillEffect(L1SkillId.잠재력저지먼트1);
					cha.removeSkillEffect(L1SkillId.잠재력저지먼트2);
					cha.removeSkillEffect(L1SkillId.잠재력저지먼트3);
					cha.removeSkillEffect(L1SkillId.잠재력저지먼트4);
					cha.removeSkillEffect(L1SkillId.잠재력저지먼트5);
				}
				L1PcInstance targetPc = (L1PcInstance) cha;
				targetPc.setSkillEffect(L1SkillId.잠재력저지먼트2, 8 * 1000);
				targetPc.저지먼트2();

				SC_SystemMessage.send(pc, "\\f4저지먼트 발동: 상대 정령내성 -15 (지속시간 8초)");
				SC_SystemMessage.send(targetPc, "\\f4저지먼트 발동: 정령내성 -15 (지속시간 8초)");

				// targetPc.sendPackets(new S_SkillSound(targetPc.getId(), 4630));
				// Broadcaster.broadcastPacket(targetPc, new S_SkillSound(targetPc.getId(),
				// 4630));
				SC_SkillSound.send(targetPc, targetPc.getId(), 16018);
				SC_SkillSound.broadcast(targetPc, targetPc.getId(), 16018);
			}
		}
		if (pc.isBlackwizard()) {
			if (ran <= Config.잠재력저지먼트2) {
				if (cha.hasSkillEffect(L1SkillId.잠재력저지먼트1) || cha.hasSkillEffect(L1SkillId.잠재력저지먼트2)
						|| cha.hasSkillEffect(L1SkillId.잠재력저지먼트3) || cha.hasSkillEffect(L1SkillId.잠재력저지먼트4)
						|| cha.hasSkillEffect(L1SkillId.잠재력저지먼트5)) {
					cha.removeSkillEffect(L1SkillId.잠재력저지먼트1);
					cha.removeSkillEffect(L1SkillId.잠재력저지먼트2);
					cha.removeSkillEffect(L1SkillId.잠재력저지먼트3);
					cha.removeSkillEffect(L1SkillId.잠재력저지먼트4);
					cha.removeSkillEffect(L1SkillId.잠재력저지먼트5);
				}
				L1PcInstance targetPc = (L1PcInstance) cha;
				targetPc.setSkillEffect(L1SkillId.잠재력저지먼트3, 8 * 1000);
				targetPc.저지먼트3();

				SC_SystemMessage.send(pc, "\\f4저지먼트 발동: 상대 용언내성 -15 (지속시간 8초)");
				SC_SystemMessage.send(targetPc, "\\f4저지먼트 발동: 용언내성 -15 (지속시간 8초)");
				// targetPc.sendPackets(new S_SkillSound(targetPc.getId(), 4630));
				// Broadcaster.broadcastPacket(targetPc, new S_SkillSound(targetPc.getId(),
				// 4630));
				SC_SkillSound.send(targetPc, targetPc.getId(), 16018);
				SC_SkillSound.broadcast(targetPc, targetPc.getId(), 16018);
			}
		}
		if (pc.isDragonknight()) {
			if (ran <= Config.잠재력저지먼트5) {
				if (cha.hasSkillEffect(L1SkillId.잠재력저지먼트1) || cha.hasSkillEffect(L1SkillId.잠재력저지먼트2)
						|| cha.hasSkillEffect(L1SkillId.잠재력저지먼트3) || cha.hasSkillEffect(L1SkillId.잠재력저지먼트4)
						|| cha.hasSkillEffect(L1SkillId.잠재력저지먼트5)) {
					cha.removeSkillEffect(L1SkillId.잠재력저지먼트1);
					cha.removeSkillEffect(L1SkillId.잠재력저지먼트2);
					cha.removeSkillEffect(L1SkillId.잠재력저지먼트3);
					cha.removeSkillEffect(L1SkillId.잠재력저지먼트4);
					cha.removeSkillEffect(L1SkillId.잠재력저지먼트5);
				}
				L1PcInstance targetPc = (L1PcInstance) cha;
				targetPc.setSkillEffect(L1SkillId.잠재력저지먼트3, 8 * 1000);
				targetPc.저지먼트3();

				SC_SystemMessage.send(pc, "\\f4저지먼트 발동: 상대 용언내성 -15 (지속시간 8초)");
				SC_SystemMessage.send(targetPc, "\\f4저지먼트 발동: 용언내성 -15 (지속시간 8초)");
				// targetPc.sendPackets(new S_SkillSound(targetPc.getId(), 4630));
				// Broadcaster.broadcastPacket(targetPc, new S_SkillSound(targetPc.getId(),
				// 4630));
				SC_SkillSound.send(targetPc, targetPc.getId(), 16018);
				SC_SkillSound.broadcast(targetPc, targetPc.getId(), 16018);
			}
		}
		if (pc.isWarrior()) {
			if (ran <= Config.잠재력저지먼트) {
				if (cha.hasSkillEffect(L1SkillId.잠재력저지먼트1) || cha.hasSkillEffect(L1SkillId.잠재력저지먼트2)
						|| cha.hasSkillEffect(L1SkillId.잠재력저지먼트3) || cha.hasSkillEffect(L1SkillId.잠재력저지먼트4)
						|| cha.hasSkillEffect(L1SkillId.잠재력저지먼트5)) {
					cha.removeSkillEffect(L1SkillId.잠재력저지먼트1);
					cha.removeSkillEffect(L1SkillId.잠재력저지먼트2);
					cha.removeSkillEffect(L1SkillId.잠재력저지먼트3);
					cha.removeSkillEffect(L1SkillId.잠재력저지먼트4);
					cha.removeSkillEffect(L1SkillId.잠재력저지먼트5);
				}
				L1PcInstance targetPc = (L1PcInstance) cha;
				targetPc.setSkillEffect(L1SkillId.잠재력저지먼트4, 8 * 1000);
				targetPc.저지먼트4();

				SC_SystemMessage.send(pc, "\\f4저지먼트 발동: 상대 공포내성 -15 (지속시간 8초)");
				SC_SystemMessage.send(targetPc, "\\f4저지먼트 발동: 공포내성 -15 (지속시간 8초)");
				// targetPc.sendPackets(new S_SkillSound(targetPc.getId(), 4630));
				// Broadcaster.broadcastPacket(targetPc, new S_SkillSound(targetPc.getId(),
				// 4630));
				SC_SkillSound.send(targetPc, targetPc.getId(), 16018);
				SC_SkillSound.broadcast(targetPc, targetPc.getId(), 16018);
			}
		}
		if (pc.isWizard()) {
			if (ran <= Config.잠재력저지먼트1) {
				if (cha.hasSkillEffect(L1SkillId.잠재력저지먼트1) || cha.hasSkillEffect(L1SkillId.잠재력저지먼트2)
						|| cha.hasSkillEffect(L1SkillId.잠재력저지먼트3) || cha.hasSkillEffect(L1SkillId.잠재력저지먼트4)
						|| cha.hasSkillEffect(L1SkillId.잠재력저지먼트5)) {
					cha.removeSkillEffect(L1SkillId.잠재력저지먼트1);
					cha.removeSkillEffect(L1SkillId.잠재력저지먼트2);
					cha.removeSkillEffect(L1SkillId.잠재력저지먼트3);
					cha.removeSkillEffect(L1SkillId.잠재력저지먼트4);
					cha.removeSkillEffect(L1SkillId.잠재력저지먼트5);
				}
				L1PcInstance targetPc = (L1PcInstance) cha;
				targetPc.setSkillEffect(L1SkillId.잠재력저지먼트5, 8 * 1000);
				targetPc.저지먼트5();

				SC_SystemMessage.send(pc, "\\f4저지먼트 발동: 상대 MR -15 (지속시간 8초)");
				SC_SystemMessage.send(targetPc, "\\f4저지먼트 발동: MR -15 (지속시간 8초)");
				// targetPc.sendPackets(new S_SkillSound(targetPc.getId(), 4630));
				// Broadcaster.broadcastPacket(targetPc, new S_SkillSound(targetPc.getId(),
				// 4630));
				SC_SkillSound.send(targetPc, targetPc.getId(), 16018);
				SC_SkillSound.broadcast(targetPc, targetPc.getId(), 16018);
			}
		}

		return dmg;
	}

	public int getitemlevel(L1PcInstance pc, L1Character cha) {
		int damage = 0;

		if (cha.getResistance().getcalcPcDefense() > 0 && cha.getResistance().getcalcPcDefense() <= 10) {
			damage = cha.getResistance().getcalcPcDefense();
		} else if (cha.getResistance().getcalcPcDefense() > 10) {
			damage = 10;

		}

		return damage;
	}

	public int getitemlevel1(L1PcInstance pc, L1Character cha) {
		int damage = 0;

		if (cha.getResistance().getcalcPcDefense() > 0 && cha.getResistance().getcalcPcDefense() <= Config.인형PVP감소수치) {
			damage = cha.getResistance().getcalcPcDefense();
		} else if (cha.getResistance().getcalcPcDefense() > Config.인형PVP감소수치) {
			damage = Config.인형PVP감소수치;

		}

		return damage;
	}

	/** 대상 Buff에 따른 대미지 연산 **/
	private double toPcBuffDmg(double dmg) {
		try {
	
			// 전사스킬 : 아머가드 - 캐릭의 AC/10의 데미지감소 효과를 얻는다.
			if (_targetPc.getPassive(MJPassiveID.ARMOR_GUARD.toInt()) != null) {
				dmg -= _targetPc.getAC().getAc() / 10;
			}

			if (_targetPc.hasSkillEffect(L1SkillId.REDUCTION_ARMOR)) {
				int targetPcLvl = _targetPc.getLevel();
				int 리덕션 = (targetPcLvl - 50) / 5 + 1;

				if (_targetPc.hasSkillEffect(L1SkillId.리덕션베테랑)) {
					if (_targetPc.getLevel() >= 80 && _targetPc.getLevel() <= 84) {
						dmg -= 리덕션 + 1;
					} else if (_targetPc.getLevel() >= 85 && _targetPc.getLevel() <= 88) {
						dmg -= 리덕션 + 2;
					} else if (_targetPc.getLevel() >= 89 && _targetPc.getLevel() <= 92) {
						dmg -= 리덕션 + 3;
					} else if (_targetPc.getLevel() >= 93 && _targetPc.getLevel() <= 96) {
						dmg -= 리덕션 + 4;
					} else if (_targetPc.getLevel() >= 97) {
						dmg -= 리덕션 + 5;
					}

				} else {

					if (targetPcLvl < 50) {
						targetPcLvl = 50;
					}
					dmg -= 리덕션;
				}
			}

			if (_targetPc.hasSkillEffect(L1SkillId.MAJESTY) || _targetPc.hasSkillEffect(L1SkillId.마제스티)) {
				int targetPcLvl = _targetPc.getLevel();
				if (targetPcLvl < 50) {
					targetPcLvl = 50;
				}
				int r = (targetPcLvl - 50) / 5 + 1;
				dmg -= r;
				/*
				 * 원본 (lvl - 60) / 2 + 1;
				 */
			}
			if (_targetPc != null && _targetPc.getAccount().getTree_select4() != 0) {
				int a = _targetPc.getAccount().getTree_select4();
				int r = _random.nextInt(100) + 1;
				if (r <= 2) {
					switch (a) {
					case 20796:
						dmg -= dmg / 20;
						break;
					case 19052:
						dmg -= dmg / 10;
						break;
					case 19055:
						dmg -= dmg / 5;
						break;
					}
					if (_targetPc.getLinMeff() != 2) {
						SC_SkillSound.send(_targetPc, _targetPc.getId(), a);
					}
					SC_SkillSound.broadcastM(_targetPc, _targetPc.getId(), a);
				}
			}
			if (_targetPc.hasSkillEffect(L1SkillId.DRAGON_SKIN)) {
				if (_targetPc.getLevel() >= 60) {
					int dsdam = ((_targetPc.getLevel() - 58) / 2);
					if (dsdam >= 5) {
						dsdam = 5;
					}
					dmg -= 5 + dsdam;
				} else {
					dmg -= 5;
				}
			}

			
			if (_targetPc.hasSkillEffect(L1SkillId.ABSOLUTE_BARRIER)) {
				dmg = 0;
			}
			if (_targetPc.hasSkillEffect(L1SkillId.ICE_LANCE)) {
				dmg = 0;
			}
			if (_targetPc.hasSkillEffect(L1SkillId.EARTH_BIND)) {
				dmg = 0;
			}
			if (_targetPc.hasSkillEffect(L1SkillId.PHANTASM)) {
				_targetPc.removeSkillEffect(L1SkillId.PHANTASM);
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		return dmg;
	}

	/** 특수 인챈트 시스템 **/
	public static double WeaponLevelAttack(L1PcInstance pc, L1Character cha, int effect, int enchant, int weaponlevel) {
		double dmg = 0;
		int locx = cha.getX();
		int locy = cha.getY();
		int Stat = 0;
		int chance = _random.nextInt(100) + 1;
		int enchatndmg = 0;

		if (pc.isWizard() || pc.isBlackwizard()) {
			Stat = pc.getAbility().getTotalInt();
		}
		if (pc.isElf()) {
			Stat = pc.getAbility().getTotalDex();
		} else {
			Stat = pc.getAbility().getTotalStr();
		}

		if (weaponlevel == 1) {
			enchatndmg = Config.Weapon_Enchant_Dmg_lvl1 + Stat;
		} else if (weaponlevel == 2) {
			enchatndmg = Config.Weapon_Enchant_Dmg_lvl2 + Stat;
		} else if (weaponlevel == 3) {
			enchatndmg = Config.Weapon_Enchant_Dmg_lvl3 + Stat;
		} else if (weaponlevel == 4) {
			enchatndmg = Config.Weapon_Enchant_Dmg_lvl4 + Stat;
		}

		if (Config.Weapon_Magic_Per + enchant + weaponlevel >= chance) {// 찬스
			dmg = _random.nextInt(enchatndmg) + 1;
			if (2 >= chance) {// 이펙트 랜타 찬스
				dmg += dmg * 0.1;// 대미지
			} else if (dmg <= 0) {
				dmg = 0;
			}
			SC_SkillSound.sendAndBroadcast(cha, cha.getId(), effect);
			/*
			 * S_EffectLocation packet = new S_EffectLocation(locx, locy, effect);
			 * pc.sendPackets(packet, false); pc.broadcastPacket(packet);
			 */
		}
		return calcDamageReduction(cha, dmg, L1Skills.ATTR_WIND);
	}

	public static double calcDamageReduction(L1Character cha, double dmg, int attr) {
		if (isFreeze(cha)) {
			return 0;
		}

		int ran1 = 0; // 랜덤 수치 적용
		int mrset = 0; // 엠알에서 랜덤 수치를 뺀값
		int mrs = cha.getResistance().getEffectedMrBySkill();
		ran1 = _random.nextInt(5) + 1;
		mrset = mrs - ran1;
		double calMr = 0.00D;
		calMr = (220 - mrset) / 250.00D;
		dmg *= calMr;

		if (dmg < 0) {
			dmg = 0;
		}

		int resist = 0;
		if (attr == L1Skills.ATTR_EARTH) {
			resist = cha.getResistance().getEarth();
		} else if (attr == L1Skills.ATTR_FIRE) {
			resist = cha.getResistance().getFire();
		} else if (attr == L1Skills.ATTR_WATER) {
			resist = cha.getResistance().getWater();
		} else if (attr == L1Skills.ATTR_WIND) {
			resist = cha.getResistance().getWind();
		}
		int resistFloor = (int) (0.32 * Math.abs(resist));
		if (resist >= 0) {
			resistFloor *= 1;
		} else {
			resistFloor *= -1;
		}
		double attrDeffence = resistFloor / 32.0;
		dmg = (1.0 - attrDeffence) * dmg;

		return dmg;
	}

	private static boolean isFreeze(L1Character cha) {

		if (cha.hasSkillEffect(L1SkillId.STATUS_FREEZE)) {
			return true;
		}
		if (cha.hasSkillEffect(L1SkillId.ABSOLUTE_BARRIER)) {
			return true;
		}
		if (cha.hasSkillEffect(L1SkillId.ICE_LANCE)) {
			return true;
		}
		if (cha.hasSkillEffect(L1SkillId.EARTH_BIND)) {
			return true;
		}

		if (cha.hasSkillEffect(L1SkillId.COUNTER_MAGIC)) {
			cha.removeSkillEffect(L1SkillId.COUNTER_MAGIC);
			int castgfx = SkillsTable.getInstance().getTemplate(L1SkillId.COUNTER_MAGIC).getCastGfx();
			SC_SkillSound.broadcast(cha, cha.getId(), castgfx);
			if (cha instanceof L1PcInstance) {
				L1PcInstance pc = (L1PcInstance) cha;
				SC_SkillSound.send(pc, pc.getId(), castgfx);
			}
			return true;
		}
		return false;
	}

	protected static void broadcast(L1Character c, ServerPacket pck) {
		c.sendPackets(pck, false);
		c.broadcastPacket(pck);
	}

	public void set_hit_rate(int rate) {
		_hitRate = rate;
	}

	public void set_hit(boolean hit) {
		_isHit = hit;
	}

	public void set_is_critical(boolean is_critical) {
		_isCritical = is_critical;
	}
	
	/**
	 * 요정 인페르노 이펙트 및 모션 실행
	 */
	public void actionInferno(int step) {
	    // step 1: 17561, 2: 17563, 3: 17565, 4: 17567
	    int[] gfxIds = { 0, 17561, 17563, 17565, 17567 };
	    if (step < 1 || step >= gfxIds.length) return;
	    int gfxId = gfxIds[step];

	    if (_calcType == PC_PC || _calcType == PC_NPC) {
	        // 공격자(PC) 처리
	        _pc.setHeading(_pc.targetDirection(_targetX, _targetY));
	        
	        // 패킷 송신 통합 (나와 주변에 보냄)
	        long skillSound = SC_SkillSound.pack(_targetId, gfxId);

	        SC_AttackMissPacket.send(_pc.getNetConnection(), _pc, _targetId);
	        SC_AttackMissPacket.broadcast(_pc, _targetId);
	        
	        SC_DoActionGFX.send(
	                _pc.getNetConnection(),
	                _pc.getId(),
	                ActionCodes.ACTION_Damage);
	        SC_DoActionGFX.broadcast(
	                _pc,
	                ActionCodes.ACTION_Damage);
	        
	        SC_SkillSound.sendPacked(_pc, skillSound);
	        SC_SkillSound.broadcastFastPacked(_pc, skillSound);

	    } else if (_calcType == NPC_PC) {
	        // 공격자(NPC) 처리
	        _npc.setHeading(_npc.targetDirection(_targetX, _targetY));
	        
	        int actId = (getActId() > 0) ? getActId() : ActionCodes.ACTION_Attack;
	        
	        if (getGfxId() > 0) {
	            SC_UseAttackSkill.broadcast(_npc, _target, _npc.getId(), getGfxId(), _targetX, _targetY, actId, 0);
	        } else {
	            SC_AttackMissPacket.broadcast(_npc, _targetId, actId);
	        }
	        
	        SC_DoActionGFX.broadcast(_npc, ActionCodes.ACTION_Damage);
	        SC_SkillSound.broadcastFast(_npc, _targetId, gfxId);
	    }
	}

	/**
	 * 요정 인페르노 대미지 적용
	 */
	public void commitInferno(int step) {
		int damage = calcInfernoDamage(step);
		
		if (damage <= 0) return;

		// 공격 타입에 따른 대상 대미지 전달
		switch (_calcType) {
		case PC_PC:  _pc.receiveDamage(_targetPc, damage); break;
		case PC_NPC: _pc.receiveDamage(_targetNpc, damage); break;
		case NPC_PC: _npc.receiveDamage(_targetPc, damage); break;
		}
	}

	/**
	 * 요정 인페르노 대미지 계산
	 */
	private int calcInfernoDamage(int step) {
	    // 공격자로부터 무기 정보를 가져옴 
		 L1PcInstance attacker = _targetPc; 
	    
	    if (attacker == null) {
	    	return 0;
	    }
	    L1ItemInstance weapon = attacker.getWeapon();
	    
	    if (weapon == null || weapon.getItem().getType() != 1) {
	        return 0;
	    }
	    int dmgSmall = weapon.getItem().getDmgSmall();
	    int addDmg = weapon.getItem().getDmgModifier();
	    int enchant = weapon.getEnchantLevel();

	    int effectiveEnchant = enchant;
	    if (enchant >= 10) {
	        effectiveEnchant += (enchant - 10) + 1;
	    }
	    return (dmgSmall + effectiveEnchant + addDmg) * step;
	}
}
