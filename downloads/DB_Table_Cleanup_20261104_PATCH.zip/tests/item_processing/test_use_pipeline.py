#!/usr/bin/env python3
"""Run actual use stages/target decoder against deterministic game-service edges.

Effects/DB/world are doubles here; the independent AST audit covers all moved
effect bodies and exit destinations, and test_transactions covers real receipts.
"""
from pathlib import Path
import subprocess, tempfile, re

ROOT=Path(__file__).resolve().parents[2]
FUNCTION=Path('l1j/server/server/model/item/function')
legacy=(ROOT/'tests/item_processing/fixtures/ItemUseCreature.before.java.txt').read_text()
token=re.compile(r'"(?:\\.|[^"\\])*"|\'(?:\\.|[^\'\\])*\'|//[^\n]*|/\*[\s\S]*?\*/|\w+|\s+|.',re.UNICODE)
a=legacy.index('switch (itemId)');b=legacy.index('{',a);depth=1;end=b+1
for match in token.finditer(legacy,b+1):
    t=match.group()
    if t=='{':depth+=1
    elif t=='}':
        depth-=1
        if depth==0:end=match.end();break
old_switch=legacy[a:end]
# Its sole early return is the invisible selection-UI path, tested separately.
oracle=old_switch.replace('return;','return null;')
files={}
def put(path,code):files[path]=code
def cls(path,code):put(path+'.java',code)
pkg='package l1j.server.server.model.item.function;'
cls('l1j/server/server/templates/L1Item','''package l1j.server.server.templates;
public class L1Item {public int id,type=20,type2,useType;public int getItemId(){return id;}public int getType(){return type;}public int getType2(){return type2;}public int getUseType(){return useType;}}
''')
cls('l1j/server/server/templates/L1EtcItem','''package l1j.server.server.templates;
public class L1EtcItem extends L1Item {public int delay,effect,min,max;public int get_delayid(){return delay;}public int get_delayEffect(){return effect;}public int getMinLevel(){return min;}public int getMaxLevel(){return max;}}
''')
cls('l1j/server/server/model/Instance/L1ItemInstance','''package l1j.server.server.model.Instance;
import java.sql.Timestamp;import l1j.server.server.templates.*;
public class L1ItemInstance {
 public L1Item template;public int id=7,count=2,charge=2;public Timestamp last;
 public L1Item getItem(){return template;}public int getItemId(){return template.id;}public int getId(){return id;}public int getCount(){return count;}public String getLogName(){return "fixture";}
 public int getChargeCount(){return charge;}public void setChargeCount(int n){charge=n;UseEvents.add("charge:"+n);}
 public Timestamp getLastUsed(){return last;}public void setLastUsed(Timestamp t){last=t;UseEvents.add("last-used");}
}
''')
cls('l1j/server/server/model/Instance/UseEvents','''package l1j.server.server.model.Instance;
public class UseEvents {public static final java.util.List<String> events=new java.util.ArrayList<>();public static void add(String s){events.add(s);}}
''')
cls('l1j/server/server/model/L1PcInventory','''package l1j.server.server.model;
import l1j.server.server.model.Instance.*;
public class L1PcInventory {
 public static final int COL_CHARGE_COUNT=1,COL_DELAY_EFFECT=2;public int arrow,lookups;public L1ItemInstance selected,sting;
 public L1ItemInstance getItem(int id){lookups++;return selected!=null&&selected.id==id?selected:null;}
 public void setArrow(int n){arrow=n;UseEvents.add("arrow:"+n);}public int getArrowItemId(){return arrow;}
 public L1ItemInstance getArrow(){return selected!=null&&selected.getItemId()==arrow?selected:null;}
 public L1ItemInstance findItemId(int id){return selected!=null&&selected.getItemId()==id?selected:null;}
 public L1ItemInstance getSting(){return sting;}public void setSting(int n){UseEvents.add("sting:"+n);}
 public void removeItem(L1ItemInstance i,int n){i.count-=n;UseEvents.add("remove:"+n);}
 public void updateItem(L1ItemInstance i,int col){UseEvents.add("update:"+col);}public void saveItem(L1ItemInstance i,int col){UseEvents.add("save:"+col);}
}
''')
cls('l1j/server/server/model/Instance/L1PcInstance','''package l1j.server.server.model.Instance;
import l1j.server.server.model.L1PcInventory;
public class L1PcInstance {
 public int hp=100,level=60,job;public boolean gm,invis,delayed;public final L1PcInventory inv=new L1PcInventory();public L1ItemInstance weapon;
 public int getCurrentHp(){return hp;}public int getId(){return 99;}public L1PcInventory getInventory(){return inv;}
 public boolean hasItemDelay(int id){return delayed;}public int getLevel(){return level;}public boolean isGm(){return gm;}
 public boolean isElf(){return job==1;}public boolean isWizard(){return job==2;}public boolean isKnight(){return job==3;}
 public boolean isInvisble(){return invis;}public void sendPackets(String s){UseEvents.add("message:"+s);}public L1ItemInstance getWeapon(){return weapon;}
}
''')
cls('l1j/server/server/model/network/core/CIOClient','package l1j.server.server.model.network.core;public class CIOClient {}')
cls('l1j/server/server/model/network/core/cs/packet/CS_ItemUse','package l1j.server.server.model.network.core.cs.packet;public class CS_ItemUse {}')
for name,body in {
 'SC_SystemMessage':'public static void send(L1PcInstance p,String s){UseEvents.add("message:"+s);}',
 'SC_ServerMessage':'public static void send(L1PcInstance p,int n,Object... values){UseEvents.add("server:"+n);}',
 'SC_Paralysis':'public static final int TYPE_TELEPORT_UNLOCK=7;public static void send(L1PcInstance p,int n,boolean on){UseEvents.add("unlock:"+n);}',
 'SC_ItemName':'public static void send(L1PcInstance p,L1ItemInstance i){UseEvents.add("item-name");}',
 'SC_SkillSound':'public static void send(L1PcInstance p,int id,int sound){UseEvents.add("sound:"+sound);}',
 'SC_NPCTalkReturn':'public static void send(L1PcInstance p,int id,String html){UseEvents.add("html:"+html);}'
}.items():
    cls('l1j/server/server/model/network/core/sc/packet/'+name,
        'package l1j.server.server.model.network.core.sc.packet;import l1j.server.server.model.Instance.*;public class '+name+'{'+body+'}')
cls('l1j/server/MJCTSystem/Loader/MJCTLoadManager','package l1j.server.MJCTSystem.Loader;public class MJCTLoadManager {public static final int CTSYSTEM_STORE_ID=3000468;}')
cls('l1j/server/server/model/L1ItemDelay','''package l1j.server.server.model;import l1j.server.server.model.Instance.*;
public class L1ItemDelay {public static void onItemUse(L1PcInstance p,L1ItemInstance i){UseEvents.add("item-delay");}}
''')
cls('l1j/server/server/utils/ItemUseUtil','package l1j.server.server.utils;public class ItemUseUtil {public static int handled=-1;public static boolean Use(int id){return id==handled;}}')
cls('l1j/server/server/model/item/L1TreasureBox','''package l1j.server.server.model.item;import l1j.server.server.model.Instance.*;
public class L1TreasureBox {public static boolean configured=true;public static L1TreasureBox get(int id){return configured?new L1TreasureBox():null;}public void openAtomic(L1PcInstance p,L1ItemInstance i){UseEvents.add("box");}}
''')
cls(str(FUNCTION/'CItemUse'),pkg+'''import l1j.server.server.model.Instance.*;import l1j.server.server.model.network.core.CIOClient;
public class CItemUse {public static void useSupplemental(CIOClient c,L1PcInstance p,L1ItemInstance i,int target){UseEvents.add("supplemental");}}
''')
cls(str(FUNCTION/'StarterSupportHandler'),pkg+'''import l1j.server.server.model.Instance.*;
public class StarterSupportHandler {public static StarterSupportHandler getInstance(){return new StarterSupportHandler();}public void handle(L1PcInstance p,int id,L1ItemInstance i){UseEvents.add("starter");}}
''')
cls(str(FUNCTION/'ItemUseDispatcher'),pkg+'''import l1j.server.server.model.Instance.UseEvents;
final class ItemUseDispatcher {static ItemUseResult result=ItemUseResult.COMPLETE;static Runnable effect;static ItemUseResult use(ItemUseContext c){UseEvents.add("effect");if(effect!=null)effect.run();return result;}}
''')
for name in ['ItemUseContext','ItemUseResult','ItemUseTargeting','ItemUseAdmission','ItemUseCompletion','ItemUsePreparation','ItemUseService']:
    put(str(FUNCTION/(name+'.java')),(ROOT/'src'/FUNCTION/(name+'.java')).read_text())

harness=pkg+r'''
import java.util.*;import java.sql.Timestamp;
import l1j.server.server.model.Instance.*;import l1j.server.server.templates.*;
import l1j.server.server.utils.ItemUseUtil;
import l1j.server.MJCTSystem.Loader.MJCTLoadManager;
import l1j.server.server.model.network.core.sc.packet.*;
public class UsePipelineContract {
 static int passed;static L1PcInstance pc;static L1ItemInstance item;static L1EtcItem template;
 static void check(boolean c,String why){if(!c)throw new AssertionError(why+" events="+UseEvents.events);}
 static void reset(int id){UseEvents.events.clear();pc=new L1PcInstance();template=new L1EtcItem();template.id=id;item=new L1ItemInstance();item.template=template;
  ItemUseDispatcher.result=ItemUseResult.COMPLETE;ItemUseDispatcher.effect=null;ItemUseUtil.handled=-1;}
 static void use(){ItemUseService.use(null,pc,item,item.id,88,32769,32770,"chosen",5);}
 static void events(String... expected){check(UseEvents.events.equals(List.of(expected)),"ordered effects changed");}
 static void test(String name,Runnable r){r.run();passed++;System.out.println("PASS "+name);}
 static Object[] legacy(int itemId,int use_type,int targetId,int x,int y,String name,int skillId){
  int l=0,spellsc_objid=0,spellsc_x=0,spellsc_y=0,blanksc_skillid=0,cookStatus=0,cookNo=0,fishX=0,fishY=0,bookmark_x=0,bookmark_y=0,BookTel=0,use_objid=0;
  short bookmark_mapid=0;String s="";
ORACLE
  return new Object[]{l,s,spellsc_objid,spellsc_x,spellsc_y,blanksc_skillid,cookStatus,cookNo,fishX,fishY,bookmark_mapid,bookmark_x,bookmark_y,BookTel,use_objid};
 }
 static Object[] decoded(ItemUseContext c){return new Object[]{c.targetItemObjectId(),c.text(),c.spellTargetId(),c.spellX(),c.spellY(),c.blankScrollSkillId(),c.cookingStatus(),c.cookingNumber(),c.fishingX(),c.fishingY(),c.bookmarkMapId(),c.bookmarkX(),c.bookmarkY(),c.teleportBookSlot(),c.storedItemObjectId()};}
 public static void main(String[] args){
  java.util.logging.Logger.getLogger("l1j.server.server.model.network.core.cs.packet.CS_ItemUse").setLevel(java.util.logging.Level.OFF);
  test("target decoder matches original switch over explicit IDs, type priority and signed packed coordinates",()->{
   reset(9001000);int[] ids={IDS};Random random=new Random(81024);int count=0;
   for(int n=0;n<ids.length+10000;n++)for(int type:new int[]{0,5,17,30,9}) {
    int id=n<ids.length?ids[n]:random.nextInt();template.id=id;template.useType=type;
    int target=n%4==0?0xffffffff:n%4==1?Integer.MIN_VALUE:n%4==2?0x80018002:random.nextInt();
    int x=random.nextInt(),y=random.nextInt(),skill=random.nextInt();String name=n%2==0?null:"기존 문자열";
    Object[] expected=legacy(id,type,target,x,y,name,skill);ItemUseContext c=new ItemUseContext(null,pc,item,7,target,x,y,name,skill);
    check(Arrays.equals(expected,decoded(c)),"decoder mismatch id="+id+" type="+type);count++;
   }System.out.println("decoder comparisons="+count);UseEvents.events.clear();
  });
  test("selection sound/UI remains before HP admission and invisible early exit",()->{
   reset(40088);pc.hp=0;use();events("sound:21174","html:neigetele4");
   reset(40088);pc.invis=true;use();events("sound:21174","message:지금은 사용할 수 없는 상태입니다.");
  });
  test("supplemental path preserves precedence and skips ordinary delay tail",()->{
   reset(40088);ItemUseUtil.handled=40088;pc.hp=0;use();events("supplemental");
  });
  test("HP, item delay and ticket rejection run before effects and target lookup",()->{
   for(int branch=0;branch<3;branch++){reset(branch==2?8500000:9001000);if(branch==0)pc.hp=0;if(branch==1){template.delay=1;pc.delayed=true;}
    use();events();check(pc.inv.lookups==0,"rejected use looked up target");}
  });
  test("cooldown inclusive second boundary and original remaining-time message",()->{
   reset(9001000);template.effect=60;item.last=new Timestamp(System.currentTimeMillis()-60000);use();
   check(UseEvents.events.size()==1&&UseEvents.events.getFirst().equals("message:0분 0초 후에 사용할 수 있습니다. "),"cooldown boundary/message changed");
   reset(9001000);template.effect=60;item.last=new Timestamp(System.currentTimeMillis()-62000);use();check(UseEvents.events.contains("effect"),"expired reuse time rejected");
  });
  test("level and soul-class rejection preserve messages and GM exception",()->{
   reset(9001000);template.min=61;use();events("message:61레벨 이상이 되면 사용할 수 있는 아이템입니다.","unlock:7");
   reset(9001000);template.max=59;use();events("message:59레벨 이하일 때만 사용할 수 있는 아이템입니다.","unlock:7");
   reset(9001000);template.min=90;pc.gm=true;use();events("effect","item-delay");
   reset(40576);use();events("server:264");reset(40576);pc.job=1;use();events("effect","item-delay");
  });
  test("normal completion and early-stop have distinct cooldown/charge tails",()->{
   reset(9001000);template.effect=1;use();events("effect","last-used","update:2","save:2","item-delay");
   reset(9001000);template.effect=1;ItemUseDispatcher.result=ItemUseResult.STOP;use();events("effect");check(item.last==null,"early return started cooldown");
  });
  test("charged item reuse and exhaustion keep exact mutation order",()->{
   reset(410008);template.effect=1;item.charge=2;use();events("effect","charge:1","last-used","update:1","save:1","item-delay");
   reset(410008);template.effect=1;item.charge=1;use();events("effect","charge:0","remove:1","item-delay");check(item.last==null,"exhausted charge touched timestamp");
  });
  test("weapon/armor skips ETC level and preparation but starts normal item delay",()->{
   for(int type:new int[]{1,2}){reset(9001000);template.type2=type;template.min=90;template.type=16;use();events("effect","item-delay");}
  });
  test("starter and treasure-box paths stop before generic effects",()->{
   reset(3000572);use();events("starter");
   reset(9001000);template.type=16;use();events("box");
  });
  test("ammunition selection preserves ordinary fallthrough",()->{
   reset(9001000);template.type=0;use();events("arrow:9001000","item-name","effect","item-delay");
   reset(9001000);template.type=0;pc.weapon=new L1ItemInstance();pc.weapon.template=new L1EtcItem();
   use();events("effect","item-delay");
  });
  test("selected item reference is captured before effect and normal tail",()->{
   reset(40074);L1ItemInstance target=new L1ItemInstance();target.id=88;pc.inv.selected=target;
   ItemUseContext c=new ItemUseContext(null,pc,item,7,88,0,0,"",0);pc.inv.selected=null;check(c.targetItem()==target,"selected target looked up lazily after mutation");
  });
  System.out.println("RESULT passed="+passed+" failed=0");
 }
}
'''
ids=sorted(set(map(int,re.findall(r'(?m)^\s*case\s+(\d+)\s*:',old_switch))))+[3000468,600226,600227,3000235,41255,41259,41260,0,-1]
harness=harness.replace('ORACLE',oracle).replace('IDS',','.join(map(str,ids)))
put(str(FUNCTION/'UsePipelineContract.java'),harness)
with tempfile.TemporaryDirectory() as td:
    d=Path(td)
    for rel,text in files.items():
        p=d/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(text)
    sources=sorted(str(p) for p in d.rglob('*.java'))
    subprocess.run(['java','-m','jdk.compiler/com.sun.tools.javac.Main','-source','21','-target','21','-encoding','UTF-8','-d',td,*sources],check=True,timeout=60)
    subprocess.run(['java','-ea','-cp',td,'l1j.server.server.model.item.function.UsePipelineContract'],check=True,timeout=60)
