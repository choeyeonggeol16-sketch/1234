#!/usr/bin/env python3
"""Ensure the offline table audit rejects absent tables without treating columns as tables."""
from pathlib import Path
import importlib.util
ROOT=Path(__file__).resolve().parents[2]
spec=importlib.util.spec_from_file_location('audit_db_tables',ROOT/'tools/audit_db_tables.py')
audit=importlib.util.module_from_spec(spec);spec.loader.exec_module(audit)
queries=[
 'SELECT rank FROM characters',
 'SELECT * FROM characters, missing_joined AS b WHERE characters.objid=b.id',
 'INSERT INTO `없는테이블` VALUES (?)',
 'CREATE TABLE IF NOT EXISTS missing_create (id INT)',
 'SELECT * FROM information_schema.TABLES WHERE TABLE_NAME=?',
 "SELECT 'from not_a_table' FROM accounts",
 'SELECT * FROM characters WHERE objid IN (1,2)',
 'UPDATE missing_update SET value=?',
 'REPLACE INTO missing_replace VALUES (?)',
 'SELECT * FROM characters JOIN missing_explicit ON 1=1',
 'SELECT * FROM ${unreviewedTable}',
]
report=audit.audit(ROOT,[{'file':'fixture.java','line':i+1,'sql':q} for i,q in enumerate(queries)],['characters','accounts'])
expected={'missing_joined','없는테이블','missing_create','missing_update','missing_replace','missing_explicit'}
assert set(report['missing'])==expected,report['missing']
assert len(report['unresolved'])==1 and report['unresolved'][0]['expression']=='unreviewedTable'
print('PASS absent tables, columns, literals, system schemas, comma/explicit joins and unknown dynamic table rejection')
