﻿param([int]$TargetPid = 0, [switch]$CollectOnly)
$ErrorActionPreference = 'Stop'
$desktopPath = [Environment]::GetFolderPath('Desktop')
if (-not $desktopPath) { $desktopPath = $PSScriptRoot }
$outputPath = Join-Path $desktopPath 'PSS_UI_Check'
[void](New-Item -ItemType Directory -Path $outputPath -Force)
$reportPath = Join-Path $outputPath 'report.txt'
$script:report = New-Object 'System.Collections.Generic.List[string]'
function Note([string]$text) { $script:report.Add($text); Write-Host $text }

if (-not ('PssUiProbe' -as [type])) { Add-Type -TypeDefinition @'
using System;
using System.Text;
using System.Collections.Generic;
using System.Runtime.InteropServices;
public static class PssUiProbe {
  public delegate bool EnumProc(IntPtr window, IntPtr parameter);
  [DllImport("kernel32.dll", SetLastError=true)] public static extern IntPtr OpenProcess(uint access, bool inherit, int pid);
  [DllImport("kernel32.dll")] public static extern bool CloseHandle(IntPtr handle);
  [DllImport("kernel32.dll", SetLastError=true)] public static extern bool ReadProcessMemory(IntPtr process, IntPtr address, byte[] data, UIntPtr length, out UIntPtr read);
  [DllImport("user32.dll")] static extern bool EnumWindows(EnumProc callback, IntPtr parameter);
  [DllImport("user32.dll")] static extern uint GetWindowThreadProcessId(IntPtr window, out uint pid);
  [DllImport("user32.dll", CharSet=CharSet.Unicode)] static extern int GetClassName(IntPtr window, StringBuilder text, int length);
  [DllImport("user32.dll")] public static extern bool IsWindowVisible(IntPtr window);
  [DllImport("user32.dll", SetLastError=true)] public static extern bool PostMessage(IntPtr window, uint message, IntPtr wparam, IntPtr lparam);
  public static IntPtr[] Windows(int pid) {
    var result = new List<IntPtr>();
    EnumWindows(delegate(IntPtr window, IntPtr parameter) {
      uint owner; GetWindowThreadProcessId(window, out owner);
      if (owner == (uint)pid) result.Add(window);
      return true;
    }, IntPtr.Zero);
    return result.ToArray();
  }
  public static string ClassName(IntPtr window) {
    var text = new StringBuilder(256); GetClassName(window, text, text.Capacity); return text.ToString();
  }
  public static byte[] Read(IntPtr process, uint address, int count) {
    if (address < 0x10000 || count < 1 || count > 1024) throw new ArgumentException("Invalid diagnostic read");
    var bytes = new byte[count]; UIntPtr read;
    if (!ReadProcessMemory(process, new IntPtr((long)address), bytes, new UIntPtr((uint)count), out read) || read.ToUInt64() != (ulong)count)
      throw new System.ComponentModel.Win32Exception(Marshal.GetLastWin32Error());
    return bytes;
  }
}
'@
}
function Read32([uint32]$address) {
    return [BitConverter]::ToUInt32([PssUiProbe]::Read($script:processHandle, $address, 4), 0)
}
function Dump([string]$name, [uint32]$address, [int]$count) {
    try {
        $bytes = [PssUiProbe]::Read($script:processHandle, $address, $count)
        [IO.File]::WriteAllBytes((Join-Path $outputPath ($name + '.bin')), $bytes)
        Note ('{0} address=0x{1:X8} bytes={2}' -f $name, $address, [BitConverter]::ToString($bytes))
    } catch { Note ($name + ': ' + $_.Exception.Message) }
}
function Snapshot([string]$label) {
    Note ('--- ' + $label + ' ---')
    try {
        $phase = Read32 0x15D8E44
        $uiPointer = Read32 0x15B4BCC
        Note ('phase={0} UI=0x{1:X8}' -f $phase, $uiPointer)
        if ($uiPointer) {
            $tablePointer = Read32 $uiPointer
            $showPointer = Read32 ($tablePointer + 0x44)
            Note ('vtable=0x{0:X8} show=0x{1:X8}' -f $tablePointer, $showPointer)
            Dump ($label + '-ui-object') $uiPointer 128
            Dump ($label + '-ui-vtable') $tablePointer 128
            Dump ($label + '-ui-show') $showPointer 256
        }
    } catch { Note ('UI read failed: ' + $_.Exception.Message) }
}
$script:processHandle = [IntPtr]::Zero
try {
    Note ('PSS settings check ' + [DateTime]::Now.ToString('s'))
    Note 'No START request is sent. This invokes only the existing PSS settings button.'
    if ($TargetPid -eq 0) {
        $candidates = @(Get-Process | Where-Object {
            try {
                $_.MainModule.FileVersionInfo.FileVersion -eq '19, 02, 15, 1002' -or
                ($_.MainModule.FileVersionInfo.FileMajorPart -eq 19 -and
                 $_.MainModule.FileVersionInfo.FileMinorPart -eq 2 -and
                 $_.MainModule.FileVersionInfo.FileBuildPart -eq 15 -and
                 $_.MainModule.FileVersionInfo.FilePrivatePart -eq 1002)
            } catch { $false }
        })
        if ($candidates.Count -ne 1) {
            $candidates | Format-Table -Property @('Id', 'ProcessName') | Out-Host
            throw 'Select one client using -TargetPid <PID>. Start the game and attach the original PSS helper first.'
        }
        $targetProcess = $candidates[0]
    } else { $targetProcess = Get-Process -Id $TargetPid }
    $clientPath = $targetProcess.MainModule.FileName
    $clientHash = (Get-FileHash -LiteralPath $clientPath -Algorithm SHA256).Hash
    Note ('PID={0} SHA256={1}' -f $targetProcess.Id, $clientHash)
    if ($clientHash -ne '9C82129EFED1D93981782069E82DE79869920769AA0F67BC1183CA75CF621823') {
        throw 'Exact client hash mismatch. No fixed-address reads or UI invocation were attempted.'
    }
    if ($targetProcess.MainModule.BaseAddress.ToInt64() -ne 0x400000) { throw 'Unexpected client base address.' }
    # Query + read access only. No process memory writes or remote threads.
    $script:processHandle = [PssUiProbe]::OpenProcess(0x410, $false, $targetProcess.Id)
    if ($script:processHandle -eq [IntPtr]::Zero) {
        throw 'Cannot read client memory. Run with the same privilege level as the game.'
    }
    Snapshot 'before'
    # Capture only the known request wrappers, without executing them.
    Dump 'native-start-request' 0x642BF0 256
    Dump 'native-finish-request' 0x642B10 128
    Dump 'native-time-request' 0x642B80 128
    $panelHandle = [IntPtr]::Zero
    foreach ($windowHandle in [PssUiProbe]::Windows($targetProcess.Id)) {
        $className = [PssUiProbe]::ClassName($windowHandle)
        Note ('window class={0} visible={1}' -f $className, [PssUiProbe]::IsWindowVisible($windowHandle))
        if ($className -eq 'Pss2019Panel') { $panelHandle = $windowHandle }
    }
    if (-not $CollectOnly) {
        if ($panelHandle -eq [IntPtr]::Zero) { throw 'PSS panel not found. Attach PSS버튼.exe first.' }
        if ((Read32 0x15D8E44) -ne 3) { throw 'Enter the world with your character first.' }
        $queued = [PssUiProbe]::PostMessage($panelHandle, 0x111, [IntPtr]101, [IntPtr]::Zero)
        Note ('PSS settings button request queued=' + $queued)
        if (-not $queued) { throw 'Settings button request failed.' }
        Start-Sleep -Milliseconds 700
        Snapshot 'after'
    }
    Note 'The button request is not proof that the native window opened or that 2111 was sent.'
} catch { Note ('ERROR: ' + $_.Exception.Message) }
finally {
    if ($script:processHandle -ne [IntPtr]::Zero) { [void][PssUiProbe]::CloseHandle($script:processHandle) }
    $script:report | Set-Content -LiteralPath $reportPath -Encoding UTF8
    Write-Host ('Report: ' + $reportPath)
}
