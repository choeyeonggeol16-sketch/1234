package l1j.server.server.model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.logging.Logger;

import l1j.server.DatabaseFactory;
import l1j.server.server.model.Instance.L1PcInstance;
import l1j.server.server.utils.SQLUtil;

public class L1Quest {
	private static Logger _log = Logger.getLogger(L1Quest.class.getName());

	public static final int QUEST_LEVEL15 = 1;
	public static final int QUEST_LEVEL30 = 2;
	public static final int QUEST_LEVEL45 = 3;
	public static final int QUEST_LEVEL50 = 4;
	public static final int QUEST_LEVEL5 = 5;
	public static final int QUEST_수련자물품 = 6;
	public static final int QUEST_LEVEL55 = 7;

	public static final int QUEST_FIRSTQUEST = 40; // ## A70 말하는 두루마리 퀘스트 추가

	public static final int QUEST_LYRA = 10;
	public static final int QUEST_OILSKINMANT = 11;

	public static final int QUEST_DOROMOND = 20;
	public static final int QUEST_RUBA = 21;
	public static final int QUEST_AREX = 22;

	public static final int QUEST_LUKEIN1 = 23;
	public static final int QUEST_TBOX1 = 24;
	public static final int QUEST_TBOX2 = 25;
	public static final int QUEST_TBOX3 = 26;
	public static final int QUEST_SIMIZZ = 27;
	public static final int QUEST_DOIL = 28;
	public static final int QUEST_RUDIAN = 29;
	public static final int QUEST_RESTA = 30;
	public static final int QUEST_CADMUS = 31;
	public static final int QUEST_KAMYLA = 32;
	public static final int QUEST_CRYSTAL = 33;
	public static final int QUEST_LIZARD = 34;
	public static final int QUEST_KEPLISHA = 35;
	public static final int QUEST_DESIRE = 36;
	public static final int QUEST_SHADOWS = 37;
	public static final int QUEST_ROI = 38;
	public static final int QUEST_MOONBOW = 39;
	public static final int QUEST_ICEQUEENRING = 41;
	public static final int QUEST_END = 255;

	// 스냅퍼 방지/귀걸이
	public static final int QUEST_SLOT76 = 60;
	public static final int QUEST_SLOT81 = 61;
	public static final int QUEST_SLOT59 = 62;
	public static final int QUEST_SAI_RUNE70 = 63;
	public static final int QUEST_SLOT_SHOULD = 64;	// 견갑
	public static final int QUEST_SLOT_BADGE = 65;	// 휘장
	public static final int QUEST_HAMO = 80;

	private L1PcInstance _owner = null;
	private HashMap<Integer, Integer> _quest = null;

	public L1Quest(L1PcInstance owner) {
		_owner = owner;
	}

	public L1PcInstance get_owner() {
		return _owner;
	}

    public static int[] readSnapshot(int characterId) {
        int[] pairs = new int[16];
        int count = 0;
        try (Connection con = DatabaseFactory.getInstance().getConnection();
             PreparedStatement ps = con.prepareStatement(
                     "SELECT quest_id, quest_step FROM character_quests WHERE char_id=?")) {
            ps.setInt(1, characterId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    if (count == pairs.length) {
                        int[] bigger = new int[pairs.length << 1];
                        System.arraycopy(pairs, 0, bigger, 0, count);
                        pairs = bigger;
                    }
                    final int questId = rs.getInt(1);
                    if (rs.wasNull())
                        throw new SQLException("NULL quest ID in login snapshot: " + characterId);
                    final int step = rs.getInt(2);
                    if (rs.wasNull())
                        throw new SQLException("NULL quest step in login snapshot: "
                                + characterId + "/" + questId);
                    pairs[count++] = questId;
                    pairs[count++] = step;
                }
            }
        } catch (SQLException e) {
            throw new IllegalStateException("Quest DB read failed: " + characterId, e);
        }
        if (count == pairs.length) return pairs;
        int[] result = new int[count];
        System.arraycopy(pairs, 0, result, 0, count);
        return result;
    }

    public void applySnapshot(int[] pairs) {
        // Login snapshots are a complete replacement, not incremental updates.
        // Validate before publication: stale QUEST_END flags must not leak into
        // a later login or the legacy level-gift migration decision.
        if (pairs == null || (pairs.length & 1) != 0)
            throw new IllegalArgumentException("Invalid quest snapshot");
        final HashMap<Integer, Integer> loaded = new HashMap<>(Math.max(16, pairs.length));
        for (int i = 0; i < pairs.length; i += 2) {
            final int questId = pairs[i];
            if (questId <= 0 || loaded.putIfAbsent(questId, pairs[i + 1]) != null)
                throw new IllegalArgumentException("Invalid or duplicate quest ID: " + questId);
        }
        _quest = loaded;
    }

	public int get_step(int quest_id) {
        // A failed or partial DB read must not make a durable quest look
        // incomplete. Publish the cache only after the full snapshot loads.
        if (_quest == null) applySnapshot(readSnapshot(_owner.getId()));
        Integer step = _quest.get(quest_id);
        return step == null ? 0 : step.intValue();
    }

	public void set_step(int quest_id, int step) {
        // A failed SQL write must not manufacture a completed quest in memory.
        // The next login may recover a commit whose JDBC reply was lost.
        try (Connection con = DatabaseFactory.getInstance().getConnection();
             PreparedStatement pstm = con.prepareStatement(
                     "insert into character_quests set char_id=?, quest_id=?, quest_step=? "
                     + "on duplicate key update quest_step=?")) {
            pstm.setInt(1, _owner.getId());
            pstm.setInt(2, quest_id);
            pstm.setInt(3, step);
            pstm.setInt(4, step);
            pstm.executeUpdate();
        } catch (SQLException failure) {
            throw new IllegalStateException("Quest step persistence failed: "
                    + _owner.getId() + "/" + quest_id, failure);
        }
        if (_quest == null) {
            // Keep unrelated stored quest flags if the map has not yet loaded.
            applySnapshot(readSnapshot(_owner.getId()));
        } else {
            _quest.put(quest_id, step);
        }
    }

    /** Cache-only replay of an already committed quest row. Never issue JDBC on
     * the CIO owner; an unloaded quest map will read the durable row on demand.
     */
    public void applyCommittedStepIfLoaded(int questId, int step) {
        if (_quest != null) _quest.put(questId, step);
    }

	public void add_step(int quest_id, int add) {
		int step = get_step(quest_id);
		step += add;
		set_step(quest_id, step);
	}

	public void set_end(int quest_id) {
		set_step(quest_id, QUEST_END);
	}

	public boolean isEnd(int quest_id) {
		if (get_step(quest_id) == QUEST_END) {
			return true;
		}
		return false;
	}

}
