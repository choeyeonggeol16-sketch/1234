package l1j.server.server.model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Timestamp;
import java.util.Calendar;
import java.util.HashMap;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.RejectedExecutionException;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.logging.Level;
import java.util.logging.Logger;

import l1j.server.DatabaseFactory;
import l1j.server.server.ThreadPool;
import l1j.server.server.model.gametime.RealTimeClock;
import l1j.server.server.utils.SQLUtil;

public class L1ClanRanking implements Runnable {
	
	private static final Logger _log = Logger.getLogger(L1ClanRanking.class.getName());

	private static L1ClanRanking _instance = new L1ClanRanking();

	public static L1ClanRanking getInstance() {
		return _instance;
	}

	private volatile boolean _isStart;
	private ScheduledFuture<?> _updateFuture;
	private final AtomicBoolean _updateQueued = new AtomicBoolean();
	
	private int _currentTime;
	private int _clanRank = 0;
	
	private HashMap<Integer, RankData> _curankData = new HashMap<Integer, RankData>();
	private HashMap<String, Integer> _parankData = new HashMap<String, Integer>();	
		
	public synchronized void start() {
		if (_isStart) return;
		// Run on the existing scheduler once per minute, not a forever-sleeping
		// task occupying one of the bounded instant workers.
		final ScheduledFuture<?> future = ThreadPool.getInstance()
				.scheduleAtFixedRate(this::submitUpdate, 1L, 60_000L);
		if (future == null) {
			_log.warning("Clan ranking periodic update admission rejected");
			return;
		}
		_updateFuture = future;
		_isStart = true;
	}

	private void submitUpdate() {
		if (!_isStart || !_updateQueued.compareAndSet(false, true)) return;
		try {
			ThreadPool.getInstance().execute(() -> {
				try { run(); }
				finally { _updateQueued.set(false); }
			});
		} catch (RejectedExecutionException rejected) {
			_updateQueued.set(false);
			_log.log(Level.WARNING, "Clan ranking update rejected; retry next minute", rejected);
		}
	}

	@Override
	public void run() {
		if (!_isStart) return;
		try {
			if (isChangeTime()) {
				clanchange();
				_currentTime = (int) (System.currentTimeMillis() / 1000);
			}
		} catch (Exception error) {
			_log.log(Level.WARNING, "Clan ranking update failed", error);
		}
	}

	private boolean isChangeTime() {
		if (_currentTime == 0) {
			return true;
		}
		return RealTimeClock.getInstance().getRealTime().get(Calendar.MINUTE) == 0;
	}

	public void gmcommand() {
		try {
			clanchange();	
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	private void clanchange() {
		Connection con = null;
		PreparedStatement pstm = null;
		ResultSet rs = null;
		try {
			clearAllDatas();
			con = DatabaseFactory.getInstance().getConnection();
			pstm = con.prepareStatement("SELECT clan_id, clan_name, ranktime, rankdate FROM clan_data WHERE ranktime > 0 ORDER BY ranktime");
			rs = pstm.executeQuery();

			while (rs.next()) {
				int claniD = rs.getInt("clan_id");
				String clannamE =rs.getString("clan_name");
				int timE = rs.getInt("ranktime");
				Timestamp datA = rs.getTimestamp("rankdate");
				addRankerData(claniD, clannamE, timE, datA);
			}
		} catch (Exception e) {
			_log.log(Level.WARNING, "", e);
		} finally {
			SQLUtil.close(rs);
			SQLUtil.close(pstm);
			SQLUtil.close(con);
		}
	}

	private int getCurrentRank() {
		return _clanRank;
	}
	
	private int getNextRank() {
		return ++_clanRank;
	}
	
	private int getMaxRank() {
		return 200;
	}
	
	private int getOldRank(String name) {
		if (_parankData.containsKey(name)) {
			return _parankData.get(name);
		}
		return 0;
	}


	private void addRankerData(int clanId, String name, int time, Timestamp data) {
		int currentRank = getCurrentRank();
		int maxRank = getMaxRank();
		if (currentRank < maxRank) {
			int oldRank = getOldRank(name);
			int nextRank = getNextRank();
			_curankData.put(nextRank, new RankData(nextRank, oldRank, clanId, name, time, data));
		}
	}
	

	public RankData[] getRankerDatas() {		
		return _curankData.values().toArray(new RankData[_curankData.values().size()]);		
	}


	private void clearAllDatas() {
		_parankData.clear();	
		_parankData.putAll(new HashMap<String, Integer>());
		for (RankData data : getRankerDatas()) {
			_parankData.put(data.getClanName(), data.getCurrentR());
		}	
		_curankData.clear();	
		_curankData.putAll(new HashMap<Integer, RankData>());
		_clanRank = 0;		
	}
	
	public RankData getClanRankerData(String name) {
		RankData[] datas = getRankerDatas();
		if (datas != null) {
			for (RankData data : datas) {
				if (data.getClanName().equals(name)) {
					return data;
				}
			}
		}
		return null;
	}
	
	public class RankData {
		private int _currentR;
		private int _pastR;
		private int _clanid;
		private String _clanname;
		private int _comtime;
		private Timestamp _date;

		public int getCurrentR() {
			return _currentR;
		}

		public int getPastR() {
			return _pastR;
		}

		public int getClanid() {
			return _clanid;
		}

		public String getClanName() {
			return _clanname;
		}

		public int getComTime() {
			return _comtime;
		}

		public Timestamp getDate() {
			return _date;
		}
		
		public RankData(int currentRank, int pastRank, int clanId, String clanName, int tiMe, Timestamp daTa) {
			_currentR = currentRank;
			_pastR = pastRank == 0 ? currentRank : pastRank;
			_clanid = clanId;
			_clanname = clanName;
			_comtime = tiMe;
			_date = daTa;		
		}
	}
}