package l1j.server.server.model;

import java.util.Iterator;

import l1j.server.server.model.Instance.L1PcInstance;
import l1j.server.server.model.network.packet.ServerPacket;

public class Broadcaster {
	/**
	 * 캐릭터의 가시 범위에 있는 플레이어에, 패킷을 송신한다.
	 * 
	 * @param packet
	 *            송신하는 패킷을 나타내는 ServerBasePacket 오브젝트.
	 */
	public static void broadcastPacket(L1Character cha, ServerPacket packet) {
		Iterator<L1PcInstance> iter = L1World.getInstance().getVisiblePlayer(cha).iterator();
		L1PcInstance pc = null;
		
		while (iter.hasNext()) {
			pc = iter.next();
			if (pc == null)  continue;
			pc.sendPackets(packet, false);
		}
	}
	

    

    

    
}
