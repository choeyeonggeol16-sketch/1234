from pathlib import Path
import tempfile,subprocess,os,shutil
ROOT=Path(__file__).resolve().parents[2];B=ROOT/'src/l1j/server/server';OUT=ROOT/'test-results/npc_action_security';OUT.mkdir(parents=True,exist_ok=True);J=os.environ.get('JAVAC','javac')
def method(s,sig):
 a=s.index(sig);i=s.index('{',a)+1;d=1
 while d:
  if s[i]=='{':d+=1
  elif s[i]=='}':d-=1
  i+=1
 return s[a:i]
def compile_run(root,main):
 files=list(root.rglob('*.java'));r=subprocess.run([J,'--release','21','-encoding','UTF-8','-d',str(root/'classes'),*map(str,files)],capture_output=True,text=True);assert r.returncode==0,r.stderr
 r=subprocess.run(['java','-ea','-cp',str(root/'classes'),main],cwd=root,capture_output=True,text=True,timeout=30);print(r.stdout,r.stderr);(OUT/(main.split('.')[-1]+'.log')).write_text(r.stdout+r.stderr);assert r.returncode==0
with tempfile.TemporaryDirectory() as td:
 r=Path(td)
 def put(name,body):
  p=r/(name.replace('.','/')+'.java');p.parent.mkdir(parents=True,exist_ok=True);p.write_text(body)
 for name in ['NpcActionContext','NpcActionSecurity','L1NpcXmlAction','L1NpcAction']:
  raw=(B/'model/npc/action'/(name+'.java')).read_bytes()
  try:s=raw.decode('utf-8')
  except UnicodeError:s=raw.decode('cp949')
  put('l1j.server.server.model.npc.action.'+name,s)
 put('l1j.server.server.model.L1Object','''package l1j.server.server.model;public class L1Object{public int x,y,map;public int getX(){return x;}public int getY(){return y;}public int getMapId(){return map;}}''')
 put('l1j.server.server.model.Instance.L1NpcInstance','''package l1j.server.server.model.Instance;public class L1NpcInstance extends l1j.server.server.model.L1Object{public int id=1;public boolean isDead(){return false;}public Template getNpcTemplate(){return new Template(id);}public static class Template{int id;Template(int i){id=i;}public int get_npcId(){return id;}}}''')
 put('l1j.server.server.model.Instance.L1PcInstance','''package l1j.server.server.model.Instance;public class L1PcInstance extends l1j.server.server.model.L1Object{public boolean dead,ghost;final l1j.server.server.model.npc.action.NpcActionContext c=new l1j.server.server.model.npc.action.NpcActionContext();public boolean isDead(){return dead;}public boolean isGhost(){return ghost;}public l1j.server.server.model.npc.action.NpcActionContext getNpcActionContext(){return c;}public int getLevel(){return 50;}public int getType(){return 0;}public Quest getQuest(){return new Quest();}public static class Quest{public int get_step(int i){return 1;}}}''')
 put('l1j.server.server.utils.IntRange','''package l1j.server.server.utils;public class IntRange{final int a,b;public IntRange(int a,int b){this.a=a;this.b=b;}public boolean includes(int n){return n>=a&&n<=b;}}''')
 put('l1j.server.server.model.npc.action.L1NpcHtml','package l1j.server.server.model.npc.action;public class L1NpcHtml{}')
 put('l1j.server.server.model.npc.action.L1NpcXmlParser','''package l1j.server.server.model.npc.action;import org.w3c.dom.*;import java.util.*;public class L1NpcXmlParser{public static int getIntAttribute(Element e,String n,int d){return e.hasAttribute(n)?Integer.parseInt(e.getAttribute(n)):d;}public static int parseQuestId(String n){return n.isEmpty()?-1:Integer.parseInt(n);}public static int parseQuestStep(String n){return n.isEmpty()?-1:Integer.parseInt(n);}public static List<L1NpcAction> listActions(Element e){List<L1NpcAction>a=new ArrayList<>();for(Node n=e.getFirstChild();n!=null;n=n.getNextSibling())if(n instanceof Element x)a.add(new Probe(x));return a;}public static class Probe extends L1NpcXmlAction{public Probe(Element e){super(e);}public L1NpcHtml execute(String n,l1j.server.server.model.Instance.L1PcInstance pc,l1j.server.server.model.L1Object o,byte[] b){return new L1NpcHtml();}}}''')
 put('l1j.server.server.utils.FileUtil','''package l1j.server.server.utils;public class FileUtil{public static String getExtension(java.io.File f){String n=f.getName();return n.substring(n.lastIndexOf('.')+1);}}''')
 put('l1j.server.server.datatables.NpcActionTable',(B/'datatables/NpcActionTable.java').read_bytes().decode('utf-8'))
 data=r/'data/xml/NpcActions';data.mkdir(parents=True)
 (data/'test.xml').write_text('''<NpcActionList><Action Name="unbound"/><Action Name="bound" NpcId="1"/></NpcActionList>''')
 put('SecurityTest','''import l1j.server.server.model.npc.action.*;import l1j.server.server.model.Instance.*;import l1j.server.server.datatables.*;import java.util.concurrent.*;
public class SecurityTest{static int count;static void ok(boolean b){count++;if(!b)throw new AssertionError("case "+count);}public static void main(String[]a)throws Exception{
 NpcActionContext c=new NpcActionContext();Object n=new Object(),other=new Object();ok(!c.allows(n,1));c.begin(n,10);ok(c.allows(n,11));ok(!c.allows(other,11));ok(!c.allows(n,TimeUnit.MINUTES.toNanos(2)+10));c.clear();ok(!c.allows(n,11));ok(!c.consumePoly(11));c.permitPoly(10);ok(c.consumePoly(11));ok(!c.consumePoly(12));c.permitPoly(10);ok(!c.consumePoly(TimeUnit.MINUTES.toNanos(2)+10));c.permitPoly(10);c.begin(n,11);ok(!c.consumePoly(12));
 L1PcInstance pc=new L1PcInstance();L1NpcInstance npc=new L1NpcInstance();ok(!NpcActionSecurity.canAct(pc,npc));pc.getNpcActionContext().begin(npc,System.nanoTime());ok(NpcActionSecurity.canAct(pc,npc));npc.map=1;ok(!NpcActionSecurity.canAct(pc,npc));npc.map=0;npc.x=7;ok(!NpcActionSecurity.canAct(pc,npc));npc.x=6;ok(NpcActionSecurity.canAct(pc,npc));npc.x=Integer.MIN_VALUE;ok(!NpcActionSecurity.canTalk(pc,npc));npc.x=0;pc.dead=true;ok(!NpcActionSecurity.canAct(pc,npc));pc.dead=false;pc.ghost=true;ok(!NpcActionSecurity.canAct(pc,npc));pc.ghost=false;ok(!NpcActionSecurity.canAct(pc,new L1NpcInstance()));ok(!NpcActionSecurity.canTalk(pc,pc));ok(!NpcActionSecurity.allowsPaidMorph(npc));
 NpcActionTable.load();NpcActionTable t=NpcActionTable.getInstance();ok(t.get("unbound",pc,npc).execute("unbound",pc,npc,new byte[0])==null);ok(t.get("bound",pc,npc).execute("bound",pc,npc,new byte[0])!=null);npc.id=2;ok(t.get("bound",pc,npc)==null);pc.getNpcActionContext().clear();ok(t.get("bound",pc,npc).execute("bound",pc,npc,new byte[0])==null);
 System.out.println("PASS "+count+" production context/security/XML-dispatch checks (typed dependency stubs)");}}
''')
 compile_run(r,'SecurityTest')
with tempfile.TemporaryDirectory() as td:
 r=Path(td);s=(B/'clientpackets/C_NPCAction.java').read_bytes().decode('utf-8')
 methods='\n'.join(method(s,n) for n in ['private String getYaheeAmulet(', 'private String getBarlogEarring('])
 code='''import java.util.*;import java.util.concurrent.*;public class AccessoryTest{
 static class ItemInstance{String getLogName(){return "item";}}static class S_ServerMessage{S_ServerMessage(Object...o){}}static class S_SystemMessage{S_SystemMessage(String s){}}
 static class L1NpcInstance{Template getNpcTemplate(){return new Template();}}static class Template{String get_name(){return "npc";}}
 static class Inventory{Map<Integer,Integer>items=new HashMap<>();boolean fail;boolean checkItem(int id){return items.getOrDefault(id,0)>0;}ItemInstance storeItem(int id,int n){if(fail)return null;items.merge(id,n,Integer::sum);return new ItemInstance();}boolean consumeItem(int id,int n){if(!checkItem(id))return false;items.merge(id,-n,Integer::sum);return true;}}
 static class L1PcInstance{int karma;Inventory inv=new Inventory();int getKarmaLevel(){return karma;}Inventory getInventory(){return inv;}void sendPackets(Object p){}}
 '''+methods+'''
 static void ok(boolean b){if(!b)throw new AssertionError();}public static void main(String[]a)throws Exception{AccessoryTest t=new AccessoryTest();L1NpcInstance n=new L1NpcInstance();L1PcInstance p=new L1PcInstance();p.karma=1;t.getBarlogEarring(p,n,"1");t.getBarlogEarring(p,n,"1");ok(p.inv.items.get(21020)==1);p.karma=2;t.getBarlogEarring(p,n,"2");ok(p.inv.items.get(21020)==0&&p.inv.items.get(21021)==1);p.karma=1;t.getBarlogEarring(p,n,"1");ok(p.inv.items.get(21020)==0);
 L1PcInstance bad=new L1PcInstance();bad.karma=1;bad.inv.items.put(21020,1);t.getBarlogEarring(bad,n,"2");ok(bad.inv.items.get(21020)==1&&!bad.inv.checkItem(21021));bad.karma=2;bad.inv.fail=true;t.getBarlogEarring(bad,n,"2");ok(bad.inv.items.get(21020)==1);
 L1PcInstance many=new L1PcInstance();many.karma=1;ExecutorService e=Executors.newFixedThreadPool(8);List<Future<?>> jobs=new ArrayList<>();for(int i=0;i<32;i++)jobs.add(e.submit(()->t.getBarlogEarring(many,n,"1")));for(Future<?>f:jobs)f.get();e.shutdown();ok(many.inv.items.get(21020)==1);
 L1PcInstance am=new L1PcInstance();am.karma=-1;t.getYaheeAmulet(am,n,"1");t.getYaheeAmulet(am,n,"1");ok(am.inv.items.get(20358)==1);System.out.println("PASS actual accessory method extraction: repeat, upgrade, downgrade, karma mismatch, failed create, 32 concurrent requests, amulet replay");}}
'''
 (r/'AccessoryTest.java').write_text(code);compile_run(r,'AccessoryTest')
