package l1j.server.server.model.npc.action;

import java.nio.file.Files;
import java.nio.file.Path;
import java.io.InputStream;
import java.util.HashSet;
import java.util.Set;
import java.util.Properties;
import java.util.logging.Logger;
import l1j.server.server.model.L1Object;
import l1j.server.server.model.Instance.L1NpcInstance;
import l1j.server.server.model.Instance.L1PcInstance;

public final class NpcActionSecurity {
    private static final Set<Integer> PAID_MORPH_NPCS = loadPaidMorphNpcs();
    private NpcActionSecurity() { }
    public static boolean canTalk(L1PcInstance pc, L1Object obj) {
        if (pc == null || pc.isDead() || pc.isGhost() || !(obj instanceof L1NpcInstance)) return false;
        return !((L1NpcInstance) obj).isDead() && pc.getMapId() == obj.getMapId()
                && Math.abs((long) pc.getX() - obj.getX()) <= 6
                && Math.abs((long) pc.getY() - obj.getY()) <= 6;
    }
    public static boolean canAct(L1PcInstance pc, L1Object obj) {
        return canTalk(pc, obj) && pc.getNpcActionContext().allows(obj, System.nanoTime());
    }
    public static boolean allowsPaidMorph(L1NpcInstance npc) {
        return npc != null && PAID_MORPH_NPCS.contains(npc.getNpcTemplate().get_npcId());
    }
    private static Set<Integer> loadPaidMorphNpcs() {
        Path path = Path.of("config/npc-action-security.properties");
        if (!Files.exists(path)) return Set.of();
        Properties p = new Properties();
        try (InputStream in = Files.newInputStream(path)) {
            p.load(in);
            Set<Integer> ids = new HashSet<>();
            for (String token : p.getProperty("paidMorphNpcIds", "").split(",")) {
                if (!token.trim().isEmpty()) {
                    int id = Integer.parseInt(token.trim());
                    if (id <= 0) throw new IllegalArgumentException("NPC id must be positive");
                    ids.add(id);
                }
            }
            return Set.copyOf(ids);
        } catch (Exception failure) {
            Logger.getLogger(NpcActionSecurity.class.getName()).warning("Invalid paidMorphNpcIds; NPC morph disabled: " + failure);
            return Set.of();
        }
    }
}
