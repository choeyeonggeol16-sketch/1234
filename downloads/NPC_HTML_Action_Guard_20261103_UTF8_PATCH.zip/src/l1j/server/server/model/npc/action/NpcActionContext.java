package l1j.server.server.model.npc.action;

import java.lang.ref.WeakReference;
import java.util.concurrent.TimeUnit;

/** One bounded, session-owned dialog and a one-shot server-issued morph menu. */
public final class NpcActionContext {
    private static final long TTL = TimeUnit.MINUTES.toNanos(2);
    private WeakReference<Object> dialog;
    private long dialogStarted;
    private boolean polyPending;
    private long polyStarted;
    public synchronized void clear() { dialog = null; polyPending = false; }
    public synchronized void begin(Object npc, long now) {
        clear(); dialog = new WeakReference<>(npc); dialogStarted = now;
    }
    public synchronized boolean allows(Object npc, long now) {
        if (npc == null || dialog == null || dialog.get() != npc || now - dialogStarted >= TTL) return false;
        return true;
    }
    public synchronized void permitPoly(long now) {
        dialog = null; polyPending = true; polyStarted = now;
    }
    public synchronized boolean consumePoly(long now) {
        boolean allowed = polyPending && now - polyStarted < TTL;
        polyPending = false;
        return allowed;
    }
}
