PSS reconnect read-only check

1. Keep the character logged in while PSS is NOT working.
2. Extract both files together and double-click PSS_Reconnect_Check.cmd.
3. Select PSS2019_trace.txt in the actual game folder.
4. A timestamped PSS_Reconnect_*.txt report is written to the Desktop.

No PID entry or DLL replacement is required. The check records loaded DLL paths,
process IDs, TCP connection states, port settings, and the tail of the trace.
This is a diagnostic tool, not a connection fix. It changes no game/server files.
Trace last-write time is for the whole file; old DLL lines have no per-line timestamps.
Module enumeration may be restricted; an unreadable module does not prove it is absent.
