@echo off
powershell.exe -NoProfile -STA -ExecutionPolicy Bypass -File "%~dp0PSS_Reconnect_Check.ps1"
pause
