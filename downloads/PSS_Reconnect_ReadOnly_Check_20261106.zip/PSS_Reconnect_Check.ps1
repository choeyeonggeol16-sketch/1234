$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Windows.Forms
$picker = New-Object System.Windows.Forms.OpenFileDialog
$picker.Title = 'Select PSS2019_trace.txt from the GAME folder'
$picker.Filter = 'PSS trace|PSS2019_trace.txt|Text files|*.txt'
if ($picker.ShowDialog() -ne 'OK') { exit }
$tracePath = $picker.FileName
$gameDir = Split-Path -Parent $tracePath
$report = New-Object 'System.Collections.Generic.List[string]'
function Add-Line([string]$line) { [void]$report.Add($line) }
Add-Line ('PSS read-only reconnect snapshot: ' + (Get-Date -Format o))
Add-Line 'No files or processes are changed. No packets are sent.'
Add-Line ('Trace: ' + $tracePath)
Add-Line ('Trace last write: ' + (Get-Item -LiteralPath $tracePath).LastWriteTime.ToString('o'))
$dllPath = Join-Path $gameDir 'Pss2019.dll'
if (Test-Path -LiteralPath $dllPath) {
    Add-Line ('DLL SHA256: ' + (Get-FileHash -LiteralPath $dllPath -Algorithm SHA256).Hash)
}
$iniPath = Join-Path $gameDir 'Pss2019.ini'
Add-Line '-- Bridge INI (ports only; other sections omitted) --'
if (Test-Path -LiteralPath $iniPath) {
    $inBridge = $false
    foreach ($line in Get-Content -LiteralPath $iniPath) {
        if ($line -match '^\s*\[([^]]+)\]') { $inBridge = $Matches[1] -ieq 'PssBridge' }
        elseif ($inBridge -and $line -match '^\s*(GamePort|WindowPort)\s*=') { Add-Line $line }
    }
} else { Add-Line 'No INI beside selected trace. DLL defaults: GamePort=5000, WindowPort=5001.' }
Add-Line '-- Processes with Pss2019.dll loaded --'
$gamePids = New-Object 'System.Collections.Generic.List[int]'
foreach ($proc in Get-Process -ErrorAction SilentlyContinue) {
    try {
        $mods = @($proc.Modules | Where-Object { $_.ModuleName -ieq 'Pss2019.dll' })
        if ($mods.Count -eq 0) { continue }
        [void]$gamePids.Add($proc.Id)
        Add-Line ('PID={0} Name={1}' -f $proc.Id, $proc.ProcessName)
        try { Add-Line ('Started: ' + $proc.StartTime.ToString('o')) } catch { }
        foreach ($mod in $mods) { Add-Line ('Loaded DLL: ' + $mod.FileName) }
    } catch { }
}
if ($gamePids.Count -eq 0) {
    Add-Line 'No readable loaded module found. Access restrictions can also cause this result.'
    foreach ($proc in Get-Process -ErrorAction SilentlyContinue) {
        if ($proc.ProcessName -match '(?i)mjlin|lineage|^lin$|^lc$|^l1$') {
            Add-Line ('Candidate PID={0} Name={1}' -f $proc.Id, $proc.ProcessName)
            [void]$gamePids.Add($proc.Id)
        }
    }
}
Add-Line '-- TCP connections for those processes --'
try {
    $connections = @(Get-NetTCPConnection -ErrorAction Stop | Where-Object { $gamePids.Contains([int]$_.OwningProcess) })
    foreach ($conn in $connections) {
        Add-Line ('PID={0} {1}:{2} -> {3}:{4} {5}' -f $conn.OwningProcess, $conn.LocalAddress, $conn.LocalPort, $conn.RemoteAddress, $conn.RemotePort, $conn.State)
    }
    if ($connections.Count -eq 0) { Add-Line 'No TCP rows for selected processes.' }
} catch { Add-Line ('TCP inspection failed: ' + $_.Exception.Message) }
Add-Line '-- Last 70 trace lines (existing DLL writes UTF-16LE) --'
Get-Content -LiteralPath $tracePath -Encoding Unicode -Tail 70 | ForEach-Object { Add-Line $_ }
$desktopPath = [Environment]::GetFolderPath('Desktop')
if ([string]::IsNullOrEmpty($desktopPath)) { $desktopPath = $env:TEMP }
$outPath = Join-Path $desktopPath ('PSS_Reconnect_{0}.txt' -f (Get-Date -Format 'yyyyMMdd_HHmmss_fff'))
$report | Out-File -LiteralPath $outPath -Encoding UTF8
Write-Host ('Report: ' + $outPath)
Write-Host 'Run this while the character is ONLINE and PSS is NOT working.'
