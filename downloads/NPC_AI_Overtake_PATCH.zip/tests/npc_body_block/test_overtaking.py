#!/usr/bin/env python3
"""Production movement and far-overtake bodies with deterministic tile/probe doubles."""
from pathlib import Path
import subprocess,tempfile,shutil
p=Path(__file__).with_name('test_body_block.py');ns={'__file__':str(p)}
exec(p.read_text().split('compiler=')[0],ns)
java=ns['java'];a=java.index(' public static void main(String[] args)')
java=java[:a]+'''
 static L1MonsterInstance far(){
  L1MonsterInstance c=new L1MonsterInstance();c.target=new L1Character();c.target.y=-20;
  c.open[1]=c.open[7]=true;return c;
 }
 public static void main(String[] args){
  L1MonsterInstance c=far();
  check(move(c)==RUNNING&&c.x==1&&c.y==-1,"far rear monster must step forward around leader");
  check(c.consumed==1&&c.fallbacks==0,"one committed step; old lateral fan never used");
  c.open[0]=true;check(move(c)==RUNNING&&c.x==1&&c.y==-2,"resume straight chase after passing lane opens");
  c=far();c.open[1]=false;
  check(move(c)==RUNNING&&c.x==-1&&c.y==-1,"other forward side used when preferred is occupied");
  c=far();c.open[1]=c.open[7]=false;
  check(move(c)==DYNAMIC_BLOCKED&&c.moves==0,"no bypass yields to wander");
  c=far();c.target.y=-8;
  check(move(c)==DYNAMIC_BLOCKED&&c.moves==0,"near crowd still yields to wander");
  c=far();c.staticOpen=false;
  check(move(c)==DYNAMIC_BLOCKED&&c.moves==0,"cannot overtake through wall");
  c=far();c.target.y=20;
  check(move(c)==DYNAMIC_BLOCKED&&c.moves==0,"step increasing target distance rejected");
  c=far();c.target.dead=true;
  check(move(c)==DYNAMIC_BLOCKED&&c.moves==0,"dead target cannot trigger bypass");
  c=far();c.race=true;
  check(move(c)==DYNAMIC_BLOCKED&&c.moves==0,"lost atomic move does not claim success");
  c=far();final L1MonsterInstance moving=c;c.probeHook=()->moving.target.x++;
  check(move(c)==DYNAMIC_BLOCKED&&c.moves==0,"target movement during probe aborts old decision");
  c=far();final L1MonsterInstance retarget=c;c.probeHook=()->retarget.target=new L1Character();
  check(move(c)==DYNAMIC_BLOCKED&&c.moves==0,"retarget during probe aborts old decision");
  c=far();final L1MonsterInstance retired=c;c.probeHook=()->retired.generation++;
  check(move(c)==DYNAMIC_BLOCKED&&c.moves==0,"stale action generation cannot commit");
  c=far();c.action=14;
  check(move(c)==RUNNING&&c.y==-1,"relative chase may overtake at range");
  for(int i=0;i<100;i++){
   c=far();check(move(c)==RUNNING&&c.x==1,"same actor keeps deterministic preferred side");
  }
  System.out.println("PASS far/relative overtaking, both sides, blocked/near/wall cases, strict progress, target/death/generation/commit races and stable preference");
 }
}
'''
with tempfile.TemporaryDirectory() as td:
 f=Path(td)/'BodyBlockContract.java';f.write_text(java)
 subprocess.run([shutil.which('javac') or '/workspace/java-toolchain/bin/javac','--release','21','-d',td,str(f)],check=True)
 subprocess.run(['java','-ea','-cp',td,'BodyBlockContract'],check=True)
