package l1j.server.server.network;
import java.net.*;import java.io.*;import java.util.*;import java.util.concurrent.*;import java.util.concurrent.atomic.*;
public class MonsterBurstTest {
 static void check(boolean b,String m){if(!b)throw new AssertionError(m);}
 static byte[] packet(int n,int size){byte[] b=new byte[size];b[0]=(byte)n;b[1]=(byte)(n>>>8);b[2]=(byte)(n>>>16);b[3]=(byte)(n>>>24);return b;}
 static final class App implements SessionApplication {
  final NettySession session;final CountDownLatch opened;int encodeKey,decodeKey;volatile int received;
  App(NettySession s,CountDownLatch l){session=s;opened=l;}
  public void onOpen(){session.markAuthenticated();opened.countDown();}
  public byte[] encode(byte[] b){int key=++encodeKey;for(int i=0;i<b.length;i++)b[i]^=(byte)key;return b;}
  public byte[] decode(byte[] b){return b;}
  public void onPacket(byte[] b){received++;session.send(b);}
  public void onClosed(CloseReason r){}
 }
 static final class Fixture implements AutoCloseable {
  final AtomicReference<App> app=new AtomicReference<>();final CountDownLatch opened=new CountDownLatch(1);final TransportServer server;final Socket socket=new Socket();int key;
  Fixture(Properties p)throws Exception {server=new TransportServer(new NetworkConfig(p),s->{App a=new App(s,opened);app.set(a);return a;});server.start(new InetSocketAddress("127.0.0.1",0));socket.setSoTimeout(8000);socket.connect(server.localAddress());check(opened.await(3,TimeUnit.SECONDS),"open");}
  NettySession session(){return app.get().session;}
  CountDownLatch holdIo()throws Exception {CountDownLatch entered=new CountDownLatch(1),release=new CountDownLatch(1);session().channel.eventLoop().execute(()->{entered.countDown();try{if(!release.await(5,TimeUnit.SECONDS))throw new AssertionError("hold timeout");}catch(InterruptedException e){Thread.currentThread().interrupt();}});check(entered.await(3,TimeUnit.SECONDS),"hold entered");return release;}
  int read()throws Exception {InputStream in=socket.getInputStream();int lo=in.read(),hi=in.read();check(lo>=0&&hi>=0,"peer closed before frame");int n=lo+(hi<<8)-2;byte[] b=in.readNBytes(n);check(b.length==n,"truncated");int k=++key;for(int i=0;i<b.length;i++)b[i]^=(byte)k;return (b[0]&255)|((b[1]&255)<<8)|((b[2]&255)<<16)|((b[3]&255)<<24);}
  void drained()throws Exception {long end=System.nanoTime()+TimeUnit.SECONDS.toNanos(5);while(server.snapshot().outboundPackets()!=0&&System.nanoTime()<end)Thread.sleep(2);check(server.snapshot().outboundPackets()==0&&server.snapshot().outboundBytes()==0,"outbound budget leak");}
  public void close()throws Exception {socket.close();check(server.awaitDrained(5000),"session cleanup leak "+server.snapshot());server.close();}
 }
 static Properties properties(){Properties p=new Properties();p.setProperty("ioThreads","1");p.setProperty("gameThreads","2");p.setProperty("shutdownMs","5000");return p;}
 static void burst(int bodySize)throws Exception {
  try(Fixture f=new Fixture(properties())){CountDownLatch release=f.holdIo();int accepted=0;try{for(int i=0;i<6000;i++){if(!f.session().send(packet(i,bodySize)))break;accepted++;}}finally{release.countDown();}
   System.out.println("burst accepted="+accepted+" queuedBytes="+f.session().pendingOutboundBytes());check(accepted==6000,"valid monster burst rejected at packet "+accepted);
   for(int i=0;i<6000;i++)check(f.read()==i,"FIFO/cipher mismatch "+i);
   f.drained();check(f.session().isOpen(),"burst closed session");
   f.socket.getOutputStream().write(new byte[]{6,0,42,0,0,0});check(f.read()==42,"game input/echo did not resume");check(f.app.get().received==1,"mailbox progress");f.drained();
   System.out.println("PASS 6000 spawn-sized packets, wire FIFO, stateful codec, input progress, budget reclamation");}
 }
 static void concurrentBurst()throws Exception {
  try(Fixture f=new Fixture(properties())){CountDownLatch release=f.holdIo();ExecutorService pool=Executors.newFixedThreadPool(4);
   try {java.util.List<Future<?>> jobs=new ArrayList<>();for(int p=0;p<4;p++){final int producer=p;jobs.add(pool.submit(()->{for(int i=0;i<1500;i++){byte[] b=packet(producer*1500+i,192);check(f.session().send(b),"concurrent admission");Arrays.fill(b,(byte)0);}}));}for(Future<?> job:jobs)job.get(3,TimeUnit.SECONDS);}finally{release.countDown();pool.shutdownNow();}
   int[] next=new int[4];for(int i=0;i<6000;i++){int n=f.read();check(n>=0&&n<6000,"snapshot corrupted");int p=n/1500;check(n%1500==next[p]++,"producer FIFO");}for(int n:next)check(n==1500,"missing packets");f.drained();check(f.session().isOpen(),"concurrent burst closed");System.out.println("PASS 4 producers / 6000 packets: per-producer FIFO, input snapshot, rolling codec, budgets reclaimed");}
 }
 static void globalLimit()throws Exception {
  Properties p=properties();p.setProperty("globalOutboundPackets","4");try(Fixture f=new Fixture(p)){CountDownLatch release=f.holdIo();try{for(int i=0;i<4;i++)check(f.session().send(packet(i,8)),"global first four");check(!f.session().send(packet(4,8)),"global fifth admitted");}finally{release.countDown();}check(f.server.awaitDrained(5000),"global cleanup");f.drained();check(f.server.snapshot().closes().get(CloseReason.OUTBOUND_OVERLOAD)==1,"global reason");System.out.println("PASS global packet cap and cleanup");}
 }
 static void limit(boolean bytes)throws Exception {
  Properties p=properties();if(bytes){p.setProperty("outboundBytes","65535");p.setProperty("outboundPackets","65536");}else p.setProperty("outboundPackets","4");
  try(Fixture f=new Fixture(p)){CountDownLatch release=f.holdIo();int accepted=0;try{for(int i=0;i<2000;i++){if(!f.session().send(packet(i,bytes?1024:8)))break;accepted++;}}finally{release.countDown();}
   check(accepted==(bytes?63:4),"hard cap not enforced: "+accepted);check(f.session().isClosing(),"overload left open");check(f.server.awaitDrained(5000),"overload cleanup");f.drained();
   check(f.server.snapshot().closes().get(CloseReason.OUTBOUND_OVERLOAD)==1,"close reason");System.out.println("PASS "+(bytes?"byte":"explicit packet")+" cap and cleanup");}
 }
 public static void main(String[] args)throws Exception{switch(args[0]){case "burst"->burst(64);case "spawn"->burst(192);case "concurrent"->concurrentBurst();case "global"->globalLimit();case "bytes"->limit(true);case "packets"->limit(false);default->throw new AssertionError();}}
}
