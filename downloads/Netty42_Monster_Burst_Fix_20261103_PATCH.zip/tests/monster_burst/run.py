"""Compile the actual transport and exercise burst admission over localhost TCP.
Requires Java 21 and the five Netty 4.2.19.Final jars (existing server lib).
"""
from pathlib import Path
import os, subprocess, sys, tempfile
root=Path(__file__).resolve().parents[2]
lib=Path(os.environ.get('NETTY_LIB_DIR',str(root/'lib')))
modules=['common','buffer','transport','resolver','codec-base']
jars=[lib/('netty-'+m+'-4.2.19.Final.jar') for m in modules]
missing=[str(p) for p in jars if not p.is_file()]
if missing:raise SystemExit('Set NETTY_LIB_DIR to the server Netty 4.2.19.Final lib directory. Missing: '+', '.join(missing))
cp=os.pathsep.join(map(str,jars));modes=sys.argv[1:] or ['burst','spawn','concurrent','bytes','packets','global']
logs=root/'test-results'/'monster-burst';logs.mkdir(parents=True,exist_ok=True)
with tempfile.TemporaryDirectory(prefix='netty-monster-tests-') as work:
 subprocess.run([os.environ.get('JAVAC','javac'),'--release','21','-cp',cp,'-d',work,*map(str,(root/'src/l1j/server/server/network').glob('*.java')),str(Path(__file__).with_name('MonsterBurstTest.java'))],check=True)
 for mode in modes:
  r=subprocess.run(['java','-ea','-Dio.netty.leakDetection.level=paranoid','-cp',work+os.pathsep+cp,'l1j.server.server.network.MonsterBurstTest',mode],text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=45)
  (logs/(mode+'.log')).write_text(r.stdout);print(r.stdout,flush=True)
  if r.returncode:raise SystemExit(r.returncode)
print('PASS all requested live-TCP transport tests; full game/DB load is separate.')
