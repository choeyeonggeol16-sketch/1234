#!/usr/bin/env python3
"""Run extracted production movement/resume methods against deterministic occupancy.
No game DB, real NPC scheduler or native-binary behavior is simulated here.
"""
from pathlib import Path
import subprocess,tempfile,sys,shutil
root=Path(__file__).resolve().parents[2]
base=root/'src/l1j/server/server/model/npc/ai/action'
if '--baseline-dir' in sys.argv:
 base=Path(sys.argv[sys.argv.index('--baseline-dir')+1])
def method(file,name):
 s=(base/file).read_text();a=s.index('    private static '+('byte' if name=='moveCreature' else 'boolean')+' '+name+'(');b=s.index('{',a);depth=0
 for i in range(b,len(s)):
  if s[i]=='{':depth+=1
  elif s[i]=='}':
   depth-=1
   if not depth:return s[a:i+1]
 raise AssertionError(name)
java=r'''
class BodyBlockContract {
 static final byte RUNNING=0,DYNAMIC_BLOCKED=4;
 static final long CALC_MID_MIN_MS=100;
 static final int BLOCKED_RING_RECHECK_RADIUS=12;
 static class L1Character {int x,y; int getX(){return x;}int getY(){return y;}}
 static class L1NpcInstance extends L1Character {
  int _moveCollision,_moveHeading,_moveSide;byte action=6;
  boolean clear,contact=true,race,invalid,atAttack;int moves,fallbacks,consumed,sleeps;
  int getMapId(){return 1;}int getId(){return 5;}int getSleepTime(){return sleeps;}
 }
 static class L1MonsterInstance extends L1NpcInstance {
  int ranged=1;Template getNpcTemplate(){return new Template(ranged);}
  boolean isAttackPosition(L1Character t,int r){return atAttack;}
 }
 record Template(int value){int get_ranged(){return value;}}
 static class CCreatureController {
  static final byte ACTION_MOVE_TO_TARGET=6,ACTION_MOVE_TO_TARGET_RELATIVE=14;
 }
 static class ActionAccess {
  static byte currentAction(L1NpcInstance c){return c.action;}
  static boolean moveOneStep(L1NpcInstance c,int h){if(c.race)return false;c.y--;c.moves++;return true;}
  static void sleep(L1NpcInstance c,long ms){c.sleeps=(int)ms;}
 }
 static L1NpcInstance active;
 static class WorldCollisionHash {
  long moveCreatureProbe(short map,int x,int y,int h,int vx,int vy,int id){return (active.clear?1:0)|(active.contact?2:0);}
  static boolean moveProbeCanMove(long p){return (p&1)!=0;}
  static boolean moveProbeCollided(long p){return (p&2)!=0;}
  static int moveProbeBlockType(long p){return 2;}
  static int moveProbeBlockerId(long p){return 9;}
  static int moveProbeResponseHeading(long p){return 2;}
  static boolean moveProbeDegenerate(long p){return false;}
 }
 static final WorldCollisionHash COLLISION=new WorldCollisionHash();
 static final int[] DX={0,1,1,1,0,-1,-1,-1},DY={-1,-1,0,1,1,1,0,-1};
 static boolean validHeading(int h){return h>=0&&h<8;}
 static int segmentVectorX(L1NpcInstance c){return 0;}
 static int segmentVectorY(L1NpcInstance c){return -1;}
 static boolean debugTraceActor(L1NpcInstance c){return false;}
 static boolean claimDebugTraceActor(L1NpcInstance c){return false;}
 static void consumeSegmentStep(L1NpcInstance c){c.consumed++;}
 static void clearCollisionResponse(L1NpcInstance c){c._moveCollision=0;c._moveHeading=-1;}
 static void applyMoveCreatureResult(L1NpcInstance c,long p,int h,boolean d){c._moveCollision=WorldCollisionHash.moveProbeCollided(p)?1:0;}
 static boolean tryCollisionResolvedMove(L1NpcInstance c,int h,int r,int id,boolean d){
  c.x=c.x==0?1:0;c.fallbacks++;c.moves++;return true;
 }
 static void storeCollisionResponse(L1NpcInstance c,int r,boolean d){c._moveCollision=1;c._moveHeading=r;}
 static long repeatedCollisionDelay(L1NpcInstance c){return 300;}
 static class CDesirePQ {
  static final byte BLOCKED_ATTACK_LANE=1;
  static byte mode=1;static int released;static L1Character target=new L1Character();
  static L1Character blockedAttackTarget(L1MonsterInstance m){return target;}
  static void releaseBlockedAttack(L1MonsterInstance m){released++;}
  static byte blockedAttackMode(L1MonsterInstance m){return mode;}
 }
 static boolean laneOpen,reachable=true;static int scans;
 static boolean validDirectionTarget(L1MonsterInstance m,L1Character t){return t!=null&&!m.invalid;}
 static boolean claimReachableMeleeSlot(L1MonsterInstance m,L1Character t){scans++;return reachable;}
 static boolean isBlockedAttackLaneOpen(L1MonsterInstance m){return laneOpen;}
 static int chebyshev(int x,int y,int tx,int ty){return Math.max(Math.abs(x-tx),Math.abs(y-ty));}
''' + method('SetMoving.java','moveCreature')+method('CMoveAroundAction.java','tryResumeBlockedAttack')+r'''
 static void check(boolean c,String why){if(!c)throw new AssertionError(why);}
 static byte move(L1NpcInstance c){active=c;return moveCreature(c,0);}
 public static void main(String[] args){
  for(byte action:new byte[]{6,14})for(boolean previous:new boolean[]{false,true}){
   L1MonsterInstance c=new L1MonsterInstance();c.action=action;c._moveCollision=previous?1:0;c._moveHeading=2;
   for(int n=0;n<100;n++)check(move(c)==DYNAMIC_BLOCKED,"body-blocked chase must yield to wander");
   check(c.moves==0&&c.fallbacks==0&&c._moveSide==0,"no lateral ping-pong; correct blocked tile heading");
  }
  L1MonsterInstance clear=new L1MonsterInstance();clear.clear=true;
  check(move(clear)==RUNNING&&clear.moves==1,"enterable side contact must still move");
  L1MonsterInstance reservation=new L1MonsterInstance();reservation.contact=false;
  check(move(reservation)==RUNNING&&reservation.moves==0&&reservation.sleeps==100,"reservation race keeps retry policy");
  L1MonsterInstance wander=new L1MonsterInstance();wander.action=12;
  check(move(wander)==RUNNING&&wander.fallbacks==1,"wander collision behavior preserved");
  L1NpcInstance pet=new L1NpcInstance();
  check(move(pet)==RUNNING&&pet.fallbacks==1,"other NPC collision behavior preserved");
  L1MonsterInstance m=new L1MonsterInstance();
  laneOpen=false;reachable=false;scans=0;CDesirePQ.mode=1;
  for(int n=0;n<100;n++)check(!tryResumeBlockedAttack(m),"no current route retains wander");
  check(scans==100,"current reachability is checked instead of old tile gate");
  reachable=true;check(tryResumeBlockedAttack(m),"side route reopens despite occupied old tile");
  reachable=false;laneOpen=true;int released=CDesirePQ.released;
  m.x=9;check(!tryResumeBlockedAttack(m)&&CDesirePQ.released==released,"9-12 tile melee recovery requires a complete route");
  m.x=0;CDesirePQ.mode=2;reachable=true;
  check(tryResumeBlockedAttack(m),"full-ring recovery retains ring occupancy policy");
  m.x=20;CDesirePQ.mode=1;laneOpen=false;
  check(!tryResumeBlockedAttack(m),"blocked current first step retains long chase wander");
  laneOpen=true;check(tryResumeBlockedAttack(m),"clear current first step restores long chase");m.x=0;
  m.atAttack=true;int before=CDesirePQ.released;
  check(tryResumeBlockedAttack(m)&&CDesirePQ.released==before+1,"already attackable enemy resumes immediately");
  m.atAttack=false;m.invalid=true;before=CDesirePQ.released;
  check(!tryResumeBlockedAttack(m)&&CDesirePQ.released==before+1,"invalid target releases block without interrupting wander");
  System.out.println("PASS body-blocked/relative/repeated chase, side contact, reservation race, pet, wander, closed/open lane, ring and invalid-target recovery");
 }
}
'''
compiler=shutil.which('javac') or '/workspace/java-toolchain/bin/javac'
with tempfile.TemporaryDirectory() as td:
 p=Path(td)/'BodyBlockContract.java';p.write_text(java)
 subprocess.run([compiler,'--release','21','-d',td,str(p)],check=True)
 subprocess.run(['java','-ea','-cp',td,'BodyBlockContract'],check=True)
