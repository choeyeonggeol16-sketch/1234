import com.sun.source.util.JavacTask;
import javax.tools.*;
import java.nio.file.*;
import java.util.*;
public final class ParseSources {
    public static void main(String[] args) throws Exception {
        var compiler = ToolProvider.getSystemJavaCompiler();
        var diagnostics = new DiagnosticCollector<JavaFileObject>();
        try (var files = Files.walk(Path.of(args[0]));
             var manager = compiler.getStandardFileManager(diagnostics, null, java.nio.charset.StandardCharsets.UTF_8)) {
            var paths = files.filter(p -> p.toString().endsWith(".java")).toList();
            var units = manager.getJavaFileObjectsFromPaths(paths);
            JavacTask task = (JavacTask) compiler.getTask(null, manager, diagnostics,
                    List.of("-proc:none", "-encoding", "UTF-8", "-source", "21"), null, units);
            int parsed = 0;
            for (var ignored : task.parse()) parsed++;
            int errors = 0;
            for (var diagnostic : diagnostics.getDiagnostics()) {
                if (diagnostic.getKind() == Diagnostic.Kind.ERROR) {
                    errors++;
                    System.err.println(diagnostic);
                }
            }
            System.out.println("Java syntax parse: sources=" + parsed + " errors=" + errors);
            if (errors != 0 || parsed != paths.size()) System.exit(1);
        }
    }
}
