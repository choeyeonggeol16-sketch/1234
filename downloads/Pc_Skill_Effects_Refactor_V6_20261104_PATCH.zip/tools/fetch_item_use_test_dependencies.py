#!/usr/bin/env python3
"""Fetch the optional JAXB test runtime; production dependencies are unchanged."""
from pathlib import Path
import hashlib, json, os, urllib.request

root=Path(__file__).resolve().parents[1]
target=Path(os.environ.get('ITEM_TEST_DEPS_DIR',str(root/'lib-test')))
target.mkdir(parents=True,exist_ok=True)
for entry in json.loads((root/'tools/item_use_test_dependencies.json').read_text()):
    path=target/entry['file']
    if path.exists() and hashlib.sha256(path.read_bytes()).hexdigest()==entry['sha256']:
        continue
    data=urllib.request.urlopen(entry['url'],timeout=45).read()
    if hashlib.sha256(data).hexdigest()!=entry['sha256']:
        raise SystemExit('Dependency checksum mismatch: '+entry['file'])
    path.write_bytes(data)
print('PASS optional JAXB test dependencies verified')
