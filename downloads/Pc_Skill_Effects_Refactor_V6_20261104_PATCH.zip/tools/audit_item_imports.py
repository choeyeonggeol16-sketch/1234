#!/usr/bin/env python3
"""Compare all unaffected V4 implementations, excluding import declarations only."""
from pathlib import Path
import argparse, hashlib, re, json

p=argparse.ArgumentParser();p.add_argument('--baseline',type=Path,required=True);args=p.parse_args()
root=Path(__file__).resolve().parents[1]
before=args.baseline/'src';after=root/'src'
old={str(f.relative_to(before)):f for f in before.rglob('*.java')}
new={str(f.relative_to(after)):f for f in after.rglob('*.java')}
assert set(old)<=set(new),'source file deleted'
learning={'l1j/server/server/model/item/function/'+name+'.java' for name in ['ItemUsePassiveLearning','ItemUseSkillLearning']}
changed=[];unchanged=0;import_only=[]
def strip_imports(text):return re.sub(r'(?m)^\s*import\s+(?:static\s+)?[\w.*]+\s*;[^\S\n]*\n?','',text)
for rel,path in old.items():
    left=path.read_text();right=new[rel].read_text()
    if left==right:unchanged+=1
    else:
        changed.append(rel)
        if rel not in learning:
            assert strip_imports(left)==strip_imports(right),'Executable source changed: '+rel
            import_only.append(rel)
added=sorted(set(new)-set(old))
assert added==['l1j/server/server/model/item/function/ItemLearningRule.java'],added
report={'baseline':'published V4 532c1ee FULL_SRC','baseline_sources':len(old),'sources':len(new),
    'byte_identical':unchanged,'import_only':import_only,'changed':sorted(changed),'added':added,
    'sha256':{rel:hashlib.sha256(new[rel].read_bytes()).hexdigest() for rel in changed+added}}
(root/'validation/source_manifest.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
print('PASS source boundary:',len(old),'baseline files;',unchanged,'byte-identical;',len(import_only),'import-only; 2 learning implementations changed; 1 new policy class; no deletions')
