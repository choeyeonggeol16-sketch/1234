#!/usr/bin/env python3
"""Drop unused named imports and redundant same-package/self imports only."""
from pathlib import Path
import re, json

root=Path(__file__).resolve().parents[1]
folder=root/'src/l1j/server/server/model/item/function'
tokens=re.compile(r'"(?:\\.|[^"\\])*"|\'(?:\\.|[^\'\\])*\'|//[^\n]*|/\*[\s\S]*?\*/|[^\W\d]\w*|.',re.DOTALL|re.UNICODE)
changes={}
for path in sorted(folder.glob('*.java')):
    source=path.read_text()
    package=re.search(r'\bpackage\s+([\w.]+)\s*;',source).group(1)
    imports=list(re.finditer(r'(?m)^\s*import\s+(static\s+)?([\w.*]+)\s*;[^\S\n]*\n?',source))
    body=source
    for match in reversed(imports):body=body[:match.start()]+body[match.end():]
    identifiers={m.group() for m in tokens.finditer(body) if re.fullmatch(r'[^\W\d]\w*',m.group(),re.UNICODE)}
    removed=[]
    for match in reversed(imports):
        name=match[2];static=bool(match[1]);owner,_,short=name.rpartition('.')
        redundant=(not static and owner==package) or (static and owner==package+'.'+path.stem)
        unused=short!='*' and short not in identifiers
        if redundant or unused:
            source=source[:match.start()]+source[match.end():];removed.append(match.group().strip())
    if removed:
        # Class/method text is deliberately not reformatted by this tool.
        path.write_text(source);changes[path.name]=list(reversed(removed))
(root/'validation/import_cleanup.json').write_text(json.dumps(changes,ensure_ascii=False,indent=2))
print('Removed',sum(map(len,changes.values())),'imports in',len(changes),'item implementation files.')
