#!/usr/bin/env python3
"""Real desire heap/factory, event drain, CIO preflight and attack methods.
World, actor, skill, collision and scheduler edges are deterministic test doubles.
No game client or database is started. --baseline-root compares the pre-fix source.
"""
from pathlib import Path
import argparse,re,subprocess,tempfile
root=Path(__file__).resolve().parents[2]
p=argparse.ArgumentParser();p.add_argument('--baseline-root',type=Path);args=p.parse_args()
base=(args.baseline_root or root)/'src/l1j/server/server/model'
def method(s,signature):
 a=s.index(signature);b=s.index('{',a);depth=1;i=b+1
 while depth:
  if s[i]=='{':depth+=1
  elif s[i]=='}':depth-=1
  i+=1
 return s[a:i]
def nested(s,name):
 s=re.sub(r'(?m)^(package|import) [^\n]+\n','',s)
 return s.replace('public final class '+name,'static final class '+name)
runtime=(base/'npc/ai/action/AiRuntime.java').read_text()
pq=(base/'npc/ai/CDesirePQ.java').read_text();factory=(base/'npc/ai/CDesireFactory.java').read_text();controller=(base/'npc/ai/action/CCreatureController.java').read_text();npc=(base/'Instance/L1NpcInstance.java').read_text()
java=r'''
import java.util.*;import java.util.concurrent.*;import java.util.concurrent.atomic.*;
import java.util.concurrent.ThreadLocalRandom;import java.util.logging.*;
public class AttackRetargetContract {
 static int passed,failed;
 static void check(boolean ok,String why){if(!ok)throw new AssertionError(why);}
 static void run(String name,Runnable r){try{r.run();passed++;System.out.println("PASS "+name);}catch(Throwable e){failed++;System.out.println("FAIL "+name+": "+e);}}
 static class L1Object {int id;int getId(){return id;}}
 static class L1Character extends L1Object {
  int x=20,y=20,map=1,hp=1000;boolean dead,invisible;
  int getX(){return x;}int getY(){return y;}int getMapId(){return map;}int getCurrentHp(){return hp;}boolean isDead(){return dead;}boolean isInvisble(){return invisible;}int get_Summonre(){return 0;}
 }
 static class Template {boolean agro,coi;int ranged=1;boolean is_agro(){return agro;}boolean is_agrocoi(){return coi;}int get_ranged(){return ranged;}}
 interface Special {boolean tick(L1NpcInstance n);}
 static class HateList {
  Map<L1Character,Integer> values=new LinkedHashMap<>();boolean containsKey(L1Character c){return values.containsKey(c);}void add(L1Character c,int n){values.merge(c,n,Integer::sum);}void remove(L1Character c){values.remove(c);}
  L1Character getMaxHateCharacter(){L1Character best=null;int value=Integer.MIN_VALUE;for(var e:values.entrySet())if(e.getValue()>value){best=e.getKey();value=e.getValue();}return best;}
 }
 static class L1NpcInstance extends L1Character {
  static final int HIDDEN_STATUS_NONE=0,HATE_EVENT_SIGHT=0x7ffffffe,HATE_EVENT_INVISIBILITY=0x7ffffffd;
  static final int HATE_EVENT_ATTACKED_TAG=0x7d000000,HATE_EVENT_CLAN_TAG=0x7c000000,HATE_EVENT_DAMAGE_TAG_MASK=0xff000000,HATE_EVENT_DAMAGE_VALUE_MASK=0x00ffffff;
  private static final AtomicReferenceFieldUpdater<L1NpcInstance,L1Character> NPC_CHASE_RETARGET=AtomicReferenceFieldUpdater.newUpdater(L1NpcInstance.class,L1Character.class,"_npcChaseRetarget");
  private volatile L1Character _npcChaseRetarget;private int _npcActionCadenceOwned=1;
  final ConcurrentLinkedQueue<HateEvent> _hateQueue=new ConcurrentLinkedQueue<>();final HateList _hateList=new HateList(),_dropHateList=new HateList();
  final AtomicBoolean _castingSkill=new AtomicBoolean();L1Character _target,master;Special _special;final Template template=new Template();
  byte action=7;long _nextAllowedTickMs=1000,sleep;int submitted,heading,paralysis,hidden;boolean firstAttack,destroyed,paralyzed,sleeping,freeze,condition,movable=true,rest;
  final List<Integer> attacks=new ArrayList<>();
  L1Character getTarget(){return _target;}Template getNpcTemplate(){return template;}int getMaxHp(){return 1000;}int getNpcId(){return 1;}
  boolean isFirstAttack(){return firstAttack;}void setFirstAttack(boolean b){firstAttack=b;}boolean isDestroyed(){return destroyed;}int getHiddenStatus(){return hidden;}
  int getParalysisTime(){return paralysis;}void setParalysisTime(int n){paralysis=n;}void setParalyzed(boolean b){paralyzed=b;}boolean isParalyzed(){return paralyzed;}boolean isSleeped(){return sleeping;}boolean hasSkillEffect(int id){return freeze;}
  void setSleepTime(long n){sleep=n;}boolean checkCondition(){return condition;}void checkTarget(){}void mobTeleport(){}void onItemUse(){}boolean isMovable(){return movable;}boolean isRest(){return rest;}L1Character getMaster(){return master;}void deleteMe(){destroyed=true;}
  boolean isAttackPosition(L1Character c,int r){return c.map==map&&Math.max(Math.abs(x-c.x),Math.abs(y-c.y))<=r;}
  int targetDirection(int tx,int ty){if(tx==x)return ty<y?0:4;if(ty==y)return tx>x?2:6;return tx>x?(ty<y?1:3):(ty<y?7:5);}
  void setHeading(int n){heading=n;}void attackTarget(L1Character c){attacks.add(c.id);sleep=1000;}void tagertClear(){_target=null;}
'''+'\n'.join(method(npc,s) for s in ['public final boolean npcActionOwnsCadence()', 'public final void npcActionClaimCadence()', 'public final void npcActionReleaseCadence()', 'public final void npcChaseRetargetRequest(', 'public final L1Character npcChaseRetargetConsume()', 'public static boolean isAttackHateEvent(', 'public static boolean isClanHateEvent(', 'public static int eventDamage('])+r'''
 }
 static class L1MonsterInstance extends L1NpcInstance {
  CDesirePQ _desirePQ;boolean _desireDeferredSight;long _desireCreatedAtMs=-10000,_desireMoveAroundDecisionAtMs;
  byte _desireBlockedAttackMode;int _desireBlockedAttackTargetId,_desireBlockedLanePos,_desireMoveAroundCounter,_desireMoveAroundTargetX,_desireMoveAroundTargetY,_desireMoveAroundWaitKind,_desireResumeAttackBlockedRetries,_desireResumeAttackMapId,_desireResumeAttackPos,_desireResumeAttackTargetId,_desireResumeAttackTargetPos,_randomMoveDirection,_randomMoveDistance;
 }
 static class L1SummonInstance extends L1NpcInstance {}
 static class L1CompanionInstance extends L1NpcInstance {L1Character get_master(){return master;}}
 static class L1PcInstance extends L1Character {}
 static class L1World {static final L1World INSTANCE=new L1World();final Map<Integer,L1Object> objects=new HashMap<>();static L1World getInstance(){return INSTANCE;}L1Object findObject(int id){return objects.get(id);}boolean hasRecognizePlayerFast(L1NpcInstance n){return true;}}
 static class WorldCollisionHash {static final WorldCollisionHash INSTANCE=new WorldCollisionHash();static WorldCollisionHash getInstance(){return INSTANCE;}void cancelNpcMove(int map,int x,int y,int id){}}
 static class NpcServer {static final NpcServer INSTANCE=new NpcServer();static NpcServer getInstance(){return INSTANCE;}void wake(L1NpcInstance n){}}
 static class HateEvent {L1Character cha;int hate;static int recycled;HateEvent(L1Character c,int h){cha=c;hate=h;}static void release(HateEvent e){recycled++;}}
 static class NpcEventFactory {static boolean isSightTargetCandidate(L1NpcInstance n,L1Character c,long t){return true;}static L1Character findInvisibilityRetarget(L1MonsterInstance n,L1Character c){return null;}}
 static class L1SkillId {static final int STATUS_FREEZE=1;}
 static class ActionAccess {static byte currentAction(L1NpcInstance n){return n.action;}}
 static class SetMoving {static void clear(L1NpcInstance n){}}
 static class CMoveToTargetWaitAction {static void clear(L1NpcInstance n){}}
 static class CMoveToTargetAction {static void clearBlocked(L1NpcInstance n){}}
 static class CSkillAction {static boolean tryUse(L1NpcInstance n,L1Character c){return false;}}
 static class CCreatureController {
'''+ '\n'.join(re.findall(r'public static final byte [^;]+;',controller))+method(controller,'public static boolean isCombatAction(')+r'''
  static void submit(L1NpcInstance n,byte a){n.submitted++;}static void set(L1NpcInstance n,byte a){n.action=a;}static void think(L1NpcInstance n){n.action=ACTION_THINK;}
 }
'''+nested(pq,'CDesirePQ')+nested(factory,'CDesireFactory')+nested((base/'npc/ai/action/CAttackAction.java').read_text(),'CAttackAction')+r'''
 static class AiRuntime {
  static final Logger LOG=Logger.getLogger("retarget-test");
  static final byte PRE_EXECUTE=0,PRE_WAIT=1,PRE_RETHINK=2,PRE_STOP=3;
'''+ '\n'.join(method(runtime,sig) for sig in ['private static boolean drainHate(', 'public static byte beforeActionTick(', 'private static boolean notContinued(', 'private static boolean interruptMoveAroundOnHit(', 'private static boolean canMoveAround(', 'private static void stopMoveAroundRuntime('] + (['private static boolean acceptsCombatRetarget('] if 'private static boolean acceptsCombatRetarget(' in runtime else []))+r'''
 }
 static class Scene {
  final L1MonsterInstance n=new L1MonsterInstance();final L1PcInstance a=new L1PcInstance(),b=new L1PcInstance(),c=new L1PcInstance();
  Scene(){n.id=99;a.id=1;b.id=2;c.id=3;a.y=19;b.y=21;c.x=21;n._target=a;
   for(var x:new L1Object[]{n,a,b,c})L1World.INSTANCE.objects.put(x.id,x);
   CDesirePQ.addSightAttack(n,a,0);check(CDesirePQ.topAttackTarget(n,0)==a,"initial A");n._hateList.add(a,10);
   check(n.isAttackPosition(a,1)&&n.isAttackPosition(b,1),"A and B must both be reachable without moving");
  }
  void hit(L1Character by,int damage){n._hateQueue.offer(new HateEvent(by,L1NpcInstance.HATE_EVENT_ATTACKED_TAG|damage));}
  void drain(long now){AiRuntime.drainHate(n,now);}
  byte due(){return AiRuntime.beforeActionTick(n,1000);}
  void attackAfterRethink(){n.npcActionReleaseCadence();n._target=CDesirePQ.topAttackTarget(n,1000);n.action=CCreatureController.ACTION_ATTACK;CAttackAction.onTick(n,n._target);}
 }
 public static void main(String[] args){
  run("one-tile melee: B wins desire, owner turns and attacks B",()->{Scene s=new Scene();s.hit(s.b,300);s.drain(100);check(CDesirePQ.topAttackTarget(s.n,100)==s.b,"real desire heap must prefer B");check(s.n._target==s.a&&s.n.attacks.isEmpty()&&s.n.submitted==0&&s.n._nextAllowedTickMs==1000,"hit bypassed attack cadence");check(s.due()==AiRuntime.PRE_RETHINK&&s.n._target==s.b,"ATTACK never hands off to winning B");s.attackAfterRethink();check(s.n.attacks.equals(List.of(2))&&s.n.heading==4,"must face south and hit B without moving");});
  run("low hate is not forced last-attacker targeting",()->{Scene s=new Scene();s.hit(s.b,1);s.drain(100);check(s.due()==AiRuntime.PRE_EXECUTE&&s.n._target==s.a,"low priority hit stole A");CAttackAction.onTick(s.n,s.n._target);check(s.n.attacks.equals(List.of(1)),"wrong low-hate attack");});
  run("repeated small hits can overtake A while NPC stands still",()->{Scene s=new Scene();for(int i=0;i<26;i++){s.hit(s.b,10);s.drain(100+i);}check(s.n._target==s.a&&s.n.attacks.isEmpty(),"early side effect");check(s.due()==AiRuntime.PRE_RETHINK&&s.n._target==s.b,"accumulated B priority ignored");s.attackAfterRethink();check(s.n.attacks.equals(List.of(2)),"accumulated B never attacked");});
  run("all three existing chase handoffs remain",()->{for(byte action:new byte[]{6,11,14}){Scene s=new Scene();s.n.action=action;s.hit(s.b,300);s.drain(100);check(s.due()==AiRuntime.PRE_RETHINK&&s.n._target==s.b,"chase handoff broke: "+action);}});
  run("later C winner replaces queued B, no intermediate bonus attack",()->{Scene s=new Scene();s.hit(s.b,300);s.drain(100);s.hit(s.c,700);s.drain(110);check(s.n._target==s.a&&s.n.attacks.isEmpty(),"event applied mid-tick");check(s.due()==AiRuntime.PRE_RETHINK&&s.n._target==s.c,"latest desire winner lost");s.attackAfterRethink();check(s.n.attacks.equals(List.of(3)),"obsolete B attacked");});
  run("A retakes priority before due tick and cancels stale B request",()->{Scene s=new Scene();s.hit(s.b,300);s.drain(100);s.hit(s.a,900);s.drain(110);check(s.due()==AiRuntime.PRE_EXECUTE&&s.n._target==s.a,"stale B applied");});
  run("dead pending B is never attacked",()->{Scene s=new Scene();s.hit(s.b,300);s.drain(100);s.b.dead=true;check(s.due()==AiRuntime.PRE_EXECUTE&&s.n._target==s.a,"dead B installed");});
  run("different-map pending B is never installed",()->{Scene s=new Scene();s.hit(s.b,300);s.drain(100);s.b.map=2;check(s.due()==AiRuntime.PRE_EXECUTE&&s.n._target==s.a,"different map B installed");});
  run("invisible pending B respects monster detection",()->{Scene s=new Scene();s.hit(s.b,300);s.drain(100);s.b.invisible=true;check(s.due()==AiRuntime.PRE_EXECUTE&&s.n._target==s.a,"undetectable B installed");s=new Scene();s.n.template.coi=true;s.hit(s.b,300);s.drain(100);s.b.invisible=true;check(s.due()==AiRuntime.PRE_RETHINK&&s.n._target==s.b,"detectable B refused");});
  run("casting and freeze delay handoff without losing request",()->{for(boolean cast:new boolean[]{false,true}){Scene s=new Scene();s.hit(s.b,300);s.drain(100);s.n._castingSkill.set(cast);s.n.freeze=!cast;check(s.due()==AiRuntime.PRE_WAIT&&s.n._target==s.a,"retarget bypassed cast/freeze");s.n._castingSkill.set(false);s.n.freeze=false;check(s.due()==AiRuntime.PRE_RETHINK&&s.n._target==s.b,"delayed request lost");}});
  run("escape and explicit skill actions keep targeting contract",()->{for(byte action:new byte[]{8,13}){Scene s=new Scene();s.n.action=action;s.hit(s.b,300);s.drain(100);check(s.due()==AiRuntime.PRE_EXECUTE&&s.n._target==s.a&&s.n.npcChaseRetargetConsume()==null,"protected action retargeted");}});
  run("blocked B desire is not handed off",()->{Scene s=new Scene();s.n._desireBlockedAttackTargetId=s.b.id;s.hit(s.b,300);s.drain(100);check(s.due()==AiRuntime.PRE_EXECUTE&&s.n._target==s.a,"blocked attack installed");});
  run("dead actor cannot consume handoff or attack",()->{Scene s=new Scene();s.hit(s.b,300);s.drain(100);s.n.dead=true;check(s.due()==AiRuntime.PRE_STOP&&s.n._target==s.a&&s.n.attacks.isEmpty(),"dead NPC continued");});
  run("zero damage and loot-hate bookkeeping are preserved",()->{Scene s=new Scene();s.hit(s.b,0);s.drain(100);check(s.n._hateList.containsKey(s.b)&&s.n._dropHateList.containsKey(s.b),"zero damage event lost");check(s.due()==AiRuntime.PRE_EXECUTE&&s.n._target==s.a,"zero damage forced switch");});
  run("early deferred sight cannot hide ATTACKED behind it",()->{Scene s=new Scene();s.n._desireCreatedAtMs=0;s.n.template.agro=true;s.n._hateQueue.offer(new HateEvent(s.a,L1NpcInstance.HATE_EVENT_SIGHT));s.hit(s.b,300);s.drain(100);check(s.n._desireDeferredSight&&s.n._hateQueue.size()==1,"early sight queue contract");check(s.due()==AiRuntime.PRE_RETHINK&&s.n._target==s.b,"B hidden behind early sight");});
  System.out.println("RESULT passed="+passed+" failed="+failed);if(failed!=0)throw new AssertionError("retarget regressions failed="+failed);
 }
}
'''
# Flatten one fully qualified actor type alongside the test's nested doubles.
java=java.replace('l1j.server.server.model.Instance.L1PcInstance','L1PcInstance')
with tempfile.TemporaryDirectory() as td:
 d=Path(td);source=d/'AttackRetargetContract.java';source.write_text(java)
 subprocess.run(['java','-m','jdk.compiler/com.sun.tools.javac.Main','-source','21','-target','21','-encoding','UTF-8','-d',td,str(source)],check=True)
 subprocess.run(['java','-ea','-cp',td,'AttackRetargetContract'],check=True,timeout=30)
