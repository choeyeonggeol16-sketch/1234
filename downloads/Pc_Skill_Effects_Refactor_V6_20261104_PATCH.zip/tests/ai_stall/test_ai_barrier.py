import re, subprocess, pathlib, textwrap
ROOT=pathlib.Path(__file__).resolve().parents[2]
s=(ROOT/'src/l1j/server/server/model/character/action/CCreatureController.java').read_text()
methods=['ReconcileSight','requestSightRefresh','executeOrPublish','signalAndDrain','drainExecutables']
def method(name):
    mt=re.search(r'(?m)^    (?:public|private) [^;\n]*\b'+re.escape(name)+r'\(',s)
    assert mt,name
    p=s.index('{',mt.start()); depth=1; j=p+1
    while depth:
      if s[j]=='{':depth+=1
      elif s[j]=='}':depth-=1
      j+=1
    return s[mt.start():j]
code='''
import java.lang.invoke.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.*;
import java.util.concurrent.locks.LockSupport;
import java.util.logging.*;
public class ControllerHarness {
    static class L1Object { int getClusterMapId(){return 1;} }
    static class L1PcInstance extends L1Object {
      final int stamp; volatile int refreshed=0; volatile int sighted=0;
      L1PcInstance(int stamp){this.stamp=stamp;}
      int getSessionStamp(){return stamp;}
      void refreshSight(){refreshed++;}
      void reconcileSight(L1Object observed){sighted++;}
      void outOfSight(L1Object observed) { sighted++; }
    }
    private static final Logger EXECUTION_LOG=Logger.getLogger(ControllerHarness.class.getName());
    private static final int EXECUTION_SLOTS=32, EXECUTION_MASK=31, EXECUTION_LIMIT=24, EXECUTION_WORDS=8;
    private static final int EXEC_ACTION=1, EXEC_TIMER=2, EXEC_RESET=3, EXEC_HEADING=4,
     EXEC_SKILL_EFFECT=5, EXEC_SKILL_HEARTBEAT=6, EXEC_TELEPORT=7,
     EXEC_ITEM_DELAY=8, EXEC_SIGHT=9, EXEC_WHEEL_PC=10, EXEC_REGEN_RESET=11, EXEC_CANCELLED=0;
    private static final VarHandle EXEC_TAIL, EXEC_WORK, EXEC_SIGHT_REFRESH;
    private static final VarHandle EXEC_READY=MethodHandles.arrayElementVarHandle(long[].class);
    static {
        try {
         MethodHandles.Lookup lookup=MethodHandles.lookup();
         EXEC_TAIL=lookup.findVarHandle(ControllerHarness.class,"executionTail",long.class);
         EXEC_WORK=lookup.findVarHandle(ControllerHarness.class,"executionWork",int.class);
         EXEC_SIGHT_REFRESH=lookup.findVarHandle(ControllerHarness.class,"sightRefreshIdentity",long.class);
        } catch(ReflectiveOperationException ex){throw new ExceptionInInitializerError(ex);}
    }
    private final long[] executionWords=new long[32*8];
    private final Object[] executionRefs=new Object[64];
    private final long[] executionReady=new long[32];
    private volatile long executionTail,executionHead;
    private volatile int executionWork;
    private volatile long sightRefreshIdentity;
    private volatile Thread executionThread,executionWaiter;
    private volatile L1PcInstance actor;
    private volatile int actorEpoch=2;
    final CountDownLatch gateEntered=new CountDownLatch(1), releaseGate=new CountDownLatch(1);
    final AtomicInteger actions=new AtomicInteger(), orderedSight=new AtomicInteger();
    ControllerHarness(L1PcInstance pc){actor=pc;}
    public boolean AddAction(int id) {
      final L1PcInstance pc=actor; final int epoch=actorEpoch;
      return executeOrPublish(EXEC_ACTION,id,0,0,0,0,0L,0L,0,null,null,pc.stamp,epoch);
    }
    private void executeDirect(int kind,int action,int a0,int a1,int a2,int a3,
      long l0,long d0Bits,int flags,Object o0,String s0) {
       if(kind==EXEC_ACTION){
         if(action==0){gateEntered.countDown();try{releaseGate.await();}catch(InterruptedException e){throw new RuntimeException(e);}}
         actions.incrementAndGet();
       }
       if(kind==EXEC_SIGHT){
          final L1PcInstance pc=actor; if(pc!=null){pc.reconcileSight((L1Object)o0); orderedSight.incrementAndGet();}
       }
    }
'''+'\n'.join(method(m) for m in methods)+'''
    static void check(boolean x,String why){if(!x)throw new AssertionError(why);}
    public static void main(String[] args)throws Exception {
      for(int repeat=0;repeat<15;repeat++){
        L1PcInstance pc=new L1PcInstance(123);
        ControllerHarness ctrl=new ControllerHarness(pc);
        Thread owner=new Thread(()->check(ctrl.AddAction(0),"first action"),"controller-first-owner");
        owner.start(); check(ctrl.gateEntered.await(2,TimeUnit.SECONDS),"gate entered");
        for(int i=1;i<24;i++)check(ctrl.AddAction(i),"queue admit "+i);
        check(ctrl.executionTail-ctrl.executionHead==24,"exact full queue");
        long t0=System.nanoTime();
        for(int i=0;i<2000;i++)check(ctrl.ReconcileSight(new L1Object(),false),"sight accepted");
        long dt=System.nanoTime()-t0;
        check(dt < TimeUnit.SECONDS.toNanos(2),"NPC publisher blocked: "+dt);
        check(ctrl.executionWork==25,"24 ticket work + one coalesced sight work");
        ctrl.releaseGate.countDown();
        owner.join(5000);
        check(!owner.isAlive(),"owner hung");
        check(ctrl.executionTail==ctrl.executionHead,"queue drained");
        check(ctrl.executionWork==0,"work leaked: "+ctrl.executionWork);
        check(ctrl.sightRefreshIdentity==0,"dirty pending leaked");
        check(ctrl.actions.get()==24,"actions lost");
        check(pc.refreshed==1,"sight not coalesced: "+pc.refreshed);
        check(pc.sighted==0,"unwanted individual sight dispatch");
        if(repeat==0) System.out.println("PASS saturation 24+2000 sightings, no NPC blocking, 1 sight refresh, FIFO drain");
      }
      {
        L1PcInstance pc=new L1PcInstance(444);
        ControllerHarness ctrl=new ControllerHarness(pc);
        Thread owner=new Thread(()->check(ctrl.AddAction(0),"initial"));owner.start();
        check(ctrl.gateEntered.await(2,TimeUnit.SECONDS),"gate");
        for(int i=1;i<24;i++)check(ctrl.AddAction(i),"fill");
        Thread[] producers=new Thread[8];
        for(int t=0;t<8;t++) producers[t]=new Thread(()->{
          for(int i=0;i<1000;i++)check(ctrl.ReconcileSight(new L1Object(),false),"concurrent sight");
        });
        for(Thread p:producers)p.start();
        for(Thread p:producers){p.join(3000);check(!p.isAlive(),"publisher blocked");}
        check(ctrl.executionWork==25,"concurrent coalescing work mismatch");
        ctrl.releaseGate.countDown();owner.join(5000);
        check(!owner.isAlive() && ctrl.executionWork==0 && pc.refreshed==1,"concurrent coalescing failure");
        System.out.println("PASS 8 concurrent sight producers/8000 signals, 1 refresh");
      }
      {
        L1PcInstance oldpc=new L1PcInstance(1), newpc=new L1PcInstance(2);
        ControllerHarness ctrl=new ControllerHarness(oldpc);
        Thread owner=new Thread(()->check(ctrl.AddAction(0),"initial"));owner.start();
        check(ctrl.gateEntered.await(2,TimeUnit.SECONDS),"gate");
        for(int i=1;i<24;i++)check(ctrl.AddAction(i),"fill");
        check(ctrl.ReconcileSight(new L1Object(),false),"old sight");
        ctrl.actorEpoch=3;ctrl.actor=newpc;ctrl.actorEpoch=4;
        ctrl.releaseGate.countDown();owner.join(5000);
        check(oldpc.refreshed==0 && newpc.refreshed==0,"stale refresh ran");
        check(ctrl.executionWork==0,"work leak on epoch change");
        System.out.println("PASS stale epoch suppressed, no hang");
      }
    }
}
'''
import tempfile
with tempfile.TemporaryDirectory() as tmp:
 p=pathlib.Path(tmp)/'ControllerHarness.java';p.write_text(code)
 run=lambda cmd:subprocess.run(cmd,check=True,capture_output=True,text=True,timeout=30)
 print(run(['javac',str(p)]).stderr)
 print(run(['java','-cp',str(tmp),'ControllerHarness']).stdout)
