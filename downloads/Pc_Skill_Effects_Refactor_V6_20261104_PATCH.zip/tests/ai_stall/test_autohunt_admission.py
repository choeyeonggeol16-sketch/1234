import re, pathlib, subprocess
root=pathlib.Path(__file__).resolve().parents[2]
p=root/'src/l1j/server/server/model/character/autohunt/AHExecutor.java'
s=p.read_text(encoding='utf8')
m=re.search(r'(?m)^    public void startAutoHunt\(L1PcInstance pc\) \{',s);assert m
b=s.index('{',m.start());j=b+1;depth=1
while depth:
 if s[j]=='{':depth+=1
 elif s[j]=='}':depth-=1
 j+=1
source=s[m.start():j]
text='''
public class AutoHuntHarness {
  static class L1PcInstance {
    int id=4, map=12, sprite=320;boolean active=false;int resets=0;boolean potion;
    int getId(){return id;}int getMapId(){return map;}int getCurrentSpriteId(){return sprite;}
    void setAutoPotion(boolean p){potion=p;}void setAutoMapId(int a){}void setAutoPolyID(int a){}
    void setAutoHunt(boolean a){active=a;}
  }
  static class Config {static final boolean AUTO_HUNT_DEFAULT_POTION=true;}
  static class SC_SystemMessage {static void send(L1PcInstance pc,String msg){lastMessage=msg;}}
  static String lastMessage="";
  static class CIOThreadCallback {
    interface Handle {boolean isCancelled();}
    static CIOThreadCallback instance=new CIOThreadCallback();
    static CIOThreadCallback getInstance(){return instance;}
    boolean allow;
    Handle startAutoHunt(int id,long ms){return allow ? new Handle(){public boolean isCancelled(){return false;}} : null;}
  }
  static int guidanceCount=0;
  void resetAuto(L1PcInstance pc){pc.resets++;}
  void sendGuidancePackets(L1PcInstance pc){guidanceCount++;}
''' + source + '''
  static void check(boolean x,String reason){if(!x)throw new AssertionError(reason);}
  public static void main(String[] args){
    AutoHuntHarness x=new AutoHuntHarness(); L1PcInstance pc=new L1PcInstance();
    CIOThreadCallback.getInstance().allow=false;
    x.startAutoHunt(pc);
    check(!pc.active,"failed wheel left auto-hunt active");
    check(pc.resets==2,"failure cleanup missing");
    check(guidanceCount==0,"misleading success msg");
    check(lastMessage.contains("타이머"),"missing failure notice");
    CIOThreadCallback.getInstance().allow=true;
    x.startAutoHunt(pc);
    check(pc.active,"successful wheel not active");
    check(guidanceCount==1,"successful notice absent");
    check(pc.potion,"auto potion not configured");
    System.out.println("PASS auto-hunt admission false/true, state and feedback");
  }
}
'''
import tempfile
with tempfile.TemporaryDirectory() as tmp:
 p=pathlib.Path(tmp)/'AutoHuntHarness.java';p.write_text(text)
 subprocess.run(['javac',str(p)],check=True,timeout=20)
 subprocess.run(['java','-cp',str(tmp),'AutoHuntHarness'],check=True,timeout=20)
