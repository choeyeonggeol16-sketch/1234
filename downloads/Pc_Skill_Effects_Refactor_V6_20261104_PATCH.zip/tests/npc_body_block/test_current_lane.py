#!/usr/bin/env python3
"""Extract the production current-lane test; verify history cannot decide recovery."""
from pathlib import Path
import sys,subprocess,tempfile,shutil
root=Path(__file__).resolve().parents[2]
p=root/'src/l1j/server/server/model/npc/ai/action/CMoveAroundAction.java'
if len(sys.argv)>1:p=Path(sys.argv[1])
s=p.read_text();a=s.index('    private static boolean isBlockedAttackLaneOpen(');b=s.index('{',a);d=0
for i in range(b,len(s)):
 if s[i]=='{':d+=1
 elif s[i]=='}':
  d-=1
  if d==0:break
method=s[a:i+1]
java='''
class CurrentLaneContract {
 static class L1Character {int x=10,y=10;int getX(){return x;}int getY(){return y;}}
 static class Map {boolean pass=true;boolean isMovePassableGeoNpc(int x,int y,int h){return pass;}}
 static class Template {int get_ranged(){return 2;}}
 static class L1MonsterInstance extends L1Character {
  int _desireBlockedLanePos=(4<<16)|4; Map map=new Map();boolean attack;
  Template getNpcTemplate(){return new Template();}int getMapId(){return 1;}int getId(){return 7;}
  Map getMap(){return map;}boolean isAttackPosition(L1Character t,int r){return attack;}
 }
 static class CDesirePQ {static L1Character target=new L1Character();static L1Character blockedAttackTarget(L1MonsterInstance m){return target;}}
 static boolean validDirectionTarget(L1MonsterInstance m,L1Character t){return t!=null;}
 static class WorldCollisionHash {
  boolean oldOpen=false,nextOpen=true;int lastX,lastY;
  boolean canEnter(short map,int x,int y,int id){lastX=x;lastY=y;return x==4&&y==4?oldOpen:nextOpen;}
 }
 static final WorldCollisionHash COLLISION=new WorldCollisionHash();
 static final int[] DX={0,1,1,1,0,-1,-1,-1},DY={-1,-1,0,1,1,1,0,-1};
 static class PathFinder {
  static class Node {int x,y;Node(int x,int y){this.x=x;this.y=y;}}
  Node next=new Node(10,9);int calls;
  Node searchTail(L1MonsterInstance m,int x,int y,int map,boolean b){calls++;return next;}
  int calcheading(int x,int y,int tx,int ty){return 0;}
 }
 static class AstarProvider {static final PathFinder p=new PathFinder();static PathFinder get(){return p;}}
'''+method+'''
 static void check(boolean c,String m){if(!c)throw new AssertionError(m);}
 public static void main(String[] args){
  L1MonsterInstance m=new L1MonsterInstance();
  check(isBlockedAttackLaneOpen(m),"occupied historical tile must not veto a clear current step");
  check(COLLISION.lastX==10&&COLLISION.lastY==9,"live occupancy must inspect current route");
  COLLISION.oldOpen=true;COLLISION.nextOpen=false;
  check(!isBlockedAttackLaneOpen(m),"empty historical tile must not release a blocked current step");
  COLLISION.nextOpen=true;AstarProvider.p.next=null;
  check(!isBlockedAttackLaneOpen(m),"no current route remains blocked");
  AstarProvider.p.next=new PathFinder.Node(10,10);
  check(!isBlockedAttackLaneOpen(m),"stationary route is not progress");
  AstarProvider.p.next=new PathFinder.Node(10,9);m.map.pass=false;
  check(!isBlockedAttackLaneOpen(m),"static wall remains blocked");
  m.map.pass=true;m._desireBlockedLanePos=(20<<16)|20;
  check(isBlockedAttackLaneOpen(m),"history changes cannot veto a clear current route");
  System.out.println("PASS current route: stale occupied/empty tiles, live occupancy, missing route, zero step and wall");
 }
}
'''
with tempfile.TemporaryDirectory() as td:
 f=Path(td)/'CurrentLaneContract.java';f.write_text(java)
 subprocess.run([shutil.which('javac') or '/workspace/java-toolchain/bin/javac','--release','21','-d',td,str(f)],check=True)
 subprocess.run(['java','-ea','-cp',td,'CurrentLaneContract'],check=True)
