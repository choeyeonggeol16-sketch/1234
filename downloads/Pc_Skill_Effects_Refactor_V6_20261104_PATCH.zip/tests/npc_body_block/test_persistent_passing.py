#!/usr/bin/env python3
"""Real bounded BFS, ring claim, blocked-chase handoff and reserved movement methods.
Only map/occupancy/physical-commit and actor services are deterministic doubles.
"""
from pathlib import Path
import subprocess,tempfile,shutil,re
root=Path(__file__).resolve().parents[2];action=root/'src/l1j/server/server/model/npc/ai/action'
def extract(path,name):
 s=path.read_text();m=re.search(r'(?m)^    (?:private|public|static)[^\n;{]*\b'+name+r'\(',s);assert m,name
 a=m.start();b=s.index('{',a);d=0
 for i in range(b,len(s)):
  if s[i]=='{':d+=1
  elif s[i]=='}':
   d-=1
   if not d:return s[a:i+1]
 raise AssertionError(name)
def methods(path,names):return '\n'.join(extract(path,n) for n in names)
pf=root/'src/l1j/server/server/model/ai/core/PathFinder.java'
ss=pf.read_text();aa=ss.index('    private static final int BODY_ROUTE_RADIUS');bb=ss.index('    /**',aa)
router=ss[aa:bb]+methods(pf,['scanBodyRoute','scanBodyRouteToMeleeRing','scanBodyRouteInternal','scanBodyRouteWindow','bodyRouteDistanceTo','bodyRouteFirstHeadingTo','headingFromDelta'])
sm=methods(action/'SetMoving.java',['tickToReservedAttackSlot','reservedChaseStillCurrent'])
claim=methods(action/'CMoveAroundAction.java',['claimReachableMeleeSlot','ringTurnRank','isUsableMeleeSlot','chebyshev'])
chase=methods(action/'CMoveToTargetAction.java',['tryPassBlockedChase','tickReservedAttackSlot','clearReservedAttackSlot'])
s=(action/'CMoveToTargetAction.java').read_text();a=s.index('if (move == SetMoving.DYNAMIC_BLOCKED)');b=s.index('isMeleeAttackRingFull(monster, target)',a)
assert 'tryPassBlockedChase(' in s[a:b], 'live chase must route before declaring a ring/body block'
java='''
import java.util.*;
class PersistentPassingContract {
 static final int[] DX={0,1,1,1,0,-1,-1,-1},DY={-1,-1,0,1,1,1,0,-1};
 static final long RESERVED_SLOT_CLAIM_MS=6000,DYNAMIC_BLOCK_RETRY_MS=300;
 static final int RESERVED_SLOT_BLOCK_RETRY_LIMIT=3;
 static long key(int x,int y){return ((long)x<<32)|(y&0xffffffffL);}
 static class MapGrid {Set<Long> walls=new HashSet<>();
  boolean isPassable(int x,int y){return x>=0&&y>=0&&x<40&&y<40&&!walls.contains(key(x,y));}
  boolean isNull(){return false;}}
 static final MapGrid MAP=new MapGrid();
 static class L1Map extends MapGrid {boolean isPassable(int x,int y){return MAP.isPassable(x,y);}}
 static class L1WorldMap {static L1WorldMap getInstance(){return new L1WorldMap();}L1Map getMap(int id){return new L1Map();}}
 static class L1Object {int id,x,y;int getId(){return id;}int getX(){return x;}int getY(){return y;}int getMapId(){return 1;}}
 static class L1Character extends L1Object {
  boolean dead;int getCurrentHp(){return dead?0:100;}boolean isDead(){return dead;}boolean isInvisble(){return false;}
  L1Map getMap(){return new L1Map();}boolean glanceCheck(int x,int y){return MAP.isPassable(x,y);}
  int targetDirection(int tx,int ty){return PathFinder.headingFromDelta(Integer.compare(tx,x),Integer.compare(ty,y));}
 }
 static class Template {int get_ranged(){return 1;}boolean is_agrocoi(){return false;}}
 static class L1NpcInstance extends L1Character {
  L1Character target;byte action=6;int generation=1,moves,sleep,_moveSide;
  int npcActionGeneration(){return generation;}L1Character getTarget(){return target;}Template getNpcTemplate(){return new Template();}
  boolean isAttackPosition(L1Character t,int r){return Math.max(Math.abs(x-t.x),Math.abs(y-t.y))<=r;}
 }
 static class L1MonsterInstance extends L1NpcInstance {
  int _desireResumeAttackPos,_desireResumeAttackTargetId,_desireResumeAttackTargetPos;
  short _desireResumeAttackMapId;int _desireResumeAttackBlockedRetries,_desireBlockedAttackTargetId,_pathFindFailCount;
 }
 static class WorldCollisionHash {
  static final WorldCollisionHash ONE=new WorldCollisionHash();static WorldCollisionHash getInstance(){return ONE;}
  HashMap<Long,Integer> bodies=new HashMap<>(),claims=new HashMap<>();
  boolean canEnter(short m,int x,int y,int id){return MAP.isPassable(x,y)&&
   (bodies.getOrDefault(key(x,y),0)==0||bodies.get(key(x,y))==id)&&
   (claims.getOrDefault(key(x,y),0)==0||claims.get(key(x,y))==id);}
  boolean reserveNpcMove(short m,int x,int y,int id,long ttl){if(!canEnter(m,x,y,id))return false;claims.put(key(x,y),id);return true;}
  void cancelNpcMove(short m,int x,int y,int id){claims.remove(key(x,y),id);}
  long moveCreatureProbe(short m,int x,int y,int h,int vx,int vy,int id){return canEnter(m,x+DX[h],y+DY[h],id)?1:0;}
  static boolean moveProbeCanMove(long p){return p==1;}
 }
 static final WorldCollisionHash COLLISION=WorldCollisionHash.ONE;
 static class PathNodeWorld {static boolean isStepPassableStrict(L1Map m,int x,int y,int h){return m.isPassable(x+DX[h],y+DY[h]);}}
 static class PathFinder {
'''+router+'''
 }
 static class AstarProvider {static final PathFinder P=new PathFinder();static PathFinder get(){return P;}}
 static class ActionAccess {
  static byte currentAction(L1NpcInstance c){return c.action;}
  static void sleep(L1NpcInstance c,long ms){c.sleep=(int)ms;}
  static boolean moveOneStep(L1NpcInstance c,int h){int nx=c.x+DX[h],ny=c.y+DY[h];
   if(!COLLISION.canEnter((short)1,nx,ny,c.id))return false;
   COLLISION.bodies.remove(key(c.x,c.y),c.id);c.x=nx;c.y=ny;COLLISION.bodies.put(key(nx,ny),c.id);
   COLLISION.claims.remove(key(nx,ny),c.id);c.moves++;c.sleep=150;return true;}
 }
 static class CCreatureController {static final byte ACTION_MOVE_TO_TARGET=6,ACTION_MOVE_TO_TARGET_RELATIVE=14,
   RESULT_RUNNING=0,RESULT_DONE=1,RESULT_INVALID=2;}
 static class CDesirePQ {static void releaseBlockedAttack(L1MonsterInstance m){m._desireBlockedAttackTargetId=0;}}
 static class SetMoving {
  static boolean debugTraceActor(L1NpcInstance c){return false;}
  static final byte RUNNING=0,AT_DISTANCE=1,INVALID=2,DYNAMIC_BLOCKED=4;static final long CALC_MID_MIN_MS=100;
  static boolean validHeading(int h){return h>=0&&h<8;}static void prepareMoveKey(L1NpcInstance c,int k){}
  static int pointKey(int m,int x,int y){return x*40+y;}static void clearCollisionResponse(L1NpcInstance c){}
'''+sm+'''
 }
 static class CMoveAroundAction {
  static final int BLOCKED_RING_RECHECK_RADIUS=12;static final long OPEN_LANE_CLAIM_MAX_MS=6000;
'''+claim+'''
 }
 static boolean validTarget(L1MonsterInstance m,L1Character t){return !m.dead&&!t.dead;}
 static boolean isUsableMeleeSlot(L1Character t,int x,int y){return CMoveAroundAction.isUsableMeleeSlot(t,x,y);}
'''+chase+'''
 static void check(boolean c,String m){if(!c)throw new AssertionError(m);}
 static L1MonsterInstance scene(){
  MAP.walls.clear();COLLISION.bodies.clear();COLLISION.claims.clear();
  L1MonsterInstance rear=new L1MonsterInstance();rear.id=2;rear.x=20;rear.y=23;
  L1Character target=new L1Character();target.id=99;target.x=20;target.y=20;rear.target=target;
  COLLISION.bodies.put(key(20,23),2);COLLISION.bodies.put(key(20,22),1);COLLISION.bodies.put(key(20,20),99);
  MAP.walls.add(key(19,22));MAP.walls.add(key(21,22));return rear;
 }
 public static void main(String[] args){
  L1MonsterInstance rear=scene();
  check(!COLLISION.canEnter((short)1,19,22,2)&&!COLLISION.canEnter((short)1,21,22,2),"old two-diagonal passing is blocked");
  check(tryPassBlockedChase(rear,rear.target,1,(byte)6)==0&&rear.moves==1,"route-aware chase must move now, not wander");
  check(rear.y==23&&rear.x!=20,"first route step is sideways; instant target-distance decrease is insufficient");
  int slot=rear._desireResumeAttackPos;check(slot!=0,"goal retained for following ticks");
  int steps=1;while(!rear.isAttackPosition(rear.target,1)&&steps<20){
   int before=rear.moves;byte r=tickReservedAttackSlot(rear,rear.target,1);
   check(r==0&&rear.moves==before+1,"passing route progresses each subsequent tick without idle retry");
   check(rear._desireResumeAttackPos==slot,"same attack-slot destination retained");steps++;
  }
  check(rear.isAttackPosition(rear.target,1),"rear reaches attack position around leader");
  rear=scene();check(tryPassBlockedChase(rear,rear.target,1,(byte)6)==0,"second route starts");
  COLLISION.bodies.remove(key(20,22));MAP.walls.clear();
  int before=rear.moves;check(tickReservedAttackSlot(rear,rear.target,1)==0&&rear.moves==before+1,"leader death/opening allows next route step");
  rear=scene();for(int h=0;h<8;h++)COLLISION.bodies.put(key(20+DX[h],20+DY[h]),100+h);
  check(tryPassBlockedChase(rear,rear.target,1,(byte)6)==-1&&rear.moves==0,"full attack ring leaves wander policy intact");
  rear=scene();rear.generation=2;
  check(tryPassBlockedChase(rear,rear.target,1,(byte)6)==2&&rear.moves==0,"stale action cannot claim/move");
  System.out.println("PASS real BFS+claim+chase+reserved movement: sideways-first passing progresses every tick, stable slot, opening, full ring, stale generation");
 }
}
'''
with tempfile.TemporaryDirectory() as td:
 f=Path(td)/'PersistentPassingContract.java';f.write_text(java)
 subprocess.run([shutil.which('javac') or '/workspace/java-toolchain/bin/javac','--release','21','-d',td,str(f)],check=True)
 subprocess.run(['java','-ea','-cp',td,'PersistentPassingContract'],check=True)
