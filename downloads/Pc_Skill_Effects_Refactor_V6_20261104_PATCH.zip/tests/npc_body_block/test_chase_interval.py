#!/usr/bin/env python3
"""Extract real tickInternal; verify first and subsequent steps keep the sprite walk cadence."""
from pathlib import Path
import tempfile,subprocess,shutil,sys
root=Path(__file__).resolve().parents[2]
p=root/'src/l1j/server/server/model/npc/ai/action/SetMoving.java'
if len(sys.argv)>1:p=Path(sys.argv[1])
s=p.read_text();a=s.index('    private static byte tickInternal(');b=s.index('{',a);d=0
for i in range(b,len(s)):
 if s[i]=='{':d+=1
 elif s[i]=='}':
  d-=1
  if not d:break
java='''
class ChaseIntervalContract {
 static final byte RUNNING=0,AT_DISTANCE=1,PATH_FAILED=3;
 static final int SEGMENT_PATH_FAILED=-1,SEGMENT_WAIT=1,SEGMENT_OK=0;
 static final long CALC_MID_MIN_MS=100,CALC_MID_MAX_MS=800;
 static class L1NpcInstance {
  int x,y,_moveSegmentX,_moveSegmentY,_moveContactX,_moveCollision,_moveHeading;long sleep=150;
  int getX(){return x;}int getY(){return y;}int getId(){return 1;}long getSleepTime(){return sleep;}
 }
 static class ActionAccess {static void sleep(L1NpcInstance c,long ms){c.sleep=ms;}}
 static class AstarProvider {
  static final AstarProvider p=new AstarProvider();static AstarProvider get(){return p;}
  boolean pending=true;int retired;
  boolean consumeInitialChaseAstarTransition(L1NpcInstance c){if(!pending)return false;pending=false;retired++;return true;}
 }
 static void prepareMoveKey(L1NpcInstance c,int k){}
 static boolean debugTraceActor(L1NpcInstance c){return false;}
 static boolean withinDistanceSquared(int x,int y,int tx,int ty,int distance){return false;}
 static void clearSegment(L1NpcInstance c){}static void clearCollisionResponse(L1NpcInstance c){}
 static void refreshLiveTarget(L1NpcInstance c,int x,int y,int tx,int ty){}
 static int segmentHeading(L1NpcInstance c,boolean raster){return 0;}
 static boolean validHeading(int h){return h>=0&&h<8;}
 static int segmentRemainingMs(L1NpcInstance c){return 800;}
 static int buildCalcMidSegment(L1NpcInstance c,int x,int y,boolean r,boolean combat){return 0;}
 static boolean staticPassable(L1NpcInstance c,int h){return true;}
 static void invalidateStaticDestination(L1NpcInstance c){}static void expireSegmentKeepHeading(L1NpcInstance c){}
 static byte moveCreature(L1NpcInstance c,int h){c.y--;c.sleep=150;return RUNNING;}
'''+s[a:i+1]+'''
 public static void main(String[] args){
  L1NpcInstance c=new L1NpcInstance();
  for(int n=0;n<5;n++){
   long expected=150;
   if(tickInternal(c,0,-20,1,1,false,true)!=RUNNING||c.sleep!=expected||c.y!=-n-1)
    throw new AssertionError("first and subsequent sprite walk cadence; got "+c.sleep+" expected "+expected);
  }
  if(AstarProvider.p.retired!=1)throw new AssertionError("transition marker must still be consumed");
  System.out.println("PASS real tickInternal: first A* and subsequent steps preserve sprite walk interval");
 }
}
'''
with tempfile.TemporaryDirectory() as td:
 f=Path(td)/'ChaseIntervalContract.java';f.write_text(java)
 subprocess.run([shutil.which('javac') or '/workspace/java-toolchain/bin/javac','--release','21','-d',td,str(f)],check=True)
 subprocess.run(['java','-ea','-cp',td,'ChaseIntervalContract'],check=True)
