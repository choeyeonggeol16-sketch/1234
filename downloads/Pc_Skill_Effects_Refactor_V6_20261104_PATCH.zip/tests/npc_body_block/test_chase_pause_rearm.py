#!/usr/bin/env python3
"""Real tickInternal + real PathFinder marker: worker/cache changes cannot inject pauses."""
from pathlib import Path
import argparse,re,subprocess,tempfile
root=Path(__file__).resolve().parents[2]
p=argparse.ArgumentParser();p.add_argument('--baseline-root',type=Path);a=p.parse_args()
source=(a.baseline_root or root)/'src/l1j/server/server/model'
def method(s,sig):
 a=s.index(sig);b=s.index('{',a);depth=1;i=b+1
 while depth:
  if s[i]=='{':depth+=1
  elif s[i]=='}':depth-=1
  i+=1
 return s[a:i]
# Reuse the existing movement-edge doubles and replace only marker/step setup.
fixture=root/'tests/npc_body_block/test_chase_interval.py'
ns={'__file__':str(fixture)}
import sys
saved=sys.argv;sys.argv=[str(fixture)]
try:exec(fixture.read_text().split('with tempfile.TemporaryDirectory()')[0],ns)
finally:sys.argv=saved
java=ns['java'];original=ns['s'][ns['a']:ns['i']+1]
java=java.replace(original,method((source/'npc/ai/action/SetMoving.java').read_text(),'    private static byte tickInternal('))
java=java.replace(' static class L1NpcInstance {',' static class L1Object {int id=1;int getId(){return id;}int getMapId(){return 1;}}\n static class L1NpcInstance extends L1Object {')
java=java.replace('long sleep=150;','long sleep=150,walk=150;boolean ready;int buildResult;byte moveResult;')
java=java.replace('int getId(){return 1;}','int getId(){return id;}')
start=java.index(' static class AstarProvider {');end=java.index(' static void prepareMoveKey',start)
path=(source/'ai/core/PathFinder.java').read_text()
java=java[:start]+''' static class PathFinder {
  static final int ROUTE_CACHE_SIZE=4096,ROUTE_CACHE_MASK=4095;
  final int[] initialChaseActor=new int[ROUTE_CACHE_SIZE];final byte[] initialChaseState=new byte[ROUTE_CACHE_SIZE];final long[] nativeRouteKey=new long[ROUTE_CACHE_SIZE];boolean lastNativeAstarBuilt;
  void build(L1Object c){observeInitialChaseActor(c);lastNativeAstarBuilt=true;nativeRouteKey[routeSlot(c.getId())]=routeKey(c.getId(),c.getMapId());armInitialChaseAstarTransition(c);}
'''+''.join(method(path,s) for s in ['    public void armInitialChaseAstarTransition(', '    public boolean consumeInitialChaseAstarTransition(', '    private void observeInitialChaseActor(', '    private static long routeKey(', '    private static int routeSlot('])+'''
 }
 static class AstarProvider {static final ThreadLocal<PathFinder> LOCAL=ThreadLocal.withInitial(PathFinder::new);static PathFinder get(){return LOCAL.get();}}
'''+java[end:]
java=java.replace('static int segmentHeading(L1NpcInstance c,boolean raster){return 0;}','static int segmentHeading(L1NpcInstance c,boolean raster){return c.ready?0:-1;}')
java=java.replace('static int buildCalcMidSegment(L1NpcInstance c,int x,int y,boolean r,boolean combat){return 0;}','static int buildCalcMidSegment(L1NpcInstance c,int x,int y,boolean r,boolean combat){AstarProvider.get().build(c);c.ready=true;return c.buildResult;}')
java=java.replace('static byte moveCreature(L1NpcInstance c,int h){c.y--;c.sleep=150;return RUNNING;}','static byte moveCreature(L1NpcInstance c,int h){if(c.moveResult!=RUNNING)return c.moveResult;c.y--;c.sleep=c.walk;return RUNNING;}')
start=java.index(' public static void main(String[] args)');java=java[:start]+r'''
 static int passed,failed;
 static void check(boolean ok,String why){if(!ok)throw new AssertionError(why);}
 static void run(String name,Runnable r){try{AstarProvider.LOCAL.remove();r.run();passed++;System.out.println("PASS "+name);}catch(Throwable e){failed++;System.out.println("FAIL "+name+": "+e);}}
 static void step(L1NpcInstance c){check(tickInternal(c,0,-20,1,c.id,false,true)==RUNNING,"movement failed");check(c.sleep==c.walk,"successful clear-path step paused "+c.sleep+"ms, sprite interval="+c.walk);}
 public static void main(String[] args){
  run("first A* step uses real sprite interval at 100/150/250/1000ms",()->{for(long walk:new long[]{100,150,250,1000}){AstarProvider.LOCAL.remove();L1NpcInstance c=new L1NpcInstance();c.walk=walk;for(int n=0;n<5;n++)step(c);check(c.y==-5,"clear path stopped progressing");}});
  run("colliding NPC IDs cannot reintroduce 800ms stops",()->{L1NpcInstance a=new L1NpcInstance(),b=new L1NpcInstance();b.id=4097;for(int n=0;n<10;n++){a.ready=false;step(a);b.ready=false;step(b);}check(a.y==-10&&b.y==-10,"collision scene lost steps");});
  run("same stationary target across three real worker threads",()->{L1NpcInstance c=new L1NpcInstance();java.util.concurrent.atomic.AtomicReference<Throwable> failure=new java.util.concurrent.atomic.AtomicReference<>();for(int n=0;n<3;n++){Thread t=new Thread(()->{try{c.ready=false;step(c);}catch(Throwable e){failure.set(e);}});t.start();try{t.join(3000);}catch(InterruptedException e){throw new RuntimeException(e);}check(!t.isAlive(),"worker hung");if(failure.get()!=null)throw new AssertionError(failure.get());}check(c.y==-3,"worker transition lost movement");});
  run("transition marker is retired without waiting",()->{L1NpcInstance c=new L1NpcInstance();step(c);check(!AstarProvider.get().consumeInitialChaseAstarTransition(c),"marker remained armed");});
  run("failed path and blocked move do not consume successful-step marker",()->{L1NpcInstance c=new L1NpcInstance();c.buildResult=SEGMENT_PATH_FAILED;check(tickInternal(c,0,-20,1,c.id,false,true)==PATH_FAILED&&c.y==0,"failed path moved");check(AstarProvider.get().consumeInitialChaseAstarTransition(c),"failed path consumed marker");AstarProvider.LOCAL.remove();c=new L1NpcInstance();c.moveResult=4;check(tickInternal(c,0,-20,1,c.id,false,true)==4&&c.y==0,"blocked step moved");check(AstarProvider.get().consumeInitialChaseAstarTransition(c),"blocked step consumed marker");});
  System.out.println("RESULT passed="+passed+" failed="+failed);if(failed!=0)throw new AssertionError("clear-path cadence regressions failed="+failed);
 }
}
'''
with tempfile.TemporaryDirectory() as td:
 f=Path(td)/'ChaseIntervalContract.java';f.write_text(java)
 subprocess.run(['java','-m','jdk.compiler/com.sun.tools.javac.Main','-source','21','-target','21','-encoding','UTF-8','-d',td,str(f)],check=True)
 subprocess.run(['java','-ea','-cp',td,'ChaseIntervalContract'],check=True,timeout=30)
