#!/usr/bin/env python3
"""Real chase/segment heading methods: nearest angle, legacy scope and GEO fallback."""
from pathlib import Path
import tempfile,subprocess,shutil,re
root=Path(__file__).resolve().parents[2]
s=(root/'src/l1j/server/server/model/npc/ai/action/SetMoving.java').read_text()
def extract(name):
 m=re.search(r'(?m)^    private static [^\n{]+\b'+name+r'\(',s);assert m,name
 a=m.start();b=s.index('{',a);d=0
 for i in range(b,len(s)):
  if s[i]=='{':d+=1
  elif s[i]=='}':
   d-=1
   if not d:return s[a:i+1]
 raise AssertionError(name)
for name in ['buildCalcMidSegment','segmentHeading']:
 assert 'chaseSegmentHeading(' in extract(name),name+' must use chase angle'
java='''
class ChaseAngleContract {
 static class L1NpcInstance {
  int x,y,_moveSegmentX,_moveSegmentY,_moveContactX=800;byte _moveSide=0,action=6;
  int getX(){return x;}int getY(){return y;}int getId(){return 1;}
 }
 static class L1MonsterInstance extends L1NpcInstance{}
 static class ActionAccess {static byte currentAction(L1NpcInstance c){return c.action;}}
 static class CCreatureController {static final byte ACTION_MOVE_TO_TARGET=6,ACTION_MOVE_TO_TARGET_RELATIVE=14;}
 static final int[] DX={0,1,1,1,0,-1,-1,-1},DY={-1,-1,0,1,1,1,0,-1};
 static int blocked=-1;
 static boolean staticPassable(L1NpcInstance c,int h){return h!=blocked;}
 static boolean validHeading(int h){return h>=0&&h<8;}
 static boolean debugTraceActor(L1NpcInstance c){return false;}
 static void expireSegmentKeepHeading(L1NpcInstance c){c._moveContactX=0;}
'''+ '\n'.join(extract(n) for n in ['chaseSegmentHeading','coalescedSegmentHeading','segmentHeading','firstRasterHeading','headingFromStep'])+'''
 static void check(boolean c,String msg){if(!c)throw new AssertionError(msg);}
 public static void main(String[] args){
  L1MonsterInstance m=new L1MonsterInstance();
  check(coalescedSegmentHeading(-2,-1)==6,"old 4-o'clock approach forced west first");
  check(chaseSegmentHeading(m,-2,-1)==7,"4-o'clock monster approaches northwest diagonally now");
  check(chaseSegmentHeading(m,2,1)==3&&chaseSegmentHeading(m,2,-1)==1&&chaseSegmentHeading(m,-2,1)==5,"all oblique quadrants");
  check(chaseSegmentHeading(m,0,-5)==0&&chaseSegmentHeading(m,5,0)==2,"true cardinal approach unchanged");
  check(chaseSegmentHeading(m,10,1)==2,"shallow angle correctly remains cardinal");
  m.action=14;check(chaseSegmentHeading(m,-2,-1)==7,"relative chase also follows angle");
  m.action=12;check(chaseSegmentHeading(m,-2,-1)==6,"wander retains grouped steering");
  m.action=6;check(chaseSegmentHeading(new L1NpcInstance(),-2,-1)==6,"other NPCs retain steering");
  for(int tx=-12;tx<=12;tx++)for(int ty=-12;ty<=12;ty++){
   m.x=0;m.y=0;m._moveSide=0;m._moveContactX=800;m._moveSegmentX=tx;m._moveSegmentY=ty;int steps=0;
   while(m.x!=tx||m.y!=ty){
    int before=Math.max(Math.abs(tx-m.x),Math.abs(ty-m.y));int h=segmentHeading(m,false);
    check(h>=0&&h<8,"valid angle");m.x+=DX[h];m.y+=DY[h];
    check(Math.max(Math.abs(tx-m.x),Math.abs(ty-m.y))==before-1,"forward progress without detour/oscillation");
    check(++steps<30,"bounded arrival");
   }
   check(steps==Math.max(Math.abs(tx),Math.abs(ty)),"shortest 8-way step count preserved");
  }
  m.x=m.y=0;m._moveSide=0;m._moveContactX=800;m._moveSegmentX=9;m._moveSegmentY=-4;blocked=1;
  check(segmentHeading(m,false)==2,"blocked diagonal uses original GEO-legal raster fallback");
  System.out.println("PASS actual chase angle: old/new 4-o'clock heading, quadrants, relative/legacy scope, 625 destinations shortest progress and GEO fallback");
 }
}
'''
with tempfile.TemporaryDirectory() as td:
 p=Path(td)/'ChaseAngleContract.java';p.write_text(java)
 subprocess.run([shutil.which('javac') or '/workspace/java-toolchain/bin/javac','--release','21','-d',td,str(p)],check=True)
 subprocess.run(['java','-ea','-cp',td,'ChaseAngleContract'],check=True)
