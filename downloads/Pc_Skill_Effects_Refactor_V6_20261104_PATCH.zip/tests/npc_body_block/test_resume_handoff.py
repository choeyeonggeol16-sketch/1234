#!/usr/bin/env python3
"""Extract real wander onEnd; completed recovery must not rearm old rest cadence."""
from pathlib import Path
import subprocess,tempfile,shutil,sys
root=Path(__file__).resolve().parents[2]
p=root/'src/l1j/server/server/model/npc/ai/action/CMoveAroundAction.java'
if len(sys.argv)>1:p=Path(sys.argv[1])
s=p.read_text();a=s.index('    public static void onEnd(');b=s.index('{',a);d=0
for i in range(b,len(s)):
 if s[i]=='{':d+=1
 elif s[i]=='}':
  d-=1
  if not d:break
java='''
class ResumeHandoffContract {
 static class L1NpcInstance {byte action=12;int generation=5,wakes,clears;boolean cadence=true;long deadline=60000;}
 static class L1MonsterInstance extends L1NpcInstance{}
 static class ActionAccess {static byte currentAction(L1NpcInstance c){return c.action;}}
 static class SetMoving {static void clear(L1NpcInstance c){c.clears++;}}
 static void clearDestination(L1NpcInstance c){c.clears++;}
 static void clearRuntime(L1MonsterInstance c){c.clears++;}
 static class CCreatureController {
  static final byte ACTION_MOVE_AROUND_NATIVE=12,RESULT_DONE=1;
  static void think(L1NpcInstance c){c.action=0;}
  static void rethinkNow(L1NpcInstance c){think(c);c.generation++;c.cadence=false;c.deadline=0;c.wakes++;}
 }
'''+s[a:i+1]+'''
 static void check(boolean c,String m){if(!c)throw new AssertionError(m);}
 public static void main(String[] args){
  for(long oldSleep:new long[]{300,800,6000}){
   L1MonsterInstance c=new L1MonsterInstance();c.deadline=oldSleep;
   onEnd(c,(byte)1);
   check(c.action==0&&c.wakes==1&&!c.cadence&&c.deadline==0&&c.generation==6,
     "reopened route must invalidate old "+oldSleep+"ms cadence and wake AI");
   check(c.clears==1,"owned wander runtime cleared");
  }
  L1MonsterInstance successor=new L1MonsterInstance();successor.action=6;
  onEnd(successor,(byte)1);
  check(successor.generation==5&&successor.wakes==0&&successor.clears==0,"stale wander cannot retire successor");
  L1MonsterInstance running=new L1MonsterInstance();onEnd(running,(byte)0);
  check(running.wakes==0&&running.generation==5,"non-DONE result does not force immediate rethink");
  System.out.println("PASS production wander completion: immediate handoff, old deadline invalidation and successor guard");
 }
}
'''
with tempfile.TemporaryDirectory() as td:
 f=Path(td)/'ResumeHandoffContract.java';f.write_text(java)
 subprocess.run([shutil.which('javac') or '/workspace/java-toolchain/bin/javac','--release','21','-d',td,str(f)],check=True)
 subprocess.run(['java','-ea','-cp',td,'ResumeHandoffContract'],check=True)
