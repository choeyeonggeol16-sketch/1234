#!/usr/bin/env python3
"""Real router+claim+chase: south approach must reach sole north attack entrance."""
from pathlib import Path
import tempfile,subprocess,shutil,sys
p=Path(__file__).with_name('test_persistent_passing.py');ns={'__file__':str(p)}
exec(p.read_text().split('with tempfile.TemporaryDirectory()')[0],ns)
java=ns['java']
if '--baseline-dir' in sys.argv:
 baseline=Path(sys.argv[sys.argv.index('--baseline-dir')+1])
 extract=ns['extract'];old=baseline/'PathFinder.java';s=old.read_text();a=s.index('    private static final int BODY_ROUTE_RADIUS');b=s.index('    /**',a)
 oldrouter=s[a:b]+ '\n'.join(extract(old,n) for n in ['scanBodyRoute','scanBodyRouteToMeleeRing','scanBodyRouteInternal','bodyRouteDistanceTo','bodyRouteFirstHeadingTo','headingFromDelta'])
 a=java.index(' static class PathFinder {');b=java.index(' static class AstarProvider',a)
 java=java[:a]+' static class PathFinder {\n'+oldrouter+'\n }\n'+java[b:]
 current=extract(ns['action']/'CMoveAroundAction.java','claimReachableMeleeSlot')
 java=java.replace(current,extract(baseline/'CMoveAroundAction.java','claimReachableMeleeSlot'))
a=java.index(' public static void main(String[] args)')
java=java[:a]+'''
 static L1MonsterInstance opposite(boolean opening,int actorY){
  MAP.walls.clear();COLLISION.bodies.clear();COLLISION.claims.clear();
  L1MonsterInstance rear=new L1MonsterInstance();rear.id=2;rear.x=20;rear.y=actorY;
  L1Character t=new L1Character();t.id=99;t.x=20;t.y=20;rear.target=t;
  COLLISION.bodies.put(key(20,actorY),2);COLLISION.bodies.put(key(20,20),99);
  // Seven target approaches are body-occupied. Only 12 o'clock is usable.
  for(int h=1;h<8;h++)COLLISION.bodies.put(key(20+DX[h],20+DY[h]),100+h);
  // The only crossing is outside the old actor-centered 25x25 window.
  for(int x=0;x<40;x++)if(!opening||x!=36)MAP.walls.add(key(x,22));
  return rear;
 }
 public static void main(String[] args){
  L1MonsterInstance c=opposite(true,30);
  check(tryPassBlockedChase(c,c.target,1,(byte)6)==0&&c.moves==1,"south approach must route around barrier to open NORTH entrance");
  check(c._desireResumeAttackPos==((20<<16)|19),"north entrance selected, not occupied south entrance");
  check(AstarProvider.P.bodyRouteOriginY!=30,"failed local search expanded between actor and target");
  int goal=c._desireResumeAttackPos,steps=1;
  while(!c.isAttackPosition(c.target,1)&&steps<100){
   int before=c.moves;check(tickReservedAttackSlot(c,c.target,1)==0&&c.moves==before+1,"detour keeps moving on every tick");
   check(c._desireResumeAttackPos==goal,"north attack goal retained around barrier");steps++;
  }
  check(c.x==20&&c.y==19,"south monster arrives at north entrance");
  c=opposite(false,30);
  check(tryPassBlockedChase(c,c.target,1,(byte)6)==-1&&c.moves==0,"empty north tile alone is not proof of a route");
  c=opposite(true,35);MAP.walls.clear();
  check(tryPassBlockedChase(c,c.target,1,(byte)6)==0,"old 12-tile actor cutoff must not hide north entrance");
  c=scene();MAP.walls.clear();
  int actorY=c.y;check(CMoveAroundAction.claimReachableMeleeSlot(c,c.target),"ordinary local route still found");
  check(AstarProvider.P.bodyRouteOriginY==actorY,"local route avoids expanded search");
  c=opposite(true,30);COLLISION.bodies.put(key(20,19),100);
  int epoch=AstarProvider.P.bodyRouteEpoch;
  check(tryPassBlockedChase(c,c.target,1,(byte)6)==-1&&AstarProvider.P.bodyRouteEpoch==epoch,"full ring skips route scan and preserves wander fallback");
  System.out.println("PASS real south-to-north detour: expanded search, sole north entrance, persistent arrival, disconnected rejection, old-distance cutoff, local fast path and full-ring fallback");
 }
}
'''
with tempfile.TemporaryDirectory() as td:
 f=Path(td)/'PersistentPassingContract.java';f.write_text(java)
 subprocess.run([shutil.which('javac') or '/workspace/java-toolchain/bin/javac','--release','21','-d',td,str(f)],check=True)
 subprocess.run(['java','-ea','-cp',td,'PersistentPassingContract'],check=True)
