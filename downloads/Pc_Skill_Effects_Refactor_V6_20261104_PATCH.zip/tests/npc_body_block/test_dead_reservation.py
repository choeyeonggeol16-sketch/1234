#!/usr/bin/env python3
"""Compile the complete production TileOccupancyNpc with map/world/collection doubles."""
from pathlib import Path
import tempfile,subprocess,shutil,sys
root=Path(__file__).resolve().parents[2]
p=root/'src/l1j/server/server/model/character/TileOccupancy/TileOccupancyNpc.java'
if len(sys.argv)>1:p=Path(sys.argv[1])
files={
'org/agrona/collections/Long2LongHashMap.java':'''package org.agrona.collections;
public class Long2LongHashMap {private final java.util.HashMap<Long,Long> data=new java.util.HashMap<>();
 public Long2LongHashMap(int n,float f,long missing){}public long get(long k){return data.getOrDefault(k,0L);}
 public long put(long k,long v){Long old=data.put(k,v);return old==null?0:old;}
 public long remove(long k){Long old=data.remove(k);return old==null?0:old;}public void clear(){data.clear();}}''',
'l1j/server/server/model/L1Object.java':'''package l1j.server.server.model;
public class L1Object {public final int id;public L1Object(int n){id=n;}}''',
'l1j/server/server/model/L1World.java':'''package l1j.server.server.model;
public class L1World {static final L1World ONE=new L1World();public static L1World getInstance(){return ONE;}
 public final java.util.concurrent.ConcurrentHashMap<Integer,L1Object> objects=new java.util.concurrent.ConcurrentHashMap<>();
 public L1Object findObject(int n){return objects.get(n);}}''',
'l1j/server/server/model/Instance/L1NpcInstance.java':'''package l1j.server.server.model.Instance;
public class L1NpcInstance extends l1j.server.server.model.L1Object {
 public volatile boolean dead,pass;public L1NpcInstance(int n){super(n);}public boolean isDead(){return dead;}
 public int getHiddenStatus(){return 0;}public boolean isPassableNpc(){return pass;}}''',
'l1j/server/server/model/Instance/L1PcInstance.java':'''package l1j.server.server.model.Instance;
public class L1PcInstance extends l1j.server.server.model.L1Object {public L1PcInstance(int n){super(n);}
 public boolean isDead(){return false;}public boolean isGhost(){return false;}public boolean isGmInvis(){return false;}}''',
'l1j/server/server/model/map/L1Map.java':'''package l1j.server.server.model.map;
public class L1Map {public int getWidth(){return 100;}public int getHeight(){return 100;}}''',
'l1j/server/server/model/map/L1WorldMap.java':'''package l1j.server.server.model.map;
public class L1WorldMap {public static L1WorldMap getInstance(){return new L1WorldMap();}public L1Map getMap(int n){return new L1Map();}}''',
'l1j/server/server/model/character/TileOccupancy/TileOccupancy.java':'''package l1j.server.server.model.character.TileOccupancy;
public class TileOccupancy {static final Object G=new Object();public static TileOccupancy getInstance(){return new TileOccupancy();}
 public int getOccupier(int m,int x,int y){return 0;}public int getReservedBy(int m,int x,int y){return 0;}
 public static int gateIndex(int m,int x,int y){return 0;}public static Object gate(int n){return G;}}''',
'TestDeadReservation.java':'''import l1j.server.server.model.character.TileOccupancy.TileOccupancyNpc;
import l1j.server.server.model.Instance.L1NpcInstance;
import l1j.server.server.model.L1World;
public class TestDeadReservation {
 static void check(boolean c,String msg){if(!c)throw new AssertionError(msg);}
 static L1NpcInstance npc(int id){L1NpcInstance n=new L1NpcInstance(id);L1World.getInstance().objects.put(id,n);return n;}
 public static void main(String[] args)throws Exception{
  TileOccupancyNpc p=TileOccupancyNpc.getInstance();short m=1;L1NpcInstance a=npc(1);npc(2);npc(3);
  check(p.canMoveTo(m,10,10,1,6000),"original owner claims slot");
  check(p.getReservedBy(m,10,10)==1&&!p.canMoveTo(m,10,10,2,6000),"live owner still blocks others");
  a.dead=true;check(p.getReservedBy(m,10,10)==0,"dead owner must not block until TTL");
  check(p.canMoveTo(m,10,10,2,6000),"new owner can claim dead owner's empty slot immediately");
  p.cancelMove(m,10,10,1);check(p.getReservedBy(m,10,10)==2,"late dead-owner cancel preserves successor");
  check(!p.commitMove(m,0,0,10,10,3),"commit cannot steal live successor reservation");
  p.cancelMove(m,10,10,2);a.dead=false;
  check(p.canMoveTo(m,11,10,1,6000),"second claim");a.dead=true;
  check(p.canMoveTo(m,11,10,3,6000),"admission cleans dead claim without prior query");
  check(p.commitMove(m,0,0,11,10,3)&&p.getOccupier(m,11,10)==3,"normal commit after cleanup");
  a.dead=false;check(p.canMoveTo(m,12,10,1,6000),"third claim");a.dead=true;
  check(p.commitMove(m,0,0,12,10,2),"commit path cleans dead reservation");
  a.dead=false;check(p.canMoveTo(m,13,10,1,6000),"fourth claim");L1World.getInstance().objects.remove(1);
  check(p.getReservedBy(m,13,10)==0,"removed owner claim cleared");
  p.resetAll();java.util.concurrent.ExecutorService pool=java.util.concurrent.Executors.newFixedThreadPool(8);
  java.util.List<java.util.concurrent.Future<Boolean>> fs=new java.util.ArrayList<>();
  for(int id=10;id<42;id++){final int n=id;npc(n);fs.add(pool.submit(()->p.canMoveTo(m,20,20,n,6000)));}
  int winners=0;for(var f:fs)if(f.get())winners++;pool.shutdown();
  check(winners==1,"live reservations stay exclusive under contention");
  System.out.println("PASS complete TileOccupancyNpc: dead/removed cleanup, immediate reclaim, commit, late cancel and 32-contender exclusivity");
 }
}'''
}
files['l1j/server/server/model/character/TileOccupancy/TileOccupancyNpc.java']=p.read_text()
with tempfile.TemporaryDirectory() as td:
 paths=[]
 for n,s in files.items():
  f=Path(td)/n;f.parent.mkdir(parents=True,exist_ok=True);f.write_text(s);paths.append(str(f))
 subprocess.run([shutil.which('javac') or '/workspace/java-toolchain/bin/javac','--release','21','-d',td,*paths],check=True)
 subprocess.run(['java','-ea','-cp',td,'TestDeadReservation'],check=True)
