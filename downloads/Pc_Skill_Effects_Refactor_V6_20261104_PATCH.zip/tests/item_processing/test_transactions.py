#!/usr/bin/env python3
"""Compile complete production transaction/owner/admission classes against game/DB doubles.
Use --source-root to compare a source baseline. JDBC, sockets and world effects are
not integration-tested here; the full production tree is compiled separately.
"""
from pathlib import Path
import argparse, re, subprocess, tempfile, shutil, os
parser=argparse.ArgumentParser();parser.add_argument('--source-root',type=Path);parser.add_argument('--benchmark',action='store_true');parser.add_argument('--benchmark-only',action='store_true');parser.add_argument('--forks',type=int,default=1);args=parser.parse_args()
ROOT=Path(__file__).resolve().parents[2];SRC=(args.source_root or ROOT)/'src'
BASE=SRC/'l1j/server/server';DEPS=Path(os.environ.get('ITEM_DEPS_DIR','/workspace/dependencies/item-processing'))
def extract(text,signature):
 a=text.index(signature);b=text.index('{',a);depth=1;i=b+1
 while depth:
  if text[i]=='{':depth+=1
  elif text[i]=='}':depth-=1
  i+=1
 return text[a:i]
new=(BASE/'model/InventoryTransactionOwners.java').exists()
snapshot=extract((BASE/'storage/mysql/MySqlCharactersItemStorage.java').read_text(),'public static final class ItemSnapshot')
warehouse=(BASE/'model/Warehouse/Warehouse.java').read_text();key=(BASE/'storage/CacheD.java').read_text();user=(BASE/'model/network/core/cs/packet/User.java').read_text()
files={}
def put(path,text):files[path]=text
put('l1j/server/Config.java','package l1j.server; public class Config {public static double RATE_WEIGHT_LIMIT=1.0;public static int 영웅유물=10;}')
put('l1j/server/server/templates/L1Item.java','''package l1j.server.server.templates;
public class L1Item {public final int id;public int weight,charge,bless;public boolean stack=true;public L1Item(int id){this.id=id;}public int getItemId(){return id;}public String getName(){return "item"+id;}public int getWeight(){return weight;}public int getMaxChargeCount(){return charge;}public int getBless(){return bless;}public int getType1(){return 0;}public int getType2(){return 0;}public int getType(){return 0;}public int getLightFuel(){return 0;}public int getMaxUseTime(){return 0;}}
''')
fields={'Count':('int','count','1'),'EnchantLevel':('int','enchant','0'),'Identified':('boolean','identified','false'),'_durability':('int','durability','0'),'ChargeCount':('int','charge','0'),'RemainingTime':('int','remaining','0'),'LastUsed':('java.sql.Timestamp','lastUsed','null'),'Bless':('int','bless','0'),'AttrEnchantLevel':('int','attr','0'),'SpecialEnchant':('int','special','0'),'EndTime':('java.sql.Timestamp','endTime','null'),'Package':('boolean','pack','false'),'_bless_level':('int','blessLevel','0'),'_bless_level2':('int','blessLevel2','0'),'_item_level':('int','itemLevel','0'),'Hotel_Town':('String','hotel','null'),'Equipped':('boolean','equipped','false')}
item='''package l1j.server.server.model.Instance;
import l1j.server.server.templates.L1Item;
public class L1ItemInstance {private int id;private L1Item item;public L1ItemInstance(){}public L1ItemInstance(L1Item t,int n){item=t;count=n;}public int getId(){return id;}public void setId(int n){id=n;}public L1Item getItem(){return item;}public void setItem(L1Item t){item=t;}public int getItemId(){return item.getItemId();}public boolean isStackable(){return item.stack;}
'''
for suffix,(typ,field,default) in fields.items():
 getter=('is' if typ=='boolean' else 'get')+suffix
 item+=f'private {typ} {field}={default};public {typ} {getter}(){{return {field};}}public void set{suffix}({typ} x){{{field}=x;}}\n'
item+='public void install(L1ItemInstance x){id=x.id;item=x.item;'+''.join(f'{f}=x.{f};' for t,f,d in fields.values())+'}\n'
item+='public static class LastStatus {'+''.join('public void '+name+'(){}' for name in sorted(set(re.findall(r'getLastStatus\(\)\.(\w+)\(',snapshot))))+'}public LastStatus getLastStatus(){return new LastStatus();}}'
put('l1j/server/server/model/Instance/L1ItemInstance.java',item)
pc='''package l1j.server.server.model.Instance;
import java.util.concurrent.atomic.*;import l1j.server.server.model.*;import l1j.server.server.model.network.core.CIOClient;
public class L1PcInstance {
 public final int id;public int stamp=101,trade;public boolean market,resolving,tradeOk=true;public CIOClient client;
 private volatile int itemTransferBusy;private static final AtomicIntegerFieldUpdater<L1PcInstance> ITEM_TRANSFER_BUSY=AtomicIntegerFieldUpdater.newUpdater(L1PcInstance.class,"itemTransferBusy");
 public final L1PcInventory inv=new L1PcInventory();public L1PcInstance(int n){id=n;client=new CIOClient(this);}public int getId(){return id;}public int getSessionStamp(){return stamp;}public CIOClient getNetConnection(){return client;}public L1PcInventory getInventory(){return inv;}public int getTradeID(){return trade;}public boolean isTradeResolving(){return resolving;}public boolean getTradeOk(){return tradeOk;}public boolean isPrivateShop(){return market;}public int getMaxWeight(){return 100000000;}
'''
prodpc=(BASE/'model/Instance/L1PcInstance.java').read_text()
pc+='\n'.join(extract(prodpc,s) for s in ['public boolean tryBeginItemTransfer()','public void endItemTransfer()','public boolean isItemTransferBusy()'])+'}'
put('l1j/server/server/model/Instance/L1PcInstance.java',pc)
put('l1j/server/server/model/network/core/CIOClient.java','''package l1j.server.server.model.network.core;
import l1j.server.server.model.Instance.L1PcInstance;
public class CIOClient {public boolean connected=true;public L1PcInstance active;public CIOClient(L1PcInstance p){active=p;}public boolean isConnected(){return connected;}public L1PcInstance getActiveChar(){return active;}public void kick(){connected=false;}}
''')
put('l1j/server/server/model/L1PcInventory.java','''package l1j.server.server.model;
import java.util.concurrent.CopyOnWriteArrayList;import l1j.server.server.model.Instance.L1ItemInstance;
public class L1PcInventory {
 public static final int MAX_SIZE=180;public final CopyOnWriteArrayList<L1ItemInstance> items=new CopyOnWriteArrayList<>();public boolean failReplay;
 public java.util.List<L1ItemInstance> getItems(){return items;}public L1ItemInstance getItem(int id){for(var x:items)if(x.getId()==id)return x;return null;}
 public void applyEconomyImage(L1ItemInstance original,L1ItemInstance image){if(failReplay)throw new IllegalStateException("injected replay failure");if(image==null){items.remove(original);}else if(original==null){L1ItemInstance result=new L1ItemInstance();result.install(image);items.add(result);}else original.install(image);}
}
''')
put('l1j/server/server/model/L1Inventory.java','package l1j.server.server.model;public class L1Inventory {public static final int MAX_AMOUNT=2000000000;}')
put('l1j/server/server/model/L1World.java','''package l1j.server.server.model;public class L1World {private static final L1World INSTANCE=new L1World();public final java.util.Map<Integer,Object> objects=new java.util.concurrent.ConcurrentHashMap<>();public static L1World getInstance(){return INSTANCE;}public Object findObject(int id){return objects.get(id);}}''')
put('l1j/server/server/IdFactory.java','''package l1j.server.server;public class IdFactory {private static final IdFactory INSTANCE=new IdFactory();private int next=10000;public static IdFactory getInstance(){return INSTANCE;}public int nextId(){return ++next;}}''')
put('l1j/server/server/datatables/ItemTable.java','''package l1j.server.server.datatables;import l1j.server.server.templates.L1Item;public class ItemTable {private static final ItemTable INSTANCE=new ItemTable();public static ItemTable getInstance(){return INSTANCE;}public L1Item getTemplate(int id){return new L1Item(id);}}''')
put('l1j/server/server/model/item/L1ItemId.java','package l1j.server.server.model.item;public class L1ItemId {public static final int KILLTON_CONTRACT=9900001,MERIN_CONTRACT=9900002,DRAGON_KEY=9900003;}')
put('l1j/server/server/model/Warehouse/Warehouse.java','package l1j.server.server.model.Warehouse;import l1j.server.server.model.Instance.L1ItemInstance;import java.sql.Timestamp;public class Warehouse {'+extract(warehouse,'private static Timestamp copyTime(')+extract(warehouse,'public static L1ItemInstance transferCopy(')+'}')
put('l1j/server/server/storage/mysql/MySqlCharactersItemStorage.java','package l1j.server.server.storage.mysql;import l1j.server.server.model.Instance.L1ItemInstance;import java.sql.Timestamp;import java.util.Objects;public class MySqlCharactersItemStorage {'+snapshot+'}')
put('l1j/server/server/storage/cached/CTransaction.java','''package l1j.server.server.storage.cached;import java.sql.*;import l1j.server.server.storage.mysql.MySqlCharactersItemStorage.ItemSnapshot;public class CTransaction {public interface Mutation {void apply(Connection c)throws SQLException;}public static class OutcomeUnknownException extends RuntimeException {}public static void verifyItemPreimage(Connection c,ItemSnapshot s){}public static void requireTransactionalTables(Connection c,String... names){}}''')
fakecache='''package l1j.server.server.storage;
import java.util.*;import java.util.function.*;import l1j.server.server.model.Instance.L1ItemInstance;import l1j.server.server.storage.cached.CTransaction;import l1j.server.server.storage.mysql.MySqlCharactersItemStorage.ItemSnapshot;
public class CacheD {
 public static boolean barrier;public static WarehouseMove pending;public static boolean failBegin;
 public static class CommittedReplayException extends RuntimeException {}
 public static WarehouseMove beginEconomyMove(int owner,int key){if(failBegin)throw new IllegalStateException("not ready");return pending=new WarehouseMove();}
 public static void applyCommittedWarehouseMove(WarehouseMove m,Runnable action){action.run();}
 public static int submissions;public static void success(){WarehouseMove m=pending;barrier=true;m.success.run();}
 public static void failure(Throwable t){pending.error.accept(t);}
 public static class WarehouseMove {
  public Consumer<Throwable> error;public Runnable success;public final List<ItemSnapshot> writes=new ArrayList<>();
  public void onError(Consumer<Throwable> c){error=c;}public void stageWarehouseSql(CTransaction.Mutation op){}
  public void prepareOwnedDelete(int owner,int id){}public void prepareOwnedWrite(int owner,L1ItemInstance item,int previous){writes.add(ItemSnapshot.capture(item,owner));}
  public void commit(Runnable action){success=action;submissions++;}public void close(){}
  public void finishOwnerApply(Throwable failure){if(failure==null)barrier=false;}
 }
'''+extract(key,'public static int accountOrderKey(String account)')
if new:fakecache+=extract(key,'public static int accountOrderKey(String prefix, int characterId)')
put('l1j/server/server/storage/CacheD.java',fakecache+'}')
put('l1j/server/server/model/network/thread/CIOThreadCallback.java','''package l1j.server.server.model.network.thread;
import l1j.server.server.model.Instance.L1PcInstance;import java.util.function.Consumer;
public class CIOThreadCallback {private static final CIOThreadCallback INSTANCE=new CIOThreadCallback();public static CIOThreadCallback getInstance(){return INSTANCE;}public void completeWarehouseMove(L1PcInstance pc,int stamp,Runnable action,Consumer<Throwable> done){Throwable failure=null;try{if(pc.getSessionStamp()!=stamp)throw new IllegalStateException("stale session");action.run();}catch(Throwable t){failure=t;}done.accept(failure);}}
''')
put('l1j/server/server/model/network/core/cs/packet/User.java','''package l1j.server.server.model.network.core.cs.packet;import l1j.server.server.model.Instance.L1PcInstance;import l1j.server.server.model.L1InventoryTransaction;public class User {'''+extract(user,'public static l1j.server.server.model.L1InventoryTransaction CheckAndSetPendingUseETCItem(')+extract(user,'static void OnReplyUseItemPacket(')+'}')
put('l1j/server/server/model/network/core/sc/packet/SC_SystemMessage.java','''package l1j.server.server.model.network.core.sc.packet;import l1j.server.server.model.Instance.L1PcInstance;public class SC_SystemMessage {public static int count;public static void send(L1PcInstance p,String s){count++;}}''')
put('l1j/server/server/model/item/function/ItemUseCreature.java','''package l1j.server.server.model.item.function;public class ItemUseCreature {static final java.util.logging.Logger ITEM_USE2_LOG=java.util.logging.Logger.getLogger("test");}''')
production=['model/L1InventoryTransaction.java','model/network/core/cs/packet/CDB.java']
if new:production+=['model/InventoryTransactionOwners.java','model/item/function/ItemUseTransactions.java']
for name in production:put('l1j/server/server/'+name,(BASE/name).read_text())
harness=r'''
package l1j.server.server.model;
import java.sql.Timestamp;import java.util.*;import java.util.concurrent.atomic.*;
import l1j.server.server.model.Instance.*;import l1j.server.server.templates.*;
import l1j.server.server.storage.CacheD;import l1j.server.server.storage.mysql.MySqlCharactersItemStorage.ItemSnapshot;
import l1j.server.server.model.Warehouse.Warehouse;import l1j.server.server.model.network.core.cs.packet.CDB;
import l1j.server.server.storage.cached.CTransaction;
public class TransactionHarness {
 static int passed,failed;static volatile Object sink;
 static void check(boolean c,String why){if(!c)throw new AssertionError(why);}
 static void run(String name,Runnable action){CacheD.barrier=false;CacheD.failBegin=false;try{action.run();passed++;System.out.println("PASS "+name);}catch(Throwable e){failed++;System.out.println("FAIL "+name+": "+e);}}
 static L1PcInstance player(int id){L1PcInstance p=new L1PcInstance(id);L1ItemInstance i=item(id+100,200,5);p.inv.items.add(i);return p;}
 static L1ItemInstance item(int id,int template,int n){var i=new L1ItemInstance(new L1Item(template),n);i.setId(id);i.setIdentified(true);return i;}
 static L1ItemInstance first(L1PcInstance p){return p.inv.items.get(0);}
 static void prepare(L1PcInstance p,Runnable effect){try(var tx=L1InventoryTransaction.begin(p,77)){check(tx.debit(first(p),1),"debit");CDB.RequestUseItem(p,tx,effect);}}
 static void sameState(ItemSnapshot a,ItemSnapshot b){check(a.id==b.id&&a.ownerId==b.ownerId&&a.count==b.count,"snapshot state changed");}
 static void benchmark(){
   var mx=(com.sun.management.ThreadMXBean)java.lang.management.ManagementFactory.getThreadMXBean();mx.setThreadAllocatedMemoryEnabled(true);long tid=Thread.currentThread().threadId();var p=player(1);
   for(int pass=0;pass<6;pass++){int iterations=100000;long bytes=mx.getThreadAllocatedBytes(tid);long start=System.nanoTime();for(int n=0;n<iterations;n++){first(p).setCount(5);try(var tx=L1InventoryTransaction.begin(p,77)){tx.debit(first(p),1);tx.commit(null);}CacheD.success();sink=CacheD.pending;}long elapsed=System.nanoTime()-start;bytes=mx.getThreadAllocatedBytes(tid)-bytes;if(pass>0)System.out.println("BENCH receipt_count="+iterations+" bytes_per_receipt="+(bytes/(double)iterations)+" ns_per_receipt="+(elapsed/(double)iterations));}
  }
 public static void main(String[] args)throws Exception {
  if(args.length>0&&args[0].equals("benchmark-only")){benchmark();return;}
  java.util.logging.Logger.getLogger(L1InventoryTransaction.class.getName()).setLevel(java.util.logging.Level.OFF);
  run("prepare leaves live count and effects untouched",()->{var p=player(1);AtomicInteger effects=new AtomicInteger();prepare(p,effects::incrementAndGet);check(first(p).getCount()==5&&effects.get()==0&&p.isItemTransferBusy(),"early mutation");CacheD.success();check(first(p).getCount()==4&&effects.get()==1&&!p.isItemTransferBusy(),"commit failed");});
  run("item effect runs after reservation and FIFO barrier retire",()->{var p=player(1);AtomicBoolean ok=new AtomicBoolean();prepare(p,()->ok.set(!p.isItemTransferBusy()&&!CacheD.barrier));CacheD.success();check(ok.get(),"legacy effect still blocked by old reservation/barrier");});
  run("effect may reserve next receipt without old release unlocking it",()->{var p=player(1);AtomicBoolean entered=new AtomicBoolean();prepare(p,()->entered.set(p.tryBeginItemTransfer()));CacheD.success();check(entered.get()&&p.isItemTransferBusy(),"nested effect refused or new gate released");});
  run("confirmed rollback preserves item and releases once",()->{var p=player(1);AtomicInteger effects=new AtomicInteger();prepare(p,effects::incrementAndGet);CacheD.failure(new IllegalStateException("rollback"));check(first(p).getCount()==5&&effects.get()==0&&!p.isItemTransferBusy(),"rollback mutated inventory");});
  run("rollback callback may start another receipt",()->{var p=player(1);try(var tx=L1InventoryTransaction.begin(p,77)){tx.debit(first(p),1);tx.onFailure(()->check(p.tryBeginItemTransfer(),"cannot reenter after rollback"));tx.commit(null);}CacheD.failure(new IllegalStateException("rollback"));check(p.isItemTransferBusy(),"completion released new receipt");});
  run("unknown outcome quarantines and retains gate",()->{var p=player(1);prepare(p,null);CacheD.failure(new CTransaction.OutcomeUnknownException());check(p.isItemTransferBusy()&&!p.client.isConnected()&&first(p).getCount()==5,"uncertain result unlocked");});
  run("postcommit replay failure quarantines without releasing gate",()->{var p=player(1);prepare(p,null);p.inv.failReplay=true;CacheD.success();check(p.isItemTransferBusy()&&!p.client.isConnected(),"replay failure unlocked");});
  run("effect failure disconnects after durable inventory publication",()->{var p=player(1);prepare(p,()->{throw new IllegalStateException("effect failure");});CacheD.success();check(first(p).getCount()==4&&!p.client.isConnected(),"durable result not preserved");});
  run("stale session cannot apply receipt or clear new identity",()->{var p=player(1);prepare(p,null);p.stamp++;CacheD.success();check(first(p).getCount()==5&&p.isItemTransferBusy(),"stale replay applied");});
  run("second busy owner does not unlock its prior receipt",()->{var a=player(1);var b=player(2);b.tryBeginItemTransfer();boolean refused=false;try(var tx=L1InventoryTransaction.begin(a,b)){}catch(IllegalStateException e){refused=true;}check(refused&&!a.isItemTransferBusy()&&b.isItemTransferBusy(),"partial admission leaked/unlocked");});
  run("begin failure returns acquired reservation",()->{var p=player(1);CacheD.failBegin=true;try{L1InventoryTransaction.begin(p,77);throw new AssertionError("admitted");}catch(IllegalStateException e){}check(!p.isItemTransferBusy(),"begin leaked gate");});
  run("pair transfer preserves identity, quantities and both gates",()->{var a=player(2);var b=player(1);var i=first(a);i.getItem().stack=false;i.setCount(1);try(var tx=L1InventoryTransaction.begin(a,b)){tx.transfer(a,i,1,b);tx.commit(null);}check(a.isItemTransferBusy()&&b.isItemTransferBusy(),"pair not reserved");CacheD.success();check(a.inv.getItem(i.getId())==null&&b.inv.getItem(i.getId())!=null&&!a.isItemTransferBusy()&&!b.isItemTransferBusy(),"pair replay failed");});
  run("unmanned shop uses buyer owner and inventory monitor",()->{var buyer=player(1);var seller=player(2);seller.market=true;seller.client.connected=false;L1World.getInstance().objects.put(2,seller);try(var tx=L1InventoryTransaction.begin(buyer,seller)){tx.transfer(seller,first(seller),1,buyer);tx.commit(null);}CacheD.success();check(first(seller).getCount()==4&&!buyer.isItemTransferBusy()&&!seller.isItemTransferBusy(),"shop completion failed");});
  run("preimage mutation rejected before submission",()->{var p=player(1);boolean refused=false;try(var tx=L1InventoryTransaction.begin(p,77)){tx.debit(first(p),1);first(p).setChargeCount(7);try{tx.commit(null);}catch(IllegalStateException e){refused=true;}}check(refused&&!p.isItemTransferBusy(),"changed preimage admitted");});
  run("detached timestamps cannot mutate live item",()->{var p=player(1);first(p).setLastUsed(new Timestamp(1000));first(p).setEndTime(new Timestamp(2000));try(var tx=L1InventoryTransaction.begin(p,77)){AtomicReference<L1ItemInstance> ref=new AtomicReference<>();tx.change(p,first(p),ref::set);var image=ref.get();image.getLastUsed().setTime(9000);image.getEndTime().setTime(9000);check(first(p).getLastUsed().getTime()==1000&&first(p).getEndTime().getTime()==2000,"detached image aliases live timestamp");}});
  run("submitted timestamps frozen against caller mutation",()->{var p=player(1);var i=first(p);i.setLastUsed(new Timestamp(1000));i.setEndTime(new Timestamp(2000));L1ItemInstance image;try(var tx=L1InventoryTransaction.begin(p,77)){AtomicReference<L1ItemInstance> ref=new AtomicReference<>();tx.change(p,i,ref::set);image=ref.get();tx.commit(null);}image.getLastUsed().setTime(9000);image.getEndTime().setTime(9000);CacheD.success();check(i.getLastUsed().getTime()==1000&&i.getEndTime().getTime()==2000,"submitted image aliases caller timestamp");});
  run("grant-copy isolates caller and preserves metadata",()->{var p=player(1);var input=item(1000,300,2);input.setEnchantLevel(7);input.setLastUsed(new Timestamp(1234));try(var tx=L1InventoryTransaction.begin(p,77)){var image=tx.grantCopy(p,input,2);check(image!=input&&image.getEnchantLevel()==7,"grant metadata");input.setCount(99);input.setEnchantLevel(3);input.getLastUsed().setTime(9000);check(image.getCount()==2&&image.getEnchantLevel()==7&&image.getLastUsed().getTime()==1234,"grant aliases source");tx.commit(null);}CacheD.success();check(p.inv.getItem(1000).getCount()==2,"grant failed");});
  run("two inputs consume atomically or neither",()->{var p=player(1);var second=item(500,300,1);p.inv.items.add(second);AtomicInteger n=new AtomicInteger();try(var tx=L1InventoryTransaction.begin(p,77)){check(tx.debit(first(p),1)&&tx.debit(second,1),"two debit");CDB.RequestUseItem(p,tx,n::incrementAndGet);}CacheD.success();check(first(p).getCount()==4&&p.inv.getItem(500)==null&&n.get()==1,"two-input publication");});
  run("quantity limit refuses before live mutation",()->{var p=player(1);first(p).setCount(L1Inventory.MAX_AMOUNT);try(var tx=L1InventoryTransaction.begin(p,77)){check(tx.grantCopy(p,first(p),1)==null,"overflow accepted");}check(first(p).getCount()==L1Inventory.MAX_AMOUNT&&!p.isItemTransferBusy(),"overflow changed live count");});
  run("all compared fields including timestamp nanos detect mismatch",()->{var p=player(1);var i=first(p);i.setLastUsed(new Timestamp(1234));i.setEndTime(new Timestamp(5678));ItemSnapshot a=ItemSnapshot.capture(i,p.id);sameState(a,ItemSnapshot.capture(i,p.id));i.getLastUsed().setNanos(123456789);check(!Objects.equals(a.lastUsed,i.getLastUsed()),"snapshot lost nanos");});
'''

harness+=r'''
  run("2000 randomized inventory plans preserve projected outcomes",()->{
   Random random=new Random(819);long digest=1;int accepted=0,rejected=0;
   for(int scenario=0;scenario<2000;scenario++){
    var p=player(1);p.inv.items.clear();int size=random.nextInt(205);
    for(int n=0;n<size;n++){var i=item(1000+n,200+random.nextInt(18),random.nextInt(40)==0?L1Inventory.MAX_AMOUNT:1+random.nextInt(9));i.getItem().weight=random.nextInt(3)==0?0:random.nextInt(100);p.inv.items.add(i);}
    boolean committed=false;
    try(var tx=L1InventoryTransaction.begin(p,77)){
     if(!p.inv.items.isEmpty())tx.debit(first(p),1);
     var reward=item(9000,200+random.nextInt(20),1+random.nextInt(5));reward.getItem().weight=random.nextInt(100);
     tx.grantCopy(p,reward,reward.getCount());tx.commit(null);committed=true;
    }catch(IllegalStateException expected){}
    if(committed){CacheD.success();accepted++;}else rejected++;
    digest=digest*31+(committed?1:0);
    for(var i:p.inv.items){digest=digest*31+i.getId();digest=digest*31+i.getItemId();digest=digest*31+i.getCount();}
    check(!p.isItemTransferBusy(),"random plan gate leaked");
   }
   System.out.println("DIFFERENTIAL scenarios=2000 accepted="+accepted+" rejected="+rejected+" digest="+Long.toUnsignedString(digest));
  });
'''
if new:
 harness+=r'''
  run("FIFO keys exactly match legacy decimal hashing",()->{Random r=new Random(17);for(String prefix:new String[]{"item-use:","nshop:","pcroom:","", "한글:"}){for(int id:new int[]{0,1,-1,Integer.MIN_VALUE,Integer.MAX_VALUE,10,1000000})check(CacheD.accountOrderKey(prefix,id)==CacheD.accountOrderKey(prefix+id),"boundary key mismatch");for(int n=0;n<20000;n++){int id=r.nextInt();check(CacheD.accountOrderKey(prefix,id)==CacheD.accountOrderKey(prefix+id),"random key mismatch");}}});
  run("allocation-free preimage matcher covers every persisted field",()->{var p=player(1);var i=first(p);i.setLastUsed(new Timestamp(1234));i.setEndTime(new Timestamp(5678));var a=ItemSnapshot.capture(i,p.id);check(a.matchesCurrent(i,p.id)&&!a.matchesCurrent(i,p.id+1)&&!a.matchesCurrent(null,p.id),"identity match");
  for(var m:L1ItemInstance.class.getMethods()){if(!m.getName().startsWith("set")||m.getParameterCount()!=1||m.getName().equals("setItem"))continue;var before=Warehouse.transferCopy(i,i.getId(),i.getCount(),i.getChargeCount());before.setEquipped(i.isEquipped());try{Class<?> t=m.getParameterTypes()[0];Object value=t==int.class?19:t==boolean.class?false:t==String.class?"changed":new Timestamp(9999);if(t==boolean.class){String getter="is"+m.getName().substring(3);value=!(Boolean)L1ItemInstance.class.getMethod(getter).invoke(i);}m.invoke(i,value);check(!a.matchesCurrent(i,p.id),"field ignored: "+m.getName());i.install(before);}catch(ReflectiveOperationException e){throw new RuntimeException(e);}}});
  run("owner reservation release is once-only even across threads",()->{var p=player(1);var owners=new InventoryTransactionOwners(p,null,false);owners.release();check(p.tryBeginItemTransfer(),"new gate unavailable");List<Thread> threads=new ArrayList<>();for(int n=0;n<20;n++){var t=new Thread(owners::release);threads.add(t);t.start();}for(var t:threads)try{t.join();}catch(Exception e){throw new RuntimeException(e);}check(p.isItemTransferBusy(),"old release unlocked new receipt");});
  run("owner order, connection identity and stamp validation",()->{var a=player(8);var b=player(2);var owners=new InventoryTransactionOwners(a,b,false);check(owners.get(0)==b&&owners.get(1)==a&&owners.current(a),"order/identity");a.stamp++;check(!owners.current(a),"stale identity accepted");owners.release();check(a.isItemTransferBusy()&&!b.isItemTransferBusy(),"new stamp was unlocked");});
  run("shared consume helper preserves duplicate/null input rejection",()->{var p=player(1);int submitted=CacheD.submissions;l1j.server.server.model.item.function.ItemUseTransactions.consumeTwo(p,first(p),first(p),()->{throw new AssertionError("effect");});l1j.server.server.model.item.function.ItemUseTransactions.consume(p,null,null);check(CacheD.submissions==submitted&&!p.isItemTransferBusy()&&first(p).getCount()==5,"invalid consume admitted");});
  run("shared consume helper waits for durable reply",()->{var p=player(1);AtomicInteger effects=new AtomicInteger();l1j.server.server.model.item.function.ItemUseTransactions.consume(p,first(p),effects::incrementAndGet);check(effects.get()==0&&first(p).getCount()==5,"early helper effect");CacheD.success();check(effects.get()==1&&first(p).getCount()==4&&!p.isItemTransferBusy(),"helper result");});
'''
harness+=r'''
  if(args.length>0&&args[0].equals("benchmark"))benchmark();
  System.out.println("RESULT passed="+passed+" failed="+failed);
  if(failed!=0)throw new AssertionError("transaction regressions failed="+failed);
 }
}
'''
put('l1j/server/server/model/TransactionHarness.java',harness)
with tempfile.TemporaryDirectory() as td:
 d=Path(td)
 for name,text in files.items():p=d/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(text)
 cp=str(DEPS/'trove4j-3.0.3.jar')
 cmd=['java','-m','jdk.compiler/com.sun.tools.javac.Main','-source','21','-target','21','-encoding','UTF-8','-cp',cp,'-d',str(d/'classes')]+[str(d/x) for x in files]
 subprocess.run(cmd,check=True)
 for fork in range(args.forks):
  if args.forks>1:print('FORK',fork+1,flush=True)
  subprocess.run(['java','-Xmx1g','-ea','-cp',str(d/'classes')+':'+cp,'l1j.server.server.model.TransactionHarness']+(['benchmark-only'] if args.benchmark_only else ['benchmark'] if args.benchmark else []),check=True,timeout=90)
