#!/usr/bin/env python3
"""Execute original and refactored book learning with real packet serialization."""
from pathlib import Path
import subprocess, tempfile, shutil, os

ROOT=Path(__file__).resolve().parents[2]
REL=Path('l1j/server/server/model/item/function')
CP=os.pathsep.join([os.environ.get('ITEM_BUILD_CLASSES',str(ROOT/'build/item-processing/classes')),*map(str,Path(os.environ.get('ITEM_DEPS_DIR',str(ROOT/'lib'))).glob('*.jar'))])
files={}
def put(name,code):files[Path(name+'.java')]=code
put('l1j/server/server/model/Instance/UseEvents','package l1j.server.server.model.Instance; public class UseEvents { public static final java.util.List<String> all=new java.util.ArrayList<>(); }')
put('l1j/server/server/templates/L1Item','package l1j.server.server.templates; public class L1Item { public String name; public String getName(){return name;} }')
put('l1j/server/server/templates/L1Skills','''package l1j.server.server.templates;
public class L1Skills {public String name;public int level,id,skill,attr;public String getName(){return name;}public int getSkillLevel(){return level;}public int getId(){return id;}public int getSkillId(){return skill;}public int getAttr(){return attr;}}''')
put('l1j/server/server/model/Instance/L1ItemInstance','''package l1j.server.server.model.Instance;
public class L1ItemInstance {public final l1j.server.server.templates.L1Item item=new l1j.server.server.templates.L1Item();public int count=3;public l1j.server.server.templates.L1Item getItem(){return item;}}''')
put('l1j/server/server/model/L1PcInventory','''package l1j.server.server.model;import l1j.server.server.model.Instance.*;
public class L1PcInventory {public void removeItem(L1ItemInstance item,int count){item.count-=count;UseEvents.all.add("remove:"+count);}}''')
put('l1j/server/server/model/Instance/L1PcInstance','''package l1j.server.server.model.Instance;
import l1j.server.server.model.network.core.CIOClient;
public class L1PcInstance {public int attr;public boolean gm,known;public final CIOClient client=new CIOClient();private final l1j.server.server.model.L1PcInventory inv=new l1j.server.server.model.L1PcInventory();public int getId(){return 77;}public int getElfAttr(){return attr;}public boolean isGm(){return gm;}public boolean isSkillMastery(int id){UseEvents.all.add("known:"+id);return known;}public l1j.server.server.model.L1PcInventory getInventory(){return inv;}public CIOClient getNetConnection(){return client;}}''')
put('l1j/server/server/datatables/SkillsTable','''package l1j.server.server.datatables;
import l1j.server.server.templates.L1Skills;import l1j.server.server.model.Instance.UseEvents;
public class SkillsTable {public static final java.util.Map<Integer,L1Skills> skills=new java.util.HashMap<>();private static final SkillsTable ONE=new SkillsTable();public static SkillsTable getInstance(){return ONE;}public L1Skills getTemplate(int id){return skills.get(id);}public void spellMastery(int pc,int skill,String name,int a,int b){UseEvents.all.add("mastery:"+pc+":"+skill+":"+name);}}''')
for cls in ['SC_ServerMessage','SC_SystemMessage']:
 put('l1j/server/server/model/network/core/sc/packet/'+cls,'package l1j.server.server.model.network.core.sc.packet;import l1j.server.server.model.Instance.*;public class '+cls+' {public static void send(L1PcInstance pc,'+('int' if cls=='SC_ServerMessage' else 'String')+' value){UseEvents.all.add("message:"+value);}}')
put('l1j/server/server/model/network/core/sc/packet/SC_SkillSound','''package l1j.server.server.model.network.core.sc.packet;import l1j.server.server.model.Instance.*;
public class SC_SkillSound {public static long pack(int id,int effect){return ((long)id<<32)|(effect&0xffffffffL);}public static void sendPacked(L1PcInstance pc,long sound){UseEvents.all.add("sound:"+sound);}public static void broadcastPacked(L1PcInstance pc,long sound){UseEvents.all.add("broadcast:"+sound);}}''')
put('l1j/server/Config','package l1j.server;public class Config {public static String STUN_SKILL_RND_TIME="500,1000,1500",STUN_SKILL_RND_TIME111="800,1600",STUN_SKILL_RND_TIME11="700,1400";}')
fixture=ROOT/'tests/item_processing/fixtures/ItemUseSpellBooks.before.java.txt'
legacy=fixture.read_text(); token=__import__('re').compile(r'"(?:\\.|[^"\\])*"|\'(?:\\.|[^\'\\])*\'|//[^\n]*|/\*[\s\S]*?\*/|.',__import__('re').DOTALL)
methods=[]
for n in range(1,7):
 start=legacy.index('public static void SpellBook'+str(n)+'(');brace=legacy.index('{',start);depth=1
 for match in token.finditer(legacy,brace+1):
  if match.group()=='{':depth+=1
  elif match.group()=='}':depth-=1
  if depth==0:methods.append(legacy[start:match.end()]);break
put(str(REL/'LegacySkillBookLearning'),'''package l1j.server.server.model.item.function;
import l1j.server.server.model.Instance.*;import l1j.server.server.model.network.core.CIOClient;import l1j.server.server.model.network.core.sc.packet.*;import l1j.server.server.datatables.SkillsTable;import l1j.server.server.templates.L1Skills;
class LegacySkillBookLearning {'''+ '\n'.join(methods)+'}')
put(str(REL/'EffectRefactorContract'),r'''package l1j.server.server.model.item.function;
import java.util.*;import java.util.concurrent.*;import l1j.server.server.model.Instance.*;import l1j.server.server.templates.L1Skills;import l1j.server.server.datatables.SkillsTable;
class EffectRefactorContract {
 static int checks; static void check(boolean b,String msg){checks++;if(!b)throw new AssertionError(msg);}
 static void legacy(int kind,L1PcInstance pc,L1ItemInstance item){switch(kind){case 0->LegacySkillBookLearning.SpellBook1(pc,item,null);case 1->LegacySkillBookLearning.SpellBook2(pc,item);case 2->LegacySkillBookLearning.SpellBook3(pc,item,null);case 3->LegacySkillBookLearning.SpellBook4(pc,item,null);case 4->LegacySkillBookLearning.SpellBook5(pc,item,null);case 5->LegacySkillBookLearning.SpellBook6(pc,item,null);}}
 static List<String> execute(int kind,boolean old,int attr,boolean gm,boolean known,String name){UseEvents.all.clear();L1PcInstance pc=new L1PcInstance();pc.attr=attr;pc.gm=gm;pc.known=known;L1ItemInstance item=new L1ItemInstance();item.item.name=name;if(old)legacy(kind,pc,item);else ItemUseSkillBookLearning.learn(pc,item,ItemUseSkillBookLearning.Kind.values()[kind]);return List.copyOf(UseEvents.all);}
 static void books(){Random random=new Random(1729);int scenarios=0;
  for(int kind=0;kind<6;kind++)for(int round=0;round<500;round++){
   SkillsTable.skills.clear();var info=ItemUseSkillBookLearning.Kind.values()[kind];int chosen=info.first+random.nextInt(info.last-info.first+1);
   for(int id=1;id<=241;id++){L1Skills skill=new L1Skills();skill.id=random.nextInt();skill.skill=id+1000;skill.level=random.nextInt(35)-2;skill.name="스킬"+(round%7==0?"중복":id);skill.attr=new int[]{0,1,2,4,8,16}[random.nextInt(6)];SkillsTable.skills.put(id,skill);}
   int attr=new int[]{0,1,2,4,8,16}[random.nextInt(6)];boolean gm=random.nextBoolean(),known=random.nextBoolean();String name=round%13==0?"없는 책":info.prefix+SkillsTable.skills.get(chosen).name+")";
   var before=execute(kind,true,attr,gm,known,name);var after=execute(kind,false,attr,gm,known,name);check(before.equals(after),"book difference kind="+kind+" round="+round+" old="+before+" new="+after);scenarios++;
  }
  System.out.println("PASS "+scenarios+" differential book uses: actual old methods vs new flow, real SC_AddSkill wire bytes, messages/sounds/mastery/debit order");
  for(String prefix:new String[]{"기술서 (","마법서 (","수정("})for(String name:new String[]{"마법","abc","İσK","𐐀","null","","가)나"})for(String book:new String[]{prefix+name+")",(prefix+name+")").toUpperCase(Locale.ROOT),prefix+name,"x"+prefix+name+")"})check(ItemUseSkillBookLearning.matches(book,prefix,name)==book.equalsIgnoreCase(prefix+name+")"),"name match semantics");
 }
 static String outcome(String csv,Random random,ItemUseDurationChoices.Choices choices){try {String result;if(choices==null){String[] values=csv.split(",");result=Integer.valueOf(values[random.nextInt(values.length)]).toString();}else result=Integer.toString(choices.choose(csv,random));return result+":"+random.nextLong();}catch(RuntimeException failure){return failure.getClass().getName()+":"+random.nextLong();}}
 static void durations()throws Exception {var choices=new ItemUseDurationChoices.Choices();String[] values={"500,1000,1500","800,1600","9,,11",",", "",null,"1,invalid,3"," 8,7","2147483648,2","2,3,","-5,0,42"};for(int i=0;i<5000;i++){String csv=values[i%values.length];check(outcome(csv,new Random(i),null).equals(outcome(csv,new Random(i),choices)),"duration behavior changed for "+csv);}
  var workers=Executors.newFixedThreadPool(4);try {List<Future<?>> jobs=new ArrayList<>();for(int t=0;t<4;t++){final int thread=t;jobs.add(workers.submit(()->{for(int i=0;i<3000;i++){String csv=values[(thread+i)%2];if(!outcome(csv,new Random(i),null).equals(outcome(csv,new Random(i),choices)))throw new AssertionError("concurrent cache mix");}}));}for(var job:jobs)job.get();}finally{workers.shutdownNow();}
  System.out.println("PASS 5000 duration comparisons including invalid/unselected tokens, RNG state and configuration changes; 12000 concurrent choices");
 }
 public static void main(String[] args)throws Exception {books();durations();System.out.println("RESULT assertions="+checks);}
}''')

with tempfile.TemporaryDirectory() as td:
 d=Path(td)
 stubs=ROOT/'tests/item_processing/stubs_transport'
 put('l1j/server/server/model/network/packet/ServerPacket',(stubs/'l1j/server/server/model/network/packet/ServerPacket.java').read_text())
 for name in ['CIOClient','CIOUserSocket','CIOFrame']:
  p=stubs/'l1j/server/server/model/network/core'/(name+'.java');text=p.read_text()
  if name=='CIOUserSocket':text=text.replace('checksum = length', 'l1j.server.server.model.Instance.UseEvents.all.add("skill:"+java.util.HexFormat.of().formatHex(lastBytes));\n        checksum = length')
  put('l1j/server/server/model/network/core/'+name,text)
 for rel,text in files.items():
  p=d/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(text)
 real=[REL/'ItemUseDurationChoices.java',REL/'ItemUseSkillBookLearning.java',Path('l1j/server/server/model/network/buffer/WriteBuffer.java'),Path('l1j/server/server/model/network/core/sc/packet/SC_AddSkill.java')]
 sources=[*map(str,d.rglob('*.java')),*[str(ROOT/'src'/p) for p in real]]
 subprocess.run(['java','-m','jdk.compiler/com.sun.tools.javac.Main','--enable-preview','-source','21','-target','21','-encoding','UTF-8','-cp',CP,'-d',td,*sources],check=True,timeout=60)
 subprocess.run(['java','--enable-preview','-ea','-cp',td+os.pathsep+CP,'l1j.server.server.model.item.function.EffectRefactorContract'],check=True,timeout=60)
