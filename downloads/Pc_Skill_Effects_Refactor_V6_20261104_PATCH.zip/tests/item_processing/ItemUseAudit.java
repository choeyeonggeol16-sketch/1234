import java.nio.file.*;
import java.util.*;
import java.util.regex.*;
import javax.tools.*;
import com.sun.source.tree.*;
import com.sun.source.util.*;

/** Independent AST audit of dispatch labels, effects and their exit destinations. */
class ItemUseAudit {
    static final Map<String,String> NAMES=Map.ofEntries(
        Map.entry("l1iteminstance","item"),Map.entry("l1iteminstance1","targetItem"),
        Map.entry("l","targetItemObjectId"),Map.entry("s","text"),
        Map.entry("spellsc_objid","spellTargetId"),Map.entry("spellsc_x","spellTargetX"),
        Map.entry("spellsc_y","spellTargetY"),Map.entry("blanksc_skillid","blankScrollSkillId"),
        Map.entry("cookStatus","cookingStatus"),Map.entry("cookNo","cookingNumber"),
        Map.entry("fishX","fishingX"),Map.entry("fishY","fishingY"),
        Map.entry("bookmark_mapid","bookmarkMapId"),Map.entry("bookmark_x","bookmarkX"),
        Map.entry("bookmark_y","bookmarkY"),Map.entry("BookTel","teleportBookSlot"),
        Map.entry("use_objid","storedItemObjectId"),Map.entry("itemObjid","itemObjectId"),
        Map.entry("use_type","itemUseType"));
    static final Pattern TOKENS=Pattern.compile("\"(?:\\\\.|[^\"\\\\])*\"|'(?:\\\\.|[^'\\\\])*'|//[^\\n]*|/\\*[\\s\\S]*?\\*/|\\s+|.",Pattern.DOTALL);
    record Edit(int a,int b,String text) {}
    static String compact(String text) {
        // Tokenize strings/comments first: message text and escapes remain exact.
        StringBuilder out=new StringBuilder();int i=0;
        while(i<text.length()) {
            char c=text.charAt(i);
            if(c=='"'||c=='\'') {
                int a=i++;while(i<text.length()){char q=text.charAt(i++);if(q=='\\'&&i<text.length())i++;else if(q==c)break;}
                out.append(text,a,i);
            } else if(c=='/'&&i+1<text.length()&&text.charAt(i+1)=='/') {
                i+=2;while(i<text.length()&&text.charAt(i)!='\n')i++;
            } else if(c=='/'&&i+1<text.length()&&text.charAt(i+1)=='*') {
                int end=text.indexOf("*/",i+2);i=end<0?text.length():end+2;
            } else {if(!Character.isWhitespace(c))out.append(c);i++;}
        }
        return out.toString();
    }
    static class Source {
        final String text;final CompilationUnitTree unit;final SourcePositions positions;
        Source(Path p)throws Exception {
            text=Files.readString(p);var compiler=ToolProvider.getSystemJavaCompiler();
            try(var fm=compiler.getStandardFileManager(null,null,null)) {
                var input=new SimpleJavaFileObject(java.net.URI.create("string:///AuditInput.java"),JavaFileObject.Kind.SOURCE) {
                    @Override public CharSequence getCharContent(boolean ignoreEncodingErrors){return text;}
                };
                var task=(JavacTask)compiler.getTask(null,fm,null,List.of("-proc:none"),null,List.of(input));
                unit=task.parse().iterator().next();positions=Trees.instance(task).getSourcePositions();
            }
        }
        int a(Tree t){return (int)positions.getStartPosition(unit,t);}
        int b(Tree t){return (int)positions.getEndPosition(unit,t);}
        MethodTree method(String name) {
            List<MethodTree> result=new ArrayList<>();
            new TreeScanner<Void,Void>(){
                @Override public Void visitMethod(MethodTree m,Void p){if(m.getName().contentEquals(name))result.add(m);return null;}
            }.scan(unit,null);
            check(result.size()==1,"ambiguous method "+name);return result.getFirst();
        }
        String canonical(Tree node,SwitchTree outer,boolean mapNames) {
            int start=a(node),end=b(node);List<Edit> edits=new ArrayList<>();
            new TreePathScanner<Void,Void>() {
                @Override public Void visitIdentifier(IdentifierTree t,Void p) {
                    if(mapNames&&NAMES.containsKey(t.getName().toString()))
                        edits.add(new Edit(a(t),b(t),NAMES.get(t.getName().toString())));
                    return null;
                }
                boolean nestedFunction() {
                    for(var q=getCurrentPath().getParentPath();q!=null;q=q.getParentPath()) {
                        if(q.getLeaf() instanceof LambdaExpressionTree)return true;
                        if(q.getLeaf() instanceof MethodTree)return a(q.getLeaf())>start;
                    }
                    return false;
                }
                @Override public Void visitReturn(ReturnTree t,Void p) {
                    if(!nestedFunction()) {
                        String expr=t.getExpression()==null?"":t.getExpression().toString();
                        if(expr.isEmpty()||expr.equals("ItemUseResult.STOP")) {
                            edits.add(new Edit(a(t),b(t),"@STOP@"));return null;
                        }
                        if(expr.equals("ItemUseResult.COMPLETE")) {
                            edits.add(new Edit(a(t),b(t),"@TAIL@"));return null;
                        }
                    }
                    return super.visitReturn(t,p);
                }
                @Override public Void visitYield(YieldTree t,Void p) {
                    String expr=t.getValue().toString();
                    if(expr.equals("ItemUseResult.COMPLETE")||expr.equals("ItemUseResult.STOP")) {
                        edits.add(new Edit(a(t),b(t),expr.endsWith("COMPLETE")?"@TAIL@":"@STOP@"));return null;
                    }
                    return super.visitYield(t,p);
                }
                @Override public Void visitBreak(BreakTree t,Void p) {
                    if(t.getLabel()==null&&outer!=null)for(var q=getCurrentPath().getParentPath();q!=null;q=q.getParentPath()) {
                        var x=q.getLeaf();
                        if(x instanceof SwitchTree || x instanceof ForLoopTree || x instanceof EnhancedForLoopTree
                                || x instanceof WhileLoopTree || x instanceof DoWhileLoopTree) {
                            if(x==outer)edits.add(new Edit(a(t),b(t),"@TAIL@"));break;
                        }
                    }
                    return null;
                }
            }.scan(TreePath.getPath(unit,node),null);
            edits.sort(Comparator.comparingInt(Edit::a).reversed());String s=text.substring(start,end);
            for(Edit e:edits)s=s.substring(0,e.a-start)+e.text+s.substring(e.b-start);
            return compact(s);
        }
    }
    record Group(List<String> labels,List<? extends StatementTree> statements) {}
    static boolean completes(StatementTree t) {
        if(t instanceof ReturnTree||t instanceof BreakTree||t instanceof ThrowTree)return false;
        if(t instanceof BlockTree b)return b.getStatements().isEmpty()||completes(b.getStatements().getLast());
        if(t instanceof IfTree x)return x.getElseStatement()==null||completes(x.getThenStatement())||completes(x.getElseStatement());
        return true;
    }
    static SwitchTree largestSwitch(MethodTree method) {
        List<SwitchTree> found=new ArrayList<>();new TreeScanner<Void,Void>(){
            @Override public Void visitSwitch(SwitchTree t,Void p){found.add(t);return super.visitSwitch(t,p);}
        }.scan(method.getBody(),null);
        return found.stream().max(Comparator.comparingInt(t->t.getCases().size())).orElseThrow();
    }
    static List<Group> groups(SwitchTree s) {
        List<Group> groups=new ArrayList<>();List<String> labels=new ArrayList<>();
        for(CaseTree c:s.getCases()) {
            if(c.getExpressions().isEmpty())labels.add("default");else for(var e:c.getExpressions())labels.add(e.toString());
            if(!c.getStatements().isEmpty()){groups.add(new Group(List.copyOf(labels),c.getStatements()));labels.clear();}
        }
        check(labels.isEmpty(),"unmatched fallthrough labels");return groups;
    }
    static void check(boolean ok,String why){if(!ok)throw new AssertionError(why);}
    static Map<String,Source> cache=new HashMap<>();
    public static void main(String[] args)throws Exception {
        Path root=Path.of(args[0]),base=root.resolve("src/l1j/server/server/model/item/function");
        Source old=new Source(root.resolve("tests/item_processing/fixtures/ItemUseCreature.before.java.txt"));
        SwitchTree before=largestSwitch(old.method("useCreatureItem"));List<Group> groups=groups(before);
        Source dispatch=new Source(base.resolve("ItemUseDispatcher.java"));
        // Arrow switch is an expression, so find it separately.
        List<SwitchExpressionTree> exprs=new ArrayList<>();new TreeScanner<Void,Void>(){
            @Override public Void visitSwitchExpression(SwitchExpressionTree t,Void p){exprs.add(t);return super.visitSwitchExpression(t,p);}
        }.scan(dispatch.method("use"),null);
        var after=exprs.getFirst().getCases();check(after.size()==groups.size(),"case group count changed");
        int labels=0;
        for(int i=0;i<groups.size();i++) {
            var g=groups.get(i);var c=after.get(i);var names=c.getExpressions().stream().map(Object::toString).toList();
            if(names.isEmpty())names=List.of("default");check(names.equals(g.labels),"case labels/order changed at "+i);labels+=c.getExpressions().size();
            String expected="";for(var st:g.statements)expected+=old.canonical(st,before,true);
            if(completes(g.statements.getLast()))expected+="@TAIL@";
            Source actualSource=dispatch;List<? extends StatementTree> statements;
            if(c.getBody() instanceof MethodInvocationTree call) {
                var select=(MemberSelectTree)call.getMethodSelect();String className=select.getExpression().toString();
                if(!cache.containsKey(className))cache.put(className,new Source(base.resolve(className+".java")));
                actualSource=cache.get(className);var method=actualSource.method(select.getIdentifier().toString());
                statements=method.getBody().getStatements().stream().filter(t->!(t instanceof VariableTree v
                    && v.getInitializer()!=null&&v.getInitializer().toString().startsWith("use."))).toList();
            } else statements=((BlockTree)c.getBody()).getStatements();
            String actual="";for(var st:statements)actual+=actualSource.canonical(st,null,false);
            if(!actual.equals(expected)) {
                int at=0;while(at<Math.min(actual.length(),expected.length())&&actual.charAt(at)==expected.charAt(at))at++;
                throw new AssertionError("effect/exit changed at group "+i+" "+g.labels+" offset "+at
                    +"\nexpected="+expected.substring(Math.max(0,at-60),Math.min(expected.length(),at+140))
                    +"\nactual="+actual.substring(Math.max(0,at-60),Math.min(actual.length(),at+140)));
            }
        }
        Source oldUser=new Source(root.resolve("tests/item_processing/fixtures/User.before.java.txt"));
        Source extensions=new Source(base.resolve("ItemUseExtensions.java"));
        check(oldUser.canonical(oldUser.method("UseItem").getBody(),null,true)
            .equals(extensions.canonical(extensions.method("use").getBody(),null,false)),"extension precedence/effects changed");
        Source user=new Source(root.resolve("src/l1j/server/server/model/network/core/cs/packet/User.java"));
        for(String method:List.of("OnUseItemPacket0","CanUseItem","CheckAndSetPendingUseETCItem","OnReplyUseItemPacket"))
            check(oldUser.canonical(oldUser.method(method).getBody(),null,false)
                .equals(user.canonical(user.method(method).getBody(),null,false)),"packet/transaction method changed: "+method);
        System.out.println("PASS AST audit: "+groups.size()+" effect branches, "+labels+" explicit labels; literals/order/exits, extension precedence and 4 packet/transaction APIs preserved");
    }
}
