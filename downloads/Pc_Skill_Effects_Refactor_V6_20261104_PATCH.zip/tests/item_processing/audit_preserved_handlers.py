#!/usr/bin/env python3
"""Verify all item-effect source bodies against a baseline, excluding reviewed common plumbing."""
from pathlib import Path
import argparse, re, json, hashlib, subprocess
p=argparse.ArgumentParser();p.add_argument('--baseline',type=Path,required=True);a=p.parse_args()
root=Path(__file__).resolve().parents[2];relative=Path('src/l1j/server/server/model/item/function')
def method(s,signature):
 start=s.index(signature);b=s.index('{',start);depth=1;i=b+1
 while depth:
  if s[i]=='{':depth+=1
  elif s[i]=='}':depth-=1
  i+=1
 return s[start:i]
def plumbing(s,name):
 s=re.sub(r'CacheD\.accountOrderKey\(("[^"\n]+")\s*\+\s*(pc\.getId\(\)|characterId)\)',r'ORDER_KEY(\1,\2)',s)
 s=re.sub(r'CacheD\.accountOrderKey\(("[^"\n]+")\s*,\s*(pc\.getId\(\)|characterId)\)',r'ORDER_KEY(\1,\2)',s)
 if name=='ItemUseCreature.java':
  s=s.replace('Calendar cal = Calendar.getInstance();','final long now = System.currentTimeMillis();')
  # Only the legacy common item reuse-time block used this expression.
  s=s.replace('cal.getTimeInMillis() - lastUsed.getTime()','now - lastUsed.getTime()')
 if name=='ItemUseDurable.java':
  for signature in ['public static void UseDurableConsume(', 'public static void UseDurableConsumeTwoInput(']:
   s=s.replace(method(s,signature),signature+'REVIEWED_SHARED_CONSUME')
 # Remove whitespace only outside quoted Java literals; preserve game strings exactly.
 tokens=re.findall(r'"(?:\\.|[^"\\])*"|\'(?:\\.|[^\'\\])*\'|[^\"\'\s]+',s)
 return ''.join(tokens)
checked=[]
split_dispatch=(root/relative/'ItemUseDispatcher.java').exists()
if split_dispatch:
 subprocess.run(['java',str(root/'tests/item_processing/ItemUseAudit.java'),str(root)],check=True,timeout=60)
for before in sorted((a.baseline/relative).glob('*.java')):
 after=root/relative/before.name
 comparison=after
 if split_dispatch and before.name=='ItemUseCreature.java':
  # Its moved bodies/labels/exits were checked above; independently verify the
  # frozen reference is the baseline plus only the reviewed V2 common changes.
  comparison=root/'tests/item_processing/fixtures/ItemUseCreature.before.java.txt'
 if plumbing(before.read_text(),before.name)!=plumbing(comparison.read_text(),before.name):
  raise AssertionError('Unreviewed item-effect body change: '+before.name)
 checked.append(before.name)
result={'item_function_files_checked':len(checked),'excluded_plumbing':['FIFO key construction (exact hash equivalence tested)','common reuse-time clock read','one/two-input durable-consume wrappers'],'files':checked}
(root/'validation/item_handler_preservation.json').write_text(json.dumps(result,indent=2))
print('PASS preserved item-effect bodies:',len(checked),'files; gameplay literals retained')
