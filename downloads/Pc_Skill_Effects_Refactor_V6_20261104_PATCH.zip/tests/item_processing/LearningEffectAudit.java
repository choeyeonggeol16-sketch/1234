import java.nio.file.*;
import java.util.*;
import java.util.regex.*;
import javax.tools.*;
import com.sun.source.tree.*;
import com.sun.source.util.*;

/** Compare every deferred effect body, independently of runtime test scenarios. */
class LearningEffectAudit {
    static CompilationUnitTree read(Path path)throws Exception {
        var compiler=ToolProvider.getSystemJavaCompiler();
        try(var fm=compiler.getStandardFileManager(null,null,null)) {
            String text=Files.readString(path);
            var file=new SimpleJavaFileObject(java.net.URI.create("string:///Audit.java"),JavaFileObject.Kind.SOURCE) {
                @Override public CharSequence getCharContent(boolean ignored){return text;}
            };
            var task=(JavacTask)compiler.getTask(null,fm,null,List.of("-proc:none"),null,List.of(file));
            return task.parse().iterator().next();
        }
    }
    static String compact(String text) {
        StringBuilder out=new StringBuilder();
        for(int i=0;i<text.length();) {
            char c=text.charAt(i);
            if(c=='"'||c=='\'') {
                int a=i++;while(i<text.length()){char x=text.charAt(i++);if(x=='\\'&&i<text.length())i++;else if(x==c)break;}
                out.append(text,a,i);
            } else {if(!Character.isWhitespace(c))out.append(c);i++;}
        }
        return out.toString();
    }
    static String expanded(String body) {
        String sound="SC_SkillSound.send(pc,pc.getId(),224);SC_SkillSound.broadcast(pc,pc.getId(),224);";
        body=compact(body).replace("playLearnSound(pc);",sound);
        var matcher=Pattern.compile("finishPassive\\(pc,([^)]*)\\);").matcher(body);
        return matcher.replaceAll(m->Matcher.quoteReplacement("pc.setSkillEffect("+m.group(1)+",-1);"+sound));
    }
    public static void main(String[] args)throws Exception {
        Path root=Path.of(args[0]);int count=0;
        for(String owner:List.of("ItemUsePassiveLearning","ItemUseSkillLearning")) {
            Map<String,String> old=new LinkedHashMap<>(),current=new LinkedHashMap<>();
            new TreeScanner<Void,Void>() {
                @Override public Void visitCase(CaseTree c,Void ignored) {
                    List<LambdaExpressionTree> callbacks=new ArrayList<>();
                    new TreeScanner<Void,Void>() {
                        @Override public Void visitMethodInvocation(MethodInvocationTree call,Void p) {
                            if(call.getMethodSelect().toString().endsWith("useDurablePassive")||call.getMethodSelect().toString().endsWith("UseDurableExchange"))
                                callbacks.add((LambdaExpressionTree)call.getArguments().getLast());
                            return super.visitMethodInvocation(call,p);
                        }
                    }.scan(c,null);
                    if(callbacks.size()!=1)throw new AssertionError("old callback count");
                    for(var label:c.getExpressions())old.put(label.toString(),compact(callbacks.getFirst().getBody().toString()));
                    return null;
                }
            }.scan(read(root.resolve("tests/item_processing/fixtures/"+owner+".v4.java.txt")),null);
            new TreeScanner<Void,Void>() {
                @Override public Void visitMethod(MethodTree method,Void p) {
                    return method.getName().contentEquals("effectFor")?super.visitMethod(method,p):null;
                }
                @Override public Void visitCase(CaseTree c,Void p) {
                    if(c.getBody() instanceof LambdaExpressionTree callback)
                        for(var label:c.getExpressions())current.put(label.toString(),expanded(callback.getBody().toString()));
                    return null;
                }
            }.scan(read(root.resolve("src/l1j/server/server/model/item/function/"+owner+".java")),null);
            if(!old.equals(current))throw new AssertionError("effect body or item routing changed: "+owner);
            count+=old.size();
        }
        System.out.println("PASS "+count+" deferred effect bodies and item routes exactly preserved after expanding shared sound/passive helpers");
    }
}
