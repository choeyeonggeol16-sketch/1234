import java.nio.file.*;
import java.util.*;
import javax.tools.*;
import com.sun.source.tree.*;
import com.sun.source.util.*;

/** Independent parser audit of moved effects, their dispatch, and legacy APIs. */
class EffectSourceAudit {
    record Source(CompilationUnitTree unit, ClassTree type) {
        Map<String,MethodTree> methods() {
            Map<String,MethodTree> result=new LinkedHashMap<>();
            for(var member:type.getMembers()) if(member instanceof MethodTree m && m.getReturnType()!=null)
                result.put(m.getName().toString(),m);
            return result;
        }
        Map<String,String> cases() {
            Map<String,String> result=new LinkedHashMap<>();
            var method=methods().get("use");
            for(var statement:method.getBody().getStatements()) if(statement instanceof SwitchTree sw)
                for(var c:sw.getCases()) for(var label:c.getExpressions())
                    result.put(label.toString(),compact(c.getStatements().toString()));
            return result;
        }
    }
    static Source read(Path path)throws Exception {
        var compiler=ToolProvider.getSystemJavaCompiler();
        try(var fm=compiler.getStandardFileManager(null,null,null)) {
            String text=Files.readString(path);
            var file=new SimpleJavaFileObject(java.net.URI.create("string:///Audit.java"),JavaFileObject.Kind.SOURCE) {
                @Override public CharSequence getCharContent(boolean ignored) {return text;}
            };
            var task=(JavacTask)compiler.getTask(null,fm,null,List.of("-proc:none"),null,List.of(file));
            var unit=task.parse().iterator().next();
            return new Source(unit,(ClassTree)unit.getTypeDecls().getFirst());
        }
    }
    static String compact(String text) {
        text=unicode(text);
        StringBuilder out=new StringBuilder();
        for(int i=0;i<text.length();) {
            char c=text.charAt(i);
            if(c=='"'||c=='\'') {
                int start=i++;while(i<text.length()) {char x=text.charAt(i++);if(x=='\\'&&i<text.length())i++;else if(x==c)break;}
                out.append(text,start,i);
            } else {if(!Character.isWhitespace(c))out.append(c);i++;}
        }
        return out.toString();
    }
    static String unicode(String text) {
        StringBuilder out=new StringBuilder();int slashes=0;
        for(int i=0;i<text.length();i++) {
            char c=text.charAt(i);
            if(c=='\\' && slashes%2==0 && i+5<text.length() && text.charAt(i+1)=='u') {
                try {int value=Integer.parseInt(text.substring(i+2,i+6),16);
                    if(value>=128){out.append((char)value);i+=5;slashes=0;continue;}
                } catch(NumberFormatException ignored) {}
            }
            out.append(c);slashes=c=='\\'?slashes+1:0;
        }
        return out.toString();
    }
    static String reviewedCombat(String text) {
        text=compact(text).replace("Randomrandom=newRandom();","Randomrandom=ThreadLocalRandom.current();");
        for(var rule:List.of(new String[]{"STUN_SKILL_RND_TIME","엘븐스트라이크시간","blaze"},
                new String[]{"STUN_SKILL_RND_TIME111","엘븐스트라이크시간","elven"},
                new String[]{"STUN_SKILL_RND_TIME11","데몰리션시간","demolition"})) {
            String old="String[]stunTimeArray=Config."+rule[0]+".split(\",\");"+rule[1]+"=Integer.valueOf(stunTimeArray[random.nextInt(stunTimeArray.length)]).intValue();";
            text=text.replace(old,"finalint"+rule[1]+"=ItemUseDurationChoices."+rule[2]+"(random);");
        }
        return text;
    }
    static void check(boolean ok,String reason) {if(!ok)throw new AssertionError(reason);}
    public static void main(String[] args)throws Exception {
        Path root=Path.of(args[0]),base=root.resolve("src/l1j/server/server/model/item/function");
        Path fixtures=root.resolve("tests/item_processing/fixtures");
        var before=read(fixtures.resolve("ItemUseCombatAbilities.before.java.txt")).methods();
        var facade=read(base.resolve("ItemUseCombatAbilities.java")).methods();
        check(before.keySet().equals(facade.keySet()),"combat public API methods changed");
        Map<String,String> owners=new HashMap<>();
        for(String name:List.of("ItemUseStunCombat","ItemUseMagicCombat","ItemUseShadowCombat","ItemUseCommandCombat","ItemUseCombatSupport")) {
            var source=read(base.resolve(name+".java"));
            for(var entry:source.methods().entrySet()) {
                String method=entry.getKey();var old=before.get(method);check(old!=null,"unexpected moved combat method");
                check(reviewedCombat(old.getBody().toString()).equals(compact(entry.getValue().getBody().toString())),"combat effect changed: "+method);
                check(owners.put(method,name)==null,"duplicate combat method");
            }
        }
        check(owners.size()==before.size(),"missing combat implementation");
        for(var entry:before.entrySet()) {
            String name=entry.getKey();var old=entry.getValue();var api=facade.get(name);
            check(old.getReturnType().toString().equals(api.getReturnType().toString())&&old.getParameters().toString().equals(api.getParameters().toString()),"API signature changed: "+name);
            String arguments=String.join(",",old.getParameters().stream().map(p->p.getName().toString()).toList());
            String expected="{"+(old.getReturnType().toString().equals("void")?"":"return")+owners.get(name)+"."+name+"("+arguments+");}";
            check(compact(api.getBody().toString()).equals(expected),"facade forwarding changed: "+name);
        }
        System.out.println("PASS 14 combat bodies and API forwarding unchanged except reviewed local durations, bounded CSV reuse and per-thread RNG");
        Map<String,String> expected=read(fixtures.resolve("ItemUseAdvancedAbilities.before.java.txt")).cases();
        Map<String,String> after=new HashMap<>(),routes=new HashMap<>();
        boolean rules=Files.exists(base.resolve("ItemLearningRule.java"));
        for(String name:List.of("ItemUsePassiveLearning","ItemUseSkillLearning","ItemUseActiveSkills")) {
            boolean ruleModule=rules&&!name.equals("ItemUseActiveSkills");
            var source=read(ruleModule?fixtures.resolve(name+".v4.java.txt"):base.resolve(name+".java"));
            for(var entry:source.cases().entrySet()) {check(after.put(entry.getKey(),entry.getValue())==null,"duplicate advanced case");routes.put(entry.getKey(),name);}
        }
        check(expected.equals(after),"advanced case bodies/labels/exits changed");
        var dispatch=read(base.resolve("ItemUseAdvancedAbilities.java")).methods().get("use");
        int count=0;
        for(var st:dispatch.getBody().getStatements())if(st instanceof SwitchTree sw)for(var c:sw.getCases())for(var label:c.getExpressions()) {
            check(compact(c.getBody().toString()).equals(routes.get(label.toString())+".use(pc,l1iteminstance,itemId);"),"advanced route changed");count++;
        }
        check(count==expected.size(),"advanced route count changed");
        System.out.println("PASS 52 original advanced cases and current high-level item routes preserved");
        if(rules) {
            var process=new ProcessBuilder("java",root.resolve("tests/item_processing/LearningEffectAudit.java").toString(),root.toString()).inheritIO().start();
            check(process.waitFor()==0,"learning effect audit failed");
        }
    }
}
