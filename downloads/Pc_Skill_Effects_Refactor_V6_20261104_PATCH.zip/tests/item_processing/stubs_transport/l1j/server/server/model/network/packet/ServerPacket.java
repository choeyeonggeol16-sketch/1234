package l1j.server.server.model.network.packet;
import l1j.server.server.model.network.core.CIOClient;
import l1j.server.server.model.network.buffer.WriteBuffer;
public abstract class ServerPacket {
    protected abstract void writeImpl(CIOClient client, WriteBuffer buffer);
    public final void serialize(CIOClient client, WriteBuffer buffer) { writeImpl(client, buffer); }
}
