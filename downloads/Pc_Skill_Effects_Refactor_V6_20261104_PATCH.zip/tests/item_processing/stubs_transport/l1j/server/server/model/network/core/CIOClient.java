package l1j.server.server.model.network.core;
import l1j.server.server.model.network.packet.ServerPacket;
public final class CIOClient {
    public final CIOUserSocket socket = new CIOUserSocket();
    public boolean connected = true;
    public boolean isConnected() { return connected; }
    public CIOUserSocket getConnection() { return socket; }
    public void sendPacket(ServerPacket packet) { socket.sendLegacy(this, packet); }
}
