#!/usr/bin/env python3
"""Compare the actual V4 handlers and V5 rules, including deferred effect callbacks."""
from pathlib import Path
import os, subprocess, tempfile, re, json

ROOT=Path(__file__).resolve().parents[2]
REL=Path('l1j/server/server/model/item/function')
CP=os.pathsep.join([os.environ.get('ITEM_BUILD_CLASSES',str(ROOT/'build/item-processing/classes')),
    *map(str,Path(os.environ.get('ITEM_DEPS_DIR',str(ROOT/'lib'))).glob('*.jar'))])
fixtures=ROOT/'tests/item_processing/fixtures'
recipes=json.loads((fixtures/'learning_rules_v4.json').read_text())
files={}
def put(name,text):files[Path(name+'.java')]=text
put('l1j/server/Config','package l1j.server;public class Config {public static int 어드밴스레벨=85,이뮨투함블레이드레벨=85;}')
put('l1j/server/server/model/Instance/UseEvents','''package l1j.server.server.model.Instance;
public class UseEvents {public static final java.util.List<String> all=new java.util.ArrayList<>();public static Runnable pending;public static void add(String event){all.add(event);}}''')
put('l1j/server/server/model/Instance/L1ItemInstance','package l1j.server.server.model.Instance;public class L1ItemInstance {public int count=2;public String toString(){return "item";}}')
put('l1j/server/server/model/L1PcInventory','''package l1j.server.server.model;import l1j.server.server.model.Instance.*;
public class L1PcInventory {public final java.util.Set<Integer> items=new java.util.HashSet<>();public boolean checkItem(int id){UseEvents.add("item?"+id);return items.contains(id);}}''')
pc='''package l1j.server.server.model.Instance;import java.util.*;
public class L1PcInstance {
 public int type,level=95;public boolean nonAction;public final Set<Integer> effects=new HashSet<>(),spells=new HashSet<>();public final l1j.server.server.model.L1PcInventory inv=new l1j.server.server.model.L1PcInventory();
 public int getId(){UseEvents.add("id");return 77;}public int getType(){UseEvents.add("class");return type;}public int getLevel(){UseEvents.add("level");return level;}
 public int getCurrentHp(){UseEvents.add("hp");return 70;}public int getMaxHp(){UseEvents.add("maxhp");return 100;}
 public boolean hasSkillEffect(int id){UseEvents.add("effect?"+id);return effects.contains(id);}
 public void setSkillEffect(int id,int time){effects.add(id);UseEvents.add("set:"+id+":"+time);}public void removeSkillEffect(int id){effects.remove(id);UseEvents.add("remove:"+id);}
 public void sendPackets(String message){UseEvents.add("message:"+message);}public void setBraveSpeed(int speed){UseEvents.add("speed:"+speed);}
 public l1j.server.server.model.L1PcInventory getInventory(){UseEvents.add("inventory");return inv;}
 public String toString(){return "pc";}
 FLAG_METHODS
}'''
flags=sorted({name for row in recipes for name in re.findall(r'pc\.(\w+)\(true\)',row['effect'])})
pc=pc.replace('FLAG_METHODS','\n'.join('public void '+name+'(boolean enabled){UseEvents.add("flag:'+name+':"+enabled);}' for name in flags))
put('l1j/server/server/model/Instance/L1PcInstance',pc)
put('l1j/server/server/datatables/SkillsTable','''package l1j.server.server.datatables;
import l1j.server.server.model.Instance.*;public class SkillsTable {public static L1PcInstance pc;private static final SkillsTable ONE=new SkillsTable();public static SkillsTable getInstance(){return ONE;}public boolean spellCheck(int id,int skill){UseEvents.add("spell?"+skill);return pc.spells.contains(skill);}}''')
put('l1j/server/server/utils/MJCommons','''package l1j.server.server.utils;import l1j.server.server.model.Instance.*;public class MJCommons {public static boolean isNonAction(L1PcInstance pc){UseEvents.add("action?");return pc.nonAction;}}''')
put(str(REL/'ItemUseDurableSkills'),'''package l1j.server.server.model.item.function;
import l1j.server.server.model.Instance.*;class ItemUseDurableSkills {static void useDurablePassive(L1PcInstance pc,L1ItemInstance item,int skill,int replaced,Runnable effect){UseEvents.add("passive:"+skill+":"+replaced);UseEvents.pending=effect;}}''')
put(str(REL/'ItemUseDurable'),'''package l1j.server.server.model.item.function;
import l1j.server.server.model.Instance.*;class ItemUseDurable {static void UseDurableExchange(L1PcInstance pc,L1ItemInstance item,int reward,Runnable effect){UseEvents.add("exchange:"+reward);UseEvents.pending=effect;}}''')
for cls,methods in {'SC_SkillSound':['send','broadcast'],'SC_SkillBrave':['send','broadcast'],'SC_HpUpdate':['send'],'SC_InventoryIcon':['icoNew','icoEnd','iconNewUnLimit'],'SC_SystemMessage':['send']}.items():
 put('l1j/server/server/model/network/core/sc/packet/'+cls,'package l1j.server.server.model.network.core.sc.packet;import l1j.server.server.model.Instance.*;public class '+cls+' {'+'\n'.join('public static void '+m+'(Object... args){UseEvents.add("'+cls+'.'+m+':"+java.util.Arrays.toString(args));}' for m in methods)+'}')
for owner in ['ItemUsePassiveLearning','ItemUseSkillLearning']:
 text=(fixtures/(owner+'.v4.java.txt')).read_text().replace(owner,'Legacy'+owner)
 put(str(REL/('Legacy'+owner)),text)
ids=','.join(row['id'] for row in recipes)
targets=','.join(row['target'] for row in recipes)
owners=','.join('true' if 'Passive' in row['owner'] else 'false' for row in recipes)
special=sorted({n for row in recipes for n in re.findall(r'L1SkillId\.(\w+)',row['effect'])}|{'가드피어','가드피어호러'})
put(str(REL/'LearningRulesContract'),r'''package l1j.server.server.model.item.function;
import java.util.*;import java.lang.reflect.*;import l1j.server.Config;import l1j.server.server.model.Instance.*;import l1j.server.server.model.character.skill.L1SkillId;import l1j.server.server.datatables.SkillsTable;
class LearningRulesContract {
 static final int[] IDS={IDS_LIST},TARGETS={TARGET_LIST};static final boolean[] PASSIVE={OWNERS};static final int[] SPECIAL={SPECIAL_IDS};static int comparisons,successes;
 record Result(List<String> events,Set<Integer> effects,boolean admitted){}
 static Result run(boolean old,int index,int type,int level,int mask,boolean commit){
  L1PcInstance pc=new L1PcInstance();pc.type=type;pc.level=level;pc.nonAction=(mask&2)!=0;
  if((mask&1)!=0){pc.effects.add(TARGETS[index]);pc.inv.items.add(TARGETS[index]);}
  for(int spell:new int[]{68,77,88,174})if((mask&(4<<(spell%4)))!=0)pc.spells.add(spell);
  for(int i=0;i<SPECIAL.length;i++)if((mask&(16<<(i%3)))!=0)pc.effects.add(SPECIAL[i]);
  SkillsTable.pc=pc;UseEvents.all.clear();UseEvents.pending=null;L1ItemInstance item=new L1ItemInstance();
  if(old){if(PASSIVE[index])LegacyItemUsePassiveLearning.use(pc,item,IDS[index]);else LegacyItemUseSkillLearning.use(pc,item,IDS[index]);}
  else {if(PASSIVE[index])ItemUsePassiveLearning.use(pc,item,IDS[index]);else ItemUseSkillLearning.use(pc,item,IDS[index]);}
  boolean admitted=UseEvents.pending!=null;
  if(admitted){
   for(Field field:UseEvents.pending.getClass().getDeclaredFields())if(!Modifier.isStatic(field.getModifiers())&&field.getType()!=L1PcInstance.class)throw new AssertionError("callback retained extra context: "+field);
   // The existing commit can complete later. Mutate state between admission and effects.
   pc.effects.add(L1SkillId.HOLY_WALK);pc.effects.add(L1SkillId.MOVING_ACCELERATION);pc.effects.add(L1SkillId.ADVANCE_SPIRIT);pc.effects.add(L1SkillId.REDUCTION_ARMOR);
   if(commit){UseEvents.add("commit");UseEvents.pending.run();}else UseEvents.add("save-failed:no-effect");
  }
  return new Result(List.copyOf(UseEvents.all),Set.copyOf(pc.effects),admitted);
 }
 public static void main(String[] args){Set<Integer> admittedIds=new HashSet<>();
  for(int i=0;i<IDS.length;i++)for(int type=0;type<8;type++)for(int state=0;state<128;state++){
   int level=new int[]{0,1,79,80,84,85,86,100}[state%8];Config.어드밴스레벨=state%3==0?80:95;Config.이뮨투함블레이드레벨=state%3==0?80:95;
   boolean commit=(state%3)!=0;Result old=run(true,i,type,level,state,commit);Result current=run(false,i,type,level,state,commit);comparisons++;
   if(!old.equals(current))throw new AssertionError("id="+IDS[i]+" class="+type+" level="+level+" state="+state+" old="+old+" new="+current);
   if(old.admitted){successes++;admittedIds.add(IDS[i]);}
  }
  if(admittedIds.size()!=IDS.length)throw new AssertionError("missing successful item coverage: "+admittedIds.size()+"/"+IDS.length);
  for(boolean passive:new boolean[]{true,false})for(int id:new int[]{0,-1,123456789}){UseEvents.all.clear();if(passive)ItemUsePassiveLearning.use(null,null,id);else ItemUseSkillLearning.use(null,null,id);if(!UseEvents.all.isEmpty())throw new AssertionError("unknown item changed");}
  System.out.println("PASS "+comparisons+" differential learning uses across "+IDS.length+" items; admitted="+successes+"; every item has successful coverage");
  System.out.println("PASS exact condition-read/message/debit/callback order, dynamic config, deferred completion and failed-save suppression; callbacks capture player only");
 }
}'''.replace('IDS_LIST',ids).replace('TARGET_LIST',targets).replace('OWNERS',owners).replace('SPECIAL_IDS',','.join('L1SkillId.'+s for s in special)))
with tempfile.TemporaryDirectory() as td:
 d=Path(td)
 for rel,text in files.items():
  p=d/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(text)
 actual=[ROOT/'src'/REL/(name+'.java') for name in ['ItemLearningRule','ItemUsePassiveLearning','ItemUseSkillLearning']]
 subprocess.run(['java','-m','jdk.compiler/com.sun.tools.javac.Main','--enable-preview','-source','21','-target','21','-encoding','UTF-8','-cp',CP,'-d',td,*map(str,d.rglob('*.java')),*map(str,actual)],check=True,timeout=60)
 subprocess.run(['java','--enable-preview','-ea','-cp',td+os.pathsep+CP,'l1j.server.server.model.item.function.LearningRulesContract'],check=True,timeout=60)
