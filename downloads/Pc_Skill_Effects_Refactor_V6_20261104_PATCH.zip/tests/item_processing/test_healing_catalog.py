#!/usr/bin/env python3
"""Verify real JAXB array binding and atomic catalog replacement without a game DB."""
from pathlib import Path
import tempfile, subprocess, os

ROOT=Path(__file__).resolve().parents[2]
CP=os.pathsep.join([os.environ.get('ITEM_BUILD_CLASSES',str(ROOT/'build/item-processing/classes')),
    *map(str,Path(os.environ.get('ITEM_DEPS_DIR',str(ROOT/'lib'))).glob('*.jar')),
    *map(str,Path(os.environ.get('ITEM_TEST_DEPS_DIR',str(ROOT/'lib-test'))).glob('*.jar'))])
with tempfile.TemporaryDirectory() as td:
    d=Path(td)
    p=d/'l1j/server/server/datatables/ItemTable.java';p.parent.mkdir(parents=True)
    p.write_text('''package l1j.server.server.datatables; public class ItemTable {
    private static final ItemTable ONE=new ItemTable();public static ItemTable getInstance(){return ONE;}
    public l1j.server.server.templates.L1Item getTemplate(int id){return new l1j.server.server.templates.L1EtcItem();}}
    ''')
    (d/'CatalogContract.java').write_text('''
import java.nio.file.*;import java.lang.reflect.*;import java.util.concurrent.atomic.*;
import l1j.server.server.model.item.function.L1HealingPotion;
class CatalogContract {
 static final Path XML=Path.of("data/xml/Item/HealingPotion.xml");static int checks;
 static void check(boolean ok,String msg){checks++;if(!ok)throw new AssertionError(msg);}
 static String item(int id,int min){return "<Item ItemId='"+id+"' Remove='1'><Effect Min='"+min+"' Max='80' GfxId='197' MapId='0'/><Effect Min='20' Max='40' GfxId='198' MapId='4'/></Item>";}
 static void write(String data)throws Exception{Files.createDirectories(XML.getParent());Files.writeString(XML,data);}
 static Object effects(L1HealingPotion potion)throws Exception{Field f=L1HealingPotion.class.getDeclaredField("_effects");f.setAccessible(true);return f.get(potion);}
 public static void main(String[] args)throws Exception {
  write("<ItemEffectList>"+item(40010,30)+item(40011,40)+"</ItemEffectList>");L1HealingPotion.load();
  var original=L1HealingPotion.get(40010);check(original!=null,"initial load");Object effects=effects(original);check(effects.getClass().isArray()&&Array.getLength(effects)==2,"real JAXB array binding/order");
  Field min=Array.get(effects,0).getClass().getDeclaredField("_min");min.setAccessible(true);check(min.getInt(Array.get(effects,0))==30,"first effect order");
  write("<ItemEffectList><broken");L1HealingPotion.reload();check(L1HealingPotion.get(40010)==original,"failed reload discarded good catalog");
  write("<ItemEffectList>"+item(40010,50)+"</ItemEffectList>");L1HealingPotion.reload();check(L1HealingPotion.get(40010)!=original&&L1HealingPotion.get(40011)==null,"reload replaces successful snapshot");
  write("<ItemEffectList>"+item(40012,60)+"</ItemEffectList>");L1HealingPotion.load();check(L1HealingPotion.get(40010)!=null&&L1HealingPotion.get(40012)!=null,"load preserves merge semantics");
  AtomicBoolean running=new AtomicBoolean(true);AtomicReference<Throwable> failure=new AtomicReference<>();Thread reader=new Thread(()->{try{while(running.get()){if(L1HealingPotion.get(40010)==null)throw new AssertionError("partially published catalog");}}catch(Throwable t){failure.set(t);}});reader.start();
  try{for(int i=0;i<12;i++){write("<ItemEffectList>"+item(40010,30+i)+"</ItemEffectList>");L1HealingPotion.reload();}}finally{running.set(false);reader.join();}
  check(failure.get()==null,"concurrent reader failure: "+failure.get());
  System.out.println("PASS real JAXB Effect[] binding, effect order, successful replacement/load merge, failed reload retention and concurrent reads; checks="+checks);
 }
}
''')
    subprocess.run(['java','-m','jdk.compiler/com.sun.tools.javac.Main','--enable-preview','-source','21','-target','21','-encoding','UTF-8','-cp',CP,'-d',td,str(p),str(d/'CatalogContract.java')],check=True,timeout=45)
    subprocess.run(['java','--enable-preview','-ea','-cp',td+os.pathsep+CP,'CatalogContract'],check=True,cwd=d,timeout=45)
