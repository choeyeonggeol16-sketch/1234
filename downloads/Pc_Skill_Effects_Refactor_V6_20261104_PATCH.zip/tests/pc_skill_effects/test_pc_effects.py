#!/usr/bin/env python3
"""Execute original PC methods and extracted effects with real buff wire encoding."""
from pathlib import Path
import json, os, re, subprocess, tempfile

ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).resolve().parent
CP=os.pathsep.join([os.environ.get('ITEM_BUILD_CLASSES',str(ROOT/'build/item-processing/classes')),
    *map(str,Path(os.environ.get('ITEM_DEPS_DIR',str(ROOT/'lib'))).glob('*.jar'))])
rows=json.loads((HERE/'methods.v5.json').read_text())
files={}
def put(path,text):files[Path(path+'.java')]=text
put('l1j/server/Config','package l1j.server;public class Config {public static boolean 수배온오프;public static int 수배번호=50001,수배번호1=50002;}')
put('l1j/server/server/model/Instance/UseEvents','''package l1j.server.server.model.Instance;
public class UseEvents {public static final java.util.List<String> all=new java.util.ArrayList<>();public static void add(String text){all.add(text);}}
''')
pc='''package l1j.server.server.model.Instance;
import java.util.*;import l1j.server.server.model.network.core.CIOClient;
public class L1PcInstance {
 public static final String WANTED_TITLE="wanted",WANTED_TITLE1="wanted-upgrade";
 public static final CIOClient CLIENT=new CIOClient();
 public int level,baseHp,baseMp,maxHp,maxMp,currentHp,currentMp,magicBuffHp,advenHp,advenMp;public boolean inParty;
 public final Map<String,Integer> stats=new TreeMap<>();public final Set<Integer> skills=new TreeSet<>();
 public final Values ability=new Values("ability"),resistance=new Values("resistance"),ac=new Values("ac");
 public final Party party=new Party();
 public class Values {final String prefix;Values(String prefix){this.prefix=prefix;}
  NESTED_METHODS
 }
 public class Party {public void refreshPartyMemberStatus(L1PcInstance pc){UseEvents.add("party-refresh:"+pc);}}
 public void add(String key,int value){stats.merge(key,value,Integer::sum);UseEvents.add(key+":"+value);}
 public Values getAbility(){UseEvents.add("ability");return ability;}public Values getResistance(){UseEvents.add("resistance");return resistance;}public Values getAC(){UseEvents.add("ac");return ac;}
 public int getLevel(){UseEvents.add("level");return level;}public int getId(){UseEvents.add("id");return 77;}
 public int getBaseMaxHp(){UseEvents.add("baseHp");return baseHp;}public int getBaseMaxMp(){UseEvents.add("baseMp");return baseMp;}
 public int getCurrentHp(){UseEvents.add("hp");return currentHp;}public int getCurrentMp(){UseEvents.add("mp");return currentMp;}public int getMaxHp(){UseEvents.add("maxHp");return maxHp;}public int getMaxMp(){UseEvents.add("maxMp");return maxMp;}
 public void addMaxHp(int n){maxHp+=n;UseEvents.add("addHp:"+n);}public void addMaxMp(int n){maxMp+=n;UseEvents.add("addMp:"+n);}
 public void setMagicBuffHp(int n){magicBuffHp=n;UseEvents.add("magicHp:"+n);}public int getMagicBuffHp(){UseEvents.add("magicHp?");return magicBuffHp;}
 public void setAdvenHp(int n){advenHp=n;UseEvents.add("advenHp:"+n);}public int getAdvenHp(){UseEvents.add("advenHp?");return advenHp;}
 public void setAdvenMp(int n){advenMp=n;UseEvents.add("advenMp:"+n);}public int getAdvenMp(){UseEvents.add("advenMp?");return advenMp;}
 public boolean isInParty(){UseEvents.add("inParty?");return inParty;}public Party getParty(){UseEvents.add("party");return party;}
 public boolean hasSkillEffect(int id){UseEvents.add("skill?"+id);return skills.contains(id);}public void removeSkillEffect(int id){skills.remove(id);UseEvents.add("remove:"+id);}public void setSkillEffect(int id,int time){skills.add(id);UseEvents.add("skill:"+id+":"+time);}
 public int getTotalER(){UseEvents.add("ER");return stats.getOrDefault("addEffectedER",0)+7;}
 public CIOClient getNetConnection(){return CLIENT;}public void sendPackets(String text){UseEvents.add("message:"+text);}
 public String toString(){return "pc";}
 DIRECT_METHODS
}
'''
nested=sorted({name for row in rows for owner,name in re.findall(r'pc\.(get\w+)\(\)\.(\w+)\(',row['body']) if owner!='getParty'})
nested_code=[]
for name in nested:
 if name in ['addSpecialResistance','addSpecialPierce']:
  nested_code.append('public void '+name+'(l1j.server.server.utils.eKind kind,int value){add(prefix+".'+name+':"+kind,value);}')
 else:nested_code.append('public void '+name+'(int value){add(prefix+".'+name+'",value);}')
direct=sorted({name for row in rows for name in re.findall(r'pc\.(add\w+)\(',row['body'])}-{'addMaxHp','addMaxMp'})
pc=pc.replace('NESTED_METHODS','\n'.join(nested_code)).replace('DIRECT_METHODS','\n'.join('public void '+name+'(int value){add("'+name+'",value);}' for name in direct))
put('l1j/server/server/model/Instance/L1PcInstance',pc)
put('l1j/server/server/model/network/core/CIOClient','''package l1j.server.server.model.network.core;
public class CIOClient {public final CIOUserSocket socket=new CIOUserSocket();public boolean connected=true;public boolean isConnected(){return connected;}public CIOUserSocket getConnection(){return socket;}public l1j.server.server.model.network.utill.ConnectionState getConnectionState(){return l1j.server.server.model.network.utill.ConnectionState.IN_GAME;}public boolean isGameSessionReady(){return true;}}
''')
transport=ROOT/'tests/item_processing/stubs_transport/l1j/server/server/model/network/core'
for name in ['CIOFrame','CIOUserSocket']:
 text=(transport/(name+'.java')).read_text()
 if name=='CIOUserSocket':
  text=text[:text.index('    public void sendLegacy(')]+'}\n'
  text=text.replace('import l1j.server.server.model.network.packet.ServerPacket;','')
  text=text.replace('checksum = length','l1j.server.server.model.Instance.UseEvents.add("wire:"+java.util.HexFormat.of().formatHex(lastBytes));\n        checksum = length')
 put('l1j/server/server/model/network/core/'+name,text)
for name,methods in {'SC_CharTitle':['send','broadcast'],'SC_HpUpdate':['send'],'SC_MpUpdate':['send'],'SC_OwnCharAttrDef':['send'],'SC_OwnCharStatus':['send'],'SC_OwnCharStatus2':['send'],'SC_SPMR':['send'],'SC_PacketBox':['send'],'SC_SystemMessage':['send'],'SC_InventoryIcon':['iconNewUnLimit','icoEnd']}.items():
 constants='public static final int GREEN_MESSAGE=1,ER_UpDate=2;' if name=='SC_PacketBox' else ''
 put('l1j/server/server/model/network/core/sc/packet/'+name,'package l1j.server.server.model.network.core.sc.packet;import l1j.server.server.model.Instance.*;public class '+name+' {'+constants+'\n'.join('public static void '+m+'(Object... values){UseEvents.add("'+name+'.'+m+':"+java.util.Arrays.toString(values));}' for m in methods)+'}')
imports='''import l1j.server.Config;import l1j.server.server.model.character.skill.L1SkillId;import l1j.server.server.model.network.core.sc.packet.*;import l1j.server.server.packets.Protocol.Packet.SC_SpellBuffNoti;import l1j.server.server.packets.Protocol.Packet.SC_SpellBuffNoti.eNotiType;import l1j.server.server.packets.Protocol.Packet.SC_SpellBuffNoti.eDurationShowType;import l1j.server.server.utils.eKind;'''
put('l1j/server/server/model/Instance/LegacyPcEffects','package l1j.server.server.model.Instance;'+imports+'class LegacyPcEffects extends L1PcInstance {\n'+'\n'.join(r['old'] for r in rows)+'\n}')
# Freeze the actual rewritten PC method text, independently of the helper fixture.
current=(ROOT/'src/l1j/server/server/model/Instance/L1PcInstance.java').read_text()
wrappers=[]
for row in rows:
 match=re.search(r'public void '+re.escape(row['name'])+r'\(boolean isOn\) \{[^\n]+\}',current)
 assert match,row['name'];wrappers.append(match.group())
put('l1j/server/server/model/Instance/ExtractedPcEffects','package l1j.server.server.model.Instance;import l1j.server.server.model.character.effect.*;class ExtractedPcEffects extends L1PcInstance {\n'+'\n'.join(wrappers)+'\n}')
names=','.join('"'+r['name']+'"' for r in rows)
put('l1j/server/server/model/Instance/PcEffectsContract',r'''package l1j.server.server.model.Instance;
import java.util.*;import java.lang.reflect.*;import l1j.server.Config;import l1j.server.server.model.character.skill.L1SkillId;
class PcEffectsContract {
 static final String[] NAMES={METHOD_NAMES};static int comparisons,wireComparisons;
 record Result(List<String> events,Map<String,Integer> stats,Set<Integer> skills,List<Integer> health){}
 static Result run(boolean original,String name,int level,boolean party,boolean flag,boolean connected,int repeats)throws Exception {
  L1PcInstance pc=original?new LegacyPcEffects():new ExtractedPcEffects();pc.level=level;pc.baseHp=1001+level*7;pc.baseMp=503+level*3;pc.maxHp=pc.baseHp;pc.maxMp=pc.baseMp;pc.currentHp=pc.maxHp/2;pc.currentMp=pc.maxMp/2;pc.inParty=party;
  if((level&1)!=0)pc.skills.add(L1SkillId.MEDITATION);Config.수배온오프=level%2==0;L1PcInstance.CLIENT.connected=connected;
  UseEvents.all.clear();Method method=pc.getClass().getMethod(name,boolean.class);method.setAccessible(true);
  for(int i=0;i<repeats;i++)method.invoke(pc,flag);
  if(L1PcInstance.CLIENT.socket.active!=0)throw new AssertionError("frame leak");
  return new Result(List.copyOf(UseEvents.all),Map.copyOf(pc.stats),Set.copyOf(pc.skills),List.of(pc.maxHp,pc.maxMp,pc.magicBuffHp,pc.advenHp,pc.advenMp));
 }
 static void compare(String name,int level,boolean party,boolean flag,boolean connected,int repeats)throws Exception {
  Result old=run(true,name,level,party,flag,connected,repeats),now=run(false,name,level,party,flag,connected,repeats);comparisons++;
  if(!old.equals(now))throw new AssertionError(name+" level="+level+" flag="+flag+" old="+old+" new="+now);
  if(now.events.stream().anyMatch(x->x.startsWith("wire:")))wireComparisons++;
 }
 public static void main(String[] args)throws Exception {
  for(String name:NAMES)for(int level=0;level<=120;level++)for(boolean party:new boolean[]{false,true})for(boolean flag:new boolean[]{false,true})compare(name,level,party,flag,true,level%3+1);
  for(String name:NAMES)for(int level:new int[]{-1,81,85,94,101,Integer.MAX_VALUE})for(boolean flag:new boolean[]{false,true})compare(name,level,true,flag,false,2);
  System.out.println("PASS "+comparisons+" original/extracted PC effect comparisons over "+NAMES.length+" methods; potential wire cases="+wireComparisons);
  System.out.println("PASS exact stat deltas, party refresh, UI/message order, real protobuf bytes/presence fields, true/false flags, repeated calls and disconnected sends");
 }
}'''.replace('METHOD_NAMES',names))
with tempfile.TemporaryDirectory() as td:
 d=Path(td)
 for path,text in files.items():
  p=d/path;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(text)
 helpers=sorted((ROOT/'src/l1j/server/server/model/character/effect').glob('*.java'))
 sources=[*map(str,d.rglob('*.java')),*map(str,helpers)]
 subprocess.run(['java','-m','jdk.compiler/com.sun.tools.javac.Main','--enable-preview','-source','21','-target','21','-encoding','UTF-8','-cp',CP,'-d',td,*sources],check=True,timeout=60)
 subprocess.run(['java','--enable-preview','-ea','-cp',td+os.pathsep+CP,'l1j.server.server.model.Instance.PcEffectsContract'],check=True,timeout=60)
