import java.nio.file.*;
import java.util.*;
import javax.tools.*;
import com.sun.source.tree.*;
import com.sun.source.util.*;

/** Verify the real PC class keeps its fields, public API and all unrelated members. */
class PcEffectSourceAudit {
    static ClassTree read(Path path)throws Exception {
        var compiler=ToolProvider.getSystemJavaCompiler();
        try(var fm=compiler.getStandardFileManager(null,null,null)) {
            var task=(JavacTask)compiler.getTask(null,fm,null,List.of("-proc:none"),null,fm.getJavaFileObjects(path));
            return (ClassTree)task.parse().iterator().next().getTypeDecls().getFirst();
        }
    }
    static boolean effect(Tree member) {
        return member instanceof MethodTree m && m.getParameters().toString().equals("boolean isOn");
    }
    static void check(boolean ok,String msg){if(!ok)throw new AssertionError(msg);}
    public static void main(String[] args)throws Exception {
        String relative="src/l1j/server/server/model/Instance/L1PcInstance.java";
        var old=read(Path.of(args[0]).resolve(relative));var current=read(Path.of(args[1]).resolve(relative));
        check(old.getMembers().size()==current.getMembers().size(),"PC member count changed");
        int moved=0,fields=0,other=0;
        for(int i=0;i<old.getMembers().size();i++) {
            Tree before=old.getMembers().get(i),after=current.getMembers().get(i);
            if(!effect(before)) {
                check(before.toString().equals(after.toString()),"unrelated PC member changed: "+before.getKind());
                if(before instanceof VariableTree)fields++;else other++;
                continue;
            }
            var a=(MethodTree)before;var b=(MethodTree)after;
            check(a.getName().toString().equals(b.getName().toString())&&a.getReturnType().toString().equals(b.getReturnType().toString())
                &&a.getParameters().toString().equals(b.getParameters().toString())
                &&a.getModifiers().toString().equals(b.getModifiers().toString()),"PC API signature changed");
            check(b.getBody().getStatements().size()==1,"PC effect still has executable plumbing");
            var call=(MethodInvocationTree)((ExpressionStatementTree)b.getBody().getStatements().getFirst()).getExpression();
            String owner=((MemberSelectTree)call.getMethodSelect()).getExpression().toString();
            check(Set.of("PcPassiveEffects","PcPotentialEffects","PcClanBuffEffects","PcWantedEffects").contains(owner),"wrong effect owner");
            check(call.getArguments().getFirst().toString().equals("this"),"player receiver changed");
            var kind=(MemberSelectTree)call.getArguments().get(1);
            check(kind.getExpression().toString().equals(owner+".Kind")
                &&kind.getIdentifier().toString().equals(a.getName().toString()),"effect mapping changed");
            check(call.getArguments().size()==(owner.equals("PcWantedEffects")?3:2),"effect parameters changed");
            if(call.getArguments().size()==3)check(call.getArguments().getLast().toString().equals("isOn"),"toggle flag lost");
            moved++;
        }
        check(moved==64,"effect count changed");
        Path folder=Path.of(args[1]).resolve("src/l1j/server/server/model/character/effect");
        try(var paths=Files.list(folder)) {
            for(Path path:paths.filter(p->p.toString().endsWith(".java")).toList()) {
                var type=read(path);
                for(var member:type.getMembers()) if(member instanceof VariableTree field)
                    check(field.getModifiers().getFlags().contains(javax.lang.model.element.Modifier.STATIC),"per-player effect object state added");
            }
        }
        System.out.println("PASS 64 one-line PC effect delegates/signatures; unchanged PC fields="+fields+", unrelated members="+other+"; four stateless helper modules");
    }
}
