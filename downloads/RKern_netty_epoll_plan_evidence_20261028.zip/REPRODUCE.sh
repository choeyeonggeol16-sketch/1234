# These are diagnostic correctness/path tests; DO NOT compare their timings to production benchmarks.
python3 build.py --fetch-deps
python3 run.py --mode smoke --warmup 1 --seconds 1 --case fairness-16 --engine diag-default --engine diag-queued --keep-going --label fifo-new
python3 run.py --mode measure --rounds 2 --warmup 1 --seconds 1 --case fairness-16 --engine diag-default --engine diag-queued --keep-going --label fifo-repeat-new
python3 run.py --mode smoke --warmup 1 --seconds 1 --case many-1024 --engine diag-routes --engine diag-routes-no-fairness --keep-going --label routes-new
python3 run.py --mode smoke --warmup 1 --seconds 1 --case burst-128 --engine diag-batch-detail-batch --keep-going --label batch-new
