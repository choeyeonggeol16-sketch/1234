# 진단·구현 지침 자료

진단 소스는 배포용 가속 패치가 아닙니다. 카운터가 타이밍을 바꾸므로 진단 실행의 속도를 최종 성능으로 사용하지 마세요. diag-queued는 모든 SEND를 티켓화한 정확성 대조군입니다. 운영 적용을 완료한 소스가 아닙니다.

순수 Java, 기존 프로토콜/FIFO 유지, NPC·DB 수정 없음이 구현 지침의 범위입니다.

Linux/JDK 21에서 `python3 build.py --fetch-deps`로 빌드합니다. dependency는 고정된 버전과 SHA-256을 검사합니다. 재현 명령은 REPRODUCE.sh를 참조하세요.

구현 지침은 RKern_NETTY_EPOLL_IMPLEMENTATION_PLAN_20261028.md, 관측 카운터는 diagnostics-summary.json에 있습니다. 기존 유효 성능 54회와 전체 재현 코드는 동봉한 이전 비교 ZIP에 있습니다.
