from pathlib import Path, PurePosixPath
import argparse,zipfile,json,hashlib,subprocess,urllib.request

root=Path(__file__).resolve().parent
parser=argparse.ArgumentParser()
parser.add_argument('--fetch-deps',action='store_true')
args=parser.parse_args()
baseline=root/'baseline_benchmark'
if not (baseline/'sources/v5-manifest.json').exists():
    with zipfile.ZipFile(root/'RKern_netty_epoll_rebench_20261028.zip') as z:
        for name in z.namelist():
            p=PurePosixPath(name)
            if p.is_absolute() or '..' in p.parts:raise ValueError('Unsafe bundled path')
        z.extractall(baseline)
lib=root/'lib';lib.mkdir(exist_ok=True)
for row in json.loads((baseline/'dependencies.json').read_text()):
    target=lib/row['name']
    if not target.exists():
        if not args.fetch_deps:raise SystemExit('Missing dependency '+row['name']+'; use --fetch-deps')
        urllib.request.urlretrieve(row['url'],target)
    assert hashlib.sha256(target.read_bytes()).hexdigest()==row['sha256'],row['name']
cp=':'.join(str(p) for p in sorted(lib.glob('*.jar')))
manifest=json.loads((baseline/'sources/v5-manifest.json').read_text())
for rel,sha in manifest['actual_sha256'].items():
    assert hashlib.sha256((baseline/'sources/v5'/rel).read_bytes()).hexdigest()==sha
files=[baseline/'sources/v5'/rel for rel in manifest['actual_sha256']]+list((baseline/'stubs').rglob('*.java'))+[baseline/'harness/client/NettyBench.java']
client=root/'client/classes';client.mkdir(parents=True,exist_ok=True)
subprocess.run(['java','com.sun.tools.javac.Main','-encoding','UTF-8','-cp',cp,'-d',str(client),*[str(p) for p in files]],check=True)
for name in ['diag-default','diag-queued','diag-routes','diag-batch-detail']:
    directory=root/name
    files=list((directory/'src').rglob('*.java'))+list((directory/'stubs').rglob('*.java'))+[directory/'NettyBench.java']
    output=directory/'classes';output.mkdir(exist_ok=True)
    subprocess.run(['java','com.sun.tools.javac.Main','-encoding','UTF-8','-cp',cp,'-d',str(output),*[str(p) for p in files]],check=True)
print('Built diagnostic copies and original common client. Diagnostic timings are NOT performance results.')
