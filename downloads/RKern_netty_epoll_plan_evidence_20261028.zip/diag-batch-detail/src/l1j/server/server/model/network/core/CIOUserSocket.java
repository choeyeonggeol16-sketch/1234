package l1j.server.server.model.network.core;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.nio.channels.AsynchronousSocketChannel;
import java.nio.channels.CompletionHandler;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.Executor;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.VarHandle;
import java.util.concurrent.atomic.AtomicLongArray;

import l1j.server.server.Opcodes;
import l1j.server.server.model.character.CYieldLock;
import l1j.server.server.model.network.buffer.ReadBuffer;
import l1j.server.server.model.network.codec.Cryptor;
import l1j.server.server.model.network.safe.NetworkSafeLoadManager;
import l1j.server.server.model.network.thread.CIOThreadCallback;
import l1j.server.server.model.network.utill.ConnectionConfig;

import l1j.server.server.model.network.buffer.WriteBuffer;
import l1j.server.server.model.network.packet.CPacketHandler;
import l1j.server.server.model.network.packet.WritablePacket;

/**
 * Java NIO.2 transport with a per-socket 512-slot callback serializer.
 * WRITE completions and SEND starts follow the connection's ticket/FIFO
 * execution rule. READ framing retains its independent direct callback path;
 * creature actions execute on completion workers through their own
 * controller serializer; session/wheel ownership is still isolated.
 */
public final class CIOUserSocket implements AutoCloseable, Runnable {
    @FunctionalInterface
    public interface Closed {
        void onClosed(CIOUserSocket connection);
    }

    private final java.util.concurrent.atomic.AtomicInteger _diagnosticReaders = new java.util.concurrent.atomic.AtomicInteger();
    private static final java.util.concurrent.atomic.AtomicLong DIAG_READ_EVENTS = new java.util.concurrent.atomic.AtomicLong();
    private static final java.util.concurrent.atomic.LongAdder DIAG_READ_INDIRECT = new java.util.concurrent.atomic.LongAdder();
    private static final java.util.concurrent.atomic.LongAdder DIAG_READ_DIRECT = new java.util.concurrent.atomic.LongAdder();
    private static final java.util.concurrent.atomic.LongAdder DIAG_SELF_PENDING_ONLY = new java.util.concurrent.atomic.LongAdder();
    private volatile Thread _diagnosticSubmitThread;
    private static final java.util.concurrent.atomic.LongAdder DIAG_READ_OVERLAP = new java.util.concurrent.atomic.LongAdder();
    private static final java.util.concurrent.atomic.AtomicLong DIAG_INLINE_OVER_PENDING = new java.util.concurrent.atomic.AtomicLong();
    private static final java.util.concurrent.atomic.LongAdder DIAG_CALLBACK_SAME = new java.util.concurrent.atomic.LongAdder();
    private static final java.util.concurrent.atomic.LongAdder DIAG_CALLBACK_OTHER = new java.util.concurrent.atomic.LongAdder();
    private static final java.util.concurrent.atomic.LongAdder DIAG_BATCH_FAST_FRAMES = new java.util.concurrent.atomic.LongAdder();
    private static final java.util.concurrent.atomic.LongAdder DIAG_BATCH_FALLBACK_FRAMES = new java.util.concurrent.atomic.LongAdder();
    private static final java.util.concurrent.atomic.LongAdder DIAG_BATCH_PENDING_OWNER = new java.util.concurrent.atomic.LongAdder();
    private static final java.util.concurrent.atomic.LongAdder DIAG_BATCH_PENDING_OTHER = new java.util.concurrent.atomic.LongAdder();
    public static String diagnosticSummary() {
        return "DIAGNOSTIC read_overlap="+DIAG_READ_OVERLAP.sum()+" inline_over_pending="+DIAG_INLINE_OVER_PENDING.get()
                +" callback_same="+DIAG_CALLBACK_SAME.sum()+" callback_other="+DIAG_CALLBACK_OTHER.sum()
                +" read_events="+DIAG_READ_EVENTS.get()+" read_indirect_samples="+DIAG_READ_INDIRECT.sum()+" read_direct_samples="+DIAG_READ_DIRECT.sum()
                +" batch_self_pending_only="+DIAG_SELF_PENDING_ONLY.sum()
                +" batch_fast_frames="+DIAG_BATCH_FAST_FRAMES.sum()+" batch_fallback_frames="+DIAG_BATCH_FALLBACK_FRAMES.sum()
                +" batch_pending_owner_attempts="+DIAG_BATCH_PENDING_OWNER.sum()+" batch_pending_other_attempts="+DIAG_BATCH_PENDING_OTHER.sum();
    }

    private final AsynchronousSocketChannel _channel;
    private final CIOBufferPool _pool;
    private final CYieldLock _stateLock = new CYieldLock();
    private static final Logger LOG = Logger.getLogger(CIOUserSocket.class.getName());
    // Diagnostics only; no new per-connection atomics or per-SEND allocation.
    public static final int REJECT_WIRE_BYTES = 1;
    public static final int REJECT_LOCAL_FRAMES = 2;
    public static final int REJECT_SERIALIZER = 3;
    public static final int REJECT_POOL = 4;
    public static final int REJECT_ENCODING = 5;
    private static final AtomicLongArray SEND_REJECTIONS = new AtomicLongArray(6);
    public static long sendRejections(int reason) {
        if (reason <= 0 || reason >= SEND_REJECTIONS.length())
            throw new IllegalArgumentException("invalid SEND rejection reason");
        return SEND_REJECTIONS.get(reason);
    }
    private static boolean rejectSend(int reason) {
        SEND_REJECTIONS.incrementAndGet(reason);
        return false;
    }
    private static final boolean DIRECT_UNROUTED = Boolean.parseBoolean(System.getProperty("cio.directUnrouted", "true"));
    private static final class DecodeState {
        final ReadBuffer buffer = new ReadBuffer();
        boolean active;
        DecodeState nested;
    }
    private static final ThreadLocal<DecodeState> DECODE = ThreadLocal.withInitial(DecodeState::new);
    private static DecodeState acquireDecodeState() {
        DecodeState state = DECODE.get();
        while (state.active) {
            if (state.nested == null) state.nested = new DecodeState();
            state = state.nested;
        }
        state.active = true;
        return state;
    }
    private volatile Cryptor _cryptor;
    private volatile boolean _handshakePlainPending;
    void initializeCipher(long seed) {
        final Cryptor cryptor = new Cryptor();
        cryptor.initKey(seed);
        _cryptor = cryptor;
        _handshakePlainPending = true;
    }
    void clearCipher() {
        _handshakePlainPending = false;
        _cryptor = null;
    }
    private Cryptor readCipher() { return _cryptor; }
    private boolean decryptPreviewed(ReadBuffer buffer, int length, int expectedOpcode, Cryptor cipher) {
        if (cipher == null || length < 8 || _cryptor != cipher) return false;
        cipher.decrypt(buffer, 0, length);
        if ((buffer.readByte(0) & 0xFF) != expectedOpcode)
            throw new IllegalStateException("cipher opcode preview mismatch");
        return true;
    }
    boolean encrypt(WriteBuffer buffer, int offset, int length) {
        if (_handshakePlainPending) {
            _handshakePlainPending = false;
            return true;
        }
        final Cryptor cipher = _cryptor;
        if (cipher == null) return true;
        try {
            cipher.encrypt(buffer, offset, length);
            return true;
        } catch (Exception error) {
            LOG.log(Level.SEVERE, "[CIOUserSocket] packet encryption failed", error);
            return false;
        }
    }
    boolean decrypt(ReadBuffer buffer, int offset, int length) {
        final Cryptor cipher = _cryptor;
        if (cipher == null) return true;
        try {
            cipher.decrypt(buffer, offset, length);
            return true;
        } catch (Exception error) {
            LOG.log(Level.WARNING, "[CIOUserSocket] packet decryption failed", error);
            return false;
        }
    }
    private volatile CIOClient _client;
    private final String _remoteAddress;
    private final int _affinityShard;
    private volatile int _closing;
    private volatile int _disconnecting;
    private volatile Runnable _onDrained;

    private final Closed _closedCallback;
    private CIOBufferPool.Lease[] _pending;
    private final int _maxQueuedFrames;
    // Volatile primitives avoid five standalone Atomic* objects per connection.
    // VarHandles preserve CAS/getAndAdd semantics when completion threads race.
    private volatile int _closed;
    private volatile int _closeNotified;

    private static final int SOCKET_SLOTS = 512;
    private static final int SOCKET_MASK = SOCKET_SLOTS - 1;
    private static final int SOCKET_REJECT_AT = SOCKET_SLOTS - 8;
    private static final long SOCKET_SEND_START = 1L;
    private static final long SOCKET_WRITE_COMPLETE = 2L;
    private static final long SOCKET_SEND_ENQUEUE = 3L;
    private static final long SOCKET_CANCELLED = 4L;
    private final long[] _socketCallbacks = new long[SOCKET_SLOTS];
    private final long[] _socketArguments = new long[SOCKET_SLOTS];
    private final CIOBufferPool.Lease[] _socketSendArguments = new CIOBufferPool.Lease[SOCKET_SLOTS];

    private volatile long _socketTicket;
    private long _socketHead;
    private volatile int _socketPending;
    private volatile int _socketDraining;
    private volatile Thread _socketOwner;
    // Java NIO.2 may complete synchronously inside the write() invocation.
    // Such a callback must not retire its pooled ByteBuffer until write() returns.
    private boolean _socketPosting;
    // A socket issues at most one outstanding WRITE. The mailbox rejects a
    // duplicate completion before its serializer ticket can run.
    private volatile long _writeEvent;
    private static final int WRITE_DONE = 1;
    private static final int WRITE_FAILED = 2;
    private static final int GATHER_DONE = 3;
    private static final int GATHER_FAILED = 4;
    private volatile int _readKick;
    // At most one deferred READ pump task per socket; the socket itself is
    // the reusable Runnable, with no per-frame continuation allocation.
    private volatile int _readContinuationQueued;
    private volatile Executor _ioExecutor;
    // Zero disables fairness; a positive limit is a maximum number of complete
    // frames one READ pump may dispatch before yielding to other I/O sockets.
    private static final int READ_FRAME_BUDGET = Math.max(0,
            Math.min(256, Integer.getInteger("cio.readFrameBudget", 32)));
    static boolean readFairnessEnabled() { return READ_FRAME_BUDGET != 0; }
    // READ completion is consumed only by the existing per-socket READ pump.
    // 0=empty, 1=failure, >=2=successful completion (transferred bytes + 2).
    // This keeps _readPending and zero-completion handling off foreign I/O threads.
    private volatile int _readEvent;
    private static final VarHandle CLOSED, CLOSE_NOTIFIED, READ_KICK, READ_ACTIVE,
            WRITE_EVENT, READ_EVENT, READ_CONTINUATION_QUEUED, SOCKET_TICKET, SOCKET_PENDING, SOCKET_DRAINING,
            DISCONNECTING, ON_DRAINED;
    private static final VarHandle SOCKET_CALLBACK_SLOT = MethodHandles.arrayElementVarHandle(long[].class);
    private static final VarHandle SOCKET_ARGUMENT_SLOT = MethodHandles.arrayElementVarHandle(long[].class);
    static {
        try {
            final MethodHandles.Lookup lookup = MethodHandles.lookup();
            CLOSED = lookup.findVarHandle(CIOUserSocket.class, "_closed", int.class);
            CLOSE_NOTIFIED = lookup.findVarHandle(CIOUserSocket.class, "_closeNotified", int.class);
            SOCKET_TICKET = lookup.findVarHandle(CIOUserSocket.class, "_socketTicket", long.class);
            SOCKET_PENDING = lookup.findVarHandle(CIOUserSocket.class, "_socketPending", int.class);
            SOCKET_DRAINING = lookup.findVarHandle(CIOUserSocket.class, "_socketDraining", int.class);
            WRITE_EVENT = lookup.findVarHandle(CIOUserSocket.class, "_writeEvent", long.class);
            READ_KICK = lookup.findVarHandle(CIOUserSocket.class, "_readKick", int.class);
            READ_EVENT = lookup.findVarHandle(CIOUserSocket.class, "_readEvent", int.class);
            READ_CONTINUATION_QUEUED = lookup.findVarHandle(CIOUserSocket.class,
                    "_readContinuationQueued", int.class);
            READ_ACTIVE = lookup.findVarHandle(CIOUserSocket.class, "_readActive", int.class);
            DISCONNECTING = lookup.findVarHandle(CIOUserSocket.class, "_disconnecting", int.class);
            ON_DRAINED = lookup.findVarHandle(CIOUserSocket.class, "_onDrained", Runnable.class);
        } catch (ReflectiveOperationException e) {
            throw new ExceptionInInitializerError(e);
        }
    }

    // One reusable flush list per CIO owner thread. This is not a packet queue:
    // leases remain owned by their connections, and no additional worker is used.
    private static final ThreadLocal<SendBurst> SEND_BURST = new ThreadLocal<>();
    private SendBurst _burstOwner;
    private static final int BURST_MAX_BYTES = 8192;
    private static final int BURST_INITIAL_SOCKETS = 32;
    private static final int BURST_MAX_SOCKETS = 256;

    private static final class SendBurst {
        CIOUserSocket[] sockets = new CIOUserSocket[BURST_INITIAL_SOCKETS];
        int size;
        int depth;
        boolean flushing;

        boolean attach(CIOUserSocket socket) {
            if (flushing) return false;
            if (socket._burstOwner == this) return true;
            // Grow only when a large AOI burst actually needs more sockets.
            // The hard cap bounds how long a CIO owner can defer initial WRITEs.
            if (size == sockets.length) {
                if (size >= BURST_MAX_SOCKETS) return false;
                sockets = java.util.Arrays.copyOf(sockets,
                        Math.min(BURST_MAX_SOCKETS, sockets.length << 1));
            }
            sockets[size++] = socket;
            socket._burstOwner = this;

            return true;
        }

        void flush() {
            if (flushing) return;
            flushing = true;
            final int n = size;
            size = 0;
            try {
                for (int i = 0; i < n; i++) {
                    final CIOUserSocket socket = sockets[i];
                    sockets[i] = null;
                    socket._stateLock.lock(); try {
                        if (socket._burstOwner == this) socket._burstOwner = null;
                    } finally { socket._stateLock.unlock(); }
                    // May have been posted by another producer; kickWrite is idempotent.
                    try { socket.kickWrite(); }
                    catch (Throwable failure) { socket.close(); }
                }
            } finally {
                flushing = false;
            }
        }
    }

    /** Scope only current direct opcode dispatch; leave external producers on immediate SEND. */
    public static void beginSendBurst() {
        SendBurst burst = SEND_BURST.get();
        if (burst == null) {
            burst = new SendBurst();
            SEND_BURST.set(burst);
        }
        ++burst.depth;
    }

    public static void endSendBurst() {
        final SendBurst burst = SEND_BURST.get();
        if (burst == null || burst.depth <= 0)
            throw new IllegalStateException("unbalanced SEND burst");
        if (--burst.depth == 0) burst.flush();
    }

    /** Flush the current game command without discarding the owner-local burst scope. */
    public static void flushSendBurst() {
        final SendBurst burst = SEND_BURST.get();
        if (burst != null && burst.depth != 0) burst.flush();
    }

    /* Queue and active WRITE mutations use _stateLock, never a global pool lock. */
    private int _head;
    private int _tail;
    private int _queued;
    // Frames admitted to the 512-slot serializer but not yet attached to SEND.
    private int _stagedSends;
    // Byte-based connection-local backpressure, in addition to frame-count bound.
    // Counts all committed wire bytes including gather writes and packed frames.
    private static final int MAX_PENDING_WIRE_BYTES = Math.max(131072,
            Math.min(8 * 1024 * 1024, Integer.getInteger("cio.maxPendingWireBytes", 4 * 1024 * 1024)));
    // Flow-control stops inbound processing before a slow client accumulates
    // hundreds of 16K leases. The 4MB / 256 frame hard admission caps and
    // lossless SEND contract are preserved; this is READ backpressure only.
    private static final boolean SEND_READ_WATERMARK = Boolean.parseBoolean(
            System.getProperty("cio.sendReadWatermark", "true"));
    private static final int SEND_READ_HIGH_WATER_BYTES = Math.min(
            MAX_PENDING_WIRE_BYTES * 3 / 4,
            Math.max(64 * 1024, Integer.getInteger("cio.sendReadHighBytes", 256 * 1024)));
    private static final int SEND_READ_LOW_WATER_BYTES = SEND_READ_HIGH_WATER_BYTES / 2;
    private static final int SEND_READ_HIGH_WATER_FRAMES = Math.max(4, Math.min(256,
            Integer.getInteger("cio.sendReadHighFrames", 32)));
    private static final int SEND_READ_LOW_WATER_FRAMES = SEND_READ_HIGH_WATER_FRAMES / 2;
    private int _outstandingWireBytes;
    // Uncommitted direct producers own pooled leases too. Include their maximum
    // wire sizes in admission and READ watermark decisions until commit/abort.
    private int _reservedWireBytes;
    private int _outstandingFrames;
    private volatile boolean _sendReadPaused;

    /** Always invoked with this socket's state lock held. */
    private boolean canAdmitBytes(int count) {
        return count > 0 && count <= MAX_PENDING_WIRE_BYTES - _outstandingWireBytes - _reservedWireBytes;
    }

    private void bytesAdmitted(int count) {
        bytesAdmittedBatch(count, 1);
    }

    /** Caller holds _stateLock. A validated batch publishes one watermark change. */
    private void bytesAdmittedBatch(int wireBytes, int frames) {
        _outstandingWireBytes += wireBytes;
        _outstandingFrames += frames;
        updateSendReadPauseLocked();
    }

    /** Under the state lock, accounting both published and uncommitted frames. */
    private boolean updateSendReadPauseLocked() {
        if (!SEND_READ_WATERMARK) return false;
        final int bytes = _outstandingWireBytes + _reservedWireBytes;
        final int frames = _outstandingFrames + _reservedDirect;
        if (!_sendReadPaused && (bytes >= SEND_READ_HIGH_WATER_BYTES
                || frames >= SEND_READ_HIGH_WATER_FRAMES)) {
            _sendReadPaused = true;
        } else if (_sendReadPaused && bytes <= SEND_READ_LOW_WATER_BYTES
                && frames <= SEND_READ_LOW_WATER_FRAMES) {
            _sendReadPaused = false;
            return _closed == 0 && _readActive != 0;
        }
        return false;
    }

    /** Under the state lock; caller kicks READ only after unlocking. */
    private boolean bytesReleased(int count, int frames) {
        _outstandingWireBytes -= count;
        _outstandingFrames -= frames;
        if (_outstandingWireBytes < 0 || _outstandingFrames < 0)
            throw new IllegalStateException("negative outstanding SEND accounting");
        return updateSendReadPauseLocked();
    }

    // Reserved producer slots for existing direct-frame serializers. A reservation
    // survives the serializer and is consumed atomically by commit or abort.
    private int _reservedDirect;
    private volatile CIOBufferPool.Lease _writing;
    // Per-connection fixed gather array: no byte-copy and no batch allocation.
    private static final int GATHER_MAX_FRAMES = 8;
    // Medium S-packets share the same ordered wire batch when space permits.
    private static final int PACK_MAX_FRAME_BYTES = 2048;
    private CIOBufferPool.Lease[] _gatherFrames;
    private ByteBuffer[] _gatherBuffers;
    private int _gatherCount;
    private int _zeroWriteCompletions;
    private int _zeroReadCompletions;

    /* READ lease is released only after the last completion callback, never during a pending read. */
    private volatile int _readActive;
    private CIOBufferPool.Lease _reading;
    private volatile boolean _readReleased;
    private volatile boolean _readPending;
    // Only the READ pump touches this; preserves buffered frames if an ACK races pause.
    private boolean _readYielded;

    // One reusable callback across all connections. A callback only publishes its
    // result; the socket READ pump owns the receive-buffer and READ state changes.
    private static final CompletionHandler<Integer, CIOUserSocket> READ_COMPLETION = new CompletionHandler<>() {
        @Override
        public void completed(Integer bytes, CIOUserSocket connection) {
            connection.publishReadCompletion(bytes == null ? -1 : bytes.intValue());
        }
        @Override
        public void failed(Throwable error, CIOUserSocket connection) {
            connection.publishReadCompletion(-1);
        }
    };

    private void publishReadCompletion(int bytes) {
        long eventNumber=DIAG_READ_EVENTS.incrementAndGet();
        if((eventNumber & 127L)==0 && eventNumber<=65536L) {
            boolean indirect=false;
            for(StackTraceElement frame:Thread.currentThread().getStackTrace()) {
                if(frame.getClassName().equals("sun.nio.ch.Invoker$2")) {indirect=true;break;}
            }
            if(indirect)DIAG_READ_INDIRECT.increment();else DIAG_READ_DIRECT.increment();
        }


        final int event = bytes < 0 || bytes > CIOBufferPool.LARGE_BYTES
                ? 1 : bytes + 2;
        if (!READ_EVENT.compareAndSet(this, 0, event)) {
            // An already-published completion cannot be overwritten by a
            // second callback; the first one must still release its READ lease.
            close();
            return;
        }
        kickRead();
    }

    private static final CompletionHandler<Integer, CIOUserSocket> WRITE_COMPLETION = new CompletionHandler<>() {
        @Override
        public void completed(Integer bytes, CIOUserSocket connection) {

            connection.publishWriteCompletion(WRITE_DONE, WRITE_FAILED,
                    bytes == null ? -1L : bytes.longValue());
        }
        @Override
        public void failed(Throwable error, CIOUserSocket connection) {
            connection.publishWriteCompletion(WRITE_DONE, WRITE_FAILED, -1L);
        }
    };

    private static final CompletionHandler<Long, CIOUserSocket> GATHER_COMPLETION = new CompletionHandler<>() {
        @Override
        public void completed(Long bytes, CIOUserSocket connection) {

            connection.publishWriteCompletion(GATHER_DONE, GATHER_FAILED,
                    bytes == null ? -1L : bytes.longValue());
        }
        @Override
        public void failed(Throwable error, CIOUserSocket connection) {
            connection.publishWriteCompletion(GATHER_DONE, GATHER_FAILED, -1L);
        }
    };

    /**
     * A WRITE's pending I/O keeps its lease attached to this socket. The NIO.2
     * completion thread only publishes the result; the existing WRITE pump is
     * the sole executor of completion, next-send and buffer-release transitions.
     * There is only one in-flight WRITE per connection, so a single completion
     * mailbox is sufficient. The existing bounded _pending ring continues to
     * retain queued outbound buffers without a redundant callback queue.
     */
    private void publishWriteCompletion(int okKind, int failKind, long transferred) {
        if (_diagnosticSubmitThread == Thread.currentThread()) DIAG_CALLBACK_SAME.increment();
        else DIAG_CALLBACK_OTHER.increment();
        final boolean ok = transferred >= 0L && transferred <= Integer.MAX_VALUE;
        final long event = (ok ? (transferred << 3) | okKind : failKind);
        if (!WRITE_EVENT.compareAndSet(this, 0L, event)) {
            // A second completion for one in-flight WRITE is a transport violation.
            // Never overwrite the first callback or release its lease twice.
            close();
            return;
        }
        if (!serializeSocketCallback(SOCKET_WRITE_COMPLETE, event)) {
            // The completion remains in the mailbox. Close and let the current
            // drainer retire it once earlier callback tickets have finished.
            close();
        }
    }

    /** Runs only with the socket serializer's execution token. */
    private void drainWriteCompletion(long event) {
        final int kind = (int) (event & 7L);
        if (kind == WRITE_FAILED) {
            final CIOBufferPool.Lease lease = _writing;
            if (lease != null) completeWrite(lease, false);
            else close();
            return;
        }
        if (kind == GATHER_FAILED) {
            completeGather(false);
            return;
        }
        if (kind == WRITE_DONE) {
            final CIOBufferPool.Lease lease = _writing;
            if (lease == null) { close(); return; }
            if (_closed != 0) { completeWrite(lease, false); return; }
            final ByteBuffer buffer = lease.buffer();
            if (buffer.hasRemaining()) {
                final long written = event >>> 3;

                if (written == 0L && ++_zeroWriteCompletions >= 8) {
                    completeWrite(lease, false);
                    return;
                }
                if (written != 0L) _zeroWriteCompletions = 0;
                lease._ioPending = false;
                kickWrite();
            } else {
                _zeroWriteCompletions = 0;
                completeWrite(lease, true);
            }
            return;
        }
        if (kind == GATHER_DONE) {
            if (_closed != 0) { completeGather(false); return; }
            boolean remaining = false;
            for (int i = 0; i < _gatherCount; i++) {
                if (_gatherBuffers[i].hasRemaining()) {
                    remaining = true;
                    break;
                }
            }
            if (remaining) {
                final long written = event >>> 3;

                if (written == 0L && ++_zeroWriteCompletions >= 8) {
                    completeGather(false);
                    return;
                }
                if (written != 0L) _zeroWriteCompletions = 0;
                if (_writing == null) { close(); return; }
                _writing._ioPending = false;
                kickWrite();
            } else {
                _zeroWriteCompletions = 0;
                completeGather(true);
            }
            return;
        }
        close();
    }

    public CIOUserSocket(AsynchronousSocketChannel channel, CIOBufferPool pool,
                         CIOThreadCallback scheduler, String remoteAddress,
                         int affinityShard, int maxQueuedFrames, Closed closedCallback) {
        if (channel == null || pool == null || scheduler == null
                || affinityShard < 0 || affinityShard >= scheduler.shardCount()
                || maxQueuedFrames < 1)
            throw new IllegalArgumentException("invalid game socket arguments");
        _channel = channel;
        _pool = pool;
        _remoteAddress = remoteAddress == null ? "Unknown" : remoteAddress;
        _affinityShard = affinityShard;
        _closedCallback = closedCallback;
        _maxQueuedFrames = maxQueuedFrames;
    }

    /** Bind the existing NIO.2 worker executor before the first READ is posted. */
    void bindIoExecutor(Executor executor) {
        if (executor == null || _ioExecutor != null || _readActive != 0)
            throw new IllegalStateException("READ executor already bound or started");
        _ioExecutor = executor;
    }

    void bindClient(CIOClient client) {
        if (client == null || client.getConnection() != this || _client != null || _closed != 0)
            throw new IllegalStateException("socket client already bound or closed");
        _client = client;
    }

    CIOClient client() { return _client; }

    public String getRemoteAddress() { return _remoteAddress; }
    public int affinityShard() { return _affinityShard; }

    public boolean isClientConnected() {
        return isOpen() && _closing == 0 && _disconnecting == 0;
    }

    public int getEstimateQueueSize() { return pendingSendFrames(); }
    public void read() { startRead(); }

    @SuppressWarnings({"rawtypes", "unchecked"})
    public void enqueuePacket(WritablePacket packet) {
        if (packet == null || !isClientConnected()) return;
        final CIOClient client = _client;
        if (client == null || !tryWritePacket(client, packet)) close();
    }

    @SuppressWarnings({"rawtypes", "unchecked"})
    public void requestClientClose(WritablePacket packet) {
        if (!isClientConnected()) return;
        _closing = 1;
        final CIOClient client = _client;
        if (client == null || (packet != null && !tryWritePacket(client, packet))) {
            close();
            return;
        }
        if (isWriteIdle()) close();
    }

    public boolean sendAction(int objectId, int actionId) {
        if (!isClientConnected()) return false;
        if (tryWriteAction(objectId, actionId)) return true;
        close();
        return false;
    }

    public boolean beginClientDisconnect() {
        if (!DISCONNECTING.compareAndSet(this, 0, 1)) return false;
        _closing = 1;
        ON_DRAINED.setVolatile(this, null);
        return true;
    }

    public void finishClientDisconnect() { close(); }
    public int drainOnOwner() { return 0; }
    public void onSendDrainedOwner() { onSendProgress(); }
    public boolean hasDrainWorkOnOwner() { return getEstimateQueueSize() != 0; }
    public void requestDrain() { /* WRITE completion pump owns the drain. */ }

    public boolean whenWriteDrained(Runnable callback) {
        if (callback == null || _closed != 0) return false;
        ON_DRAINED.setVolatile(this, callback);
        if (_closed != 0) {
            ON_DRAINED.compareAndSet(this, callback, null);
            return false;
        }
        if (isWriteIdle()) onSendProgress();
        return true;
    }

    public void cancelWriteDrainCallback() {
        ON_DRAINED.setVolatile(this, null);
    }

    private void onSendProgress() {
        if (!isWriteIdle()) return;
        final Runnable callback = (Runnable) ON_DRAINED.getAndSet(this, null);
        if (callback != null) callback.run();
        if (_closing != 0) close();
    }

    /** Acquire a packet-writing slot; false/null means backpressure, not a silent successful SEND. */
    public CIOBufferPool.Lease beginOutboundFrame(int maxWireBytes) {
        return (_closed != 0) ? null : _pool.acquireSend(maxWireBytes);
    }

    /**
     * Direct-frame entry point compatible with CIOUserSocket's existing packet API.
     * Reserve one bounded queue position before exposing the writable buffer.
     * The reusable handle is owned by its pooled lease, not allocated per packet.
     */
    public CIOFrame beginDirectFrame(int maxWireBytes) {
        int slot = -1;
        boolean refused = false;
        _stateLock.lock();
        try {
            if (_closed != 0) return null;
            if (maxWireBytes <= CIOBufferPool.HEADER_BYTES
                    || maxWireBytes > CIOBufferPool.MAX_WIRE_BYTES
                    || !canAdmitBytes(maxWireBytes)) {
                rejectSend(REJECT_WIRE_BYTES);
                refused = true;
            } else if (_queued + _reservedDirect + _stagedSends
                    + (_writing == null ? 0 : 1) >= _maxQueuedFrames + 1) {
                rejectSend(REJECT_LOCAL_FRAMES);
                refused = true;
            } else {
                if (!isSocketSerializerOwner()) {
                    for (;;) {
                        final int pending = (int) SOCKET_PENDING.getVolatile(this);
                        if (pending >= SOCKET_REJECT_AT) {
                            rejectSend(REJECT_SERIALIZER);
                            refused = true;
                            break;
                        }
                        if (SOCKET_PENDING.compareAndSet(this, pending, pending + 1)) break;
                    }
                    if (!refused) slot = (int) (long) SOCKET_TICKET.getAndAdd(this, 1L) & SOCKET_MASK;
                }
                if (!refused) {
                    ++_reservedDirect;
                    _reservedWireBytes += maxWireBytes;
                    updateSendReadPauseLocked();
                }
            }
        } finally { _stateLock.unlock(); }
        if (refused) {
            // A packet that cannot be admitted must never look like a successful SEND.
            close();
            return null;
        }

        CIOBufferPool.Lease lease = null;
        try {
            lease = beginOutboundFrame(maxWireBytes);
            if (lease != null) {
                final CIOFrame frame = lease.beginDirectFrame(this);
                frame.setReservation(maxWireBytes, slot);
                return frame;
            }
            rejectSend(REJECT_POOL);
        } catch (Throwable failure) {
            rejectSend(REJECT_ENCODING);
            // Preserve the original failure, but release the ticket and lease.
            rollbackDirectBegin(maxWireBytes, slot, lease);
            close();
            throw failure;
        }
        rollbackDirectBegin(maxWireBytes, slot, lease);
        close();
        return null;
    }

    private void cancelReservedTicketLocked(int slot) {
        if (slot < 0) return;
        _socketSendArguments[slot] = null;
        SOCKET_ARGUMENT_SLOT.setRelease(_socketArguments, slot, 0L);
        SOCKET_CALLBACK_SLOT.setRelease(_socketCallbacks, slot, SOCKET_CANCELLED);
    }

    private void rollbackDirectBegin(int bytes, int slot,
            CIOBufferPool.Lease lease) {
        boolean resumeRead;
        _stateLock.lock();
        try {
            --_reservedDirect;
            _reservedWireBytes -= bytes;
            cancelReservedTicketLocked(slot);
            if (lease != null && lease.reserved()) abortOutboundFrame(lease);
            resumeRead = updateSendReadPauseLocked();
        } finally { _stateLock.unlock(); }
        if (slot >= 0) drainSocketCallbacks();
        if (resumeRead) kickRead();
        notifyClosedWhenReleased();
    }

    public boolean commitDirectFrame(CIOFrame frame) {
        if (frame == null) return false;
        final CIOBufferPool.Lease lease = frame.ioLease(this);
        final int reservedBytes = frame.reservedBytes();
        final int slot = frame.reservedTicket();
        boolean accepted = false;
        boolean direct = false;
        boolean resumeRead = false;
        _stateLock.lock();
        try {
            --_reservedDirect;
            _reservedWireBytes -= reservedBytes;
            try {
                direct = slot < 0 && isSocketSerializerOwner();
                accepted = stageOutboundFrameLocked(lease, direct, slot);
                if (accepted) frame.finishIO();
            } finally {
                if (!accepted) {
                    ++_reservedDirect;
                    _reservedWireBytes += reservedBytes;
                }
                resumeRead = updateSendReadPauseLocked();
            }
        } finally { _stateLock.unlock(); }
        if (accepted) finishStagedSend(lease, direct);
        if (resumeRead && _closed == 0) kickRead();
        if (!accepted) {
            // The caller's finally aborts the still-owned frame/ticket.
            close();
        }
        return accepted;
    }

    public void abortDirectFrame(CIOFrame frame) {
        if (frame == null) return;
        final CIOBufferPool.Lease lease = frame.ioLease(this);
        final int bytes = frame.reservedBytes();
        final int slot = frame.reservedTicket();
        boolean resumeRead;
        _stateLock.lock();
        try {
            --_reservedDirect;
            _reservedWireBytes -= bytes;
            frame.finishIO();
            cancelReservedTicketLocked(slot);
            abortOutboundFrame(lease);
            resumeRead = updateSendReadPauseLocked();
        } finally { _stateLock.unlock(); }
        if (slot >= 0) drainSocketCallbacks();
        if (resumeRead) kickRead();
        // Direct send failure is fatal for packet-stream consistency: never
        // silently lose an attack/HP update when callers ignore the boolean.
        if (_closed == 0) close();
        notifyClosedWhenReleased();
    }

    /**
     * Allocate the large pending ring only when a connection actually has a burst.
     * Called with the connection state lock held. The ring grows at most to the
     * original configured bound; no extra queue or per-frame nodes are created.
     */
    private boolean ensurePendingSlot() {
        final CIOBufferPool.Lease[] old = _pending;
        if (old == null) {
            _pending = new CIOBufferPool.Lease[Math.min(_maxQueuedFrames, 8)];
            return true;
        }
        if (_queued < old.length) return true;
        if (old.length >= _maxQueuedFrames) return false;
        final int capacity = (int) Math.min((long) _maxQueuedFrames, (long) old.length << 1);
        final CIOBufferPool.Lease[] next = new CIOBufferPool.Lease[capacity];
        final int first = Math.min(_queued, old.length - _head);
        System.arraycopy(old, _head, next, 0, first);
        if (_queued > first) System.arraycopy(old, 0, next, first, _queued - first);
        _pending = next;
        _head = 0;
        _tail = _queued;
        return true;
    }

    /** Successful commit means accepted for asynchronous SEND, not delivered to the peer. */
    public boolean commitOutboundFrame(CIOBufferPool.Lease lease) {
        final boolean admitted;
        final boolean direct;
        _stateLock.lock(); try {
            direct = isSocketSerializerOwner();
            admitted = stageOutboundFrameLocked(lease, direct);
        } finally { _stateLock.unlock(); }
        if (admitted) finishStagedSend(lease, direct);
        return admitted;
    }

    private boolean stageOutboundFrameLocked(CIOBufferPool.Lease lease, boolean direct) {
        return stageOutboundFrameLocked(lease, direct, -1);
    }

    private boolean stageOutboundFrameLocked(CIOBufferPool.Lease lease, boolean direct,
            int reservedTicketSlot) {
        if (lease == null || !_pool.owns(lease) || !lease.reserved()) return false;
        final int length = lease.writer().position();
        if (length <= CIOBufferPool.HEADER_BYTES
                || length > lease._reservedWireBytes
                || length > CIOBufferPool.MAX_WIRE_BYTES
                || _closed != 0) return false;
        if (!canAdmitBytes(length)) return rejectSend(REJECT_WIRE_BYTES);
        if (_queued + _reservedDirect + _stagedSends
                + (_writing == null ? 0 : 1) >= _maxQueuedFrames + 1)
            return rejectSend(REJECT_LOCAL_FRAMES);

        // A nested callback on the current serializer owner is executed
        // inline after unlocking. Only foreign threads consume ticket slots.
        int slot = reservedTicketSlot;
        if (!direct) {
            if (slot < 0) {
                for (;;) {
                    final int pending = (int) SOCKET_PENDING.getVolatile(this);
                    if (pending >= SOCKET_REJECT_AT) return rejectSend(REJECT_SERIALIZER);
                    if (SOCKET_PENDING.compareAndSet(this, pending, pending + 1)) break;
                }
                slot = (int) (long) SOCKET_TICKET.getAndAdd(this, 1L) & SOCKET_MASK;
            }
            _socketSendArguments[slot] = lease;
            SOCKET_ARGUMENT_SLOT.setRelease(_socketArguments, slot, 0L);
        }
        if (direct && _stagedSends != 0) {
            long count=DIAG_INLINE_OVER_PENDING.incrementAndGet();
            if(count<=5)System.err.println("INLINE_OVER_PENDING objectId="+(length==8?lease.buffer().getInt(3):-1)
                    +" staged="+_stagedSends+" pending="+SOCKET_PENDING.getVolatile(this)+" thread="+Thread.currentThread().getName());
        }
        ++_stagedSends;
        bytesAdmitted(length);
        final SendBurst burst = SEND_BURST.get();
        if (_burstOwner == null && burst != null && burst.depth != 0
                && _writing == null && _queued == 0
                && _outstandingWireBytes <= BURST_MAX_BYTES) {
            burst.attach(this);
        }
        if (!direct) SOCKET_CALLBACK_SLOT.setRelease(_socketCallbacks, slot, SOCKET_SEND_ENQUEUE);
        return true;
    }

    private boolean isSocketSerializerOwner() {
        return _socketOwner == Thread.currentThread() && !_socketPosting;
    }

    /** Direct SEND must run only after releasing the socket state lock. */
    private void finishStagedSend(CIOBufferPool.Lease lease, boolean direct) {
        if (!direct) {
            drainSocketCallbacks();
            return;
        }
        try {
            acceptStagedSend(lease);
        } catch (Throwable failure) {
            close();
        }
    }

    /** Consume SEND under the current socket serializer token. */
    private void acceptStagedSend(CIOBufferPool.Lease lease) {
        boolean start = false;
        boolean resumeRead = false;
        boolean success = false;
        _stateLock.lock(); try {
            --_stagedSends;
            final int length = lease.writer().position();
            if (_closed == 0) {
                success = commitStagedOutboundFrameLocked(lease);
                if (success && _writing != null && !_writing._ioPending) {
                    start = _burstOwner == null || _outstandingWireBytes >= BURST_MAX_BYTES;
                }
            }
            if (!success) {
                resumeRead = bytesReleased(length, 1);
                _pool.release(lease);
            }
        } finally { _stateLock.unlock(); }
        if (!success && _closed == 0) close();
        if (start && _closed == 0) kickWrite();
        if (resumeRead && _closed == 0) kickRead();
        notifyClosedWhenReleased();
    }

    /** Only the FIFO serializer owner may attach a staged SEND lease. */
    private boolean commitStagedOutboundFrameLocked(CIOBufferPool.Lease lease) {
        if (lease == null) return false;
        if (!_pool.owns(lease)) throw new IllegalArgumentException("foreign SEND lease");
        final WriteBuffer writer = lease.writer();
        final int length = writer.position();
        if (length <= CIOBufferPool.HEADER_BYTES
                || length > lease._reservedWireBytes
                || length > CIOBufferPool.MAX_WIRE_BYTES) return false;
        writer.writeShort(0, (short) length);
        writer.sealToPosition();
        lease._wireLength = length;
        lease._frameCount = 1;
        lease.publish();

        if (_closed != 0) {
            lease.unpublish();
            return false;
        }
        if (_writing != null && length <= PACK_MAX_FRAME_BYTES) {
            final CIOBufferPool.Lease tail = _queued != 0
                    ? _pending[_tail == 0 ? _pending.length - 1 : _tail - 1]
                    : (_burstOwner != null ? _writing : null);
            if (tail != null && !tail._ioPending && !tail._writePrepared
                    && tail.buffer().capacity() == CIOBufferPool.SMALL_SEND_BYTES
                    && tail._wireLength + length <= CIOBufferPool.SMALL_SEND_BYTES) {
                // Source packet is already serialized, but not yet encrypted.
                // Reuse the previously queued wire buffer without a new object.
                final ByteBuffer src = lease.buffer();
                final ByteBuffer dst = tail.buffer();
                final int offset = tail._wireLength;
                dst.limit(dst.capacity());
                // JDK absolute bulk put avoids per-byte bounds checks and
                // preserves both buffers' positions and limits.
                dst.put(offset, src, 0, length);
                tail._wireLength += length;
                tail._frameCount++;
                tail._packedFrames = true;
                _pool.release(lease);
                return true;
            }
        }
        if (_queued + _reservedDirect + (_writing == null ? 0 : 1)
                >= _maxQueuedFrames + 1) {
            lease.unpublish();
            return false;
        }
        if (_writing == null) {
            _writing = lease;
            _zeroWriteCompletions = 0;

        } else {
            if (!ensurePendingSlot()) {
                lease.unpublish();
                return false;
            }
            _pending[_tail] = lease;
            if (++_tail == _pending.length) _tail = 0;
            ++_queued;

        }
        return true;
    }

    /** Reserve FIFO position before serializing; encode does not hold the socket lock.
     * A true result means admitted to SEND, not delivered to the peer. */
    public boolean tryWritePacket(CIOClient client, WritablePacket<CIOClient> packet) {
        if (client == null || packet == null || !isOpen()) return false;
        final int learned = WriteBuffer.learnedPacketSize(packet.getClass());
        final boolean direct;
        final int slot;
        _stateLock.lock();
        try {
            if (_closed != 0) return false;
            if (!canAdmitBytes(Math.max(3, learned))) return rejectSend(REJECT_WIRE_BYTES);
            if (_queued + _reservedDirect + _stagedSends
                    + (_writing == null ? 0 : 1) >= _maxQueuedFrames + 1)
                return rejectSend(REJECT_LOCAL_FRAMES);
            direct = isSocketSerializerOwner();
            if (direct) {
                slot = -1;
            } else {
                // A completed WRITE cannot overtake an earlier SEND while its
                // producer is still serializing outside the state lock.
                for (;;) {
                    final int pending = (int) SOCKET_PENDING.getVolatile(this);
                    if (pending >= SOCKET_REJECT_AT) return rejectSend(REJECT_SERIALIZER);
                    if (SOCKET_PENDING.compareAndSet(this, pending, pending + 1)) break;
                }
                slot = (int) (long) SOCKET_TICKET.getAndAdd(this, 1L) & SOCKET_MASK;
            }
            ++_reservedDirect;
        } finally {
            _stateLock.unlock();
        }

        CIOBufferPool.Lease encoded = null;
        boolean encodeFailed = false;
        int capacity = learned > CIOBufferPool.SMALL_SEND_BYTES
                ? CIOBufferPool.MAX_WIRE_BYTES : CIOBufferPool.SMALL_SEND_BYTES;
        for (int attempt = 0; attempt < 2; attempt++) {
            CIOBufferPool.Lease lease = null;
            boolean retryLarge = false;
            try {
                lease = beginOutboundFrame(capacity);
                if (lease == null) {
                    rejectSend(REJECT_POOL);
                    break;
                }
                final WriteBuffer writer = lease.beginPacket(packet.getClass());
                packet.writeData(client, writer);
                writer.notePacketSize();
                encoded = lease;
            } catch (WriteBuffer.RegisteredCapacityExceededException oversized) {
                retryLarge = capacity < CIOBufferPool.MAX_WIRE_BYTES;
                if (!retryLarge) encodeFailed = true;
            } catch (Throwable failure) {
                encodeFailed = true;
            } finally {
                if (lease != null && lease != encoded && lease.reserved())
                    abortOutboundFrame(lease);
            }
            if (encoded != null || !retryLarge) break;
            capacity = CIOBufferPool.MAX_WIRE_BYTES;
        }

        boolean accepted = false;
        _stateLock.lock();
        try {
            --_reservedDirect;
            try {
                if (encoded != null)
                    accepted = stageOutboundFrameLocked(encoded, direct, slot);
            } catch (Throwable failure) {
                encodeFailed = true;
            } finally {
                if (!accepted) {
                    try {
                        // Keep the encoder reservation until its lease is
                        // released. Close must never publish completion first.
                        if (encoded != null && encoded.reserved())
                            abortOutboundFrame(encoded);
                    } catch (Throwable failure) {
                        encodeFailed = true;
                    } finally {
                        if (slot >= 0) {
                            // Retire even failed encoders in original FIFO order.
                            SOCKET_ARGUMENT_SLOT.setRelease(_socketArguments, slot, 0L);
                            SOCKET_CALLBACK_SLOT.setRelease(_socketCallbacks, slot, SOCKET_CANCELLED);
                        }
                    }
                }
            }
        } finally {
            _stateLock.unlock();
        }
        if (accepted) {
            finishStagedSend(encoded, direct);
        } else {
            if (encodeFailed) rejectSend(REJECT_ENCODING);
            if (slot >= 0) drainSocketCallbacks();
            if (encodeFailed || encoded != null) close();
            if (_closed != 0) kickWrite();
            notifyClosedWhenReleased();
        }
        return accepted;
    }

    /**
     * Reserve each action as a completed frame for the socket serializer.
     * Its callback coalesces into the last unsubmitted 16K batch when possible,
     * preserving FIFO order and the existing wire-frame cipher boundaries.
     */
    public boolean tryWriteAction(int objectId, int actionId) {
        boolean accepted = false;
        boolean direct = false;
        CIOBufferPool.Lease stagedLease = null;
        _stateLock.lock(); try {
            if (_closed != 0) return false;
            if (!canAdmitBytes(8)) return rejectSend(REJECT_WIRE_BYTES);
            if (_queued + _reservedDirect + _stagedSends
                    + (_writing == null ? 0 : 1) >= _maxQueuedFrames + 1)
                return rejectSend(REJECT_LOCAL_FRAMES);
            if (appendBurstActionLocked(objectId, actionId)) return true;
            {
                final CIOBufferPool.Lease lease = _pool.acquireSend(CIOBufferPool.SMALL_SEND_BYTES);
                if (lease == null) {
                    rejectSend(REJECT_POOL);
                } else {
                    try {
                        final WriteBuffer writer = lease.writer();
                        // Absolute data writes do not advance WriteBuffer position.
                        putAction(lease.buffer(), 0, objectId, actionId);
                        writer.position(8);
                        direct = isSocketSerializerOwner();
                        accepted = stageOutboundFrameLocked(lease, direct);
                        if (accepted) stagedLease = lease;
                    } finally {
                        if (!accepted && lease.reserved()) _pool.release(lease);
                    }
                }
            }
        } finally { _stateLock.unlock(); }
        if (accepted) finishStagedSend(stagedLease, direct);

        return accepted;
    }

    /**
     * The current SendBurst owns the unsubmitted first lease. No foreign
     * reservation, pending serializer callback, or I/O may precede an append.
     * Caller holds _stateLock. SEND admission remains FIFO at frame boundaries.
     */
    private CIOBufferPool.Lease writableBurstTailLocked() {
        final SendBurst burst = SEND_BURST.get();
        if (burst == null || burst.depth == 0 || _burstOwner != burst
                || _queued != 0 || _stagedSends != 0 || _reservedDirect != 0
                || (int) SOCKET_PENDING.getVolatile(this) != 0) return null;
        final CIOBufferPool.Lease tail = _writing;
        if (tail == null || tail._ioPending || tail._writePrepared
                || tail.buffer().capacity() != CIOBufferPool.SMALL_SEND_BYTES)
            return null;
        return tail;
    }

    /** No intermediate pool lease/ticket for a single complete action frame. */
    private boolean appendBurstActionLocked(int objectId, int actionId) {
        final CIOBufferPool.Lease tail = writableBurstTailLocked();
        if (tail == null || _outstandingWireBytes > BURST_MAX_BYTES - 8
                || tail._wireLength > CIOBufferPool.SMALL_SEND_BYTES - 8)
            return false;
        final ByteBuffer bytes = tail.buffer();
        bytes.limit(bytes.capacity());
        putAction(bytes, tail._wireLength, objectId, actionId);
        tail._wireLength += 8;
        ++tail._frameCount;
        tail._packedFrames = true;
        bytesAdmitted(8);
        return true;
    }

    /**
     * Network-only action batch: no allocation, one lock and one watermark
     * update for N complete 8-byte frames. Only a writable burst-owned tail
     * permits the batch fast path; otherwise original single-frame FIFO is used.
     * Existing sendAction/tryWriteAction success and failure contracts remain.
     * The supplied arrays are borrowed for this call, never retained.
     */
    public boolean tryWriteActionBatch(int[] objectIds, int[] actionIds,
            int offset, int count) {
        if (objectIds == null || actionIds == null || offset < 0 || count < 0
                || offset > objectIds.length || count > objectIds.length - offset
                || offset > actionIds.length || count > actionIds.length - offset)
            throw new IllegalArgumentException("invalid action batch range");
        int done = 0;
        while (done < count) {
            final int appended;
            _stateLock.lock();
            try {
                if ((int)SOCKET_PENDING.getVolatile(this) != 0) {
                    if (isSocketSerializerOwner()) DIAG_BATCH_PENDING_OWNER.increment();
                    else DIAG_BATCH_PENDING_OTHER.increment();
                }
                final SendBurst diagnosticBurst=SEND_BURST.get();
                final CIOBufferPool.Lease diagnosticTail=_writing;
                if ((int)SOCKET_PENDING.getVolatile(this)==1 && isSocketSerializerOwner()
                        && diagnosticBurst!=null && diagnosticBurst.depth!=0 && _burstOwner==diagnosticBurst
                        && _queued==0 && _stagedSends==0 && _reservedDirect==0
                        && diagnosticTail!=null && !diagnosticTail._ioPending && !diagnosticTail._writePrepared
                        && diagnosticTail.buffer().capacity()==CIOBufferPool.SMALL_SEND_BYTES
                        && _outstandingWireBytes<=BURST_MAX_BYTES-8
                        && diagnosticTail._wireLength<=CIOBufferPool.SMALL_SEND_BYTES-8
                        && canAdmitBytes(8)) DIAG_SELF_PENDING_ONLY.increment();
                appended = appendBurstActionBatchLocked(objectIds, actionIds,
                        offset + done, count - done);
            } finally { _stateLock.unlock(); }
            if (appended != 0) {
                DIAG_BATCH_FAST_FRAMES.add(appended);
                done += appended;
            } else {
                // Before/after an owned SendBurst or at the 8K flush boundary:
                // use the original reservation, ticket, and WRITE path.
                DIAG_BATCH_FALLBACK_FRAMES.increment();
                if (!tryWriteAction(objectIds[offset + done], actionIds[offset + done])) {
                    // Previous frames in this batch cannot be rolled back after
                    // publication; never keep a partially accepted batch live.
                    if (done != 0 && _closed == 0) close();
                    return false;
                }
                ++done;
            }
        }
        return true;
    }

    /** Batch admission and accounting are indivisible under _stateLock. */
    private int appendBurstActionBatchLocked(int[] objectIds, int[] actionIds,
            int offset, int count) {
        if (_closed != 0) return 0;
        final CIOBufferPool.Lease tail = writableBurstTailLocked();
        if (tail == null) return 0;
        final int freeBytes = Math.min(
                Math.min(BURST_MAX_BYTES - _outstandingWireBytes,
                        CIOBufferPool.SMALL_SEND_BYTES - tail._wireLength),
                MAX_PENDING_WIRE_BYTES - _outstandingWireBytes - _reservedWireBytes);
        final int frames = Math.min(count, freeBytes / 8);
        if (frames <= 0 || !canAdmitBytes(frames * 8)) return 0;

        final ByteBuffer bytes = tail.buffer();
        bytes.limit(bytes.capacity());
        int position = tail._wireLength;
        for (int i = 0; i < frames; ++i) {
            putAction(bytes, position, objectIds[offset + i], actionIds[offset + i]);
            position += 8;
        }
        tail._wireLength = position;
        tail._frameCount += frames;
        tail._packedFrames = true;
        bytesAdmittedBatch(frames * 8, frames);
        return frames;
    }

    private static void putAction(ByteBuffer out, int position, int objectId, int actionId) {
        out.putShort(position, (short) 8);
        out.put(position + 2, (byte) Opcodes.S_ACTION);
        out.putInt(position + 3, objectId);
        out.put(position + 7, (byte) actionId);
    }

    /**
     * The client cipher advances per game packet, not per transport write.
     * Each packed frame is encrypted individually in wire order.
     */
    private boolean preparePackedEncryption(CIOBufferPool.Lease lease) {
        final WriteBuffer writer = lease.writer();
        final ByteBuffer bytes = lease.buffer();
        final int length = lease.wireLength();
        int offset = 0;
        while (offset < length) {
            if (length - offset < CIOBufferPool.HEADER_BYTES) return false;
            final int frameLength = Short.toUnsignedInt(bytes.getShort(offset));
            if (frameLength <= CIOBufferPool.HEADER_BYTES
                    || frameLength > length - offset) return false;
            if (!encrypt(writer,
                    offset + CIOBufferPool.HEADER_BYTES,
                    frameLength - CIOBufferPool.HEADER_BYTES)) return false;
            offset += frameLength;
        }
        return true;
    }

    /** Only call this for a frame that was NOT committed. */
    public void abortOutboundFrame(CIOBufferPool.Lease lease) {
        if (lease == null) return;
        if (!_pool.owns(lease) || !lease.reserved())
            throw new IllegalStateException("abort after commit or foreign SEND lease");
        _pool.release(lease);
    }

    /** Exactly one pending read per socket. */
    public void startRead() {
        try {
            _stateLock.lock(); try {
                if ((_closed != 0) || !READ_ACTIVE.compareAndSet(this, 0, 1)) return;
                try {
                    _reading = _pool.acquireRecv();
                } catch (RuntimeException | Error failure) {
                    READ_ACTIVE.setVolatile(this, 0);
                    close();
                    throw failure;
                }
                if (_reading == null) {
                    READ_ACTIVE.setVolatile(this, 0);
                    close();
                    return;
                }
            } finally { _stateLock.unlock(); }
        } finally {
            // close() may reenter under the state lock on pool failure.
            if (_closed != 0) kickWrite();
        }
        kickRead();
    }

    /**
     * Only one thread may touch the compacting READ ByteBuffer at a time.
     * Synchronous completed() callbacks are trampolined without recursion.
     * Cross-thread SEND acknowledgements may race with the NIO completion.
     */
    private void kickRead() {
        if ((int) READ_KICK.getAndAdd(this, 1) != 0) return;
        int missed = 1;
        do {
            // The callback may be invoked inline, even before channel.read()
            // returns. Only this pump retires an outstanding READ operation.
            final int event = (int) READ_EVENT.getAndSet(this, 0);
            if (event != 0) {
                _readPending = false;
                if (event == 1 || _closed != 0) {
                    close();
                } else if (event == 2) {
                    if (++_zeroReadCompletions >= 8) close();
                } else {
                    _zeroReadCompletions = 0;
                }
            }
            if (_closed == 0 && !_readPending && !_sendReadPaused) {
                try {
                    if (!onRead()) {
                        close();
                    } else if (_closed == 0 && !_sendReadPaused && !_readYielded) {
                        postRead();
                    }
                } catch (Throwable failure) {
                    close();
                }
            }
            if (_readYielded && _closed == 0 && !_sendReadPaused
                    && READ_FRAME_BUDGET != 0 && _ioExecutor != null) {
                // The buffer was compacted at a complete frame boundary.
                // Release pump ownership BEFORE publishing its continuation.
                // Another kick may race and take ownership; READ_KICK still
                // serializes access to the READ lease in either case.
                READ_KICK.getAndSet(this, 0);
                scheduleReadContinuation();
                finishReadIfClosed();
                return;
            }
            missed = ((int) READ_KICK.getAndAdd(this, -missed) - missed);
        } while (missed != 0);
        finishReadIfClosed();
    }

    private void scheduleReadContinuation() {
        if (!READ_CONTINUATION_QUEUED.compareAndSet(this, 0, 1)) return;
        try {
            _ioExecutor.execute(this);
        } catch (RuntimeException refused) {
            READ_CONTINUATION_QUEUED.setVolatile(this, 0);
            // No suspended READ may be abandoned with a live session.
            close();
        }
    }

    /** A single reusable task per connection; runs on the same NIO.2 workers. */
    @Override
    public void run() {
        READ_CONTINUATION_QUEUED.setVolatile(this, 0);
        kickRead();
    }

    private void postRead() {
        if (_closed != 0) return;
        final ByteBuffer recv = _reading.buffer();
        if (!recv.hasRemaining()) {
            close();
            return;
        }
        // Set before the call: async I/O may invoke completed() synchronously.
        _readPending = true;
        try {

            _channel.read(recv, this, READ_COMPLETION);
        } catch (Throwable t) {
            _readPending = false;
            close();
        }
    }

    /** Release the READ lease on close only after the last completion. */
    private void finishReadIfClosed() {
        if ((_closed != 0) && !_readPending && _readKick == 0) {
            _stateLock.lock(); try {
                if (!_readPending && _readKick == 0) endRead();
            } finally { _stateLock.unlock(); }
        }
    }

    private boolean onRead() {
        if (_diagnosticReaders.incrementAndGet() != 1) DIAG_READ_OVERLAP.increment();
        try { return diagnosticOnReadBody(); }
        finally { _diagnosticReaders.decrementAndGet(); }
    }
    private boolean diagnosticOnReadBody() {
        _readYielded = false;
        ByteBuffer recv = _reading.buffer();
        if (recv.position() == 0) return true;
        recv.flip();
        // The READ pump owns framing and posts the next read only after the
        // current handler returns; fairness yields at complete frame boundaries.
        int frames = 0;
        while (recv.remaining() >= CIOBufferPool.HEADER_BYTES) {
            // A READ already in flight may complete after SEND pressure rises.
            // Keep its frame encrypted/buffered until the low-water release.
            if (_sendReadPaused) {
                _readYielded = true;
                break;
            }
            final int start = recv.position();
            final int wireLength = Short.toUnsignedInt(recv.order(ByteOrder.LITTLE_ENDIAN).getShort(start));
            if (wireLength < CIOBufferPool.HEADER_BYTES
                    || wireLength > CIOBufferPool.MAX_WIRE_BYTES) return false;
            if (recv.remaining() < wireLength) break;
            final boolean accepted = onReadFrame(recv, start + CIOBufferPool.HEADER_BYTES,
                    wireLength - CIOBufferPool.HEADER_BYTES);
            if (!accepted || (_closed != 0)) return false;
            recv.position(start + wireLength);
            if (_sendReadPaused) {
                _readYielded = true;
                break;
            }
            if (_ioExecutor != null && READ_FRAME_BUDGET != 0
                    && ++frames >= READ_FRAME_BUDGET
                    && recv.remaining() >= CIOBufferPool.HEADER_BYTES) {
                final int nextLength = Short.toUnsignedInt(recv.getShort(recv.position()));
                if (nextLength >= CIOBufferPool.HEADER_BYTES
                        && nextLength <= recv.remaining()) {
                    _readYielded = true;
                    break;
                }
            }
        }
        recv.compact();
        if (!recv.hasRemaining()) {
            // A complete compact-buffer-sized frame can fill this lease exactly.
            // SEND-pressure backpressure can retain a complete frame.
            if (_readYielded) return true;
            if (recv.position() < CIOBufferPool.HEADER_BYTES) return false;
            final int wireLength = Short.toUnsignedInt(recv.getShort(0));
            if (wireLength <= recv.capacity()) return false;
            final CIOBufferPool.Lease large = _pool.acquireLargeRecv();
            if (large == null) return false;
            recv.flip();
            large.buffer().put(recv);
            final CIOBufferPool.Lease old = _reading;
            _reading = large;
            _pool.release(old);
        } else if (_reading.buffer().capacity() > CIOBufferPool.RECV_BYTES
                && recv.position() == 0) {
            final CIOBufferPool.Lease compact = _pool.acquireRecv();
            if (compact != null) {
                final CIOBufferPool.Lease old = _reading;
                _reading = compact;
                _pool.release(old);
            }
        }
        return true;
    }

    private void endRead() {
        if (!READ_ACTIVE.compareAndSet(this, 1, 0)) return;
        releaseReadWhenIdle();
        notifyClosedWhenReleased();
    }

    private void releaseReadWhenIdle() {
        _stateLock.lock();
        try {
        if (_readReleased || (_readActive != 0)) return;
        final CIOBufferPool.Lease recv = _reading;
        _reading = null;
        if (recv != null) _pool.release(recv);
        _readReleased = true;
        } finally {
            _stateLock.unlock();
        }
    }

    private boolean onReadFrame(ByteBuffer wire, int bodyStart, int bodyLength) {
        if (!_client.isConnected()) return false;

        // Preserve the empty-packet flood handling (wire length == 2).
        if (bodyLength == 0) {
            if (_client.incrementEmptyPacketCount() <= ConnectionConfig.PACKET_LIMIT_PER_SEC) {
                return true;
            }
            _client.disconnect();
            return false;
        }
        _client.resetEmptyPacketCount();

        // Lineage decrypt consumes its 4-byte cipher prefix and requires 8 bytes.
        if (bodyLength < 8) {
            _client.disconnect();
            return false;
        }

        // Reuse the decoder across frames. Synchronous nested READs use a
        // nested state so the outer frame cannot be overwritten.
        final DecodeState state = acquireDecodeState();
        try {
        	
            int previewOpcode = -1;
            try {
                final Cryptor cipher = readCipher();
                previewOpcode = cipher == null ? -1
                        : cipher.peekOpcode(wire, bodyStart, bodyLength);
                if (DIRECT_UNROUTED && previewOpcode >= 0
                        && !CPacketHandler.isFastOpcode(previewOpcode)) {
                    // Unknown wire opcodes are network-only. They do not enter
                    // the game-state owner and never emit a game response.
                    final ReadBuffer decoded = state.buffer;
                    decoded.resetTrusted(wire, bodyStart, bodyLength);
                    try {
                        if (decryptPreviewed(decoded, bodyLength, previewOpcode, cipher)) {
                            decoded.limit(bodyLength - 4);
                            if (decoded.remaining() > 0) {
                                if (_client.checkPacketRateLimit(System.currentTimeMillis())) {
                                    _client.disconnect();
                                    return false;
                                }
                                final int opcode = decoded.readUnsignedByte();
                                if (opcode != previewOpcode) {
                                    throw new IllegalStateException("cipher opcode preview mismatch");
                                }
                                NetworkSafeLoadManager.isFilter(_client, opcode);
                            }

                            return true;
                        }
                        // Non-previewed packets use the regular direct decrypt path.
                    } finally {
                        decoded.clear();
                    }
                }
            } catch (Throwable error) {

                LOG.log(Level.WARNING, "[I/O OnRead] packet preview failed", error);
                _client.disconnect();
                return false;
            }

            boolean success = false;
            final ReadBuffer decoded = state.buffer;
        
            final boolean creatureOnly = previewOpcode >= 0
                    && CPacketHandler.isDirectOpcode(previewOpcode);
            try {
                decoded.resetTrusted(wire, bodyStart, bodyLength);
                if (decrypt(decoded, 0, bodyLength)) {
                    decoded.limit(bodyLength - 4);
                    if (decoded.remaining() == 0) {
                        success = _client.isConnected();
                    } else if (!_client.checkPacketRateLimit(System.currentTimeMillis())) {
                        final int opcode = decoded.readUnsignedByte();
                        if (previewOpcode >= 0 && opcode != previewOpcode)
                            throw new IllegalStateException("cipher opcode preview mismatch");
                        if (NetworkSafeLoadManager.isFilter(_client, opcode)
                                != NetworkSafeLoadManager.RESULT_FILTER) {
                            if (creatureOnly || (_client.isGameSessionReady()
                                    && !CPacketHandler.isSessionOpcode(opcode))) {
                                dispatchDecodedFrame(opcode, decoded);
                            } else {
                                synchronized (_client) {
                                    if (_client.isConnected()) {
                                        dispatchDecodedFrame(opcode, decoded);
                                    }
                                }
                            }
                        }
                        success = _client.isConnected();
                    } else {
                        _client.disconnect();
                        return false;
                    }
                }
            } catch (Throwable error) {

                LOG.log(Level.WARNING, "[I/O OnRead] packet decode failed", error);
            } finally {
                decoded.clear();
            }

            if (!success) _client.disconnect();
            return success;
        } finally {
            state.buffer.clear();
            state.active = false;
        }
    }

    private void dispatchDecodedFrame(int opcode, ReadBuffer decoded) {
        beginSendBurst();
        try {
            final CPacketHandler.PacketHandler handler =  CPacketHandler.HANDLERS[opcode & 0xFF];
            if (handler != null) handler.execute(decoded, _client);
            flushSendBurst();
        } finally {
            endSendBurst();
        }
    }

    private boolean serializeSocketCallback(long kind, long argument) {
        if (isSocketSerializerOwner()) {
            if (kind == SOCKET_SEND_START) driveWriteOnce();
            else if (kind == SOCKET_WRITE_COMPLETE
                    && WRITE_EVENT.compareAndSet(this, argument, 0L))
                drainWriteCompletion(argument);
            return true;
        }
        for (;;) {
            final int pending = (int) SOCKET_PENDING.getVolatile(this);
            if (pending >= SOCKET_REJECT_AT) return false;
            if (SOCKET_PENDING.compareAndSet(this, pending, pending + 1)) break;
        }
        final long ticket = (long) SOCKET_TICKET.getAndAdd(this, 1L);
        final int slot = (int) ticket & SOCKET_MASK;
        SOCKET_ARGUMENT_SLOT.setRelease(_socketArguments, slot, argument);
        SOCKET_CALLBACK_SLOT.setRelease(_socketCallbacks, slot, kind);
        drainSocketCallbacks();
        return true;
    }

    /** First contender becomes the inline drainer; other callers return. */
    private void drainSocketCallbacks() {
        if (!SOCKET_DRAINING.compareAndSet(this, 0, 1)) return;
        for (;;) {
            _socketOwner = Thread.currentThread();
            while ((int) SOCKET_PENDING.getVolatile(this) != 0) {
                final int slot = (int) _socketHead & SOCKET_MASK;
                final long kind = (long) SOCKET_CALLBACK_SLOT.getAcquire(_socketCallbacks, slot);
                if (kind == 0L) {
                    break;
                }
                final long argument = (long) SOCKET_ARGUMENT_SLOT.getAcquire(_socketArguments, slot);
                final CIOBufferPool.Lease sendLease = kind == SOCKET_SEND_ENQUEUE
                        ? _socketSendArguments[slot] : null;
                _socketSendArguments[slot] = null;
                SOCKET_ARGUMENT_SLOT.setRelease(_socketArguments, slot, 0L);
                SOCKET_CALLBACK_SLOT.setRelease(_socketCallbacks, slot, 0L);
                ++_socketHead;
                try {
                    if (kind == SOCKET_WRITE_COMPLETE) {
                        if (WRITE_EVENT.compareAndSet(this, argument, 0L))
                            drainWriteCompletion(argument);
                    } else if (kind == SOCKET_SEND_START) {
                        driveWriteOnce();
                    } else if (kind == SOCKET_SEND_ENQUEUE && sendLease != null) {
                        acceptStagedSend(sendLease);
                    } else if (kind != SOCKET_CANCELLED) {
                        close();
                    }
                } catch (Throwable failure) {
                    close();
                } finally {
                    SOCKET_PENDING.getAndAdd(this, -1);
                }
            }
            
            if (_closed != 0 && (int) SOCKET_PENDING.getVolatile(this) == 0) {
                final long stranded = (long) WRITE_EVENT.getAndSet(this, 0L);
                if (stranded != 0L) {
                    try { drainWriteCompletion(stranded); }
                    catch (Throwable ignored) { close(); }
                }
                try { driveWriteOnce(); }
                catch (Throwable ignored) { close(); }
            }
            
            final int nextSlot = (int) _socketHead & SOCKET_MASK;
            _socketOwner = null;
            SOCKET_DRAINING.setRelease(this, 0);
            
            if ((int) SOCKET_PENDING.getVolatile(this) == 0
                    || (long) SOCKET_CALLBACK_SLOT.getAcquire(_socketCallbacks, nextSlot) == 0L
                    || !SOCKET_DRAINING.compareAndSet(this, 0, 1)) break;
        }
        notifyClosedWhenReleased();
    }

    /** SEND registration and next-WRITE selection, executed by the serializer. */
    private void kickWrite() {
        if (!serializeSocketCallback(SOCKET_SEND_START, 0L)) close();
    }

    private void driveWriteOnce() {
        CIOBufferPool.Lease current = null;
        boolean gather = false;
        boolean cancelled = false;
        _stateLock.lock(); try {
            if (_writing != null && !_writing._ioPending) {
                current = _writing;
                cancelled = (_closed != 0);
                if (!cancelled && _gatherCount == 0 && _queued != 0) {
                    if (_gatherFrames == null) {
                        _gatherFrames = new CIOBufferPool.Lease[GATHER_MAX_FRAMES];
                        _gatherBuffers = new ByteBuffer[GATHER_MAX_FRAMES];
                    }
                    int totalBytes = current.wireLength();
                    _gatherFrames[0] = current;
                    _gatherCount = 1;
                    while (_queued != 0 && _gatherCount < GATHER_MAX_FRAMES) {
                        final CIOBufferPool.Lease candidate = _pending[_head];
                        if (totalBytes + candidate.wireLength() > CIOBufferPool.SMALL_SEND_BYTES)
                            break;
                        _pending[_head] = null;
                        if (++_head == _pending.length) _head = 0;
                        --_queued;
                        _gatherFrames[_gatherCount++] = candidate;
                        totalBytes += candidate.wireLength();
                    }
                    if (_gatherCount == 1) {
                        _gatherFrames[0] = null;
                        _gatherCount = 0;
                    }
                }
                gather = _gatherCount > 1;
                current._ioPending = true;
            }
        } finally { _stateLock.unlock(); }
        if (current != null) {
            if (cancelled) {
                if (gather) completeGather(false);
                else completeWrite(current, false);
            } else if (gather) postGather();
            else postWrite(current);
        }
    }

    /** Ordered packet encryption + async I/O scatter/gather WRITE, no coalescing copy. */
    private void postGather() {
        if (_closed != 0) {
            completeGather(false);
            return;
        }
        try {
            for (int i = 0; i < _gatherCount; i++) {
                final CIOBufferPool.Lease lease = _gatherFrames[i];
                final ByteBuffer bytes = lease.buffer();
                if (!lease._writePrepared) {
                    if (lease._packedFrames ? !preparePackedEncryption(lease)
                            : !encrypt(lease.writer(),
                                    CIOBufferPool.HEADER_BYTES,
                                    lease.wireLength() - CIOBufferPool.HEADER_BYTES)) {
                        completeGather(false);
                        return;
                    }
                    bytes.limit(lease.wireLength());
                    bytes.position(0);
                    lease._writePrepared = true;

                }
                _gatherBuffers[i] = bytes;
            }

            _diagnosticSubmitThread = Thread.currentThread();
            _socketPosting = true;
            try {
                _channel.write(_gatherBuffers, 0, _gatherCount, 0L,
                        TimeUnit.MILLISECONDS, this, GATHER_COMPLETION);
            } finally {
                _socketPosting = false;
            }
        } catch (Throwable error) {
            completeGather(false);
        }
    }

    private void completeGather(boolean success) {

        CIOBufferPool.Lease next = null;
        boolean resumeInbound = false;
        _stateLock.lock(); try {
            if (_gatherCount <= 1 || _writing != _gatherFrames[0]) {
                close();
                return;
            }
            int releasedBytes = 0;
            int releasedFrames = 0;
            for (int i = 0; i < _gatherCount; i++) {
                final CIOBufferPool.Lease frame = _gatherFrames[i];
                releasedBytes += frame.wireLength();
                releasedFrames += frame._frameCount;
                _pool.release(frame);
                _gatherFrames[i] = null;
                _gatherBuffers[i] = null;
            }
            // READ resumes once, after all gather frames have been retired.
            resumeInbound = bytesReleased(releasedBytes, releasedFrames);
            _gatherCount = 0;
            _writing = null;
            if (success && _closed == 0 && _queued != 0) {
                next = _pending[_head];
                _pending[_head] = null;
                if (++_head == _pending.length) _head = 0;
                --_queued;
                _writing = next;
                _zeroWriteCompletions = 0;
            }
        } finally { _stateLock.unlock(); }
        if (!success) close();
        else if (next != null) kickWrite();
        if (resumeInbound && _closed == 0) kickRead();
        if (success && _closed == 0) notifySendSlotAvailable();
        notifyClosedWhenReleased();
    }

    private void notifySendSlotAvailable() {
        try { onSendProgress(); } catch (Throwable failure) { close(); }
    }

    private void postWrite(CIOBufferPool.Lease lease) {
        if (_closed != 0) {
            lease._ioPending = false;
            completeWrite(lease, false);
            return;
        }
        try {
            final ByteBuffer bytes = lease.buffer();
            if (!lease._writePrepared) {
                final WriteBuffer writer = lease.writer();
                if (lease._packedFrames ? !preparePackedEncryption(lease)
                        : !encrypt(writer,
                                CIOBufferPool.HEADER_BYTES,
                                lease.wireLength() - CIOBufferPool.HEADER_BYTES)) {
                    lease._ioPending = false;
                    completeWrite(lease, false);
                    return;
                }
                bytes.limit(lease.wireLength());
                bytes.position(0);
                lease._writePrepared = true;

            }

            _diagnosticSubmitThread = Thread.currentThread();
            _socketPosting = true;
            try {
                _channel.write(bytes, this, WRITE_COMPLETION);
            } finally {
                _socketPosting = false;
            }
        } catch (Throwable error) {
            lease._ioPending = false;
            completeWrite(lease, false);
        }
    }

    private void completeWrite(CIOBufferPool.Lease lease, boolean success) {

        CIOBufferPool.Lease next = null;
        boolean resumeInbound;
        _stateLock.lock(); try {
            if (_writing != lease) {
                close();
                return;
            }
            resumeInbound = bytesReleased(lease.wireLength(), lease._frameCount);
            _pool.release(lease);
            _writing = null;
            if (success && _closed == 0 && _queued != 0) {
                next = _pending[_head];
                _pending[_head] = null;
                if (++_head == _pending.length) _head = 0;
                --_queued;
                _writing = next;
                _zeroWriteCompletions = 0;
            }
        } finally { _stateLock.unlock(); }
        if (!success) {
            close();
        } else if (next != null) {
            kickWrite();
        }
        if (resumeInbound && _closed == 0) kickRead();
        if (success && _closed == 0) notifySendSlotAvailable();
        notifyClosedWhenReleased();
    }

    /** No allocation; useful for admission diagnostics and slow-peer checks. */
    public int pendingSendBytes() {
        _stateLock.lock();
        try { return _outstandingWireBytes + _reservedWireBytes; }
        finally { _stateLock.unlock(); }
    }

    /** True when the connection's outbound backlog allows further socket reads. */
    public boolean isSendReadWritable() { return !_sendReadPaused; }

    /** Snapshot only; includes the active WRITE, queued frames and reserved producers. */
    public int pendingSendFrames() {
        _stateLock.lock();
        try { return _queued + _reservedDirect + _stagedSends
                + (_writing == null ? 0 : _gatherCount > 0 ? _gatherCount : 1); }
        finally { _stateLock.unlock(); }
    }

    public boolean isWriteIdle() {
        _stateLock.lock();
        try { return _queued == 0 && _reservedDirect == 0 && _stagedSends == 0 && _writing == null; }
        finally { _stateLock.unlock(); }
    }

    public boolean isOpen() {
        return _closed == 0 && _channel.isOpen();
    }

    /** Transport close callback is emitted after every in-flight I/O lease is released. */
    public boolean isCloseComplete() {
        return (_closeNotified != 0);
    }

    private void notifyClosedWhenReleased() {
        if (_closed == 0 || !_readReleased || _socketDraining != 0 || _socketPending != 0
                || _writeEvent != 0L) return;
        _stateLock.lock(); try {
            if (_writing != null || _queued != 0 || _reservedDirect != 0 || _stagedSends != 0) return;
        } finally { _stateLock.unlock(); }
        if (!CLOSE_NOTIFIED.compareAndSet(this, 0, 1)) return;
        clearCipher();
        if (_closedCallback != null) {
            try {
                _closedCallback.onClosed(this);
            } catch (Throwable ignored) {
                // Never retain a closed socket when a lifecycle observer fails.
            }
        }
    }

    @Override
    public void close() {
        if (!CLOSED.compareAndSet(this, 0, 1)) return;
        ON_DRAINED.setVolatile(this, null);
        try { _channel.close(); } catch (IOException ignored) {}
        _stateLock.lock(); try {
            int releasedBytes = 0;
            int releasedFrames = 0;
            while (_queued != 0) {
                final CIOBufferPool.Lease lease = _pending[_head];
                _pending[_head] = null;
                if (++_head == _pending.length) _head = 0;
                --_queued;
                releasedBytes += lease.wireLength();
                releasedFrames += lease._frameCount;
                _pool.release(lease);
            }
            if (releasedFrames != 0) bytesReleased(releasedBytes, releasedFrames);
        } finally { _stateLock.unlock(); }
        _stateLock.lock(); try {
            if (_readActive == 0) releaseReadWhenIdle();
        } finally { _stateLock.unlock(); }
        finishReadIfClosed();
        if (!_stateLock.isHeldByCurrentThread()) kickWrite();
        notifyClosedWhenReleased();
    }
}
