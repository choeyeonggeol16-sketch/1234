package l1j.server.server;

import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.Callable;
import java.util.concurrent.RejectedExecutionException;
import java.util.concurrent.RejectedExecutionHandler;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.ScheduledThreadPoolExecutor;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.logging.Logger;

import l1j.server.server.model.network.utill.PacketThreadFactory;
import l1j.server.server.utils.ThreadConfig;

public class ThreadPool {
	private static final Logger _log = Logger.getLogger(ThreadPool.class.getName());
	private static volatile ThreadPool _instance;

	// 스레드풀 상수 도입
	private static final long ONE_HUNDRED_YEARS_MS = 3155695200000L;
	private static final long MIN_DELAY_MS = 0L;
	private static final int INSTANT_POOL_KEEP_ALIVE_MINUTES = 1;
	private static final int INSTANT_QUEUE_CAPACITY = 65536;
	// Bound the number of retained scheduled tasks, including long-delay and
	// recurring tasks. These caps are admission limits, not time-wheel slots.
	private static final int SCHEDULED_PENDING_CAPACITY = 131072;
	private static final int HIGH_PRIORITY_PENDING_CAPACITY = 32768;

	private ScheduledThreadPoolExecutor _scheduler;
	private ThreadPoolExecutor _instantPool;
	private ScheduledThreadPoolExecutor _highPriorityScheduler;

	public static ThreadPool getInstance() {
		if (_instance == null) {
			synchronized (ThreadPool.class) {
				if (_instance == null) {
					_instance = new ThreadPool();
				}
			}
		}
		return _instance;
	}

	private ThreadPool() {
		_log.fine("ThreadPool: Initializing advanced thread pools.");
		
		ThreadConfig.load();

		int scheduledSize = ThreadConfig.SCHEDULED_THREAD_POOL_SIZE;
		int instantSize = ThreadConfig.INSTANT_THREAD_POOL_SIZE;
		int highPrioritySize = ThreadConfig.HIGH_PRIORITY_SCHEDULED_THREAD_POOL_SIZE;

		// 고우선순위 스케줄러 풀
		_highPriorityScheduler = new BoundedScheduledExecutor(
			highPrioritySize, HIGH_PRIORITY_PENDING_CAPACITY,
			new PacketThreadFactory("HighPriority Thread", Thread.MAX_PRIORITY),
			// A rejected deadline must never run on the caller (CIO/owner).
			// Fail admission instead of returning a Future that never executes.
			new ThreadPoolExecutor.AbortPolicy()
		);
		// Cancelled long-delay tasks must not retain their captured game objects.
		_highPriorityScheduler.setRemoveOnCancelPolicy(true);

		// 메인 스케줄러 풀 (취소된 작업 자동 정리 및 거부 정책 적용)
		_scheduler = new BoundedScheduledExecutor(
			scheduledSize, SCHEDULED_PENDING_CAPACITY,
			new PacketThreadFactory("ScheduledThread", Thread.NORM_PRIORITY),
			new ThreadPoolExecutor.AbortPolicy()
		);
		_scheduler.setRemoveOnCancelPolicy(true);
		_scheduler.prestartAllCoreThreads();

		// 즉시 처리(인스턴트) 풀 (LinkedBlockingQueue 기반 튜닝)
		_instantPool = new ThreadPoolExecutor(
			instantSize, 
			Math.max(1, instantSize), 
			INSTANT_POOL_KEEP_ALIVE_MINUTES, 
			TimeUnit.MINUTES, 
			new LinkedBlockingQueue<>(INSTANT_QUEUE_CAPACITY), 
			new PacketThreadFactory("InstantThread", Thread.NORM_PRIORITY)
		);
		// Never run arbitrary game/JDBC work on the submitting I/O/owner thread.
		// A rejected submission must be observable by its caller, including shutdown.
		_instantPool.setRejectedExecutionHandler(new ThreadPoolExecutor.AbortPolicy());
		_instantPool.prestartAllCoreThreads();

		// Both scheduled pools remove cancelled futures immediately; do not
		// scan the entire delayed queue once per minute just to purge it.
	}

	/**
	 * Bound retained delayed work without wrapping ScheduledFutureTask. Keeping
	 * the JDK task gives removeOnCancelPolicy its O(log N) heap-index removal
	 * instead of an O(N) search through the delayed queue.
	 *
	 * All external schedule entry points share this admission monitor. Active
	 * periodic tasks may requeue while producers fill the queue, so the hard
	 * upper bound is queueLimit + core thread count (no unbounded growth).
	 */
	private static final class BoundedScheduledExecutor extends ScheduledThreadPoolExecutor {
		private final int queueLimit;

		BoundedScheduledExecutor(int threads, int queueLimit,
				java.util.concurrent.ThreadFactory factory, RejectedExecutionHandler rejection) {
			super(threads, factory, rejection);
			this.queueLimit = queueLimit;
		}

		private void checkAdmission() {
			if (isShutdown() || getQueue().size() >= queueLimit)
				throw new RejectedExecutionException("Scheduled queue is closed or full: " + queueLimit);
		}

		@Override
		public synchronized ScheduledFuture<?> schedule(Runnable task, long delay, TimeUnit unit) {
			checkAdmission();
			return super.schedule(task, delay, unit);
		}

		@Override
		public synchronized <V> ScheduledFuture<V> schedule(Callable<V> task, long delay, TimeUnit unit) {
			checkAdmission();
			return super.schedule(task, delay, unit);
		}

		@Override
		public synchronized ScheduledFuture<?> scheduleAtFixedRate(
				Runnable task, long initialDelay, long period, TimeUnit unit) {
			checkAdmission();
			return super.scheduleAtFixedRate(task, initialDelay, period, unit);
		}

		@Override
		public synchronized ScheduledFuture<?> scheduleWithFixedDelay(
				Runnable task, long initialDelay, long delay, TimeUnit unit) {
			checkAdmission();
			return super.scheduleWithFixedDelay(task, initialDelay, delay, unit);
		}
	}

	/**
	 * 취소된 태스크들을 메모리에서 즉시 해제합니다.
	 */
	public static void purge() {
		if (_instance != null) {
			try {
				if (_instance._scheduler != null) _instance._scheduler.purge();
				if (_instance._instantPool != null) _instance._instantPool.purge();
				if (_instance._highPriorityScheduler != null) _instance._highPriorityScheduler.purge();
			} catch (Exception e) {
				_log.log(Level.WARNING, "ThreadPool purge error", e);
			}
		}
	}

	public void execute(Runnable r) {
		if (r == null) return;
		// AbortPolicy propagates saturation/shutdown to the caller. Do NOT retry
		// the task inline: doing so stalls CIO/game owners and hides admission loss.
		_instantPool.execute(new RunnableWrapper(r));
	}

	public void execute(Thread t) {
		if (t != null) {
			t.start();
		}
	}

	public ScheduledFuture<?> schedule(Runnable r, long delay) {
		if (r == null) return null;
		try {
			return _scheduler.schedule(new RunnableWrapper(r), validateDelay(delay), TimeUnit.MILLISECONDS);
		} catch (Exception e) {
			_log.warning("ThreadPool: Failed to schedule task " + r.getClass().getSimpleName() + ": " + e.getMessage());
			return null;
		}
	}

	public ScheduledFuture<?> scheduleAtFixedRate(Runnable r, long initialDelay, long period) {
		if (r == null) return null;
		try {
			return _scheduler.scheduleAtFixedRate(new RunnableWrapper(r), validateDelay(initialDelay), validateDelay(period), TimeUnit.MILLISECONDS);
		} catch (Exception e) {
			_log.warning("ThreadPool: Failed to schedule recurring task " + r.getClass().getSimpleName() + ": " + e.getMessage());
			return null;
		}
	}

	/** A single recurring task keeps its deadline without resubmitting on every tick. */
	public ScheduledFuture<?> scheduleWithFixedDelay(Runnable r, long initialDelay, long delay) {
		if (r == null) return null;
		try {
			return _scheduler.scheduleWithFixedDelay(new RunnableWrapper(r),
					validateDelay(initialDelay), Math.max(1L, validateDelay(delay)), TimeUnit.MILLISECONDS);
		} catch (Exception e) {
			_log.log(Level.WARNING, "ThreadPool recurring delayed task admission failed", e);
			return null;
		}
	}

	public ScheduledFuture<?> scheduleAtFixedRateLong(Runnable r, long initialDelay, long period) {
		return scheduleAtFixedRate(r, initialDelay, period);
	}
	
	public ScheduledFuture<?> schedulePriorityTaskAtFixedRate(Runnable r, long initialDelay, long period) {
		if (r == null) return null;
		if (_highPriorityScheduler == null) {
			return scheduleAtFixedRate(r, initialDelay, period);
		}
		try {
			return _highPriorityScheduler.scheduleAtFixedRate(new RunnableWrapper(r), validateDelay(initialDelay), validateDelay(period), TimeUnit.MILLISECONDS);
		} catch (Exception e) {
			_log.warning("ThreadPool: Failed to schedule high priority task " + r.getClass().getSimpleName() + ": " + e.getMessage());
			return null;
		}
	}

	private long validateDelay(long delay) {
		if (delay < MIN_DELAY_MS) {
			return MIN_DELAY_MS;
		}
		if (delay > ONE_HUNDRED_YEARS_MS) {
			return ONE_HUNDRED_YEARS_MS;
		}
		return delay;
	}


	/**
	 * 태스크 실행 중 발생하는 예외를 안전하게 잡아주는 래퍼
	 */
	private static class RunnableWrapper implements Runnable {
		private final Runnable _wrappedRunnable;

		public RunnableWrapper(Runnable runnable) {
			_wrappedRunnable = runnable;
		}

		@Override
		public void run() {
			try {
				_wrappedRunnable.run();
			} catch (Throwable t) {
				final Thread currentThread = Thread.currentThread();
				final Thread.UncaughtExceptionHandler exceptionHandler = currentThread.getUncaughtExceptionHandler();
				if (exceptionHandler != null) {
					exceptionHandler.uncaughtException(currentThread, t);
				} else {
					_log.log(Level.SEVERE, "Uncaught exception in ThreadPool task", t);
				}
			}
		}
	}
	
	/**
	 * 서버 종료 시 모든 스레드 풀을 안전하게 종료합니다.
	 */
	public void shutdown() {
		if (_instance != null) {
			try {
			//	_log.info("ThreadPool: Shutting down all thread pools.");
				if (_instance._scheduler != null) {
					_instance._scheduler.shutdownNow();
				}
				if (_instance._instantPool != null) {
					_instance._instantPool.shutdownNow();
				}
				if (_instance._highPriorityScheduler != null) {
					_instance._highPriorityScheduler.shutdownNow();
				}
			} catch (Throwable t) {
				_log.log(Level.WARNING, "ThreadPool: Exception occurred during shutdown", t);
			}
		}
	}

}