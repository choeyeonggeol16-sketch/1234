package l1j.server.server.Controller;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Calendar;
import java.util.concurrent.RejectedExecutionException;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.logging.Level;
import java.util.logging.Logger;
import l1j.server.server.model.gametime.BaseTime;
import l1j.server.server.model.gametime.RealTimeClock;
import l1j.server.server.model.gametime.TimeListener;
import l1j.server.server.ThreadPool;
import l1j.server.server.IdFactory;
import l1j.server.server.datatables.EventNpcSpawnTable;
import l1j.server.server.datatables.NpcTable;
import l1j.server.server.model.Instance.L1NpcInstance;
import l1j.server.server.model.Instance.L1PcInstance;
import l1j.server.server.model.L1Location;
import l1j.server.server.model.L1World;
import l1j.server.server.model.Light;
import l1j.server.server.model.map.L1Map;
import l1j.server.server.model.network.core.sc.packet.SC_PacketBox;
import l1j.server.server.model.network.core.sc.packet.SC_SystemMessage;
import l1j.server.server.templates.L1EventNpcSpawn;

public class EventNpcSpawnCotroller implements Runnable, TimeListener {
    private static final Logger LOG = Logger.getLogger(EventNpcSpawnCotroller.class.getName());
    public static final int SLEEP_TIME = 60000;
    private static volatile EventNpcSpawnCotroller instance;

    // These entries are touched only by one coalesced instant-pool task.
    // They replace one-shot end timers that could be silently rejected.
    private static final class ActiveSpawn {
        final L1EventNpcSpawn config;
        final long endAt;
        ActiveSpawn(L1EventNpcSpawn config, long endAt) {
            this.config = config;
            this.endAt = endAt;
        }
    }
    // Mutated exclusively on the coalesced controller task; CIO owners read an
    // immutable volatile image rather than racing ArrayList growth/shrink.
    private final List<ActiveSpawn> active = new ArrayList<>();
    private volatile ActiveSpawn[] activeSnapshot = new ActiveSpawn[0];

    private void publishActive() {
        activeSnapshot = active.toArray(new ActiveSpawn[0]);
    }
    private final AtomicBoolean inFlight = new AtomicBoolean();
    private volatile boolean started;
    private volatile int epoch;
    private volatile long completedMinute = Long.MIN_VALUE;
    private volatile boolean hasActive;

    public static EventNpcSpawnCotroller getInstance() {
        EventNpcSpawnCotroller current = instance;
        if (current == null) {
            synchronized (EventNpcSpawnCotroller.class) {
                current = instance;
                if (current == null) instance = current = new EventNpcSpawnCotroller();
            }
        }
        return current;
    }

    public synchronized void start() {
        if (started) return;
        final RealTimeClock clock = RealTimeClock.getInstance();
        if (clock == null) throw new IllegalStateException("RealTimeClock not initialized");
        ++epoch;
        started = true;
        clock.addListener(this, Calendar.SECOND);
        onSecondChanged(clock.getRealTime());
    }

    public synchronized void stop() {
        if (!started) return;
        started = false;
        ++epoch;
        RealTimeClock.getInstance().removeListener(this, Calendar.SECOND);
    }

    @Override public void onSecondChanged(BaseTime time) {
        if (!started) return;
        if (!hasActive && completedMinute == System.currentTimeMillis() / SLEEP_TIME) return;
        if (!inFlight.compareAndSet(false, true)) return;
        final int generation = epoch;
        try {
            ThreadPool.getInstance().execute(() -> {
                try {
                    if (started && epoch == generation) run();
                } finally {
                    inFlight.set(false);
                }
            });
        } catch (RejectedExecutionException rejected) {
            inFlight.set(false);
            // Nothing was advanced; the next clock second retries admission.
            LOG.log(Level.WARNING, "Event NPC controller admission rejected", rejected);
        }
    }

    @Override public void onMonthChanged(BaseTime time) { }
    @Override public void onDayChanged(BaseTime time) { }
    @Override public void onHourChanged(BaseTime time) { }
    @Override public void onMinuteChanged(BaseTime time) { }

    private boolean spawn_check() {
        final List<L1EventNpcSpawn> list = EventNpcSpawnTable.getInstance().getList();
        if (list == null || list.isEmpty()) return true;
        boolean complete = true;
        final long now = System.currentTimeMillis();
        final Date date = new Date(now);
        final int hour = date.getHours();
        final int minute = date.getMinutes();
        for (L1EventNpcSpawn spawn : list) {
            if (spawn == null || !spawn.isSpawnTime(hour, minute, now) || isSpawnActive(spawn)) continue;
            try {
                final int[] loc = spawn.getSpawnLoc();
                if (spawnTracked(spawn, loc[0], loc[1], (short) loc[2], spawn.getNpcId(),
                        0, spawn.getKeepTime() * 1000, spawn.getMent())) {
                    // Preserve active state until end processing succeeds.
                    active.add(new ActiveSpawn(spawn, now + (long) spawn.getKeepTime() * 1000L));
                    publishActive();
                    hasActive = true;
                } else {
                    complete = false;
                }
            } catch (Exception failure) {
                complete = false;
                LOG.log(Level.SEVERE, "Event NPC spawn failed", failure);
            }
        }
        return complete;
    }

    private void expireEvents(long now) {
        for (int i = 0; i < active.size();) {
            final ActiveSpawn item = active.get(i);
            if (item.endAt > now) {
                i++;
                continue;
            }
            try {
                eventEnd(item.config);
                active.remove(i);
                publishActive();
            } catch (Exception failure) {
                // Keep the entry; the following second retries on the same owner.
                LOG.log(Level.SEVERE, "Event NPC cleanup failed", failure);
                i++;
            }
        }
        hasActive = !active.isEmpty();
    }

    // Preserve the original public API for callers outside this controller.
    public static boolean isSpawn(L1EventNpcSpawn spawn) {
        final EventNpcSpawnCotroller controller = instance;
        return controller != null && controller.isSpawnActive(spawn);
    }

    private boolean isSpawnActive(L1EventNpcSpawn spawn) {
        final ActiveSpawn[] entries = activeSnapshot;
        for (int i = 0; i < entries.length; ++i) {
            if (entries[i].config == spawn) return true;
        }
        return false;
    }

    @Override
    public void run() {
        if (!started) return;
        try {
            final long now = System.currentTimeMillis();
            expireEvents(now);
            final long minute = now / SLEEP_TIME;
            if (completedMinute != minute) {
                if (spawn_check()) completedMinute = minute;
            }
        } catch (Throwable failure) {
            LOG.log(Level.SEVERE, "Event NPC controller tick failed", failure);
        }
    }

    public static void npc_spawn(L1EventNpcSpawn b, int x, int y, short map, int npcId,
                                 int randomRange, int timeMillisToDelete, String ment) {
        spawnTracked(b, x, y, map, npcId, randomRange, timeMillisToDelete, ment);
    }

	private static boolean spawnTracked(L1EventNpcSpawn b, int x, int y, short map, int npcId, int randomRange, int timeMillisToDelete, String ment)
	{
        boolean enteredWorld = false;
		try
		{
			L1NpcInstance npc = NpcTable.getInstance().newNpcInstance(npcId);
			npc.setId(IdFactory.getInstance().nextId());
			npc.setMap(map);
			if (randomRange == 0)
			{
				npc.getLocation().set(x, y, map);
				npc.getLocation().forward(5);
			}
			else
			{
				int tryCount = 0;
				do
				{
					tryCount++;
					npc.setX(x + (int)(Math.random() * randomRange) - (int)(Math.random() * randomRange));
					npc.setY(y + (int)(Math.random() * randomRange) - (int)(Math.random() * randomRange));
					if ((npc.getMap().isInMap(npc.getLocation())) && (npc.getMap().isPassable(npc.getLocation()))) {
						break;
					}
					Thread.sleep(1L);
				} while (tryCount < 50);
				if (tryCount >= 50)
				{
					npc.getLocation().set(x, y, map);
					npc.getLocation().forward(5);
				}
			}
			npc.setHomeX(npc.getX());
			npc.setHomeY(npc.getY());
			npc.setHeading(5);

			L1World.getInstance().storeAndEnterWorld(npc);
            enteredWorld = true;

			SC_SystemMessage.broadcast(ment);
			SC_PacketBox.broadcastGreen(ment);

			npc.getLight().turnOnOffLight();
			npc.startChat(0);
			if (0 < timeMillisToDelete) {
				npc.startTimedDelete(timeMillisToDelete);
			}
            return true;
		}
		catch (Exception e)
		{
            LOG.log(Level.SEVERE, "Event NPC spawn operation failed", e);
            // After entering the world it is unsafe to spawn a duplicate.
            return enteredWorld;
		}
	}

	private static void eventEnd(L1EventNpcSpawn b)
	{
		if (b == null) {
			return;
		}
		for (int i = 0; i < b.getExitMap().length; i++) {
			for (L1PcInstance pc : L1World.getInstance().getAllPlayers()) {
				if (pc != null) {
					if (pc.getMapId() == b.getExitMap()[i])
					{
						pc.start_teleport(b.getExitLoc()[0], b.getExitLoc()[1], b.getExitLoc()[2], 5, 169, true, false);
						SC_SystemMessage.send(pc, b.getEventName() + " 가(이) 종료되었습니다.");
					}
				}
			}
		}
	}
}
