package l1j.server.MJCTSystem;

import l1j.server.server.model.network.core.sc.packet.SC_CTPacket;
/** 
 * MJCTCharInfo
 * MJSoft Character TradeSystem - Object
 * made by mjsoft, 2016.
 **/
public class MJCTObject {
	public int			marbleId;
	public int			charId;
	public String		name;
	public byte[] invPck;
	public byte[] spPck;
	public SC_CTPacket.Data infoPck;
	public int value1;
	public int dex;
	public int con;
	public int wis;
	public int ints;
	public int cha;
	public int classn;
	public int ele;
	public int hp;
	public int mp;
	public int level;
	
	
	public String		clan;
	
	
	
	public void dispose(){
		
		
		/*
		 * if(infoPck != null) infoPck.clear();
		 */
	}
}
