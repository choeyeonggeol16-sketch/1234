package l1j.server.MJINNSystem;

import l1j.server.server.model.network.core.sc.packet.SC_Paralysis;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ScheduledFuture;

import l1j.server.MJTemplate.ObServer.MJAbstractCopyMapObserver;
import l1j.server.MJTemplate.ObServer.MJCopyMapObservable;
import l1j.server.server.ThreadPool;
import l1j.server.server.model.Instance.L1ItemInstance;
import l1j.server.server.model.Instance.L1PcInstance;
import l1j.server.server.model.character.skill.L1SkillId;
import l1j.server.server.model.network.core.sc.packet.SC_SystemMessage;

public class MJINNRoom extends MJAbstractCopyMapObserver implements Runnable{
	private static ConcurrentHashMap<Integer, MJINNRoom> _keys = new ConcurrentHashMap<Integer, MJINNRoom>(256);
	public static MJINNRoom create(MJINNMapInfo mapInfo, Integer[] keyIds){
		MJINNRoom room 	= new MJINNRoom();
		room._mapInfo 	= mapInfo;
		room._usageCount = keyIds.length;
		room._keyIds	= keyIds;
		MJCopyMapObservable.getInstance().register(mapInfo.mapId, room);
		for(Integer i : keyIds)
			_keys.put(i, room);
		room.on();
		return room;
	}
	
	public static boolean input(L1ItemInstance item, L1PcInstance pc){
		MJINNRoom room = _keys.get(item.getId());
		if(room != null){
			room.in(pc);
			return true;
		}
		pc.start_teleport(pc.getX(), pc.getY(), pc.getMapId(), pc.getHeading(), 169, true, false, false);
		return false;
	}
	
	public static boolean input(L1ItemInstance[] items, L1PcInstance pc){
		for(L1ItemInstance item : items){
			MJINNRoom room = _keys.get(item.getId());
			
			if(room == null)
				continue;
			
			room.in(pc);
			return true;
		}
		return false;
	}
	
	public static boolean input(L1PcInstance pc, int innId){
		L1ItemInstance[] items = pc.getInventory().findItemsId(MJINNHelper.INN_KEYID);
		
		if(items == null || items.length <= 0)
			return false;
		
		for(L1ItemInstance item : items){
			MJINNRoom room = _keys.get(item.getId());
			if(room == null)
				continue;
			
			if(room._mapInfo.innId == innId){
				room.in(pc);
				return true;
			}
		}
		return false;
		
	}
	
	public static boolean input(L1PcInstance pc){
		L1ItemInstance[] items = pc.getInventory().findItemsId(MJINNHelper.INN_KEYID);
		if(items == null || items.length <= 0)
			return false;
		return input(items, pc);
	}
	
	public static void remove(L1ItemInstance item){
		MJINNRoom room = _keys.remove(item.getId());
		if(room == null)
			return;
		
		if(--room._usageCount <= 0)
			room.off();
	}
	
	public static void remove(L1ItemInstance[] items){
		for(L1ItemInstance item : items)
			remove(item);
	}
	
	private MJINNMapInfo 		_mapInfo;
	private int							_usageCount;
	private Integer[] 				_keyIds;
	private ScheduledFuture<?>	_future;
	
	private void on(){
		_future = ThreadPool.getInstance().schedule(this, MJINNHelper.RENTAL_MINUTE * 60L * 1000L);
	}
	
	private void off(){
		if(_future != null){
			try{ _future.cancel(true); }catch(Exception e){}
			_future = null;
			notifyObservable();
		}
	}
	
	@Override
	public void run() {
		if(_isDispose)
			return;
		_future = null;
		notifyObservable();
	}
	
	@Override
	public void notifyObservable(){
		for(Integer i : _keyIds)
			_keys.remove(i);
		_mapInfo.usageCount.decrementAndGet();
		super.notifyObservable();
	}
	
	private void in(L1PcInstance pc){
		if (pc.hasSkillEffect(L1SkillId.쉐도우제약)) {
			SC_Paralysis.send(pc, SC_Paralysis.TYPE_TELEPORT_UNLOCK, false);
			return;
		}
		
		if (pc.hasSkillEffect(L1SkillId.이터디스)) {
			SC_Paralysis.send(pc, SC_Paralysis.TYPE_TELEPORT_UNLOCK, false);
			return;
		}
		if (pc.getMapId() >= 1708 && pc.getMapId() <= 1710) {
			SC_Paralysis.send(pc, SC_Paralysis.TYPE_TELEPORT_UNLOCK, false);
			SC_SystemMessage.send(pc, "여기서는 사용할 수 없습니다.");
			return;
		}
		if (_mapInfo.x == 32742){ //해적섬 여관 텔 방지
			SC_Paralysis.send(pc, SC_Paralysis.TYPE_TELEPORT_UNLOCK, false);
			return;
		}
		pc.start_teleport(_mapInfo.x, _mapInfo.y, _copyMapId, pc.getHeading(), 169, false, false, false);
	}
}
