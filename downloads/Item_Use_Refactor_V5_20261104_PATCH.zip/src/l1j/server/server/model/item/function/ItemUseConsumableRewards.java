package l1j.server.server.model.item.function;
import l1j.server.server.model.network.core.sc.packet.SC_SkillSound;
import static l1j.server.server.model.character.skill.L1SkillId.STATUS_HOLY_MITHRIL_POWDER;
import static l1j.server.server.model.character.skill.L1SkillId.STATUS_HOLY_WATER;
import static l1j.server.server.model.character.skill.L1SkillId.STATUS_HOLY_WATER_OF_EVA;
import l1j.server.Config;
import l1j.server.server.datatables.ClanTable;
import l1j.server.server.model.L1Clan;
import l1j.server.server.model.L1World;
import l1j.server.server.model.Instance.L1ItemInstance;
import l1j.server.server.model.Instance.L1NpcInstance;
import l1j.server.server.model.Instance.L1PcInstance;
import l1j.server.server.model.character.auto.AutoSystemHandler;
import l1j.server.server.model.character.skill.L1SkillId;
import l1j.server.server.model.network.core.sc.packet.SC_AuctionSystemBoard;
import l1j.server.server.model.network.core.sc.packet.SC_Board;
import l1j.server.server.model.network.core.sc.packet.SC_Boarditem;
import l1j.server.server.model.network.core.sc.packet.SC_ChatPacket;
import l1j.server.server.model.network.core.sc.packet.SC_NPCTalkReturn;
import l1j.server.server.model.network.core.sc.packet.SC_PacketBox;
import l1j.server.server.model.network.core.sc.packet.SC_ServerMessage;
import l1j.server.server.model.network.core.sc.packet.SC_SystemMessage;

final class ItemUseConsumableRewards {

    private ItemUseConsumableRewards() {}

    static void use(L1PcInstance pc, L1ItemInstance l1iteminstance, int itemId, L1ItemInstance l1iteminstance1) {
        switch (itemId) {
		case 3000195: {
		    SC_SkillSound.send(pc, pc.getId(), 21178);

		    final L1NpcInstance boardNpc =
		            L1World.getInstance()
		                    .findNpcByNpcId(4200015);

		    if (boardNpc != null) {
		        SC_Board.send(pc, boardNpc);
		    }

		    break;
		}

		case 474748: {
		    SC_SkillSound.send(pc, pc.getId(), 21178);

		    SC_PacketBox.send(pc, SC_PacketBox.GREEN_MESSAGE, "거래는 1천만 수표로만 이용이 가능합니다.");

		    final L1NpcInstance boardNpc =
		            L1World.getInstance()
		                    .findNpcByNpcId(4747470);

		    if (boardNpc != null) {
		        SC_Boarditem.sendListAsync(pc, boardNpc, 0);
		    }

		    SC_SystemMessage.send(pc, "[.물품판매] [.물품구입]으로 판매/구매 가능합니다.");

		    SC_SystemMessage.send(pc, "[.물품취소] 를 통해 본인이 등록한 물품을 취소할 수 있습니다.");

		    SC_SystemMessage.send(pc, "[.물품멘트 켬]하시면 실시간으로 판매등록된 물품들이 채팅창에 출력이 됩니다.");

		    break;
		}

		case 474750: { // 자유
		    SC_SkillSound.send(pc, pc.getId(), 21178);

		    SC_PacketBox.send(pc, SC_PacketBox.GREEN_MESSAGE, "거래 전, 공지사항의 '거래 게시판 이용 수칙'을 반드시 정독해주시기 바랍니다.");

		    final L1NpcInstance boardNpc =
		            L1World.getInstance()
		                    .findNpcByNpcId(4200022);

		    if (boardNpc != null) {
		        SC_Board.send(pc, boardNpc);
		    }

		    break;
		}

		case 474751: { // 영자
		    final L1NpcInstance boardNpc =
		            L1World.getInstance()
		                    .findNpcByNpcId(4200015);

		    if (boardNpc != null) {
		        SC_Board.send(pc, boardNpc);
		    }

		    break;
		}

		case 145001:

			CItemUse.useClanBuff(pc, l1iteminstance);

			break;
		case 145002:
			CItemUse.useClanBuff(pc, l1iteminstance);
			break;
		case 145003:
			CItemUse.useClanBuff(pc, l1iteminstance);
			break;
		case 145004:
			CItemUse.useClanBuff(pc, l1iteminstance);
			break;
		case 145005:
			CItemUse.useClanBuff(pc, l1iteminstance);
			break;
		case 145006:
			CItemUse.useClanBuff(pc, l1iteminstance);
			break;
		case 145007:
			CItemUse.useClanBuff(pc, l1iteminstance);
			break;
		case 145008:
			CItemUse.useClanBuff(pc, l1iteminstance);
			break;
		case 145009:
			CItemUse.useClanBuff(pc, l1iteminstance);
			break;
		case 145010: {
			final L1Clan pointsClan = pc.getClan();
			if (pointsClan == null || pc.getClanid() == 0) {
				pc.sendPackets("혈맹에 가입되어 있지않아 사용할 수 없습니다.");
				return;
			}
			final int pointRange = Config.혈맹포인트최대 - Config.혈맹포인트최소;
			if (pointRange <= 0) {
				pc.sendPackets("혈맹포인트 상자 설정 오류입니다.");
				return;
			}
			final int points = java.util.concurrent.ThreadLocalRandom.current().nextInt(pointRange) + Config.혈맹포인트최소;
			if (points <= 0) return;
			try (l1j.server.server.model.L1InventoryTransaction tx =
					l1j.server.server.model.L1InventoryTransaction.begin(pc,
						l1j.server.server.storage.CacheD.accountOrderKey("item-use:", pc.getId()))) {
				if (!tx.debit(l1iteminstance, 1)) return;
				ClanTable.stageWarPointDelta(tx, pointsClan, points);
				tx.onFailure(() -> pc.sendPackets("혈맹포인트 상자 사용을 저장하지 못했습니다. 아이템을 확인해 주세요."));
				tx.commit(() -> {
					pointsClan.addWarPointCommitted(points);
					for (L1PcInstance member : pointsClan.getOnlineClanMember()) {
						SC_PacketBox.send(member, SC_PacketBox.GREEN_MESSAGE,
							"\\fH" + pc.getName() + "\\f2님이 혈맹포인트상자에서 \\fH[" + points + "]\\f2 포인트를 획득하였습니다.");
						member.sendPackets("\\fH" + pc.getName() + "\\f2님이 혈맹포인트상자에서 \\fH[" + points + "]\\f2 포인트를 획득하였습니다.");
					}
				});
			} catch (RuntimeException failure) {
				pc.sendPackets("혈맹포인트 상자 사용에 실패했습니다. 아이템을 확인해 주세요.");
			}
			break;
		}
		case 474752: { // 아데나판매

		    final L1NpcInstance boardNpc =
		            L1World.getInstance()
		                    .findNpcByNpcId(45000178);

		    if (boardNpc != null) {
		        SC_AuctionSystemBoard.sendListAsync(pc, boardNpc, 0);
		    }

		    break;
		}
		case 4100203: // 슬롯 전체 개방권
		case 4100140: // 귀걸이 개방권
		case 4100141: // 왼쪽 반지 개방권
		case 4100142: // 오른쪽 반지 개방권
		case 4100143: // 견갑 개방권
		case 4100144: // 휘장 개방권
			ItemUseDurableGoods.useSlotUnlockAtomic(pc, l1iteminstance);
			break;
		case 40067:// 쑥송편
		case 41414:// 복월병
			final int restoreMpStrong = 15 + java.util.concurrent.ThreadLocalRandom.current().nextInt(30);
			ItemUseDurable.UseDurableConsume(pc, l1iteminstance, () -> {
				pc.setCurrentMp(pc.getCurrentMp() + restoreMpStrong);
				SC_SkillSound.send(pc, pc.getId(), 190);
			});
			break;
		case 40066:// 송편
		case 41413:// 월병
			final int restoreMpSmall = 5 + java.util.concurrent.ThreadLocalRandom.current().nextInt(10);
			ItemUseDurable.UseDurableConsume(pc, l1iteminstance, () -> {
				pc.setCurrentMp(pc.getCurrentMp() + restoreMpSmall);
				SC_SkillSound.send(pc, pc.getId(), 190);
			});
			break;
		case 111556:// 경험치물약
			CItemUse.useLevelExpPotion(pc, l1iteminstance);
			break;
		case 500220:
			if (pc.hasSkillEffect(L1SkillId.WITCH_MANA_POTION)) {
				int n = pc.getSkillEffectTimeSec(L1SkillId.WITCH_MANA_POTION);
				SC_SystemMessage.send(pc, String.format("%d초 후에 사용할 수 있습니다.", n));
				return;
			}
			ItemUseDurable.UseDurableConsume(pc, l1iteminstance, () -> {
				pc.setSkillEffect(L1SkillId.WITCH_MANA_POTION, 1800 * 1000);
				SC_ServerMessage.send(pc, 338, "$1084");
				pc.setCurrentMp(pc.getCurrentMp() + 1000);
				SC_SkillSound.send(pc, pc.getId(), 190);
			});
			break;
		case 1000010:
			SC_SystemMessage.send(pc, "현재 사용할 수 없는 아이템입니다.");
			break;
		case 1000110:
			SC_SystemMessage.send(pc, "현재 사용할 수 없는 아이템입니다.");
			break;
		case 1000120:
			SC_SystemMessage.send(pc, "현재 사용할 수 없는 아이템입니다.");
			break;
		case 410002:// 빛나는 나뭇잎
			final int restoreMp410002 = 44;
			ItemUseDurable.UseDurableConsume(pc, l1iteminstance, () -> {
				SC_ServerMessage.send(pc, 338, "$1084");
				pc.setCurrentMp(pc.getCurrentMp() + restoreMp410002);
			});
			break;
		case 40735:// 용기의 코인
			final int restoreMp40735 = 60;
			ItemUseDurable.UseDurableConsume(pc, l1iteminstance, () -> {
				SC_ServerMessage.send(pc, 338, "$1084");
				pc.setCurrentMp(pc.getCurrentMp() + restoreMp40735);
			});
			break;
		case 40042:// 정신력의 물약
			final int restoreMp40042 = 50;
			ItemUseDurable.UseDurableConsume(pc, l1iteminstance, () -> {
				SC_ServerMessage.send(pc, 338, "$1084");
				pc.setCurrentMp(pc.getCurrentMp() + restoreMp40042);
			});
			break;
		case 41404:// 쿠작의 영약
			final int restoreMp41404 = (80 + java.util.concurrent.ThreadLocalRandom.current().nextInt(21));
			ItemUseDurable.UseDurableConsume(pc, l1iteminstance, () -> {
				SC_ServerMessage.send(pc, 338, "$1084");
				pc.setCurrentMp(pc.getCurrentMp() + restoreMp41404);
			});
			break;
		case 41412:// 금쫑즈
			final int restoreMp41412 = (5 + java.util.concurrent.ThreadLocalRandom.current().nextInt(16));
			ItemUseDurable.UseDurableConsume(pc, l1iteminstance, () -> {
				SC_ServerMessage.send(pc, 338, "$1084");
				pc.setCurrentMp(pc.getCurrentMp() + restoreMp41412);
			});
			break;
		case 810011:
			SC_ChatPacket.sendDirect(pc, pc, "몽환의 섬 입구 크루나에게 물건을 구입할 수 있다.");
			break;
		case 3000048: // 꼬마 요정의 마음
			SC_ChatPacket.sendDirect(pc, pc, "생일 축하 요정에게 '코마'를 한 번 받을 수 있다.");
			break;
		case 40493:
			CItemUse.useGuardianFlute(pc, l1iteminstance);
			break;
		case 40328:// 6단계 마법주사위
			int gfxid = 3204 + java.util.concurrent.ThreadLocalRandom.current().nextInt(6);
			SC_SkillSound.send(pc, pc.getId(), gfxid);
			SC_SkillSound.broadcast(pc, pc.getId(), gfxid);
			break;
		case 3000150:
			CItemUse.craftLifeEye(pc, l1iteminstance);
			break;
		case 5922794:
			CItemUse.useClassGiftBundle(pc, l1iteminstance);
			break;
		case 41019:// 라스타바드 역사서 1권
			pc.start_teleport(32597, 32909, 400, pc.getHeading(), 169, true, pc.getAutoHunt());
			break;
		case 41027:// 완성한 라스타바드의 역사서
			//pc.sendPackets(new S_UserCommands7(1));
			pc.start_teleport(32745, 32791, 536, pc.getHeading(), 169, true, pc.getAutoHunt());
			break;
		case 490028: // 라우풀 물약
		case 490029: // 카오틱 물약
			ItemUseDurable.UseLawfulPotionAtomic(pc, l1iteminstance);
			break;
		case 3000175: // 탐상자
			ItemUseDurableGoods.useTamBoxAtomic(pc, l1iteminstance);
			break;
		case 45450:
		case 45451:
		case 45452:
		case 45453:
			SC_SkillSound.send(pc, pc.getId(), 21129);//21178 편지소리
			AutoSystemHandler.showAutoSettings(pc);
			break;
		case 12301:
			SC_SkillSound.send(pc, pc.getId(), 21129);
			//if(pc.getLevel() < 30){
			//	pc.sendPackets("튜토리얼 중에는 사용할 수 없습니다.");
			//	return;}
			SC_NPCTalkReturn.send(pc, pc.getId(), "GMt");

			break;
		case 4100120:
		case 4100119:
			CItemUse.useBurnedCharm(pc, l1iteminstance);
			break;
		case 3000039:
		case 3000169:
		case 718:
			CItemUse.useRandomEnchantBox(pc, l1iteminstance);
			break;
		case 698:
		case 776:
			CItemUse.useWeaponTransformation(pc, l1iteminstance, l1iteminstance1);
			break;
		case 41354:// 신성한 에바의 물
			if (pc.hasSkillEffect(STATUS_HOLY_WATER) || pc.hasSkillEffect(STATUS_HOLY_MITHRIL_POWDER)) {
				SC_ServerMessage.send(pc, 79); // \f1 아무것도 일어나지 않았습니다.
				return;
			}
			ItemUseDurable.UseDurableConsume(pc, l1iteminstance, () -> {
				pc.setSkillEffect(STATUS_HOLY_WATER_OF_EVA, 900 * 1000);
				SC_SkillSound.send(pc, pc.getId(), 190);
				SC_SkillSound.broadcast(pc, pc.getId(), 190);
				SC_ServerMessage.send(pc, 1140);
			});
			break;

        }
    }
}
