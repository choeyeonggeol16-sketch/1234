package l1j.server.server.model.item.function;

import l1j.server.Config;
import l1j.server.server.model.Instance.L1ItemInstance;
import l1j.server.server.model.Instance.L1PcInstance;
import l1j.server.server.model.character.skill.L1SkillId;
import l1j.server.server.model.character.skill.L1SkillUse;
import l1j.server.server.model.network.core.cs.packet.CS_Attr;
import l1j.server.server.model.network.core.sc.packet.SC_CurseBlind;
import l1j.server.server.model.network.core.sc.packet.SC_Karma;
import l1j.server.server.model.network.core.sc.packet.SC_MessageYN;
import l1j.server.server.model.network.core.sc.packet.SC_PacketBox;
import l1j.server.server.model.network.core.sc.packet.SC_ServerMessage;
import l1j.server.server.model.network.core.sc.packet.SC_SkillSound;
import l1j.server.server.model.network.core.sc.packet.SC_SystemMessage;
import l1j.server.server.model.poison.L1DamagePoison;
import static l1j.server.server.model.character.skill.L1SkillId.STATUS_FLOATING_EYE;
import static l1j.server.server.model.character.skill.L1SkillId.STATUS_HOLY_MITHRIL_POWDER;
import static l1j.server.server.model.character.skill.L1SkillId.STATUS_HOLY_WATER;
import static l1j.server.server.model.character.skill.L1SkillId.STATUS_HOLY_WATER_OF_EVA;
import static l1j.server.server.model.item.function.ItemUseCombatAbilities.블레이즈스턴;
import static l1j.server.server.model.item.function.ItemUseDurable.UseDurableConsume;
import static l1j.server.server.model.item.function.ItemUseMiscActions.피씨방코인;
import static l1j.server.server.model.item.function.ItemUsePotions.useCashScroll;
import static l1j.server.server.model.item.function.ItemUsePotions.usePotionCase;

/** Item-specific Consumables effects; selected once by ItemUseDispatcher. */
final class ItemUseConsumablesCases {
    private ItemUseConsumablesCases() {}

    static ItemUseResult handleCastGmBuff(ItemUseContext use) {
        L1PcInstance pc = use.player();
        int itemId = use.itemId();
        {
            int buffId = itemId - 34243;
            L1SkillUse.cast(pc, buffId, pc.getId(), pc.getX(), pc.getY(), null, 0,
                    L1SkillUse.TYPE_GMBUFF);
        }
            return ItemUseResult.COMPLETE;
    }

    static ItemUseResult handleDragonPearl(ItemUseContext use) {
        L1PcInstance pc = use.player();
        if (pc.hasSkillEffect(L1SkillId.잠재력진주)) {
            SC_SystemMessage.send(pc, "3단 가속 효과가 이미 적용 중입니다.");
            return ItemUseResult.STOP;
        }

        SC_SystemMessage.send(pc, "3단 가속 효과가 이미 적용 중입니다.");
        return ItemUseResult.COMPLETE;
    }

    static ItemUseResult handleAinGem(ItemUseContext use) {
        L1PcInstance pc = use.player();
        L1ItemInstance item = use.item();
        int itemId = use.itemId();
        if (ItemUseAinBlessing.useGemCase(pc, item, itemId)) return ItemUseResult.STOP;
        return ItemUseResult.COMPLETE;
    }

    static ItemUseResult handleMaanOrRaid(ItemUseContext use) {
        L1PcInstance pc = use.player();
        L1ItemInstance item = use.item();
        final CItemUse.Result result =
        CItemUse.use(pc, item);

        if (result == CItemUse.Result.RETURN) {
            return ItemUseResult.STOP;
        }

        return ItemUseResult.COMPLETE;
    }

    static ItemUseResult handleCashScroll(ItemUseContext use) {
        L1PcInstance pc = use.player();
        L1ItemInstance item = use.item();
        int itemId = use.itemId();
        if (itemId == 30063) {
            if (!(pc.getMapId() >= 1005 && pc.getMapId() <= 1022
                    || pc.getMapId() > 6000 && pc.getMapId() < 6999)) {
                SC_ServerMessage.send(pc, 1891);

                return ItemUseResult.STOP;
            }
        }
        UseDurableConsume(pc, item, () -> useCashScroll(pc, itemId));
        return ItemUseResult.COMPLETE;
    }

    static ItemUseResult handlePotion(ItemUseContext use) {
        L1PcInstance pc = use.player();
        L1ItemInstance item = use.item();
        int itemId = use.itemId();
        if (ItemUsePotions.usePotionCase(pc, item, itemId)) return ItemUseResult.STOP;
        return ItemUseResult.COMPLETE;
    }

    static ItemUseResult handlePcRoomBuff(ItemUseContext use) {
        L1PcInstance pc = use.player();
        L1ItemInstance item = use.item();
        int itemId = use.itemId();
        if (pc.PC방_버프) {
            SC_SystemMessage.send(pc, "이미 PC방버프가 적용 되어있습니다.");
            return ItemUseResult.STOP;
        } else {
            피씨방코인(pc, itemId, item, 7);
        }
        return ItemUseResult.COMPLETE;
    }

    static ItemUseResult handlePcRoomGift(ItemUseContext use) {
        L1PcInstance pc = use.player();
        L1ItemInstance item = use.item();
        int itemId = use.itemId();
        if (pc.PC방_버프) {
            SC_SystemMessage.send(pc, "이미 PC방버프가 적용 되어있습니다.");
            return ItemUseResult.STOP;
        } else {
            피씨방코인(pc, itemId, item, 3);
        }
        return ItemUseResult.COMPLETE;
    }

    static ItemUseResult handleGrowthPcRoomBuff(ItemUseContext use) {
        L1PcInstance pc = use.player();
        L1ItemInstance item = use.item();
        int itemId = use.itemId();
        if (pc.PC방_버프) {
            SC_SystemMessage.send(pc, "이미 PC방버프가 적용 되어있습니다.");
            return ItemUseResult.STOP;
        } else {
            피씨방코인(pc, itemId, item, 30);
        }
        return ItemUseResult.COMPLETE;
    }

    static ItemUseResult handleSupportBuff(ItemUseContext use) {
        L1PcInstance pc = use.player();
        L1ItemInstance item = use.item();
        int itemId = use.itemId();
        if (pc.getLevel() <= 55) {
            SC_SystemMessage.send(pc, "레벨 56 이상만 사용가능 합니다.");
            return ItemUseResult.STOP;
        }
        if (pc.PC방_버프) {
            SC_SystemMessage.send(pc, "이미 PC방버프가 적용 되어있습니다.");
            return ItemUseResult.STOP;
        } else {
            피씨방코인(pc, itemId, item, 1);
        }
        return ItemUseResult.COMPLETE;
    }

    static ItemUseResult handleComaCoin(ItemUseContext use) {
        L1PcInstance pc = use.player();
        L1ItemInstance item = use.item();
        {
            UseDurableConsume(pc, item, () ->
                L1SkillUse.cast(pc, 50007, pc.getId(), pc.getX(), pc.getY(),
                        null, 0, L1SkillUse.TYPE_SPELLSC));
            return ItemUseResult.COMPLETE;
        }
    }

    static ItemUseResult handleKarmaPotion(ItemUseContext use) {
        L1PcInstance pc = use.player();
        L1ItemInstance item = use.item();
        if (pc.getKarma() >= -10000000) {
            final int karmaDelta = (int) (-15000 * Config.RATE_KARMA);
            UseDurableConsume(pc, item, () -> {
                pc.addKarma(karmaDelta);
                SC_Karma.send(pc);
                SC_SystemMessage.send(pc, pc.getName() + "님의 우호도가 향상되었습니다.");
            });
        } else {
            SC_ServerMessage.send(pc, 79);
        }
        return ItemUseResult.COMPLETE;
    }

    static ItemUseResult handleFood(ItemUseContext use) {
        L1PcInstance pc = use.player();
        L1ItemInstance item = use.item();
        int itemId = use.itemId();
        pc.getInventory().removeItem(item, 1);

        if (itemId == 40057) {
            pc.setSkillEffect(STATUS_FLOATING_EYE, 0);
            if (pc.isBlind()) {
                SC_CurseBlind.send(pc, 2);
                pc.showFloatingEyeToInvis();
            }
        }
        if (pc.get_food() < 225) {
            pc.set_food(pc.get_food() + 10);
            if (itemId == 210039 || itemId == 30085) {
                pc.set_food(pc.get_food() + 90);
            }
            int foodvolume = (item.getItem().getFoodVolume() / 10);
            pc.add_food(foodvolume <= 0 ? 5 : foodvolume);
            SC_PacketBox.send(pc, SC_PacketBox.FOOD, pc.get_food());
            SC_ServerMessage.send(pc, 76, item.getItem().getNameId());
        }
        return ItemUseResult.COMPLETE;
    }

    static ItemUseResult handleMembershipBuff(ItemUseContext use) {
        L1PcInstance pc = use.player();
        int itemId = use.itemId();
        if (pc.getInventory().consumeItem(itemId, 1)) {
            if (pc.getClan() != null)
                pc.getClan().addBlessCount(10000000);
            SC_SystemMessage.send(pc, "축복의 기운 1000 추가되었습니다.");
        }
        return ItemUseResult.COMPLETE;
    }

    static ItemUseResult handleBlessWeaponScroll(ItemUseContext use) {
        L1PcInstance pc = use.player();
        L1ItemInstance item = use.item();
        if (pc.hasSkillEffect(L1SkillId.BLESS_WEAPON)) {
            SC_SystemMessage.send(pc, "블레스웨폰 스킬이 적용중입니다.");
            return ItemUseResult.STOP;
        }
        UseDurableConsume(pc, item, () -> {
            if (pc.hasSkillEffect(L1SkillId.ENCHANT_WEAPON)) {
                pc.removeSkillEffect(L1SkillId.ENCHANT_WEAPON);
            }
            L1SkillUse.cast(pc, L1SkillId.ENCHANT_WEAPON, pc.getId(), pc.getX(), pc.getY(),
                    null, 0, L1SkillUse.TYPE_GMBUFF);
        });
        return ItemUseResult.COMPLETE;
    }

    static ItemUseResult handleLevelBuff(ItemUseContext use) {
        L1PcInstance pc = use.player();
        L1ItemInstance item = use.item();
        if (pc.getLevel() >= 50) {
            SC_MessageYN.send(pc, CS_Attr.MSGCODE_622_KDINIT, 622, "당신의 킬/데스를 초기화 하시겠습니까?");
            pc.setKillDeathInitializeItem(item);
        } else
            pc.sendPackets("레벨 50 이하는 사용이 불가능 합니다.");
        return ItemUseResult.COMPLETE;
    }

    static ItemUseResult handleFoodBuff(ItemUseContext use) {
        L1PcInstance pc = use.player();
        L1ItemInstance item = use.item();
        if (pc.getLevel() >= 50) {
            SC_MessageYN.send(pc, CS_Attr.MSGCODE_622_Name, 622, "당신의 성별을 전환 하시겠습니까?");
            pc.setNameInstance(item);
        } else
            pc.sendPackets("레벨 50 이하는 사용이 불가능 합니다.");
        return ItemUseResult.COMPLETE;
    }

    static ItemUseResult handleDragonSkill(ItemUseContext use) {
        L1PcInstance pc = use.player();
        L1ItemInstance item = use.item();
        int spellTargetId = use.spellTargetId();
        if(Config.Neige_Myth_Skill == 2){
        if(pc.getCurrentSpriteId() == 19082 || pc.getCurrentSpriteId() == 18942
            || pc.getCurrentSpriteId() == 21140 || pc.getCurrentSpriteId() == 19514){
        블레이즈스턴(pc, spellTargetId, item);
        }else{
            pc.sendPackets("사용할 수 있는 조건이 아닙니다.");

        }
        }
        return ItemUseResult.COMPLETE;
    }

    static ItemUseResult handleHolyWater(ItemUseContext use) {
        L1PcInstance pc = use.player();
        L1ItemInstance item = use.item();
        if (pc.getZoneType() == 1) {
            SC_ServerMessage.send(pc, 79);
            return ItemUseResult.STOP;
        }
        UseDurableConsume(pc, item,
                () -> L1DamagePoison.doInfection(pc, pc, 3000, 5, false, 30000));
        return ItemUseResult.COMPLETE;
    }

    static ItemUseResult handleHolyWaterOfEva(ItemUseContext use) {
        L1PcInstance pc = use.player();
        L1ItemInstance item = use.item();
        if (pc.hasSkillEffect(STATUS_HOLY_WATER_OF_EVA)) {
            SC_ServerMessage.send(pc, 79);
            return ItemUseResult.STOP;
        }
        UseDurableConsume(pc, item, () -> {
            if (pc.hasSkillEffect(STATUS_HOLY_MITHRIL_POWDER)) {
                pc.removeSkillEffect(STATUS_HOLY_MITHRIL_POWDER);
            }
            pc.setSkillEffect(STATUS_HOLY_WATER, 900 * 1000);
            SC_SkillSound.send(pc, pc.getId(), 190);
            SC_SkillSound.broadcast(pc, pc.getId(), 190);
            SC_ServerMessage.send(pc, 1141);
        });
        return ItemUseResult.COMPLETE;
    }
}
