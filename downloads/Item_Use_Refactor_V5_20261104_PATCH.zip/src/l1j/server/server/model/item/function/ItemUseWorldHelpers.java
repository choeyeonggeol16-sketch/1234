package l1j.server.server.model.item.function;



import l1j.server.server.model.network.core.sc.packet.SC_SkillSound;

import java.lang.reflect.Constructor;
import java.util.ArrayList;
import java.util.Collection;
import l1j.server.Config;
import l1j.server.server.IdFactory;
import l1j.server.server.datatables.FurnitureSpawnTable;
import l1j.server.server.datatables.NpcTable;
import l1j.server.server.datatables.PetTable;
import l1j.server.server.model.L1HouseLocation;
import l1j.server.server.model.L1Object;
import l1j.server.server.model.L1World;
import l1j.server.server.model.Instance.L1FurnitureInstance;
import l1j.server.server.model.Instance.L1ItemInstance;
import l1j.server.server.model.Instance.L1NpcInstance;
import l1j.server.server.model.Instance.L1PcInstance;
import l1j.server.server.model.Instance.L1PetInstance;
import l1j.server.server.model.Instance.L1SupportInstance;



import l1j.server.server.model.network.core.sc.packet.SC_OwnCharStatus;
import l1j.server.server.model.network.core.sc.packet.SC_PacketBox;
import l1j.server.server.model.network.core.sc.packet.SC_ServerMessage;
import l1j.server.server.model.network.core.sc.packet.SC_SystemMessage;
import l1j.server.server.templates.L1Npc;
import l1j.server.server.templates.L1Pet;
import l1j.server.server.types.Point;




import static l1j.server.server.model.item.function.ItemUseEnchantments.*;
import static l1j.server.server.model.item.function.ItemUsePotions.*;
import static l1j.server.server.model.item.function.ItemUseTransformation.*;
import static l1j.server.server.model.item.function.ItemUseSpellBooks.*;
import static l1j.server.server.model.item.function.ItemUseSpecialEnchant.*;
import static l1j.server.server.model.item.function.ItemUseMiscActions.*;
import static l1j.server.server.model.item.function.ItemUseEquipment.*;
import static l1j.server.server.model.item.function.ItemUseDurable.*;
import static l1j.server.server.model.item.function.ItemUseCombatAbilities.*;
import static l1j.server.server.model.item.function.ItemUseDollEffects.*;

import static l1j.server.server.model.item.function.ItemUseCreature.*;

public final class ItemUseWorldHelpers {
    private ItemUseWorldHelpers() {}
	public static void useToiTeleportAmulet(L1PcInstance pc, int itemId, L1ItemInstance item) {
		boolean isTeleport = false;
		/** 오만부적 귀환지역제외한 아무곳이나 사용되게 **/
		if (itemId >= 40289 && itemId <= 40297) {
			if (pc.getMap().isEscapable()) {
				isTeleport = true;
			}
		}

		if (isTeleport) {
			pc.start_teleport(item.getItem().get_locx(), item.getItem().get_locy(), item.getItem().get_mapid(), 5, 169,
					true, pc.getAutoHunt());
		} else {
			SC_ServerMessage.send(pc, 79);
			// \f1 아무것도 일어나지 않았습니다.
		}
	}

	public static boolean withdrawPet(L1PcInstance pc, int itemObjectId) {
		if (!pc.getMap().isTakePets()) {
			SC_ServerMessage.send(pc, 563); // \f1 여기에서는 사용할 수 없습니다.
			return false;
		}

		if (pc.getMapId() == 781 || pc.getMapId() == 782) {
			SC_ServerMessage.send(pc, 563); // \f1 여기에서는 사용할 수 없습니다.
			return false;
		}

		if (pc.isInWarArea()) {
			SC_ServerMessage.send(pc, 563); // \f1 여기에서는 사용할 수 없습니다.
			return false;
		}

		int petCost = 0;
		Object[] petList = pc.getPetList().values().toArray();
		for (Object pet : petList) {
			if (pet instanceof L1PetInstance) {
				if (((L1PetInstance) pet).getItemObjId() == itemObjectId) {
					return false;
				}
			}

			if (pet instanceof L1PetInstance) {
				petCost += ((L1NpcInstance) pet).getPetcost();
			}
		}
		int charisma = pc.getAbility().getTotalCha();
		if (pc.isCrown()) { // CROWN
			charisma += 6;
		} else if (pc.isElf()) { // ELF
			charisma += 12;
		} else if (pc.isWizard()) { // WIZ
			charisma += 6;
		} else if (pc.isDarkelf()) { // DE
			charisma += 6;
		} else if (pc.isDragonknight()) { // 용기사
			charisma += 6;
		} else if (pc.isBlackwizard()) { // 환술사
			charisma += 6;
		}

		charisma -= petCost;
		int petCount = charisma / 6;
		if (petCount <= 0) {
			SC_ServerMessage.send(pc, 489); // 물러가려고 하는 애완동물이 너무 많습니다.
			return false;
		}

		L1Pet l1pet = PetTable.getInstance().getTemplate(itemObjectId);
		if (l1pet != null) {
			L1Npc npcTemp = NpcTable.getInstance().getTemplate(l1pet.get_npcid());
			L1PetInstance pet = new L1PetInstance(npcTemp, pc, l1pet);
			pet.setPetcost(6);
		}
		return true;
	}


	public static ArrayList<L1NpcInstance> get어드밴스1(L1Object object, int radius) {
		int map = object.getMapId();
		Point pt = object.getLocation();
		Collection<L1NpcInstance> pc1 = L1World.getInstance().getAllNpc();
		ArrayList<L1NpcInstance> result = null;
		if(radius < 0)
			result = new ArrayList<L1NpcInstance>(19 * 4);
		else if(radius == 0)
			result = new ArrayList<L1NpcInstance>(2);
		else
			result = new ArrayList<L1NpcInstance>(radius * 4);
		for (L1NpcInstance element : pc1) {
			if ((element == null) || (element.equals(object)) || (map != element.getMapId()))
				continue;
			if (radius == -1) {
				if (pt.isInScreen(element.getLocation()))
					result.add(element);
			} else if (radius == 0) {
				if (pt.isSamePoint(element.getLocation())) {
					result.add(element);
				}
			} else if (pt.getTileLineDistance(element.getLocation()) <= radius) {
				result.add(element);
			
			}
		}

		return result;
	}
	public static ArrayList<L1PcInstance> get어드밴스(L1PcInstance pc, L1Object object, int radius) {
		int map = object.getMapId();
		Point pt = object.getLocation();
		Collection<L1PcInstance> pc1 = L1World.getInstance().getAllPlayers();
		ArrayList<L1PcInstance> result = null;
		if(radius < 0)
			result = new ArrayList<L1PcInstance>(19 * 4);
		else if(radius == 0)
			result = new ArrayList<L1PcInstance>(2);
		else
			result = new ArrayList<L1PcInstance>(radius * 4);
		for (L1PcInstance element : pc1) {
			if ((element == null) || (element.equals(object)) || (map != element.getMapId()))
				continue;
			if (radius == -1) {
				if (pt.isInScreen(element.getLocation()))
					result.add(element);
			} else if (radius == 0) {
				if (pt.isSamePoint(element.getLocation())) {
					result.add(element);
				}
			} else if (pt.getTileLineDistance(element.getLocation()) <= radius) {
				result.add(element);
			
			}else if (pt.getTileLineDistance(element.getLocation()) > radius) {
				SC_PacketBox.send(pc, SC_PacketBox.GREEN_MESSAGE, "\\fY거리가 멀어서 사용할 수 없습니다.");
				SC_SystemMessage.send(pc, "\\fY거리가 멀어서 사용할 수 없습니다.");
			}
		}

		return result;
	}
	  public static void useResolvent(L1PcInstance pc, L1ItemInstance item,
            L1ItemInstance resolvent, int crystalCount) {
        CItemUse.useResolventCount(pc, item, resolvent, crystalCount);
    }


	public static void useSupport(L1PcInstance pc, int itemId, int itemObjectId) { // 쫄법사
//		if (!pc.getMap().isTakePets()) {
//			pc.sendPackets(new SC_ServerMessage(563)); // \f1 여기에서는 사용할 수 없습니다.
//			return;
//		}
//
//		if (pc.isInWarArea()) {
//			pc.sendPackets(new SC_ServerMessage(563)); // \f1 여기에서는 사용할 수 없습니다.
//			return;
//		}
//
//		if (pc.getMapId() == 5153 || pc.getMapId() == 5140) {
//			pc.sendPackets(new SC_ServerMessage(563)); // \f1 여기에서는 사용할 수 없습니다.
//			return;
//		}
//
//		if (!pc.getInventory().checkItem(40308, 5000)) {
//			pc.sendPackets(new SC_ServerMessage(337, "$4")); // \f1%0이 부족합니다.
//			return;
//		}
//		if (pc.getLevel() > 75) {
//			pc.sendPackets(new SC_SystemMessage("도우미: [75] 레벨까지 사용하실수 있습니다."));
//			return;
//		}
//		boolean isAppear = true;
//		L1SupportInstance support = null;
//		Object[] supportList = pc.getSupportList().values().toArray();
//		for (Object supportObject : supportList) {
//			support = (L1SupportInstance) supportObject;
//			if (support.getItemObjId() == itemObjectId) { // 이미 꺼내고 있는 매직 실업 수당
//				isAppear = false;
//				break;
//			}
//		}
//
//		if (isAppear) {
//			if (supportList.length >= Config.MAX_DOLL_COUNT) {// 더 이상의 monster를
//				// 조종할 수 없습니다.
//				pc.sendPackets(new SC_ServerMessage(319));
//				return;
//			}
//			int npcId = 0;
//			int supportType = 0;
//			if (itemId == 210095) {
//				npcId = 200073;
//				supportType = L1SupportInstance.SUPPORTTYPE_DWARF;
//			}
//
//			L1Npc template = NpcTable.getInstance().getTemplate(npcId);
//			support = new L1SupportInstance(template, pc, supportType, itemObjectId);
//			support.broadcastPacket(new S_SkillSound(support.getId(), 5935));
//			SC_OwnCharStatus.send(pc);
//			pc.getInventory().consumeItem(40308, 1);
//			pc.setSupporting(true);
//		} else {
//			support.broadcastPacket(new S_SkillSound(support.getId(), 5936));
//			support.deleteSupport();
//			SC_OwnCharStatus.send(pc);
//			pc.setSupporting(false);
//		}
	}

	public static void useSupport1(L1PcInstance pc, int itemId, int itemObjectId) { // 쫄법사
		if (!pc.getMap().isTakePets()) {
			SC_ServerMessage.send(pc, 563); // \f1 여기에서는 사용할 수 없습니다.
			return;
		}

		if (pc.isInWarArea()) {
			SC_ServerMessage.send(pc, 563); // \f1 여기에서는 사용할 수 없습니다.
			return;
		}

		if (pc.getMapId() == 5153 || pc.getMapId() == 5140) {
			SC_ServerMessage.send(pc, 563); // \f1 여기에서는 사용할 수 없습니다.
			return;
		}

		if (!pc.getInventory().checkItem(40308, 5000)) {
			SC_ServerMessage.send(pc, 337, "$4"); // \f1%0이 부족합니다.
			return;
		}
		if (pc.getLevel() > 75) {
			SC_SystemMessage.send(pc, "도우미: [75] 레벨까지 사용하실수 있습니다.");
			return;
		}
		boolean isAppear = true;
		L1SupportInstance support = null;
		Object[] supportList = pc.getSupportList().values().toArray();
		for (Object supportObject : supportList) {
			support = (L1SupportInstance) supportObject;
			if (support.getItemObjId() == itemObjectId) { // 이미 꺼내고 있는 매직 실업 수당
				isAppear = false;
				break;
			}
		}

		if (isAppear) {
			if (supportList.length >= Config.MAX_DOLL_COUNT) {// 더 이상의 monster를
				// 조종할 수 없습니다.
				SC_ServerMessage.send(pc, 319);
				return;
			}
			int npcId = 0;
			int supportType = 0;
			if (itemId == 2100950) {
				npcId = 7310105;
				supportType = L1SupportInstance.SUPPORTTYPE_DWARF;
			}

			L1Npc template = NpcTable.getInstance().getTemplate(npcId);
			support = new L1SupportInstance(template, pc, supportType, itemObjectId);
			SC_SkillSound.broadcast(support, support.getId(), 5935);
			SC_OwnCharStatus.send(pc);
			pc.getInventory().consumeItem(40308, 1);
			pc.setSupporting(true);
		} else {
			SC_SkillSound.broadcast(support, support.getId(), 5936);
			support.deleteSupport();
			SC_OwnCharStatus.send(pc);
			pc.setSupporting(false);
		}
	}

	public static void useFurnitureItem(L1PcInstance pc, int itemId, int itemObjectId) {
		if (!L1HouseLocation.isInHouse(pc.getX(), pc.getY(), pc.getMapId())) {
			SC_ServerMessage.send(pc, 563); // \f1 여기에서는 사용할 수 없습니다.
			return;
		}

		boolean isAppear = true;
		L1FurnitureInstance furniture = null;
		for (L1Object l1object : L1World.getInstance().getObject()) {
			if (l1object instanceof L1FurnitureInstance) {
				furniture = (L1FurnitureInstance) l1object;
				if (furniture.getItemObjId() == itemObjectId) { // 이미 꺼내고 있는 가구
					isAppear = false;
					break;
				}
			}
		}

		if (isAppear) {
			if (pc.getHeading() != 0 && pc.getHeading() != 2) {
				return;
			}
			int npcId = 0;
			switch (itemId) {
			case 41383:
				npcId = 80109;
				break;
			case 41384:
				npcId = 80110;
				break;
			case 41385:
				npcId = 80113;
				break;
			case 41386:
				npcId = 80114;
				break;
			case 41387:
				npcId = 80115;
				break;
			case 41388:
				npcId = 80124;
				break;
			case 41389:
				npcId = 80118;
				break;
			case 41390:
				npcId = 80118;
				break;
			case 41391:
				npcId = 80120;
				break;
			case 41392:
				npcId = 80121;
				break;
			case 41393:
				npcId = 80126;
				break;
			case 41394:
				npcId = 80125;
				break;
			case 41395:
				npcId = 80111;
				break;
			case 41396:
				npcId = 80112;
				break;
			case 41397:
				npcId = 80116;
				break;
			case 41398:
				npcId = 80117;
				break;
			case 41399:
				npcId = 80122;
				break;
			case 41400:
				npcId = 80123;
				break;
			}

			try {
				L1Npc l1npc = NpcTable.getInstance().getTemplate(npcId);
				if (l1npc != null) {
					try {
						String s = l1npc.getImpl();
						Constructor<?> constructor = Class.forName("l1j.server.server.model.Instance." + s + "Instance")
								.getConstructors()[0];
						Object aobj[] = { l1npc };
						furniture = (L1FurnitureInstance) constructor.newInstance(aobj);
						furniture.setId(IdFactory.getInstance().nextId());
						furniture.setMap(pc.getMapId());
						if (pc.getHeading() == 0) {
							furniture.setX(pc.getX());
							furniture.setY(pc.getY() - 1);
						} else if (pc.getHeading() == 2) {
							furniture.setX(pc.getX() + 1);
							furniture.setY(pc.getY());
						}
						furniture.setHomeX(furniture.getX());
						furniture.setHomeY(furniture.getY());
						furniture.setHeading(0);
						furniture.setItemObjId(itemObjectId);

						L1World.getInstance().storeAndEnterWorld(furniture);
						FurnitureSpawnTable.getInstance().insertFurniture(furniture);
					} catch (Exception e) {
						e.printStackTrace();
					}
				}
			} catch (Exception exception) {
			}
		} else {
			furniture.deleteMe();
			FurnitureSpawnTable.getInstance().deleteFurniture(furniture);
		}
	}

}
