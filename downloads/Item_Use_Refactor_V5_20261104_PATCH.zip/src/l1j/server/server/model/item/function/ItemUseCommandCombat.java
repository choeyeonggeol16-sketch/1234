package l1j.server.server.model.item.function;

import l1j.server.server.model.network.core.sc.packet.SC_TrueTargetNew;
import l1j.server.server.model.network.core.sc.packet.SC_SkillSound;
import static l1j.server.server.model.character.skill.L1SkillId.COUNTER_MAGIC;
import java.util.Random;
import java.util.concurrent.ThreadLocalRandom;
import l1j.server.Config;
import l1j.server.server.ActionCodes;
import l1j.server.server.model.L1Location;
import l1j.server.server.model.L1Object;
import l1j.server.server.model.L1Party;
import l1j.server.server.model.L1PcInventory;
import l1j.server.server.model.L1World;
import l1j.server.server.model.Instance.L1ItemInstance;
import l1j.server.server.model.Instance.L1PcInstance;
import l1j.server.server.model.character.skill.L1SkillId;
import l1j.server.server.model.character.skill.L1SkillUse;
import l1j.server.server.model.item.teleport.L1Teleport;
import l1j.server.server.model.network.core.sc.packet.SC_AttackPacket;
import l1j.server.server.model.network.core.sc.packet.SC_PacketBox;
import l1j.server.server.model.network.core.sc.packet.SC_ServerMessage;
import l1j.server.server.model.network.core.sc.packet.SC_SystemMessage;
import l1j.server.server.utils.MJCommons;
import static l1j.server.server.model.item.function.ItemUseCreature.*;

/**
 * Legacy combat effects grouped by responsibility. 
 */
final class ItemUseCommandCombat {
    
    private ItemUseCommandCombat() {
    }
    
    public static void 어벤저(L1PcInstance pc, int targetId, L1ItemInstance item) {
        SC_AttackPacket.send(pc.getNetConnection(), pc, 0, ActionCodes.ACTION_Wand);
        SC_AttackPacket.broadcast(pc, 0, ActionCodes.ACTION_Wand);
        L1Object target = L1World.getInstance().findObject(targetId);
        Random random = ThreadLocalRandom.current();
        int rnd = random.nextInt(100) + 1;
        if ((pc.getType() == 4 && pc.getLevel() >= 85) || pc.isGm()) {
            if (target != null) {
                if (target instanceof L1PcInstance) {
                    L1PcInstance member = (L1PcInstance)target;
                    int aa1 = random.nextInt(100) + 1;
                    int aa = member.getAC().getAc() / 2;
                    int dmg = (pc.getLevel() / 3 * Config.어벤저배율) + aa1;
                    if (pc.getId() == member.getId()) {
                        SC_SystemMessage.send(pc, "\\aH자기 자신에게는 사용할 수 없습니다");
                        return;
                    }
                    int diffLocX = Math.abs(pc.getX() - member.getX());
                    int diffLocY = Math.abs(pc.getY() - member.getY());
                    if (diffLocX > 1 || diffLocY > 1) {
                        SC_PacketBox.send(pc, SC_PacketBox.GREEN_MESSAGE, "\\fY거리가 멀어서 사용할 수 없습니다.");
                        SC_SystemMessage.send(pc, "\\fY거리가 멀어서 사용할 수 없습니다.");
                        return;
                    }
                    if (pc.hasSkillEffect(L1SkillId.어벤저대기)) {
                        int n = pc.getSkillEffectTimeSec(L1SkillId.어벤저대기);
                        SC_SystemMessage.send(pc, String.format("\\fY어벤저 대기시간 : %d초 후에 사용가능합니다.", n));
                        return;
                    }
                    if (pc.getInventory().getTypeEquipped(1, 1) >= 1 || pc.getInventory().getTypeEquipped(1, 3) >= 1 || pc.getInventory().getTypeEquipped(1, 2) >= 1 || pc.getInventory().getTypeEquipped(1, 4) >= 1 || pc.getInventory().getTypeEquipped(1, 5) >= 1 || pc.getInventory().getTypeEquipped(1, 6) >= 1 || pc.getInventory().getTypeEquipped(1, 7) >= 1 || pc.getInventory().getTypeEquipped(1, 8) >= 1 || pc.getInventory().getTypeEquipped(1, 10) >= 1 || pc.getInventory().getTypeEquipped(1, 13) >= 1 || pc.getInventory().getTypeEquipped(1, 14) >= 1 || pc.getInventory().getTypeEquipped(1, 17) >= 1 || pc.getInventory().getTypeEquipped(1, 15) >= 1 || pc.getInventory().getTypeEquipped(1, 18) >= 1 || pc.getInventory().getTypeEquipped(1, 16) >= 1) {
                        SC_SystemMessage.send(pc, "사용조건(다크엘프): 이도류, 크로우 중 착용");
                        return;
                    }
                    if (MJCommons.isNonAction(pc)) {
                        return;
                    }
                    if (pc.getSafetyZone() && (!(pc.getMapId() == 9 || pc.getMapId() == 1 || pc.getMapId() == 2))) {
                        SC_SystemMessage.send(pc, "세이프티존에서는 사용할 수 없습니다.");
                        return;
                    }
                    if (pc.isInvisble()) {
                        SC_SystemMessage.send(pc, "어벤저는 투명상태로 시전이 불가능합니다.");
                        return;
                    }
                    if (!pc.getInventory().checkItem(40321, 2)) {
                        SC_SystemMessage.send(pc, "마법 재료가 부족합니다.");
                        return;
                    }
                    if (pc.getCurrentMp() < 25) {
                        SC_ServerMessage.send(pc, 278);
                        return;
                    }
                    if (member.hasSkillEffect(COUNTER_MAGIC)) {
                        member.removeSkillEffect(COUNTER_MAGIC);
                        SC_SkillSound.broadcast(member, member.getId(), 10702);
                        SC_SkillSound.send(member, member.getId(), 10702);
                    } else {
                        if (member.getCurrentHp() <= member.getMaxHp() * 0.3) {
                            if (rnd <= Config.어벤저확률) {
                                if (!member.isGm()) member.death(pc, true);
                                if (pc.isGm()) {
                                    SC_SystemMessage.send(pc, "\\aH어벤져 확률: [" + rnd + "]  [1~" + Config.어벤저확률 + "]");
                                }
                            } else {
                                if (aa <= 0) {
                                    dmg += aa;
                                }
                                if (dmg < 100) {
                                    dmg = 100;
                                }
                                member.receiveDamage(pc, dmg);
                                if (pc.isGm()) {
                                    SC_SystemMessage.send(pc, "\\aH어벤져 데미지: " + dmg);
                                }
                            }
                        } else {
                            if (aa <= 0) {
                                dmg += aa;
                            }
                            if (dmg < 100) {
                                dmg = 100;
                            }
                            member.receiveDamage(pc, dmg);
                        }
                        if (pc.isGm()) {
                            SC_SystemMessage.send(pc, "\\aH어벤져 데미지: " + dmg);
                        }
                        SC_SkillSound.send(member, member.getId(), 14545);
                        SC_SkillSound.broadcast(member, member.getId(), 14545);
                    }
                    pc.setSkillEffect(L1SkillId.어벤저대기, Config.어벤저대기 * 1000);
                    pc.setCurrentMp(pc.getCurrentMp() - 25);
                    pc.getInventory().consumeItem(40321, 2);
                    L1SkillUse.cast(pc, L1SkillId.보조버프, pc.getId(), pc.getX(), pc.getY(), null, 0, L1SkillUse.TYPE_SPELLSC);
                } else {
                    SC_SystemMessage.send(pc, "\\aHPC에게만 가능합니다.");
                }
            } else {
                SC_SystemMessage.send(pc, "타겟이 올바르지않습니다.");
            }
        } else {
            pc.sendPackets("\\aH조건에 맞지 않아 사용할 수 없는 스킬입니다.");
            pc.sendPackets("\\aH조건:다크엘프      레벨: 85 이상");
        }
    }
    
    public static void 콜어드밴스(L1PcInstance pc, int targetId, L1ItemInstance item) {
        SC_AttackPacket.send(pc.getNetConnection(), pc, 0, ActionCodes.ACTION_Wand);
        SC_AttackPacket.broadcast(pc, 0, ActionCodes.ACTION_Wand);
        L1Object target = L1World.getInstance().findObject(targetId);
        L1Party party = pc.getParty();
        if ((pc.getType() == 0 && pc.getLevel() >= Config.어드밴스레벨) || pc.isGm()) {
            if (target != null) {
                if (party != null) {
                    if (target instanceof L1PcInstance) {
                        L1PcInstance member = (L1PcInstance)target;
                        int diffLocX = Math.abs(pc.getX() - member.getX());
                        int diffLocY = Math.abs(pc.getY() - member.getY());
                        if (diffLocX > 8 || diffLocY > 8) {
                            SC_PacketBox.send(pc, SC_PacketBox.GREEN_MESSAGE, "\\fY거리가 멀어서 사용할 수 없습니다.");
                            SC_SystemMessage.send(pc, "\\fY거리가 멀어서 사용할 수 없습니다.");
                            return;
                        }
                        if (pc.hasSkillEffect(L1SkillId.어드밴스대기)) {
                            int n = pc.getSkillEffectTimeSec(L1SkillId.어드밴스대기);
                            SC_SystemMessage.send(pc, String.format("\\fY콜 클랜 어드밴스 대기시간 : %d초 후에 사용가능합니다.", n));
                            return;
                        }
                        if (MJCommons.isNonAction(pc)) {
                            return;
                        }
                        if (pc.isInvisble()) {
                            SC_SystemMessage.send(pc, "콜 클랜 어드밴스는 투명상태로 시전이 불가능합니다.");
                            return;
                        }
                        if (!pc.getInventory().checkItem(41246, 200)) {
                            SC_SystemMessage.send(pc, "결정체가 부족합니다.");
                            return;
                        }
                        if (pc.getClanid() == 0) {
                            SC_SystemMessage.send(pc, "혈맹을 창설후에 사용가능합니다.");
                            return;
                        }
                        if (pc.getCurrentMp() < 20) {
                            SC_ServerMessage.send(pc, 278);
                            return;
                        }
                        if (pc.getId() == member.getId()) {
                            SC_SystemMessage.send(pc, "\\aH자기 자신에게는 사용할 수 없습니다");
                            return;
                        }
                        if (pc.getClanid() != member.getClanid()) {
                            SC_SystemMessage.send(pc, "같은 혈원만 소환 가능합니다.");
                            return;
                        }
                        int tx = member.getX();
                        int ty = member.getY();
                        if (!pc.glanceCheck(tx, ty) || !member.glanceCheck(pc.getX(), pc.getY())) {
                            L1Location loc = L1Teleport.getInstance().소환텔레포트(pc, 1);
                            member.어드밴스(loc.getX(), loc.getY(), loc.getMapId(), member.getHeading(), 169, false, true);
                        } else {
                            L1Location loc = L1Teleport.getInstance().소환텔레포트(pc, -1);
                            member.어드밴스(loc.getX(), loc.getY(), loc.getMapId(), member.getHeading(), 169, false, true);
                        }
                        SC_SystemMessage.send(member, "\\aH군주가 당신을 소환하였습니다.");
                        SC_SkillSound.send(member, member.getId(), 12261);
                        SC_SkillSound.broadcast(member, member.getId(), 12261);
                        SC_PacketBox.send(pc, SC_PacketBox.GREEN_MESSAGE, "\\f:콜 클랜 어드밴스로 혈맹원: [" + member.getName() + "]님을 소환하였습니다");
                        pc.setSkillEffect(L1SkillId.어드밴스대기, Config.어드밴스대기 * 1000);
                        L1SkillUse.cast(pc, L1SkillId.보조버프, pc.getId(), pc.getX(), pc.getY(), null, 0, L1SkillUse.TYPE_SPELLSC);
                        pc.setCurrentMp(pc.getCurrentMp() - 20);
                        pc.getInventory().consumeItem(41246, 200);
                        pc.getInventory().updateItem(item, L1PcInventory.COL_CHARGE_COUNT);
                    } else {
                        SC_SystemMessage.send(pc, "타겟이 올바르지않습니다.");
                    }
                } else {
                    SC_SystemMessage.send(pc, "파티가 아니거나 화면내에 파티에 속해있는 혈맹원들이 없습니다.");
                }
            } else {
                SC_SystemMessage.send(pc, "타겟이 올바르지않습니다.");
            }
        } else {
            pc.sendPackets("\\aH조건에 맞지 않아 사용할 수 없는 스킬입니다.");
            pc.sendPackets("\\aH조건: 군주      레벨: " + Config.어드밴스레벨 + " 이상");
        }
    }
    
    public static void 전투지휘봉(L1PcInstance pc, int targetId, L1ItemInstance item) {
        SC_AttackPacket.send(pc.getNetConnection(), pc, 0, ActionCodes.ACTION_Wand);
        SC_AttackPacket.broadcast(pc, 0, ActionCodes.ACTION_Wand);
        L1Object target = L1World.getInstance().findObject(targetId);
        L1Party party = pc.getParty();
        if (target != null) {
            if (party != null) {
                if (target instanceof L1PcInstance) {
                    L1PcInstance member = (L1PcInstance)target;
                    if (pc.isInvisble()) {
                        SC_SystemMessage.send(pc, "투명상태에서는 불가능합니다.");
                        return;
                    }
                    if (pc.getId() == member.getId()) {
                        SC_SystemMessage.send(pc, "\\aH자기 자신에게는 사용할 수 없습니다");
                        return;
                    }
                    if (!(pc.is_combat_field()) && pc.getClanid() == member.getClanid()) {
                        SC_SystemMessage.send(pc, "\\aH같은 혈맹원에게는 사용할 수 없습니다.");
                        return;
                    }
                    for (L1Object obj : L1World.getInstance().getClusterGrid().queryNearby(pc, 18)) {
                        if (obj instanceof L1PcInstance) {
                            L1PcInstance other = (L1PcInstance)obj;
                            if (other.hasSkillEffect(L1SkillId.전투지휘)) {
                                other.removeSkillEffect(L1SkillId.전투지휘);
                            }
                        }
                    }
                    for (L1PcInstance partymember : pc.getParty().getMembers()) {
                        if (partymember.getId() == member.getId()) {
                            SC_SystemMessage.send(pc, "\\aH파티원에게는 사용할 수 없습니다.");
                            return;
                        }
                        SC_TrueTargetNew.send(partymember, target.getId(), true);
                        if (!(pc.is_combat_field())) {
                            SC_SystemMessage.send(partymember, "\\f2[전투 지휘자: " + pc.getName() + "] 지목상대: \\fH[" + member.getName() + "] \\f2 지목!");
                        } else {
                            SC_SystemMessage.send(partymember, "\\f2[전투 지휘자: " + pc.getName() + "] 지목상대: \\fH[" + member.getName() + "] \\f2 지목!");
                        }
                    }
                    member.setSkillEffect(L1SkillId.전투지휘, 10 * 1000);
                } else {
                    SC_SystemMessage.send(pc, "타겟이 올바르지않습니다.");
                }
            } else {
                SC_SystemMessage.send(pc, "파티상태에서만 전투지휘가 가능합니다.");
            }
        } else {
            SC_SystemMessage.send(pc, "타겟이 올바르지않습니다.");
        }
    }
}
