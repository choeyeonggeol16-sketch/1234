package l1j.server.server.model.item.function;

import l1j.server.MJCTSystem.Loader.MJCTLoadManager;
import l1j.server.MJCTSystem.MJCTHandler;
import l1j.server.MJItemEnchantSystem.MJItemEnchanterLoader;
import l1j.server.server.model.Instance.L1ItemInstance;
import l1j.server.server.model.Instance.L1PcInstance;
import l1j.server.server.model.character.skill.L1SkillId;
import l1j.server.server.model.character.skill.L1SkillUse;
import l1j.server.server.model.item.L1ItemId;
import l1j.server.server.model.item.classchange.ClassChange;
import l1j.server.server.model.network.core.sc.packet.SC_InventoryIcon;
import l1j.server.server.model.network.core.sc.packet.SC_MessageYN;
import l1j.server.server.model.network.core.sc.packet.SC_NPCTalkReturn;
import l1j.server.server.model.network.core.sc.packet.SC_ShowPolyList;
import l1j.server.server.model.network.core.sc.packet.SC_SystemMessage;
import l1j.server.server.templates.L1BookMark;
import static l1j.server.server.model.item.function.ItemUseCombatAbilities.데몰리션;
import static l1j.server.server.model.item.function.ItemUseCombatAbilities.쉐도우;
import static l1j.server.server.model.item.function.ItemUseCombatAbilities.어벤저;
import static l1j.server.server.model.item.function.ItemUseCombatAbilities.엘븐스트라이크;
import static l1j.server.server.model.item.function.ItemUseCombatAbilities.이터니티;
import static l1j.server.server.model.item.function.ItemUseCombatAbilities.전투지휘봉;
import static l1j.server.server.model.item.function.ItemUseCombatAbilities.콜어드밴스;
import static l1j.server.server.model.item.function.ItemUseCreature.useFieldObjectRemovalWand;
import static l1j.server.server.model.item.function.ItemUseCreature.use_bug_down_wand;
import static l1j.server.server.model.item.function.ItemUseCreature.정상의가호;
import static l1j.server.server.model.item.function.ItemUseCreature.정상의가호2;
import static l1j.server.server.model.item.function.ItemUseDurable.UseDurableChargedBox;
import static l1j.server.server.model.item.function.ItemUseDurable.UseDurableConsume;
import static l1j.server.server.model.item.function.ItemUseEquipment.handleArmorUse;
import static l1j.server.server.model.item.function.ItemUseEquipment.handleWeaponUse;
import static l1j.server.server.model.item.function.ItemUseMiscActions.serchdroplist2;
import static l1j.server.server.model.item.function.ItemUseMiscActions.useFieldObjectRemovalWand1;
import static l1j.server.server.model.item.function.ItemUseMiscActions.useNpcSpownWand;
import static l1j.server.server.model.item.function.ItemUseMiscActions.강화버프;
import static l1j.server.server.model.item.function.ItemUseMiscActions.군주광역스턴;
import static l1j.server.server.model.item.function.ItemUseMiscActions.매직실드;
import static l1j.server.server.model.item.function.ItemUseMiscActions.비전텔레포트;
import static l1j.server.server.model.item.function.ItemUseMiscActions.투견조작;
import static l1j.server.server.model.item.function.ItemUseSpecialEnchant.무기축복;
import static l1j.server.server.model.item.function.ItemUseSpecialEnchant.무기축복100;
import static l1j.server.server.model.item.function.ItemUseSpecialEnchant.방어구축복;
import static l1j.server.server.model.item.function.ItemUseSpecialEnchant.방어구축복100;
import static l1j.server.server.model.item.function.ItemUseSpecialEnchant.악세인챈;
import static l1j.server.server.model.item.function.ItemUseSpecialEnchant.악세인챈100;
import static l1j.server.server.model.item.function.ItemUseSpecialEnchant.옵션부여;
import static l1j.server.server.model.item.function.ItemUseSpecialEnchant.집행진화주문서;
import static l1j.server.server.model.item.function.ItemUseSpecialEnchant.품질부여주문서;
import static l1j.server.server.model.item.function.ItemUseTransformation.usePolyPotion;
import static l1j.server.server.model.item.function.ItemUseWorldHelpers.useToiTeleportAmulet;

/** Explicit-ID dispatch. The default retains its original ordered range/use-type rules. */
final class ItemUseDispatcher {
    private ItemUseDispatcher() {}

    static ItemUseResult use(ItemUseContext use) {
        if(use.item().getItem().getType2()==1) {
            handleWeaponUse(use.player(),use.item());
            return ItemUseResult.COMPLETE;
        }
        if(use.item().getItem().getType2()==2) {
            handleArmorUse(use.player(),use.item());
            return ItemUseResult.COMPLETE;
        }
        if(use.item().getItem().getType2()!=0) return ItemUseResult.COMPLETE;
        L1PcInstance pc = use.player();
        L1ItemInstance item = use.item();
        L1ItemInstance targetItem = use.targetItem();
        int itemId = use.itemId();
        int spellTargetId = use.spellTargetId();
        int spellTargetX = use.spellX();
        int spellTargetY = use.spellY();
        short bookmarkMapId = use.bookmarkMapId();
        int bookmarkX = use.bookmarkX();
        int bookmarkY = use.bookmarkY();
        int teleportBookSlot = use.teleportBookSlot();
        int storedItemObjectId = use.storedItemObjectId();
        return switch(itemId) {
            case 700085, 700086 -> ItemUseUtilityCases.handleRequestAnnouncement(use);
            case 42656, 90736, 90735, 3000245, 3000244, 3000242, 90737, 6012,
                    6016 -> { UseDurableChargedBox(pc, item); yield ItemUseResult.COMPLETE; }
            case 41922, 41923, 41924, 41925 -> ItemUseConsumablesCases.handleCastGmBuff(use);
            case 50020, 50021 -> { ItemUseSealScroll.use(pc, item, targetItem, itemId); yield ItemUseResult.COMPLETE; }
            case L1ItemId.DRAGON_PEARL, L1ItemId.DRAGON_PEARL1 -> ItemUseConsumablesCases.handleDragonPearl(use);
            case 3000224 -> ItemUseRewardsCases.handleConvertAinGems(use);
            case 410139, 6017, 410138, 410064, 1000002, 1000003, 1000004, 1000007,
                    3000231, 7241, 3000457, 60255 -> ItemUseConsumablesCases.handleAinGem(use);
            case 410032, 410033, 410034, 410035, 410036, 410037, 410038, 779911,
                    779922, 779933, 3000159 -> ItemUseConsumablesCases.handleMaanOrRaid(use);
            case 410010, 410011, 410012, 4100039, 4100041, 4100042, 30063 -> ItemUseConsumablesCases.handleCashScroll(use);
            case 7007, 40010, 40011, 40012, 4100021, 40019, 40020, 40021,
                    40022, 40023, 40024, 40026, 40027, 40028, 40043, 40058,
                    40071, 40506, 40930, 41141, 41337, 60029, 60030, 140010,
                    140011, 140012, 140506, 240010, 41403, 410000, 410003, 30062,
                    30056, 42658, 40029, 4100152, 4100153, 4100154, 40858, 708,
                    3000456, 30105, 210094, 40030, 40013, 7006, 40018, 40039,
                    40040, 41338, 41261, 41262, 41268, 41269, 41271, 41272,
                    41273, 41342, 30067, 140013, 140018, 30158, 875640293, 40014,
                    140014, 41415, 30073, 40068, 140068, 210110, 30076, 712,
                    40031, 30075, 713, 210036, 30077, 40733, 210115, 40032,
                    40041, 41344, 30083, 40015, 140015, 40736, 41142, 210114,
                    30089, 40016, 140016, 210113, 40025 -> ItemUseConsumablesCases.handlePotion(use);
            case 4100133 -> { SC_ShowPolyList.send(pc, pc.getId(), "jindeath2017"); yield ItemUseResult.COMPLETE; }
            case 30060 -> ItemUseTransformationCases.handleShowPixieForms(use);
            case 3000421 -> ItemUseTransformationCases.handleShowTamForms(use);
            case 600198, 600199, 600200, 600201, 600202, 600203, 600204, 600205,
                    600206, 600207, 600208, 600209, 600210, 600211, 600212, 600213,
                    600214, 600215, 600216, 600217, 600218 -> { 강화버프(pc, itemId, item); yield ItemUseResult.COMPLETE; }
            case 600223 -> ItemUseConsumablesCases.handlePcRoomBuff(use);
            case 3000237 -> ItemUseConsumablesCases.handlePcRoomGift(use);
            case 600225 -> ItemUseConsumablesCases.handleGrowthPcRoomBuff(use);
            case 3000201 -> ItemUseConsumablesCases.handleSupportBuff(use);
            case MJCTLoadManager.CTSYSTEM_STORE_ID -> { MJCTHandler.store(pc, item, storedItemObjectId); yield ItemUseResult.COMPLETE; }
            case 600226, 3000235, 600227 -> ItemUseUtilityCases.handleStoreClassChange(use);
            case 40096 -> ItemUseTransformationCases.handlePolyScroll(use);
            case 3000467 -> ItemUseTransformationCases.handleEventPolyScroll(use);
            case 140088 -> ItemUseTransformationCases.handleBlessedPolyScroll(use);
            case 42655 -> ItemUseTransformationCases.handleTrainingPolyScroll(use);
            case 4100290 -> { usePolyPotion(pc, itemId); yield ItemUseResult.COMPLETE; }
            case 4100284, 4100285, 4100286, 4100287, 4100288, 4100289, 4200100, 4200400,
                    5922901, 41143, 41144, 41145, 30057, 30058, 30059, 8000,
                    8001, 8002 -> ItemUseTransformationCases.handlePolyPotion(use);
            case 210097, 210098, 210099, 210100, 210101, 210102, 210103, 210116,
                    210117 -> ItemUseTransformationCases.handleLevelPolyScroll(use);
            case 40317, 30087 -> ItemUseQuestCases.handleCombineMapFragments(use);
            case 210073, 210077, 500205, 500207 -> ItemUseQuestCases.handleCombineTreasureFragments(use);
            case 40126, 40098 -> ItemUseUtilityCases.handleIdentifyItem(use);
            case 41048, 41049, 41050, 41051, 41052, 41053, 41054, 41055,
                    41056, 41057 -> ItemUseQuestCases.handleVoucher(use);
            case 40931, 40932, 40933, 40934, 40935, 40936, 40937, 40938,
                    40939, 40940, 40941, 40942 -> ItemUseQuestCases.handleBagCollection(use);
            case 40943, 40944, 40945, 40946, 40947, 40948, 40949, 40950,
                    40951, 40952, 40953, 40954, 40955, 40956, 40957, 40958 -> ItemUseQuestCases.handleMixedBagCollection(use);
            case 41029 -> ItemUseQuestCases.handleSummonFragments(use);
            case 40090, 40091, 40092, 40093, 40094 -> ItemUseUtilityCases.handleWriteBlankScroll(use);
            case 40314, 40316 -> ItemUseUtilityCases.handlePlayRaceFlute(use);
            case 40315 -> ItemUseUtilityCases.handleSpecialFlute(use);
            case 40089, 140089, 30074 -> ItemUseTravelCases.handleTeleportCompanions(use);
            case 40095, 40079, 40521 -> { DominationTowerReturnHandler.getInstance().handleReturn(pc, item); yield ItemUseResult.COMPLETE; }
            case 41159, 41921 -> ItemUseTravelCases.handleReturnFromSpecialMap(use);
            case 40117 -> { yield ItemUseResult.COMPLETE; }
            case 40099, 40100, 40086, 40863, 140100, 150100 -> { TeleportUseService.clickItem(pc, itemId, bookmarkX, bookmarkY, bookmarkMapId, item); yield ItemUseResult.COMPLETE; }
            case 830001, 830002, 830003, 830004, 830005, 830006, 830007, 830008,
                    830009, 830010, 830011 -> { OmanTowerTeleportHandler.getInstance().clickItem(pc, itemId, item); yield ItemUseResult.COMPLETE; }
            case 830012, 830013, 830014, 830015, 830016, 830017, 830018, 830019,
                    830020, 830021, 830022, 830023, 830024, 830025, 830026, 830027,
                    830028, 830029, 830030, 830031 -> { OmanAmuletHandler.getInstance().clickItem(pc, itemId); yield ItemUseResult.COMPLETE; }
            case 830042, 830043, 830044, 830045, 830046, 830047, 830048, 830049,
                    830050, 830051, 830052, 830053, 830054, 830055, 830056, 830057,
                    830058, 830059, 830060, 830061 -> { OmanRandomAmulet.clickItem(pc, itemId, item); yield ItemUseResult.COMPLETE; }
            case 40901, 40902, 40903, 40904, 40905, 40906, 40907, 40908 -> ItemUseUtilityCases.handleEngagementRing(use);
            case 40555 -> ItemUseQuestCases.handleKnightQuest(use);
            case 40572 -> ItemUseQuestCases.handleQuestTeleport(use);
            case 700022 -> ItemUseQuestCases.handleMarkReward(use);
            case 40420, 40421, 40422, 40423 -> ItemUseQuestCases.handleCombineAncientBooks(use);
            case 3000455, 30104 -> ItemUseConsumablesCases.handleComaCoin(use);
            case 4100080, 7020, 7021 -> { additem2.clickItem(pc, itemId, item); yield ItemUseResult.COMPLETE; }
            case 60036, 60037, 60038, 60039, 60040 -> { additem.clickItem(pc, itemId, item); yield ItemUseResult.COMPLETE; }
            case 60041, 60042, 60043, 60044, 60045 -> { additem.clickItem(pc, itemId, item); yield ItemUseResult.COMPLETE; }
            case 68078, 68079, 68080, 68081, 68082 -> { additem.clickItem(pc, itemId, item); yield ItemUseResult.COMPLETE; }
            case 68083, 68084, 68085, 68086, 68087 -> { additem.clickItem(pc, itemId, item); yield ItemUseResult.COMPLETE; }
            case 68088, 68089, 68090, 68091, 68092 -> { additem.clickItem(pc, itemId, item); yield ItemUseResult.COMPLETE; }
            case 30124 -> { SC_SystemMessage.send(pc, "공성전 시 투석기를 사용할 때 필요한 소모성 아이템"); yield ItemUseResult.COMPLETE; }
            case 500218 -> ItemUseConsumablesCases.handleKarmaPotion(use);
            case 40008, 140008, 40410 -> ItemUseTravelCases.handleResurrectionScroll(use);
            case 40289, 40290, 40291, 40292, 40293, 40294, 40295, 40296,
                    40297 -> { useToiTeleportAmulet(pc, itemId, item); yield ItemUseResult.COMPLETE; }
            case 40280, 40281, 40282, 40283, 40284, 40285, 40286, 40287,
                    40288, 830032, 830033, 830034, 830035, 830036, 830037, 830038,
                    830039, 830040, 830041 -> { ItemUseEconomyRewards.exchangeLegacyItem(pc, item); yield ItemUseResult.COMPLETE; }
            case 40056, 40057, 40059, 40060, 40061, 40062, 40063, 40064,
                    40065, 40069, 40072, 40073, 41297, 49092, 41266, 41267,
                    41274, 41275, 41276, 41252, 49040, 49041, 49042, 49043,
                    49044, 49045, 49046, 49047, 140061, 140062, 140065, 140069,
                    140072, 410056, 210039, 30085 -> ItemUseConsumablesCases.handleFood(use);
            case 77799 -> ItemUseRewardsCases.handleClassPackage(use);
            case 408991 -> ItemUseUtilityCases.handleRequestNameChange(use);
            case 41146 -> { SC_NPCTalkReturn.send(pc, pc.getId(), "ei001"); yield ItemUseResult.COMPLETE; }
            case 41209 -> { SC_NPCTalkReturn.send(pc, pc.getId(), "ei002"); yield ItemUseResult.COMPLETE; }
            case 41210 -> { SC_NPCTalkReturn.send(pc, pc.getId(), "ei003"); yield ItemUseResult.COMPLETE; }
            case 41211 -> { SC_NPCTalkReturn.send(pc, pc.getId(), "ei004"); yield ItemUseResult.COMPLETE; }
            case 41212 -> { SC_NPCTalkReturn.send(pc, pc.getId(), "ei005"); yield ItemUseResult.COMPLETE; }
            case 41213 -> { SC_NPCTalkReturn.send(pc, pc.getId(), "ei006"); yield ItemUseResult.COMPLETE; }
            case 41214 -> { SC_NPCTalkReturn.send(pc, pc.getId(), "ei012"); yield ItemUseResult.COMPLETE; }
            case 41215 -> { SC_NPCTalkReturn.send(pc, pc.getId(), "ei010"); yield ItemUseResult.COMPLETE; }
            case 41216 -> { SC_NPCTalkReturn.send(pc, pc.getId(), "ei011"); yield ItemUseResult.COMPLETE; }
            case 41222 -> { SC_NPCTalkReturn.send(pc, pc.getId(), "ei008"); yield ItemUseResult.COMPLETE; }
            case 41223 -> { SC_NPCTalkReturn.send(pc, pc.getId(), "ei007"); yield ItemUseResult.COMPLETE; }
            case 41224 -> { SC_NPCTalkReturn.send(pc, pc.getId(), "ei009"); yield ItemUseResult.COMPLETE; }
            case 41225 -> { SC_NPCTalkReturn.send(pc, pc.getId(), "ei013"); yield ItemUseResult.COMPLETE; }
            case 41226 -> { SC_NPCTalkReturn.send(pc, pc.getId(), "ei014"); yield ItemUseResult.COMPLETE; }
            case 41227 -> { SC_NPCTalkReturn.send(pc, pc.getId(), "ei033"); yield ItemUseResult.COMPLETE; }
            case 41228 -> { SC_NPCTalkReturn.send(pc, pc.getId(), "ei034"); yield ItemUseResult.COMPLETE; }
            case 41229 -> { SC_NPCTalkReturn.send(pc, pc.getId(), "ei025"); yield ItemUseResult.COMPLETE; }
            case 41230 -> { SC_NPCTalkReturn.send(pc, pc.getId(), "ei020"); yield ItemUseResult.COMPLETE; }
            case 41231 -> { SC_NPCTalkReturn.send(pc, pc.getId(), "ei021"); yield ItemUseResult.COMPLETE; }
            case 41233 -> { SC_NPCTalkReturn.send(pc, pc.getId(), "ei019"); yield ItemUseResult.COMPLETE; }
            case 41234 -> { SC_NPCTalkReturn.send(pc, pc.getId(), "ei023"); yield ItemUseResult.COMPLETE; }
            case 41235 -> { SC_NPCTalkReturn.send(pc, pc.getId(), "ei024"); yield ItemUseResult.COMPLETE; }
            case 41239 -> { SC_NPCTalkReturn.send(pc, pc.getId(), "ei018"); yield ItemUseResult.COMPLETE; }
            case 41240 -> { SC_NPCTalkReturn.send(pc, pc.getId(), "ei022"); yield ItemUseResult.COMPLETE; }
            case 41060 -> { SC_NPCTalkReturn.send(pc, pc.getId(), "nonames"); yield ItemUseResult.COMPLETE; }
            case 41061 -> { SC_NPCTalkReturn.send(pc, pc.getId(), "kames"); yield ItemUseResult.COMPLETE; }
            case 41062 -> { SC_NPCTalkReturn.send(pc, pc.getId(), "bakumos"); yield ItemUseResult.COMPLETE; }
            case 41063 -> { SC_NPCTalkReturn.send(pc, pc.getId(), "bukas"); yield ItemUseResult.COMPLETE; }
            case 41064 -> { SC_NPCTalkReturn.send(pc, pc.getId(), "huwoomos"); yield ItemUseResult.COMPLETE; }
            case 41065 -> { SC_NPCTalkReturn.send(pc, pc.getId(), "noas"); yield ItemUseResult.COMPLETE; }
            case 41356 -> { SC_NPCTalkReturn.send(pc, pc.getId(), "rparum3"); yield ItemUseResult.COMPLETE; }
            case 40701 -> ItemUseQuestCases.handleLukeinRecord(use);
            case 40663 -> { SC_NPCTalkReturn.send(pc, pc.getId(), "sonsletter"); yield ItemUseResult.COMPLETE; }
            case 40630 -> { SC_NPCTalkReturn.send(pc, pc.getId(), "diegodiary"); yield ItemUseResult.COMPLETE; }
            case 41340 -> { SC_NPCTalkReturn.send(pc, pc.getId(), "tion"); yield ItemUseResult.COMPLETE; }
            case 41317 -> { SC_NPCTalkReturn.send(pc, pc.getId(), "rarson"); yield ItemUseResult.COMPLETE; }
            case 41318 -> { SC_NPCTalkReturn.send(pc, pc.getId(), "kuen"); yield ItemUseResult.COMPLETE; }
            case 41329 -> { SC_NPCTalkReturn.send(pc, pc.getId(), "anirequest"); yield ItemUseResult.COMPLETE; }
            case 41346 -> { SC_NPCTalkReturn.send(pc, pc.getId(), "robinscroll"); yield ItemUseResult.COMPLETE; }
            case 41347 -> { SC_NPCTalkReturn.send(pc, pc.getId(), "robinscroll2"); yield ItemUseResult.COMPLETE; }
            case 41348 -> { SC_NPCTalkReturn.send(pc, pc.getId(), "robinhood"); yield ItemUseResult.COMPLETE; }
            case 41007 -> { SC_NPCTalkReturn.send(pc, pc.getId(), "erisscroll"); yield ItemUseResult.COMPLETE; }
            case 41009 -> { SC_NPCTalkReturn.send(pc, pc.getId(), "erisscroll2"); yield ItemUseResult.COMPLETE; }
            case 41019 -> { SC_NPCTalkReturn.send(pc, pc.getId(), "lashistory1"); yield ItemUseResult.COMPLETE; }
            case 41020 -> { SC_NPCTalkReturn.send(pc, pc.getId(), "lashistory2"); yield ItemUseResult.COMPLETE; }
            case 41021 -> { SC_NPCTalkReturn.send(pc, pc.getId(), "lashistory3"); yield ItemUseResult.COMPLETE; }
            case 41022 -> { SC_NPCTalkReturn.send(pc, pc.getId(), "lashistory4"); yield ItemUseResult.COMPLETE; }
            case 41023 -> { SC_NPCTalkReturn.send(pc, pc.getId(), "lashistory5"); yield ItemUseResult.COMPLETE; }
            case 41024 -> { SC_NPCTalkReturn.send(pc, pc.getId(), "lashistory6"); yield ItemUseResult.COMPLETE; }
            case 41025 -> { SC_NPCTalkReturn.send(pc, pc.getId(), "lashistory7"); yield ItemUseResult.COMPLETE; }
            case 41026 -> { SC_NPCTalkReturn.send(pc, pc.getId(), "lashistory8"); yield ItemUseResult.COMPLETE; }
            case 210087 -> { SC_NPCTalkReturn.send(pc, pc.getId(), "first_p"); yield ItemUseResult.COMPLETE; }
            case 210093 -> { SC_NPCTalkReturn.send(pc, pc.getId(), "silrein1lt"); yield ItemUseResult.COMPLETE; }
            case 410106 -> { SC_NPCTalkReturn.send(pc, pc.getId(), "j_ep0s00"); yield ItemUseResult.COMPLETE; }
            case 410101 -> { SC_NPCTalkReturn.send(pc, pc.getId(), "j_ep0s01"); yield ItemUseResult.COMPLETE; }
            case 410103 -> { SC_NPCTalkReturn.send(pc, pc.getId(), "j_ep0s02"); yield ItemUseResult.COMPLETE; }
            case 410105 -> { SC_NPCTalkReturn.send(pc, pc.getId(), "j_ep0s03"); yield ItemUseResult.COMPLETE; }
            case 410098 -> { SC_NPCTalkReturn.send(pc, pc.getId(), "j_ep0s04"); yield ItemUseResult.COMPLETE; }
            case 410099 -> { SC_NPCTalkReturn.send(pc, pc.getId(), "j_ep0s05"); yield ItemUseResult.COMPLETE; }
            case 410100 -> { SC_NPCTalkReturn.send(pc, pc.getId(), "j_ep0s06"); yield ItemUseResult.COMPLETE; }
            case 410097 -> { SC_NPCTalkReturn.send(pc, pc.getId(), "j_ep0s07"); yield ItemUseResult.COMPLETE; }
            case 410102 -> { SC_NPCTalkReturn.send(pc, pc.getId(), "j_ep0s08"); yield ItemUseResult.COMPLETE; }
            case 410104 -> { SC_NPCTalkReturn.send(pc, pc.getId(), "j_ep0s09"); yield ItemUseResult.COMPLETE; }
            case 410107 -> { SC_NPCTalkReturn.send(pc, pc.getId(), "j_ep0s10"); yield ItemUseResult.COMPLETE; }
            case 42501 -> { pc.start_teleport(spellTargetX, spellTargetY, pc.getMapId(), pc.getHeading(), 169, false, pc.getAutoHunt()); yield ItemUseResult.COMPLETE; }
            case 41293, 41294, 41305, 41306, 4100293, 4200293, 600229, 87058,
                    87059, 9991 -> ItemUseUtilityCases.handleStartFishing(use);
            case 7024 -> ItemUseUtilityCases.handleFishingRod(use);
            case 200000 -> ItemUseUtilityCases.handleResetStats(use);
            case 3000049 -> { SC_SystemMessage.send(pc, "아덴 성당에서 경험치를 무료로 복구할 수 있습니다."); yield ItemUseResult.COMPLETE; }
            case 3000124 -> ItemUseUtilityCases.handleSummonMonster(use);
            case 210118 -> ItemUseUtilityCases.handleJoinProtectedClan(use);
            case 7643 -> ItemUseConsumablesCases.handleMembershipBuff(use);
            case 400253, 875640445 -> ItemUseRewardsCases.handleConvertAdena(use);
            case 875640295 -> ItemUseRewardsCases.handleUnlockCollection(use);
            case 875640296, 875640297, 875640298, 875640299, 875640300, 875640301, 875640302, 875640303,
                    875640304, 875640305, 875640380 -> ItemUseRewardsCases.handleSelectCollection(use);
            case 875640306, 875640307, 875640308, 875640309, 875640310, 875640311, 875640312, 875640313,
                    875640314 -> ItemUseRewardsCases.handleSelectCollectionGroup2(use);
            case 875640365, 875640366, 875640367, 875640368, 875640369, 875640370, 875640371, 875640372,
                    875640373, 875640374, 875640375, 875640376, 875640377, 875640378 -> ItemUseRewardsCases.handleSelectCollectionGroup3(use);
            case 875640315, 875640316, 875640317, 875640318, 875640319, 875640320, 875640321, 875640322,
                    875640323, 875640324, 875640325, 875640326, 875640327, 875640328, 875640329, 875640330 -> ItemUseRewardsCases.handleSelectCollectionGroup4(use);
            case 875640345, 875640346, 875640347, 875640348, 875640349, 875640350, 875640351, 875640352,
                    875640353, 875640354, 875640355, 875640356, 875640357, 875640358, 875640359, 875640360,
                    875640361, 875640362, 875640363, 875640364 -> ItemUseRewardsCases.handleSelectCollectionGroup5(use);
            case 875640331, 875640332, 875640333, 875640334, 875640335, 875640336, 875640337, 875640338,
                    875640339, 875640340, 875640341, 875640446, 875640447, 875640448 -> ItemUseRewardsCases.handleSelectCollectionGroup6(use);
            case 700081 -> { 군주광역스턴(pc); yield ItemUseResult.COMPLETE; }
            case 600228 -> ItemUseUtilityCases.handleUpgradeFishingReel(use);
            case 123123 -> ItemUseRewardsCases.handleOpenAdminPackage(use);
            case 3000063 -> { ItemUseEconomyRewards.exchangeLegacyItem(pc, item); yield ItemUseResult.COMPLETE; }
            case 110002 -> ItemUseEnchantCases.handleDollPotential(use);
            case 7010 -> { 무기축복(pc, item, targetItem); yield ItemUseResult.COMPLETE; }
            case 7011 -> { 무기축복100(pc, item, targetItem); yield ItemUseResult.COMPLETE; }
            case 8010 -> { 악세인챈(pc, item, targetItem); yield ItemUseResult.COMPLETE; }
            case 8011 -> { 악세인챈100(pc, item, targetItem); yield ItemUseResult.COMPLETE; }
            case 5922910 -> { 방어구축복(pc, item, targetItem); yield ItemUseResult.COMPLETE; }
            case 5922911 -> { 방어구축복100(pc, item, targetItem); yield ItemUseResult.COMPLETE; }
            case 622910 -> { 옵션부여(pc, item, targetItem); yield ItemUseResult.COMPLETE; }
            case 633910 -> { 품질부여주문서(pc, item, targetItem); yield ItemUseResult.COMPLETE; }
            case 885544 -> { 집행진화주문서(pc, item, targetItem); yield ItemUseResult.COMPLETE; }
            case 65648 -> { UseDurableConsume(pc, item, () -> { if (pc.hasSkillEffect(L1SkillId.God_buff)) { pc.removeSkillEffect(L1SkillId.God_buff); } L1SkillUse.cast(pc, L1SkillId.God_buff, pc.getId(), pc.getX(), pc.getY(), null, 0, L1SkillUse.TYPE_GMBUFF); }); yield ItemUseResult.COMPLETE; }
            case 40879 -> { UseDurableConsume(pc, item, () -> { if (pc.hasSkillEffect(L1SkillId.BLESSED_ARMOR)) { pc.removeSkillEffect(L1SkillId.BLESSED_ARMOR); } L1SkillUse.cast(pc, L1SkillId.BLESSED_ARMOR, pc.getId(), pc.getX(), pc.getY(), null, 0, L1SkillUse.TYPE_GMBUFF); }); yield ItemUseResult.COMPLETE; }
            case 40870 -> ItemUseConsumablesCases.handleBlessWeaponScroll(use);
            case 3000210 -> ItemUseRewardsCases.handleOpenExperienceBox(use);
            case 400254, 500254, 600254 -> ItemUseRewardsCases.handleExchangeAdenaVoucher(use);
            case 41245 -> ItemUseEnchantCases.handleResolvent(use);
            case 442455 -> ItemUseEnchantCases.handleDragonResolvent(use);
            case 41303 -> ItemUseRewardsCases.handleOpenLegacyGift(use);
            case 46161 -> { serchdroplist2(pc, spellTargetId, item); yield ItemUseResult.COMPLETE; }
            case 41304 -> ItemUseRewardsCases.handleOpenLegacyGiftGroup2(use);
            case 51093, 51094, 51095, 51096, 51097, 51098, 51099, 51100 -> { ClassChange.usePotion(pc, item); yield ItemUseResult.COMPLETE; }
            case 400246 -> ItemUseConsumablesCases.handleLevelBuff(use);
            case 410009 -> ItemUseConsumablesCases.handleFoodBuff(use);
            case 773355 -> { UseDurableConsume(pc, item, () -> { if (pc.hasSkillEffect(L1SkillId.루돌프의버프)) { pc.removeSkillEffect(L1SkillId.루돌프의버프); } pc.setSkillEffect(L1SkillId.루돌프의버프, 3600 * 1000); pc.getAbility().addAddedWis((byte) 1); SC_InventoryIcon.icoNew(pc, L1SkillId.루돌프의버프, 5087, 3600, true); }); yield ItemUseResult.COMPLETE; }
            case 560025, 560027, 560028, 560029, 4100135 -> { TelBook.clickItem(pc, itemId, teleportBookSlot, item); yield ItemUseResult.COMPLETE; }
            case 41248, 41249, 41250, 210070, 210071, 210072, 210086, 210096,
                    210105, 210106, 210107, 210108, 210109, 500212, 500213, 500214,
                    500215, 447012, 447013, 447014, 30022, 30023, 30024, 30025,
                    447015, 447016, 447017, 510216, 510217, 510218, 510219, 510220,
                    510221, 510222, 410172, 410173, 4100007, 4100008, 4100009, 4100010,
                    740, 741, 742, 743, 744, 745, 746, 750,
                    3000086, 3000087, 3000088, 3000351, 3000352, 42654, 755, 756,
                    757, 758, 759, 760, 761, 772, 773, 774,
                    775, 4100134, 4200010, 4200020, 4200030, 4200040, 4200050, 4200060,
                    950000, 950001, 950002, 950003, 950004, 950005, 950006, 950007,
                    950008, 950009, 950010, 950011, 950012, 950013, 950014, 950015,
                    950016, 950017, 950018, 950019, 4200051 -> { MagicDoll.useMagicDoll(pc, item); yield ItemUseResult.COMPLETE; }
            case 410014 -> { useNpcSpownWand(pc, 60001, item); yield ItemUseResult.COMPLETE; }
            case 4100254 -> { use_bug_down_wand(pc, spellTargetId, item); yield ItemUseResult.COMPLETE; }
            case 46160 -> { useFieldObjectRemovalWand(pc, spellTargetId, item); yield ItemUseResult.COMPLETE; }
            case 46162 -> { useFieldObjectRemovalWand1(pc, spellTargetId, item); yield ItemUseResult.COMPLETE; }
            case 220012 -> { 매직실드(pc); yield ItemUseResult.COMPLETE; }
            case 994411 -> { 투견조작(pc, spellTargetId, item); yield ItemUseResult.COMPLETE; }
            case 44114 -> { 전투지휘봉(pc, spellTargetId, item); yield ItemUseResult.COMPLETE; }
            case 70721 -> { 콜어드밴스(pc, spellTargetId, item); yield ItemUseResult.COMPLETE; }
            case 90088 -> { 비전텔레포트(pc, spellTargetX, spellTargetY); yield ItemUseResult.COMPLETE; }
            case 80888 -> { 이터니티(pc, spellTargetId, item); yield ItemUseResult.COMPLETE; }
            case 70888 -> { 엘븐스트라이크(pc, spellTargetId, item); yield ItemUseResult.COMPLETE; }
            case 875640444 -> ItemUseConsumablesCases.handleDragonSkill(use);
            case 707777 -> { 쉐도우(pc, spellTargetId, item); yield ItemUseResult.COMPLETE; }
            case 707779 -> { 어벤저(pc, spellTargetId, item); yield ItemUseResult.COMPLETE; }
            case 707781 -> { 데몰리션(pc, spellTargetId, item); yield ItemUseResult.COMPLETE; }
            case 410015 -> { useNpcSpownWand(pc, 70030, item); yield ItemUseResult.COMPLETE; }
            case 4000138, 4000139, 4000140, 4000141, 4000142, 4000143, 4000144 -> { SC_MessageYN.send(pc, 944,"드래곤볼"); yield ItemUseResult.COMPLETE; }
            case 41345 -> ItemUseConsumablesCases.handleHolyWater(use);
            case 41315 -> ItemUseConsumablesCases.handleHolyWaterOfEva(use);
            case 30055, 3000425, 711 -> { ItemUseAreaDamage.use(pc, item, spellTargetId, itemId); yield ItemUseResult.COMPLETE; }
            case 30071 -> { ItemUseEquipmentRewards.openStarterKit(pc, item); yield ItemUseResult.COMPLETE; }
            case 700024 -> { L1BookMark.Bookmarkitem(pc, item, itemId, false); yield ItemUseResult.COMPLETE; }
            case 3000065, 3000256, 3110509, 3000509, 4100446 -> { MJItemEnchanterLoader.getInstance().do_enchant(pc, item, targetItem); yield ItemUseResult.COMPLETE; }
            case 5558 -> { 정상의가호(pc, item); yield ItemUseResult.COMPLETE; }
            case 55558 -> { 정상의가호2(pc, item); yield ItemUseResult.COMPLETE; }
            case 30116 -> { ItemUseEquipmentRewards.exchangePureShirt(pc, item, targetItem); yield ItemUseResult.COMPLETE; }
            case 560030, 560031, 560032, 560033, 40130, 140130, L1ItemId.SCROLL_OF_ENCHANT_WEAPON, L1ItemId.SCROLL_OF_ENCHANT_QUEST_WEAPON,
                    L1ItemId.SCROLL_OF_ENCHANT_FANTASY_WEAPON, L1ItemId.B_SCROLL_OF_ENCHANT_WEAPON, L1ItemId.C_SCROLL_OF_ENCHANT_WEAPON, L1ItemId.IVORYTOWER_WEAPON_SCROLL, L1ItemId.ENCHANT_WEAPONA, 210085, 210064, 724,
                    210065, 210066, 210067, 310064, 310065, 310066, 310067, 310068,
                    810003, 4100148, 127000, 68076, 30146, 30068 -> ItemUseWeaponEnchantCases.use(use);
            case L1ItemId.SCROLL_OF_ENCHANT_ARMOR, L1ItemId.SCROLL_OF_ENCHANT_ARMOR4, L1ItemId.B_SCROLL_OF_ENCHANT_ARMOR5, L1ItemId.C_SCROLL_OF_ENCHANT_ARMOR6, L1ItemId.SCROLL_OF_ENCHANT_FANTASY_ARMOR, L1ItemId.B_SCROLL_OF_ENCHANT_ARMOR, L1ItemId.C_SCROLL_OF_ENCHANT_ARMOR, L1ItemId.ENCHANT_ARMOR,
                    L1ItemId.Inadril_T_ScrollA, L1ItemId.Inadril_T_ScrollB, L1ItemId.Inadril_T_ScrollC, L1ItemId.Pure_white_Scroll, L1ItemId.Roomtis_Scroll, L1ItemId.IVORYTOWER_ARMOR_SCROLL, L1ItemId.IVORYTOWER_GKFFHDNLS, L1ItemId.Inadril_T_ScrollA1,
                    L1ItemId.Inadril_T_ScrollB2, L1ItemId.Inadril_T_ScrollB3, L1ItemId.ENCHANT_TEST1, L1ItemId.ENCHANT_TEST2, L1ItemId.ENCHANT_TEST3, L1ItemId.ENCHANT_TEST4, L1ItemId.ENCHANT_TEST5, L1ItemId.ENCHANT_TEST6,
                    L1ItemId.ENCHANT_TEST33, L1ItemId.ENCHANT_TEST11, L1ItemId.ENCHANT_TEST22, L1ItemId.ENCHANT_TEST44, L1ItemId.ENCHANT_TEST55, 7004, 40129, 140129,
                    210084, 3000100, 4000517, 5991, 3000517, 210068, 68077, 98077,
                    3000380, 30069, 810012, 810013, 30147 -> ItemUseArmorEnchantCases.use(use);
            default -> ItemUseDefaultCases.use(use);
        };
    }
}
