package l1j.server.server.model.item.function;

import l1j.server.Config;
import l1j.server.server.model.Instance.L1ItemInstance;
import l1j.server.server.model.Instance.L1PcInstance;
import l1j.server.server.utils.CommonUtil;
import static l1j.server.server.model.item.function.ItemUseDurable.UseDurableConsumeTwoInput;
import static l1j.server.server.model.item.function.ItemUseDurable.UseDurableTwoInput;
import static l1j.server.server.model.item.function.ItemUseSpecialEnchant.isOwnedScrollTarget;
import static l1j.server.server.model.item.function.ItemUseWorldHelpers.useResolvent;

/** Item-specific Enchant effects; selected once by ItemUseDispatcher. */
final class ItemUseEnchantCases {
    private ItemUseEnchantCases() {}

    static ItemUseResult handleDollPotential(ItemUseContext use) {
        L1PcInstance pc = use.player();
        L1ItemInstance item = use.item();
        L1ItemInstance targetItem = use.targetItem();
        {
            if (!isOwnedScrollTarget(pc, item, targetItem)
                    || targetItem.getItemId() != 22208) return ItemUseResult.COMPLETE;
            final String upgradeName = targetItem.getName();
            if (CommonUtil.random(100) < Config.방어구비법서확률) {
                UseDurableTwoInput(pc, item, targetItem,
                        922208, () -> pc.sendPackets("강화에 성공하여 " + upgradeName + "이 강렬하게 빛납니다. "));
            } else {
                UseDurableConsumeTwoInput(pc, item, targetItem,
                        () -> pc.sendPackets("강화에 실패하여 " + upgradeName + "이 증발 하였습니다. "));
            }
            return ItemUseResult.COMPLETE;
        }
    }

    static ItemUseResult handleResolvent(ItemUseContext use) {
        L1PcInstance pc = use.player();
        L1ItemInstance item = use.item();
        L1ItemInstance targetItem = use.targetItem();
        CItemUse.useResolvent(pc, targetItem, item);
        return ItemUseResult.STOP;
    }

    static ItemUseResult handleDragonResolvent(ItemUseContext use) {
        L1PcInstance pc = use.player();
        L1ItemInstance item = use.item();
        L1ItemInstance targetItem = use.targetItem();
        CItemUse.useDragonResolvent(pc, targetItem, item);
        return ItemUseResult.STOP;
    }
}
