package l1j.server.server.model.item.function;


import l1j.server.server.model.network.core.sc.packet.SC_SPMR;

import l1j.server.server.model.network.core.sc.packet.SC_MpUpdate;
import l1j.server.server.model.network.core.sc.packet.SC_SkillSound;
import l1j.server.server.model.network.core.sc.packet.SC_HpUpdate;
import static l1j.server.server.model.character.skill.L1SkillId.CURSE_BLIND;
import static l1j.server.server.model.character.skill.L1SkillId.DANCING_BLADES;
import static l1j.server.server.model.character.skill.L1SkillId.DARKNESS;
import static l1j.server.server.model.character.skill.L1SkillId.DECAY_POTION;
import static l1j.server.server.model.character.skill.L1SkillId.EXP_POTION;
import static l1j.server.server.model.character.skill.L1SkillId.FOCUS_WAVE;
import static l1j.server.server.model.character.skill.L1SkillId.GREATER_HASTE;
import static l1j.server.server.model.character.skill.L1SkillId.HASTE;
import static l1j.server.server.model.character.skill.L1SkillId.HOLY_WALK;
import static l1j.server.server.model.character.skill.L1SkillId.HURRICANE;
import static l1j.server.server.model.character.skill.L1SkillId.LINDBIOR_SPIRIT_EFFECT;
import static l1j.server.server.model.character.skill.L1SkillId.MOVING_ACCELERATION;
import static l1j.server.server.model.character.skill.L1SkillId.SAND_STORM;
import static l1j.server.server.model.character.skill.L1SkillId.SLOW;
import static l1j.server.server.model.character.skill.L1SkillId.STATUS_BLUE_POTION;
import static l1j.server.server.model.character.skill.L1SkillId.STATUS_BLUE_POTION2;
import static l1j.server.server.model.character.skill.L1SkillId.STATUS_BRAVE;
import static l1j.server.server.model.character.skill.L1SkillId.STATUS_CASHSCROLL;
import static l1j.server.server.model.character.skill.L1SkillId.STATUS_CASHSCROLL2;
import static l1j.server.server.model.character.skill.L1SkillId.STATUS_CASHSCROLL3;
import static l1j.server.server.model.character.skill.L1SkillId.STATUS_CASHSCROLL4;
import static l1j.server.server.model.character.skill.L1SkillId.STATUS_CASHSCROLL5;
import static l1j.server.server.model.character.skill.L1SkillId.STATUS_CASHSCROLL6;
import static l1j.server.server.model.character.skill.L1SkillId.STATUS_ELFBRAVE;
import static l1j.server.server.model.character.skill.L1SkillId.STATUS_FLOATING_EYE;
import static l1j.server.server.model.character.skill.L1SkillId.STATUS_FRUIT;
import static l1j.server.server.model.character.skill.L1SkillId.STATUS_HASTE;
import static l1j.server.server.model.character.skill.L1SkillId.STATUS_UNDERWATER_BREATH;
import static l1j.server.server.model.character.skill.L1SkillId.STATUS_WISDOM_POTION;

import l1j.server.server.model.Instance.L1ItemInstance;
import l1j.server.server.model.Instance.L1PcInstance;
import l1j.server.server.model.character.skill.L1SkillId;
import l1j.server.server.model.item.L1ItemId;


import l1j.server.server.model.network.core.sc.packet.SC_InventoryIcon;

import l1j.server.server.model.network.core.sc.packet.SC_ServerMessage;
import l1j.server.server.model.network.core.sc.packet.SC_SystemMessage;

import l1j.server.server.model.network.core.sc.packet.SC_SkillBrave;
import l1j.server.server.model.network.core.sc.packet.SC_SkillHaste;
import l1j.server.server.model.network.core.sc.packet.SC_SkillIconWisdomPotion;
import l1j.server.server.model.network.core.sc.packet.SC_SkillIconBlessOfEva;
import l1j.server.server.model.network.core.sc.packet.SC_SkillIconGFX;
import l1j.server.server.model.network.core.sc.packet.SC_CurseBlind;



import static l1j.server.server.model.item.function.ItemUseEnchantments.*;
import static l1j.server.server.model.item.function.ItemUseTransformation.*;
import static l1j.server.server.model.item.function.ItemUseSpellBooks.*;
import static l1j.server.server.model.item.function.ItemUseWorldHelpers.*;
import static l1j.server.server.model.item.function.ItemUseSpecialEnchant.*;
import static l1j.server.server.model.item.function.ItemUseMiscActions.*;
import static l1j.server.server.model.item.function.ItemUseEquipment.*;
import static l1j.server.server.model.item.function.ItemUseDurable.*;
import static l1j.server.server.model.item.function.ItemUseCombatAbilities.*;
import static l1j.server.server.model.item.function.ItemUseDollEffects.*;

import static l1j.server.server.model.item.function.ItemUseCreature.*;

public final class ItemUsePotions {
	private ItemUsePotions() {}
	// true means the original item-use command returned before its delay bookkeeping.
	public static boolean usePotionCase(L1PcInstance pc, L1ItemInstance l1iteminstance, int itemId) {
		switch (itemId) {
		case 7007:
		case 40010:
		case 40011:
		case 40012:
		case 4100021:
		case 40019:
		case 40020:
		case 40021:
		case 40022:
		case 40023:
		case 40024:
		case 40026:
		case 40027:
		case 40028:
		case 40043:
		case 40058:
		case 40071:
		case 40506:
		case 40930:
		case 41141:
		case 41337:
		case 60029:
		case 60030:
		case 140010:
		case 140011:
		case 140012:
		case 140506:
		case 240010:
		case 41403:
		case 410000:
		case 410003:
		case 30062:
		case 30056:
		case 42658: // 전사의 체력 회복제
		case 40029:
		case 4100152:
		case 4100153:
		case 4100154:
			if (itemId == 30062) {
				if (!(pc.getMapId() >= 1005 && pc.getMapId() <= 1022
						|| pc.getMapId() > 6000 && pc.getMapId() < 6999)) {
					SC_ServerMessage.send(pc, 1891);
					return true;
				}
			}
			if (itemId == 30056) {
				if (!(pc.getMapId() >= 2101 && pc.getMapId() <= 2151
						|| pc.getMapId() >= 12152 && pc.getMapId() <= 12200)) {
					SC_SystemMessage.send(pc, "특정지역에서만 사용이 가능합니다.");
					return true;
				}
			}

			L1HealingPotion healingPotion = L1HealingPotion.get(itemId);
			if (healingPotion == null) {
				SC_ServerMessage.send(pc, 79);
				return true;
			}
			healingPotion.use(pc, l1iteminstance);
			break;
			// //////////////////////////////////////////////////////////////////////////////////////////
			/**************************
			 * 물약회복략 처리관련
			 ***********************************************/
			// /////////////////////////////////////////////////////////////////////////////////////////

		case 40858:// 술
			UseDurableConsume(pc, l1iteminstance, () -> pc.setDrink(true));
			break;
		case 708:
			UseDurableConsume(pc, l1iteminstance, () -> UseExpPotion1(pc, itemId));
			break;
		case 3000456:
		case 30105:// 전투의 물약
		case 210094:// 천상의 물약
			UseDurableConsume(pc, l1iteminstance, () -> UseExpPotion(pc, itemId));
			break;
		case 40030:
			useGreenPotion(pc, itemId);
			pc.getInventory().removeItem(l1iteminstance, 1);
			break;
		case 40013:
		case 7006:
		case 40018:
		case 40039:
		case 40040:
		case 41338:
		case 41261:
		case 41262:
		case 41268:
		case 41269:
		case 41271:
		case 41272:
		case 41273:
		case 41342:
		case 30067:
		case 140013:
		case 140018:
		case 30158:
		case 875640293:
			/*
			 * 초록 물약, 강화 초록 물약, 와인, 위스키, 상아탑의 속도향상 물약 축복받은 포도주, 주먹밥,
			 * 닭꼬치구이, 조각 피자, 옥수수구이 뻥튀기,오뎅, 와플, 메두사의 피, 용사의 속도 향상 물약,
			 */
			useGreenPotion(pc, itemId);
			pc.getInventory().removeItem(l1iteminstance, 1);
			break;
		case 40014:
		case 140014:
		case 41415:
			// 용기의 물약, 복지 용기의 물약, 상아탑의 용기의 물약
			if (pc.isKnight() || pc.isWarrior() || pc.isCrown()) {
				useBravePotion(pc, itemId);
				pc.getInventory().removeItem(l1iteminstance, 1);
			} else {
				SC_ServerMessage.send(pc, 79);
				// \f1 아무것도 일어나지 않았습니다.
			}
			break;
		case 30073:
			/*
			 * if (!(pc.getMapId() == 7783 || pc.getMapId() == 12152 ||
			 * pc.getMapId() == 12149 || pc.getMapId() == 3 ||
			 * pc.getMapId() == 12154 || pc.getMapId() == 12358 ||
			 * pc.getMapId() == 12153 || pc.getMapId() == 12146 ||
			 * pc.getMapId() == 12147 || pc.getMapId() == 12148 ||
			 * pc.getMapId() == 12258 || pc.getMapId() == 12150 ||
			 * pc.getMapId() == 12257 || pc.getMapId() == 12358)) {
			 * SC_SystemMessage.send(pc, 
			 * "클라우디아 맵에서만 사용이 가능합니다."); return; }
			 */
			// 용기의 물약, 복지 용기의 물약, 상아탑의 용기의 물약
			if (pc.isKnight() || pc.isWarrior() || pc.isCrown()) {
				useBravePotion(pc, itemId);
				pc.getInventory().removeItem(l1iteminstance, 1);
			} else {
				SC_ServerMessage.send(pc, 79);
				// \f1 아무것도 일어나지 않았습니다.
			}
			break;
		case 40068:
		case 140068:
		case 210110:
			// 엘븐 와퍼, 복지 엘븐 와퍼, 상아탑의 엘븐 와퍼
			if (pc.isElf()) {
				useBravePotion(pc, itemId);
				pc.getInventory().removeItem(l1iteminstance, 1);
			} else {
				SC_ServerMessage.send(pc, 79);
				// \f1 아무것도 일어나지 않았습니다.
			}
			break;
		case 30076:
			/*
			 * if (!(pc.getMapId() == 7783 || pc.getMapId() == 12152 ||
			 * pc.getMapId() == 12149 || pc.getMapId() == 3 ||
			 * pc.getMapId() == 12154 || pc.getMapId() == 12358 ||
			 * pc.getMapId() == 12153 || pc.getMapId() == 12146 ||
			 * pc.getMapId() == 12147 || pc.getMapId() == 12148 ||
			 * pc.getMapId() == 12258 || pc.getMapId() == 12150 ||
			 * pc.getMapId() == 12257 || pc.getMapId() == 12358)) {
			 * SC_SystemMessage.send(pc, 
			 * "클라우디아 맵에서만 사용이 가능합니다."); return; }
			 */
			// 엘븐 와퍼, 복지 엘븐 와퍼, 상아탑의 엘븐 와퍼
			if (pc.isElf()) {
				useBravePotion(pc, itemId);
				pc.getInventory().removeItem(l1iteminstance, 1);
			} else {
				SC_ServerMessage.send(pc, 79);
				// \f1 아무것도 일어나지 않았습니다.
			}
			break;
		case 712:
		case 40031:
			// 악마의 피, 상아탑의 악마의 피 , 복지 악마의피
			if (pc.isCrown()) {
				useBravePotion(pc, itemId);
				pc.getInventory().removeItem(l1iteminstance, 1);
			} else {
				SC_ServerMessage.send(pc, 79);
			}
			break;
		case 30075:
			/*
			 * if (!(pc.getMapId() == 7783 || pc.getMapId() == 12152 ||
			 * pc.getMapId() == 12149 || pc.getMapId() == 3 ||
			 * pc.getMapId() == 12154 || pc.getMapId() == 12358 ||
			 * pc.getMapId() == 12153 || pc.getMapId() == 12146 ||
			 * pc.getMapId() == 12147 || pc.getMapId() == 12148 ||
			 * pc.getMapId() == 12258 || pc.getMapId() == 12150 ||
			 * pc.getMapId() == 12257 || pc.getMapId() == 12358)) {
			 * SC_SystemMessage.send(pc, 
			 * "클라우디아 맵에서만 사용이 가능합니다."); return; }
			 */
			// 악마의 피, 상아탑의 악마의 피 , 복지 악마의피
			if (pc.isCrown()) {
				useBravePotion(pc, itemId);
				pc.getInventory().removeItem(l1iteminstance, 1);
			} else {
				SC_ServerMessage.send(pc, 79);
				// \f1 아무것도 일어나지 않았습니다.
			}
			break;
		case 713:
		case 210036:
			// 유그드라 열매, 상아탑의 유그드라 열매
			if (pc.isBlackwizard()) {
				useFruit(pc, itemId);
				pc.getInventory().removeItem(l1iteminstance, 1);
			} else {
				SC_ServerMessage.send(pc, 79);// \f1 아무것도 일어나지
				// 않았습니다.
			}
			break;
		case 30077:
			/*
			 * if (!(pc.getMapId() == 7783 || pc.getMapId() == 12152 ||
			 * pc.getMapId() == 12149 || pc.getMapId() == 3 ||
			 * pc.getMapId() == 12154 || pc.getMapId() == 12358 ||
			 * pc.getMapId() == 12153 || pc.getMapId() == 12146 ||
			 * pc.getMapId() == 12147 || pc.getMapId() == 12148 ||
			 * pc.getMapId() == 12258 || pc.getMapId() == 12150 ||
			 * pc.getMapId() == 12257 || pc.getMapId() == 12358)) {
			 * SC_SystemMessage.send(pc, 
			 * "클라우디아 맵에서만 사용이 가능합니다."); return; }
			 */
			// 유그드라 열매, 상아탑의 유그드라 열매
			if (pc.isBlackwizard()) {
				useFruit(pc, itemId);
				pc.getInventory().removeItem(l1iteminstance, 1);
			} else {
				SC_ServerMessage.send(pc, 79);// \f1 아무것도 일어나지
				// 않았습니다.
			}
			break;
		case 40733:// 명예의 코인
			useBravePotion(pc, itemId);
			pc.getInventory().removeItem(l1iteminstance, 1);
			break;
		case 210115:// 농축 호흡의 물약
		case 40032:// 에바의 축복
		case 40041:// 인어의 비늘
		case 41344:// 물의 정수
			useBlessOfEva(pc, itemId);
			pc.getInventory().removeItem(l1iteminstance, 1);
			break;
		case 30083:// 파란 물약
			/*
			 * if (!(pc.getMapId() == 7783 || pc.getMapId() == 12152 ||
			 * pc.getMapId() == 12149 || pc.getMapId() == 3 ||
			 * pc.getMapId() == 12154 || pc.getMapId() == 12358 ||
			 * pc.getMapId() == 12153 || pc.getMapId() == 12146 ||
			 * pc.getMapId() == 12147 || pc.getMapId() == 12148 ||
			 * pc.getMapId() == 12258 || pc.getMapId() == 12150 ||
			 * pc.getMapId() == 12257 || pc.getMapId() == 12358)) {
			 * SC_SystemMessage.send(pc, 
			 * "클라우디아 맵에서만 사용이 가능합니다."); return; }
			 */
			useBluePotion(pc, itemId);
			pc.getInventory().removeItem(l1iteminstance, 1);
			break;
		case 40015:
		case 140015:
		case 40736:// 지혜의 코인
		case 41142:// 픽시의 마나포션
		case 210114:// 복지 파란 물약
			useBluePotion(pc, itemId);
			pc.getInventory().removeItem(l1iteminstance, 1);
			break;
		case 30089:// 지혜의물약
			/*
			 * if (!(pc.getMapId() == 7783 || pc.getMapId() == 12152 ||
			 * pc.getMapId() == 12149 || pc.getMapId() == 12154 ||
			 * pc.getMapId() == 12358 || pc.getMapId() == 12153 ||
			 * pc.getMapId() == 12146 || pc.getMapId() == 12147 ||
			 * pc.getMapId() == 12148 || pc.getMapId() == 12258 ||
			 * pc.getMapId() == 12150 || pc.getMapId() == 12257 ||
			 * pc.getMapId() == 12358)) { pc.sendPackets(new
			 * SC_SystemMessage( "클라우디아 맵에서만 사용이 가능합니다.")); return; }
			 */
			if (pc.isWizard() || pc.isBlackwizard()) {
				useWisdomPotion(pc, itemId);
				pc.getInventory().removeItem(l1iteminstance, 1);
			} else {
				SC_ServerMessage.send(pc, 79);
				// \f1 아무것도 일어나지 않았습니다.
			}
			break;
		case 40016:
		case 140016:
		case 210113:
			if (pc.isWizard() || pc.isBlackwizard()) {
				useWisdomPotion(pc, itemId);
				pc.getInventory().removeItem(l1iteminstance, 1);
			} else {
				SC_ServerMessage.send(pc, 79);
				// \f1 아무것도 일어나지 않았습니다.
			}
			break;
		case 40025:// 불투명 물약
			useBlindPotion(pc);
			pc.getInventory().removeItem(l1iteminstance, 1);
			break;
		default:
			break;
		}
		return false;
	}

	public static void UseExpPotion1(L1PcInstance pc, int item_id) {
		if (pc.hasSkillEffect(71) == true) { // 디케이포션 상태
			SC_ServerMessage.send(pc, 698, "");
			return;
		}
		cancelAbsoluteBarrier(pc);

		int time = 1800;

		pc.setSkillEffect(L1SkillId.EXP_BUFF, time * 1000);
		long s = SC_SkillSound.pack(pc.getId(), 10049);
		SC_SkillSound.sendPacked(pc, s);
		SC_SkillSound.broadcastPacked(pc, s);
		long hasad = pc.getAccount().getBlessOfAin();
		if (hasad < 10000) {
			SC_InventoryIcon.iconNewUnLimit(pc, L1SkillId.EXP_BUFF + 1, 5087, true); // 세이프티존
		} else{
			SC_InventoryIcon.icoNew(pc, L1SkillId.EXP_BUFF, 5087, time, true); // 사냥터
		}
		SC_ServerMessage.send(pc, 5087);
	}

	public static void UseExpPotion(L1PcInstance pc, int item_id) {
		if (pc.hasSkillEffect(71) == true) { // 디케이포션 상태
			SC_ServerMessage.send(pc, 698, "");
			// 마력에 의해 아무것도 마실 수가 없습니다.
			return;
		}
		cancelAbsoluteBarrier(pc);

		if (item_id != 210094 && item_id != 30105 && item_id != 3000456)
			return;
		int time = 1800;

		pc.setSkillEffect(L1SkillId.EXP_POTION, time * 1000);
		long s = SC_SkillSound.pack(pc.getId(), 11308);
		SC_SkillSound.sendPacked(pc, s);
		SC_SkillSound.broadcastPacked(pc, s);
		if (pc.getMap().isSafetyZone(pc.getX(), pc.getY()))
			SC_InventoryIcon.iconNewUnLimit(pc, EXP_POTION + 1, 4973, true); // 세이프티존
		else
			SC_InventoryIcon.icoNew(pc, EXP_POTION, 4973, time, true); // 사냥터
		SC_ServerMessage.send(pc, 1313);
	}

	public static void useGreenPotion(L1PcInstance pc, int itemId) {
		if (pc.hasSkillEffect(71) == true) { // 디케이포션 상태
			SC_ServerMessage.send(pc, 698); // \f1마력에 의해 아무것도 마실 수가
			// 없습니다.
			return;
		}

		// 아브소르트바리아의 해제
		cancelAbsoluteBarrier(pc);

		int time = 0;
		if (itemId == L1ItemId.POTION_OF_HASTE_SELF || itemId == 7006) { // 그린
			time = 300;
		} else if (itemId == L1ItemId.B_POTION_OF_HASTE_SELF) { // 축복된 그린 일부
			time = 350;
		} else if (itemId == 40018 || itemId == 41342) { // 강화 그린 일부, 축복된 와인,
			time = 1800;
		} else if (itemId == 140018 || itemId == 41338 || itemId == 30158) { // 축복된
			time = 2250;
		} else if (itemId == 40039) { // 와인
			time = 600;
		} else if (itemId == 40040) { // 위스키
			time = 900;
		} else if (itemId == 30067) {
			time = 300;
		} else if (itemId == 40030) { // 상아의 탑의 헤이 파업 일부
			time = 1800;
		} else if (itemId == 41261 || itemId == 41262 || itemId == 41268 || itemId == 41269 || itemId == 41271
				|| itemId == 41272 || itemId == 41273) {
			time = 30;
		}

		SC_SkillSound.send(pc, pc.getId(), 191);
		SC_SkillSound.broadcast(pc, pc.getId(), 191);
		SC_ServerMessage.send(pc, 183);
		// XXX:헤이스트아이템 장비시, 취한 상태가 해제되는지 불명
		if (pc.getHasteItemEquipped() > 0) {
			return;
		}
		// 취한 상태를 해제
		pc.setDrink(false);

		// 헤이 파업, 그레이터 헤이 파업과는 중복 하지 않는다
		if (pc.hasSkillEffect(HASTE)) {
			pc.killSkillEffectTimer(HASTE);
			SC_SkillHaste.send(pc, pc.getId(), 0, 0);
			SC_SkillHaste.broadcast(pc, pc.getId(), 0, 0);
			pc.setMoveSpeed(0);
		} else if (pc.hasSkillEffect(GREATER_HASTE)) {
			pc.killSkillEffectTimer(GREATER_HASTE);
			SC_SkillHaste.send(pc, pc.getId(), 0, 0);
			SC_SkillHaste.broadcast(pc, pc.getId(), 0, 0);
			pc.setMoveSpeed(0);
		} else if (pc.hasSkillEffect(STATUS_HASTE)) {
			int currentTime = 0;
			currentTime = pc.getSkillEffectTimeSec(STATUS_HASTE);
			if (currentTime >= 7200) {
				time = 7200;
			} else {
				time += currentTime;
			}
		}

		// 슬로우, 그레이터 슬로우, 엔탕르중은 슬로우 상태를 해제할 뿐
		if (pc.hasSkillEffect(SLOW)) { // 슬로우
			pc.killSkillEffectTimer(SLOW);
			SC_SkillHaste.send(pc, pc.getId(), 0, 0);
			SC_SkillHaste.broadcast(pc, pc.getId(), 0, 0);
		} else {
			SC_SkillHaste.send(pc, pc.getId(), 1, time >= 7200 ? 7200 : time);
			SC_SkillHaste.broadcast(pc, pc.getId(), 1, 0);
			pc.setMoveSpeed(1);
			pc.setSkillEffect(STATUS_HASTE, (time >= 7200 ? 7200 : time) * 1000);
		}
	}

	public static void useBravePotion(L1PcInstance pc, int item_id) {
		if (pc.hasSkillEffect(71) == true) { // 디케이포션 상태
			SC_ServerMessage.send(pc, 698);// \f1마력에 의해 아무것도 마실 수가
			// 없습니다.
			return;
		}
		// 아브소르트바리아의 해제
		cancelAbsoluteBarrier(pc);

		int time = 0;
		if (item_id == L1ItemId.POTION_OF_EMOTION_BRAVERY || item_id == 30073) { // 치우침
			// 이브
			// 일부
			time = 300;
		} else if (item_id == L1ItemId.B_POTION_OF_EMOTION_BRAVERY) { // 축복된
			// 치우침이브
			// 일부
			time = 350;
		} else if (item_id == 41415) { // 강화 치우침 이브 일부
			time = 1800;
		} else if (item_id == 712) {
			time = 1800;
		} else if (item_id == 40068 || item_id == 30076) { // 에르브왓훌
			time = 480;
			if (pc.hasSkillEffect(STATUS_BRAVE)) { // 용기와는 중복 하지 않는다.
				pc.killSkillEffectTimer(STATUS_BRAVE);
				SC_SkillBrave.send(pc, pc.getId(), 0, 0);
				SC_SkillBrave.broadcast(pc, pc.getId(), 0, 0);
				pc.setBraveSpeed(0);
			}
			pc.remove_elf_second_brave();
		} else if (item_id == 140068) { // 축복된 에르브왓훌
			time = 700;
			if (pc.hasSkillEffect(STATUS_BRAVE)) { // 용기 효과와는 중복 하지 않는다.
				pc.killSkillEffectTimer(STATUS_BRAVE);
				SC_SkillBrave.send(pc, pc.getId(), 0, 0);
				SC_SkillBrave.broadcast(pc, pc.getId(), 0, 0);
				pc.setBraveSpeed(0);
			}
			pc.remove_elf_second_brave();
		} else if (item_id == 210110) { // 복지 엘븐와퍼
			time = 1800;
			if (pc.hasSkillEffect(STATUS_BRAVE)) { // 용기 효과와는 중복 하지 않는다.
				pc.killSkillEffectTimer(STATUS_BRAVE);
				SC_SkillBrave.send(pc, pc.getId(), 0, 0);
				SC_SkillBrave.broadcast(pc, pc.getId(), 0, 0);
				pc.setBraveSpeed(0);
			}

			if (pc.hasSkillEffect(FOCUS_WAVE)) {
				pc.killSkillEffectTimer(FOCUS_WAVE);
				SC_SkillBrave.send(pc, pc.getId(), 0, 0);
				SC_SkillBrave.broadcast(pc, pc.getId(), 0, 0);
				pc.setBraveSpeed(0);
			}
			if (pc.hasSkillEffect(HURRICANE)) {
				pc.killSkillEffectTimer(HURRICANE);
				SC_SkillBrave.send(pc, pc.getId(), 0, 0);
				SC_SkillBrave.broadcast(pc, pc.getId(), 0, 0);
				pc.setBraveSpeed(0);
			}
			if (pc.hasSkillEffect(SAND_STORM)) {
				pc.killSkillEffectTimer(SAND_STORM);
				SC_SkillBrave.send(pc, pc.getId(), 0, 0);
				SC_SkillBrave.broadcast(pc, pc.getId(), 0, 0);
				pc.setBraveSpeed(0);
			}
			if (pc.hasSkillEffect(DANCING_BLADES)) { // 댄싱하고는 중복하지않는다
				pc.killSkillEffectTimer(DANCING_BLADES);
				SC_SkillBrave.send(pc, pc.getId(), 0, 0);
				SC_SkillBrave.broadcast(pc, pc.getId(), 0, 0);
				pc.setBraveSpeed(0);
			}
		} else if (item_id == 40031 || item_id == 30075) { // 이비르브랏드
			time = 600;
		} else if (item_id == 40733) { // 명예의 코인
			time = 600;
			if (pc.hasSkillEffect(STATUS_ELFBRAVE)) {
				pc.killSkillEffectTimer(STATUS_ELFBRAVE);
				SC_SkillBrave.send(pc, pc.getId(), 0, 0);
				SC_SkillBrave.broadcast(pc, pc.getId(), 0, 0);
				pc.setBraveSpeed(0);
			}
			if (pc.hasSkillEffect(HOLY_WALK)) { // 호-리 워크와는 중복 하지 않는다
				pc.killSkillEffectTimer(HOLY_WALK);
				SC_SkillBrave.send(pc, pc.getId(), 0, 0);
				SC_SkillBrave.broadcast(pc, pc.getId(), 0, 0);
				pc.setBraveSpeed(0);
			}
			if (pc.hasSkillEffect(MOVING_ACCELERATION)) { // 무빙 악 세레이션과는 중복 하지
				// 않는다
				pc.killSkillEffectTimer(MOVING_ACCELERATION);
				SC_SkillBrave.send(pc, pc.getId(), 0, 0);
				SC_SkillBrave.broadcast(pc, pc.getId(), 0, 0);
				pc.setBraveSpeed(0);
			}
			if (pc.hasSkillEffect(STATUS_FRUIT)) { // 유그드라열매와는 중복안됨
				pc.killSkillEffectTimer(STATUS_FRUIT);
				pc.setBraveSpeed(0);
			}
		}

		if (item_id == 40068 || item_id == 140068 || item_id == 210110 || item_id == 30076) { // 엘븐
			// 와퍼
			SC_SkillBrave.send(pc, pc.getId(), 3, time);
			SC_SkillBrave.broadcast(pc, pc.getId(), 3, 0);
			pc.setSkillEffect(STATUS_ELFBRAVE, time * 1000);
		} else {
			SC_SkillBrave.send(pc, pc.getId(), 1, time);
			SC_SkillBrave.broadcast(pc, pc.getId(), 1, 0);
			pc.setSkillEffect(STATUS_BRAVE, time * 1000);
		}
		SC_SkillSound.send(pc, pc.getId(), 751);
		SC_SkillSound.broadcast(pc, pc.getId(), 751);
		pc.setBraveSpeed(1);
	}


	public static void useFruit(L1PcInstance pc, int item_id) {
		if (pc.hasSkillEffect(DECAY_POTION) == true) {
			SC_ServerMessage.send(pc, 698);
			return;
		}
		cancelAbsoluteBarrier(pc);

		int time = 0;
		if (item_id == 210036 || item_id == 30077) {
			time = 480;
		}
		if (item_id == 713) {
			time = 1800;
		}
		if (pc.hasSkillEffect(L1SkillId.STATUS_BRAVE)) {
			pc.killSkillEffectTimer(L1SkillId.STATUS_BRAVE);
			SC_SkillBrave.send(pc, pc.getId(), 0, 0);
			pc.setBraveSpeed(0);
		}


		pc.setSkillEffect(STATUS_FRUIT, time * 1000);
		//TODO 다크호스 추가
		SC_SkillBrave.send(pc, pc.getId(), pc.getBraveSpeed(), time);
		SC_SkillBrave.broadcast(pc, pc.getId(), pc.getBraveSpeed(), 0);
		SC_SkillSound.send(pc, pc.getId(), 7110);
		SC_SkillSound.broadcast(pc, pc.getId(), 7110);

	}
	public static void useBluePotion(L1PcInstance pc, int itemId) {
		if (pc.hasSkillEffect(DECAY_POTION)) {// 디케이 포션
			SC_ServerMessage.send(pc, 698);
			return;
		}
		cancelAbsoluteBarrier(pc);// 앱솔루트 해제
		int time = 0;
		switch (itemId) {
		case 30083:
		case 40015:
		case 40736:
			time = 600;
			break;
		case 140015:
			time = 700;
			break;
		case 41142:
			time = 300;
			break;
		case 210114:
			time = 1800;
			break;
		default:
			break;
		}
		SC_SkillIconGFX.send(pc, 34, time, true);
		SC_SkillSound.send(pc, pc.getId(), 190);
		SC_SkillSound.broadcast(pc, pc.getId(), 190);
		if (itemId == 41142) {
			pc.setSkillEffect(STATUS_BLUE_POTION2, time * 1000);
		} else {
			pc.setSkillEffect(STATUS_BLUE_POTION, time * 1000);
		}
		SC_ServerMessage.send(pc, 1007);// MP 회복 속도가 빨라집니다.
	}

	public static void useWisdomPotion(L1PcInstance pc, int item_id) {
		if (pc.hasSkillEffect(71) == true) { // 디케이포션 상태
			SC_ServerMessage.send(pc, 698); // \f1마력에 의해 아무것도 마실 수가
			// 없습니다.
			return;
		}
		// 아브소르트바리아의 해제
		cancelAbsoluteBarrier(pc);

		int time = 0; // 시간은 4의 배수로 하는 것
		switch (item_id) {
		case 40016:
		case 30089:
			time = 300;
			break;
		case 140016:
			time = 360;
			break;
		case 210113:
			time = 1000;
			break;
		default:
			return;
		}

		if (!pc.hasSkillEffect(STATUS_WISDOM_POTION)) {
			pc.getAbility().addSp(2);
			pc.addMpr(2);
		}
		SC_SkillIconWisdomPotion.send(pc, (int) (time));
		SC_SkillSound.send(pc, pc.getId(), 750);
		SC_SkillSound.broadcast(pc, pc.getId(), 750);
		pc.setSkillEffect(STATUS_WISDOM_POTION, time * 1000);

	}

	public static void useBlessOfEva(L1PcInstance pc, int item_id) {
		if (pc.hasSkillEffect(71) == true) { // 디케이포션 상태
			SC_ServerMessage.send(pc, 698); // \f1마력에 의해 아무것도 마실 수가
			// 없습니다.
			return;
		}

		// 아브소르트바리아의 해제
		cancelAbsoluteBarrier(pc);

		int time = 0;
		switch (item_id) {
		case 210115:// 농축 호흡의 물약
			time = 7200;
			break;
		case 40032:// 에바의축복
			time = 1800;
			break;
		case 40041:
			time = 300;
			break;
		case 41344:
			time = 2100;
			break;
		default:
			return;
		}
		if (pc.hasSkillEffect(STATUS_UNDERWATER_BREATH)) {
			int timeSec = pc.getSkillEffectTimeSec(STATUS_UNDERWATER_BREATH);
			time += timeSec;
			if (time > 3600) {
				time = 3600;
			}
		}
		SC_SkillIconBlessOfEva.send(pc, pc.getId(), time);
		SC_SkillSound.send(pc, pc.getId(), 190);
		SC_SkillSound.broadcast(pc, pc.getId(), 190);
		pc.setSkillEffect(STATUS_UNDERWATER_BREATH, time * 1000);
	}

	public static void useBlindPotion(L1PcInstance pc) {
		if (pc.hasSkillEffect(DECAY_POTION)) {
			SC_ServerMessage.send(pc, 698); // \f1마력에 의해 아무것도 마실 수가
			// 없습니다.
			return;
		}

		// 아브소르트바리아의 해제
		cancelAbsoluteBarrier(pc);
		boolean before_floatingEye = pc.isFloatingEye();
		int time = 480;
		if (pc.hasSkillEffect(CURSE_BLIND)) {
			pc.killSkillEffectTimer(CURSE_BLIND);
		} else if (pc.hasSkillEffect(DARKNESS)) {
			pc.killSkillEffectTimer(DARKNESS);
		} else if (pc.hasSkillEffect(LINDBIOR_SPIRIT_EFFECT)) {
			pc.killSkillEffectTimer(LINDBIOR_SPIRIT_EFFECT);
		}	
		if (pc.hasSkillEffect(STATUS_FLOATING_EYE)) {
			SC_CurseBlind.send(pc, 2);
		} else {
			SC_CurseBlind.send(pc, 1);
		}
		pc.setSkillEffect(CURSE_BLIND, time * 1000);
		if (!before_floatingEye && pc.hasSkillEffect(L1SkillId.STATUS_FLOATING_EYE)) {
			pc.showFloatingEyeToInvis();
		}
	}

	public static void useCashScroll(L1PcInstance pc, int item_id) {
		int time = 1800;
		int scroll = 0;

		if (pc.hasSkillEffect(STATUS_CASHSCROLL)) {
			pc.killSkillEffectTimer(STATUS_CASHSCROLL);
			pc.addMaxHp(-50);
			SC_HpUpdate.send(pc, pc.getCurrentHp(), pc.getMaxHp());
			if (pc.isInParty()) {
				// TODO 파티 프로토
				pc.getParty().refreshPartyMemberStatus(pc);
			}
			SC_MpUpdate.send(pc, pc.getCurrentMp(), pc.getMaxMp());
		}
		if (pc.hasSkillEffect(STATUS_CASHSCROLL2)) {
			pc.killSkillEffectTimer(STATUS_CASHSCROLL2);
			pc.addMaxMp(-40);
			SC_MpUpdate.send(pc, pc.getCurrentMp(), pc.getMaxMp());
		}
		if (pc.hasSkillEffect(STATUS_CASHSCROLL3)) {
			pc.killSkillEffectTimer(STATUS_CASHSCROLL3);
			pc.addDmgup(-3);
			pc.addHitup(-3);
			pc.getAbility().addSp(-3);
			SC_SPMR.send(pc);
		}
		if (pc.hasSkillEffect(STATUS_CASHSCROLL4)) {
			pc.killSkillEffectTimer(STATUS_CASHSCROLL4);
			pc.getAbility().addSp(-3);
			pc.addBaseMagicHitUp(-5);
			pc.getResistance().addcalcPcDefense(-3);
			SC_SPMR.send(pc);
		}
		if (pc.hasSkillEffect(STATUS_CASHSCROLL5)) {
			pc.killSkillEffectTimer(STATUS_CASHSCROLL5);
			pc.addBowDmgup(-3);
			pc.addBowHitup(-5);
			pc.getResistance().addcalcPcDefense(-3);
		}
		if (pc.hasSkillEffect(STATUS_CASHSCROLL6)) {
			pc.killSkillEffectTimer(STATUS_CASHSCROLL6);
			pc.addDmgRate(-3);
			pc.addHitup(-5);
			pc.getResistance().addcalcPcDefense(-3);
		}

		if (item_id == 410010) {
			scroll = 7893;
			pc.addMaxHp(50);
			SC_HpUpdate.send(pc, pc.getCurrentHp(), pc.getMaxHp());
			if (pc.isInParty()) {
				// TODO 파티 프로토
				pc.getParty().refreshPartyMemberStatus(pc);
			}
			SC_MpUpdate.send(pc, pc.getCurrentMp(), pc.getMaxMp());
		} else if (item_id == 410011) {
			scroll = 7894;
			pc.addMaxMp(40);
			SC_MpUpdate.send(pc, pc.getCurrentMp(), pc.getMaxMp());
		} else if (item_id == 410012 || item_id == 30063) {
			scroll = 7895;
			pc.addDmgup(3);
			pc.addHitup(3);
			pc.getAbility().addSp(3);
			SC_SPMR.send(pc);
		} else if (item_id == 4100039) {
			scroll = 16553;
			pc.getAbility().addSp(3);
			pc.addBaseMagicHitUp(5);
			pc.getResistance().addcalcPcDefense(3);
			SC_SPMR.send(pc);
		} else if (item_id == 4100041) {
			scroll = 16552;
			pc.addBowDmgup(3);
			pc.addBowHitup(5);
			pc.getResistance().addcalcPcDefense(3);
		} else if (item_id == 4100042) {
			scroll = 16551;
			pc.addDmgRate(3);
			pc.addHitup(5);
			pc.getResistance().addcalcPcDefense(3);
		}
		SC_SkillSound.send(pc, pc.getId(), scroll);
		SC_SkillSound.broadcast(pc, pc.getId(), scroll);
		pc.setSkillEffect(scroll, time * 1000);
	}

}
