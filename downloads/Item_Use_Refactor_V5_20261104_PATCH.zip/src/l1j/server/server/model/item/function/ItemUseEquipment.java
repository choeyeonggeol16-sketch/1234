package l1j.server.server.model.item.function;

import l1j.server.server.model.Instance.L1ItemInstance;
import l1j.server.server.model.Instance.L1PcInstance;
import l1j.server.server.model.character.equip.EquipService;



import l1j.server.server.model.network.core.sc.packet.SC_PacketBox;
import l1j.server.server.model.network.core.sc.packet.SC_ServerMessage;
import l1j.server.server.model.network.core.sc.packet.SC_SystemMessage;
import l1j.server.server.templates.L1Armor;
import l1j.server.server.templates.L1Item;




import static l1j.server.server.model.item.function.ItemUseEnchantments.*;
import static l1j.server.server.model.item.function.ItemUsePotions.*;
import static l1j.server.server.model.item.function.ItemUseTransformation.*;
import static l1j.server.server.model.item.function.ItemUseSpellBooks.*;
import static l1j.server.server.model.item.function.ItemUseWorldHelpers.*;
import static l1j.server.server.model.item.function.ItemUseSpecialEnchant.*;
import static l1j.server.server.model.item.function.ItemUseMiscActions.*;
import static l1j.server.server.model.item.function.ItemUseDurable.*;
import static l1j.server.server.model.item.function.ItemUseCombatAbilities.*;
import static l1j.server.server.model.item.function.ItemUseDollEffects.*;

import static l1j.server.server.model.item.function.ItemUseCreature.*;

public final class ItemUseEquipment {
    private ItemUseEquipment() {}
	public static boolean is_legend_weapon(int itemId) {
		switch (itemId) {
		case 12:
		case 61:
		case 66:
		case 86:
		case 134:
		case 202011:
		case 202012:
		case 202013:
		case 202014:
		case 123777:
		case 123888:
		case 123999:
		case 123666:
			return true;
		}

		return false;
	}
	
	public static boolean canUseByClass(L1PcInstance pc, L1Item item) {
	    if (pc == null || item == null) return false;
	    if (pc.isGm()) return true;

	    return (pc.isCrown()        && item.isUseRoyal())
	        || (pc.isKnight()       && item.isUseKnight())
	        || (pc.isElf()          && item.isUseElf())
	        || (pc.isWizard()       && item.isUseMage())
	        || (pc.isDarkelf()      && item.isUseDarkelf())
	        || (pc.isDragonknight() && item.isUseDragonKnight())
	        || (pc.isBlackwizard()  && item.isUseBlackwizard())
	        || (pc.isWarrior()         && item.isUse전사());
	}

	// 2) 레벨 제한 메시지 처리(공통). true면 "통과", false면 "막힘(메시지 보냄)".
	public static boolean checkLevelRestriction(L1PcInstance pc, int min, int max) {
	    if (pc == null) return false;

	    if (min != 0 && min > pc.getLevel()) {
	        SC_ServerMessage.send(pc, 318, String.valueOf(min));
	        return false;
	    }
	    if (max != 0 && max < pc.getLevel()) {
	        if (max < 50) SC_PacketBox.send(pc, SC_PacketBox.MSG_LEVEL_OVER, max);
	        else SC_SystemMessage.send(pc, "이 아이템은" + max + "레벨 이하만 사용할 수 있습니다. ");
	        return false;
	    }
	    return true;
	}

	// 3) Type2==1(무기) 처리
	public static void handleWeaponUse(L1PcInstance pc, L1ItemInstance inst) {
	    final L1Item item = inst.getItem();

	    // 원본은 "무기: 아이템에서 min/max"
	    final int min = item.getMinLevel();
	    final int max = item.getMaxLevel();

	    if (!checkLevelRestriction(pc, min, max)) return;

	    if (!canUseByClass(pc, item)) {
	        SC_ServerMessage.send(pc, 264);
	        return;
	    }
	    EquipService.useWeapon(pc, inst);
	}

	// 4) Type2==2(방어구) 처리
	public static void handleArmorUse(L1PcInstance pc, L1ItemInstance inst) {
	    final L1Item item = inst.getItem();

	    if (!canUseByClass(pc, item)) {
	        SC_ServerMessage.send(pc, 264);
	        return;
	    }

	    final L1Armor armor = (L1Armor) item;
	    final int min = armor.getMinLevel();
	    final int max = armor.getMaxLevel();

	    if (!checkLevelRestriction(pc, min, max)) return;

	    EquipService.useArmor(pc, inst);
	}

}
