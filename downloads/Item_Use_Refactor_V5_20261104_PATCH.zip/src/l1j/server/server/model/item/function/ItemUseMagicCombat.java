package l1j.server.server.model.item.function;

import l1j.server.server.model.network.core.sc.packet.SC_Paralysis;
import l1j.server.server.model.network.core.sc.packet.SC_SkillSound;
import static l1j.server.server.model.character.skill.L1SkillId.STATUS_FREEZE;
import java.util.Random;
import l1j.server.Config;
import l1j.server.server.ActionCodes;
import l1j.server.server.model.L1EffectSpawn;
import l1j.server.server.model.L1Object;
import l1j.server.server.model.L1World;
import l1j.server.server.model.Instance.L1EffectInstance;
import l1j.server.server.model.Instance.L1ItemInstance;
import l1j.server.server.model.Instance.L1NpcInstance;
import l1j.server.server.model.Instance.L1PcInstance;
import l1j.server.server.model.character.skill.L1SkillId;
import l1j.server.server.model.character.skill.L1SkillUse;
import l1j.server.server.model.network.core.sc.packet.SC_AttackPacket;
import l1j.server.server.model.network.core.sc.packet.SC_PacketBox;
import l1j.server.server.model.network.core.sc.packet.SC_ServerMessage;
import l1j.server.server.model.network.core.sc.packet.SC_SystemMessage;
import l1j.server.server.utils.MJCommons;
import static l1j.server.server.model.item.function.ItemUseCreature.*;
import static l1j.server.server.model.item.function.ItemUseCombatSupport.Start;
import static l1j.server.server.model.item.function.ItemUseCombatSupport.Start1;
import static l1j.server.server.model.item.function.ItemUseCombatSupport.액션;
import static l1j.server.server.model.item.function.ItemUseCombatSupport.액션1;

/**
 * Legacy combat effects grouped by responsibility. 
 */
final class ItemUseMagicCombat {
    private static final Random _random = ItemUseCreature._random;
    
    private ItemUseMagicCombat() {
    }
    
    public static void 이터니티(L1PcInstance pc, int targetId, L1ItemInstance item) {
        SC_AttackPacket.send(pc.getNetConnection(), pc, 0, ActionCodes.ACTION_Wand);
        SC_AttackPacket.broadcast(pc, 0, ActionCodes.ACTION_Wand);
        L1Object target = L1World.getInstance().findObject(targetId);
        if ((pc.getType() == 3 && pc.getLevel() >= 85) || pc.isGm()) {
            if (target != null) {
                if (target instanceof L1PcInstance) {
                    L1PcInstance member = (L1PcInstance)target;
                    if (pc.getId() == member.getId()) {
                        SC_SystemMessage.send(pc, "\\aH자기 자신에게는 사용할 수 없습니다");
                        return;
                    }
                    int diffLocX = Math.abs(pc.getX() - member.getX());
                    int diffLocY = Math.abs(pc.getY() - member.getY());
                    if (diffLocX > 10 || diffLocY > 10) {
                        SC_PacketBox.send(pc, SC_PacketBox.GREEN_MESSAGE, "\\fY거리가 멀어서 사용할 수 없습니다.");
                        SC_SystemMessage.send(pc, "\\fY거리가 멀어서 사용할 수 없습니다.");
                        return;
                    }
                    if (pc.hasSkillEffect(L1SkillId.이터니티대기)) {
                        int n = pc.getSkillEffectTimeSec(L1SkillId.이터니티대기);
                        SC_SystemMessage.send(pc, String.format("\\fY이터니티 대기시간 : %d초 후에 사용가능합니다.", n));
                        return;
                    }
                    if (MJCommons.isNonAction(pc)) {
                        return;
                    }
                    if (pc.getSafetyZone() && (!(pc.getMapId() == 9 || pc.getMapId() == 1 || pc.getMapId() == 2))) {
                        SC_SystemMessage.send(pc, "세이프티존에서는 사용할 수 없습니다.");
                        return;
                    }
                    if (pc.isInvisble()) {
                        SC_SystemMessage.send(pc, "이터니티는 투명상태로 시전이 불가능합니다.");
                        return;
                    }
                    if (pc.getCurrentMp() < 80) {
                        SC_ServerMessage.send(pc, 278);
                        return;
                    }
                    int tx = member.getX();
                    int ty = member.getY();
                    if (!pc.glanceCheck(tx, ty) || !member.glanceCheck(pc.getX(), pc.getY())) {
                        SC_PacketBox.send(pc, SC_PacketBox.GREEN_MESSAGE, "\\fY타겟과의 사이에 장애물로 인해 사용할 수 없습니다.");
                        SC_SystemMessage.send(pc, "\\fY타겟과의 사이에 장애물로 인해 사용할 수 없습니다.");
                        return;
                    }
                    int 랜덤 = _random.nextInt(100) + 1;
                    int 렙차 = pc.getLevel() - member.getLevel();
                    int 기본확률 = Config.이터기본;
                    int 양렙차 = 기본확률 + (렙차 * Config.이터양);
                    int 음렙차 = 기본확률 + (렙차 * Config.이터음);
                    if (렙차 >= 0) {
                        if (랜덤 <= 양렙차) {
                            if (양렙차 > 100) {
                                양렙차 = 100;
                            }
                            int 요정 = (int)((double)Config.이터제약 * Config.리버레이션절감);
                            if (member.hasSkillEffect(L1SkillId.리버레이션)) {
                                member.setSkillEffect(L1SkillId.이터디스, 요정);
                                member.setSkillEffect(STATUS_FREEZE, 요정);
                                L1EffectSpawn.getInstance().spawnEffect(991162, 요정, member.getX(), member.getY(), member.getMapId());
                            } else {
                                member.setSkillEffect(L1SkillId.이터디스, Config.이터제약);
                                member.setSkillEffect(STATUS_FREEZE, Config.이터제약);
                                L1EffectSpawn.getInstance().spawnEffect(991162, Config.이터제약, member.getX(), member.getY(), member.getMapId());
                            }
                            SC_SkillSound.send(member, member.getId(), 13136);
                            SC_SkillSound.broadcast(member, member.getId(), 13136);
                            SC_Paralysis.send(member, SC_Paralysis.TYPE_BIND, true);
                            member.sendPackets("창에 궤뚫려 행동에 제약을 받습니다");
                            Start(pc, member);
                        } else {
                            SC_SkillSound.send(member, member.getId(), 13136);
                            SC_SkillSound.broadcast(member, member.getId(), 13136);
                        }
                        pc.setSkillEffect(L1SkillId.이터니티대기, Config.이터니티대기 * 1000);
                        pc.setCurrentMp(pc.getCurrentMp() - 80);
                        L1SkillUse.cast(pc, L1SkillId.보조버프, pc.getId(), pc.getX(), pc.getY(), null, 0, L1SkillUse.TYPE_SPELLSC);
                        int aa1 = _random.nextInt(150) + 1;
                        int mrs = (int)(member.getMr() * 1.7 - 20);
                        int dmg = (pc.getAbility().getSp() * Config.이터니티배율) + aa1;
                        dmg = (int)calcMrDefense(member.getResistance().getEffectedMrBySkill(), dmg);
                        if (dmg < 200) {
                            dmg = 200;
                        }
                        member.receiveDamage(pc, dmg);
                        if (pc.isGm()) {
                            SC_SystemMessage.send(pc, "\\aH이터니티 데미지: " + dmg);
                            pc.sendPackets("제약: 확률[" + 랜덤 + "]   렙차[" + 렙차 + "*" + Config.이터양 + "+" + 기본확률 + "] = 확률범위[1~" + 양렙차 + "]");
                        }
                    } else {
                        if (랜덤 <= 음렙차) {
                            if (음렙차 < 30) {
                                음렙차 = 30;
                            }
                            int 요정 = (int)((double)Config.이터제약 * Config.리버레이션절감);
                            if (member.hasSkillEffect(L1SkillId.리버레이션)) {
                                member.setSkillEffect(L1SkillId.이터디스, 요정);
                                member.setSkillEffect(STATUS_FREEZE, 요정);
                                L1EffectSpawn.getInstance().spawnEffect(991162, 요정, member.getX(), member.getY(), member.getMapId());
                            } else {
                                member.setSkillEffect(L1SkillId.이터디스, Config.이터제약);
                                member.setSkillEffect(STATUS_FREEZE, Config.이터제약);
                                L1EffectSpawn.getInstance().spawnEffect(991162, Config.이터제약, member.getX(), member.getY(), member.getMapId());
                            }
                            SC_SkillSound.send(member, member.getId(), 13136);
                            SC_SkillSound.broadcast(member, member.getId(), 13136);
                            SC_Paralysis.send(member, SC_Paralysis.TYPE_BIND, true);
                            member.sendPackets("창에 궤뚫려 행동에 제약을 받습니다");
                            Start(pc, member);
                        } else {
                            SC_SkillSound.send(member, member.getId(), 13136);
                            SC_SkillSound.broadcast(member, member.getId(), 13136);
                        }
                        pc.setSkillEffect(L1SkillId.이터니티대기, Config.이터니티대기 * 1000);
                        pc.setCurrentMp(pc.getCurrentMp() - 80);
                        L1SkillUse.cast(pc, L1SkillId.보조버프, pc.getId(), pc.getX(), pc.getY(), null, 0, L1SkillUse.TYPE_SPELLSC);
                        int aa1 = _random.nextInt(150) + 1;
                        int mrs = (int)(member.getMr() * 1.7 - 20);
                        int dmg = (pc.getAbility().getSp() * Config.이터니티배율) + aa1;
                        dmg = (int)calcMrDefense(member.getResistance().getEffectedMrBySkill(), dmg);
                        if (dmg < 200) {
                            dmg = 200;
                        }
                        member.receiveDamage(pc, dmg);
                        if (pc.isGm()) {
                            SC_SystemMessage.send(pc, "\\aH이터니티 데미지: " + dmg);
                            pc.sendPackets("제약: 확률[" + 랜덤 + "]   렙차[" + 렙차 + "*" + Config.이터음 + "+" + 기본확률 + "] = 확률범위[1~" + 음렙차 + "]");
                        }
                    }
                    액션(pc, member);
                }
                if (target instanceof L1NpcInstance) {
                    L1NpcInstance member1 = (L1NpcInstance)target;
                    if (pc.getId() == member1.getId()) {
                        SC_SystemMessage.send(pc, "\\aH자기 자신에게는 사용할 수 없습니다");
                        return;
                    }
                    int diffLocX = Math.abs(pc.getX() - member1.getX());
                    int diffLocY = Math.abs(pc.getY() - member1.getY());
                    if (diffLocX > 10 || diffLocY > 10) {
                        SC_PacketBox.send(pc, SC_PacketBox.GREEN_MESSAGE, "\\fY거리가 멀어서 사용할 수 없습니다.");
                        SC_SystemMessage.send(pc, "\\fY거리가 멀어서 사용할 수 없습니다.");
                        return;
                    }
                    if (pc.hasSkillEffect(L1SkillId.이터니티대기)) {
                        int n = pc.getSkillEffectTimeSec(L1SkillId.이터니티대기);
                        SC_SystemMessage.send(pc, String.format("\\fY이터니티 대기시간 : %d초 후에 사용가능합니다.", n));
                        return;
                    }
                    if (MJCommons.isNonAction(pc)) {
                        return;
                    }
                    if (pc.getSafetyZone() && (!(pc.getMapId() == 9 || pc.getMapId() == 1 || pc.getMapId() == 2))) {
                        SC_SystemMessage.send(pc, "세이프티존에서는 사용할 수 없습니다.");
                        return;
                    }
                    if (pc.isInvisble()) {
                        SC_SystemMessage.send(pc, "이터니티는 투명상태로 시전이 불가능합니다.");
                        return;
                    }
                    if (pc.getCurrentMp() < 80) {
                        SC_ServerMessage.send(pc, 278);
                        return;
                    }
                    int tx1 = member1.getX();
                    int ty1 = member1.getY();
                    if (!pc.glanceCheck(tx1, ty1) || !member1.glanceCheck(pc.getX(), pc.getY())) {
                        SC_PacketBox.send(pc, SC_PacketBox.GREEN_MESSAGE, "\\fY타겟과의 사이에 장애물로 인해 사용할 수 없습니다.");
                        SC_SystemMessage.send(pc, "\\fY타겟과의 사이에 장애물로 인해 사용할 수 없습니다.");
                        return;
                    }
                    int qq = Config.이터몬스터;
                    int 랜덤 = _random.nextInt(100) + 1;
                    if (랜덤 <= qq) {
                        member1.setSkillEffect(L1SkillId.이터디스, Config.이터제약);
                        member1.setSkillEffect(STATUS_FREEZE, Config.이터제약);
                        SC_SkillSound.send(member1, member1.getId(), 13136);
                        SC_SkillSound.broadcast(member1, member1.getId(), 13136);
                        SC_Paralysis.send(member1, SC_Paralysis.TYPE_BIND, true);
                        Start1(pc, member1);
                        @SuppressWarnings("unused")
                        L1EffectInstance eff12 = L1EffectSpawn.getInstance().spawnEffect(991162, Config.이터제약, member1.getX(), member1.getY(), member1.getMapId());
                    } else {
                        SC_SkillSound.send(member1, member1.getId(), 13136);
                        SC_SkillSound.broadcast(member1, member1.getId(), 13136);
                    }
                    pc.setSkillEffect(L1SkillId.이터니티대기, Config.이터니티대기 * 1000);
                    pc.setCurrentMp(pc.getCurrentMp() - 80);
                    L1SkillUse.cast(pc, L1SkillId.보조버프, pc.getId(), pc.getX(), pc.getY(), null, 0, L1SkillUse.TYPE_SPELLSC);
                    int aa1 = _random.nextInt(150) + 1;
                    int mrs = (int)(member1.getMr() * 1.7 - 20);
                    int dmg = (pc.getAbility().getSp() * Config.이터니티배율) + aa1;
                    dmg = (int)calcMrDefense(member1.getResistance().getEffectedMrBySkill(), dmg);
                    if (dmg < 200) {
                        dmg = 200;
                    }
                    member1.receiveDamage(pc, dmg);
                    if (pc.isGm()) {
                        SC_SystemMessage.send(pc, "\\aH이터니티 데미지: " + dmg);
                        pc.sendPackets("제약: 확률[" + 랜덤 + "]  확률범위[1~" + Config.이터몬스터 + "]");
                    }
                    액션1(pc, member1);
                }
            } else {
                SC_SystemMessage.send(pc, "타겟이 올바르지않습니다.");
            }
        } else {
            pc.sendPackets("\\aH조건에 맞지 않아 사용할 수 없는 스킬입니다.");
            pc.sendPackets("\\aH조건:마법사      레벨: 85 이상");
        }
    }
    
    public static double calcMrDefense(int MagicResistance, double dmg) {
        double cc = 0;
        if (MagicResistance <= 19) {
            cc = 0.05;
        } else if (MagicResistance <= 29) {
            cc = 0.07;
        } else if (MagicResistance <= 39) {
            cc = 0.1;
        } else if (MagicResistance <= 49) {
            cc = 0.12;
        } else if (MagicResistance <= 59) {
            cc = 0.17;
        } else if (MagicResistance <= 69) {
            cc = 0.2;
        } else if (MagicResistance <= 79) {
            cc = 0.22;
        } else if (MagicResistance <= 89) {
            cc = 0.25;
        } else if (MagicResistance <= 99) {
            cc = 0.27;
        } else if (MagicResistance <= 110) {
            cc = 0.31;
        } else if (MagicResistance <= 120) {
            cc = 0.32;
        } else if (MagicResistance <= 130) {
            cc = 0.34;
        } else if (MagicResistance <= 140) {
            cc = 0.36;
        } else if (MagicResistance <= 150) {
            cc = 0.38;
        } else if (MagicResistance <= 160) {
            cc = 0.4;
        } else if (MagicResistance <= 170) {
            cc = 0.42;
        } else if (MagicResistance <= 180) {
            cc = 0.44;
        } else if (MagicResistance <= 190) {
            cc = 0.46;
        } else if (MagicResistance <= 200) {
            cc = 0.48;
        } else if (MagicResistance <= 220) {
            cc = 0.49;
        } else {
            cc = 0.51;
        }
        dmg -= dmg * cc;
        if (dmg < 0) {
            dmg = 0;
        }
        return dmg;
    }
}
