package l1j.server.server.model.item.function;



import l1j.server.server.model.network.core.sc.packet.SC_SkillSound;
import static l1j.server.server.model.character.skill.L1SkillId.SHAPE_CHANGE;

import java.util.Random;
import l1j.server.server.datatables.PolyTable;
import l1j.server.server.datatables.SkillsTable;
import l1j.server.server.model.L1Character;
import l1j.server.server.model.L1PolyMorph;
import l1j.server.server.model.Instance.L1ItemInstance;
import l1j.server.server.model.Instance.L1MonsterInstance;
import l1j.server.server.model.Instance.L1PcInstance;
import l1j.server.server.model.character.skill.L1SkillId;
import l1j.server.server.model.item.L1ItemId;

import l1j.server.server.model.rank.loader.RankUserLoader;


import l1j.server.server.model.network.core.sc.packet.SC_ServerMessage;
import l1j.server.server.model.network.core.sc.packet.SC_SystemMessage;
import l1j.server.server.templates.L1Skills;




import static l1j.server.server.model.item.function.ItemUseEnchantments.*;
import static l1j.server.server.model.item.function.ItemUsePotions.*;
import static l1j.server.server.model.item.function.ItemUseSpellBooks.*;
import static l1j.server.server.model.item.function.ItemUseWorldHelpers.*;
import static l1j.server.server.model.item.function.ItemUseSpecialEnchant.*;
import static l1j.server.server.model.item.function.ItemUseMiscActions.*;
import static l1j.server.server.model.item.function.ItemUseEquipment.*;
import static l1j.server.server.model.item.function.ItemUseDurable.*;
import static l1j.server.server.model.item.function.ItemUseCombatAbilities.*;
import static l1j.server.server.model.item.function.ItemUseDollEffects.*;

import static l1j.server.server.model.item.function.ItemUseCreature.*;

public final class ItemUseTransformation {
    private static final Random _random = ItemUseCreature._random;
    private ItemUseTransformation() {}
	public static boolean usePolyScroll(L1PcInstance pc, int item_id, String s) {
//		 System.out.println(s);//변신 액션찾을때
		int time = 0;
		boolean ring = false;
		switch (item_id) {
		case 40088:
		case 40096:
			
			time = 1800;
			break;
		case 900075:
			//ring = true;
			time = 3600;
			break;
			
		case 140088:
			time = 2100;
			break;
		case 210112:
			time = 3600;
			break;
		case 40008:
			time = 7200;
			break;
		case 140008:
			time = 7200;
			break;
		default:
			return false;
		}
		if (s.startsWith("maple")) {
			String aa = s;
			String bb = aa.replace("maple ", "");
			s = bb;
		}
		if (s.equalsIgnoreCase("ranking class polymorph")) {
			if (pc.isCrown()) {
				if (pc.get_sex() == 0)
					s = "rangking prince male";
				else
					s = "rangking prince female";
			} else if (pc.isKnight()) {
				if (pc.get_sex() == 0)
					s = "rangking knight male";
				else
					s = "rangking knight female";
			} else if (pc.isElf()) {
				if (pc.get_sex() == 0)
					s = "rangking elf male";
				else
					s = "rangking elf female";
			} else if (pc.isWizard()) {
				if (pc.get_sex() == 0)
					s = "rangking wizard male";
				else
					s = "rangking wizard female";
			} else if (pc.isDarkelf()) {
				if (pc.get_sex() == 0)
					s = "rangking darkelf male";
				else
					s = "rangking darkelf female";
			} else if (pc.isDragonknight()) {
				if (pc.get_sex() == 0)
					s = "rangking dragonknight male";
				else
					s = "rangking dragonknight female";
			} else if (pc.isBlackwizard()) {
				if (pc.get_sex() == 0)
					s = "rangking illusionist male";
				else
					s = "rangking illusionist female";
			} else if (pc.isWarrior()) {
				if (pc.get_sex() == 0)
					s = "rangking warrior male";
				else
					s = "rangking warrior female";
			}
		}
		if (s.equalsIgnoreCase("myth class polymorph")) {
			if (pc.isCrown()) {
				if (pc.get_sex() == 0)
					s = "royal male r";
				else
					s = "royal female r";
			} else if (pc.isKnight()) {
				if (pc.get_sex() == 0)
					s = "knight male r";
				else
					s = "knight female r";
			} else if (pc.isElf()) {
				if (pc.get_sex() == 0)
					if(pc.getCurrentSpriteId() != 21070){
					s = "elf male r";
					}else{
						s = "elf old male";
					}
				else
					if(pc.getCurrentSpriteId() != 21066){
					s = "elf female r";
					}else{
						s = "elf old female";
					}
			} else if (pc.isWizard()) {
				if (pc.get_sex() == 0)
					s = "wizard male r";
				else
					s = "wizard female r";
			} else if (pc.isDarkelf()) {
				if (pc.get_sex() == 0)
					s = "darkelf male r";
				else
					s = "darkelf female r";
			} else if (pc.isDragonknight()) {
				if (pc.get_sex() == 0)
					s = "dragon r";
				else
					s = "dragon r";
			} else if (pc.isBlackwizard()) {
				if (pc.get_sex() == 0)
					s = "dopel male";
				else
					s = "dopel female";
			} else if (pc.isWarrior()) {
				if (pc.get_sex() == 0)
					s = "my warrior";
				else
					s = "my warrior";
			}
		}
		if (s.equalsIgnoreCase("ranking class polymorph1")) {
			if (pc.isCrown()) {
				if (pc.get_sex() == 0)
					s = "rangking prince male1";
				else
					s = "rangking prince female1";
			} else if (pc.isKnight()) {
				if (pc.get_sex() == 0)
					s = "rangking knight male1";
				else
					s = "rangking knight female1";
			} else if (pc.isElf()) {
				if (pc.get_sex() == 0)
					s = "rangking elf male1";
				else
					s = "rangking elf female1";
			} else if (pc.isWizard()) {
				if (pc.get_sex() == 0)
					s = "rangking wizard male1";
				else
					s = "rangking wizard female1";
			} else if (pc.isDarkelf()) {
				if (pc.get_sex() == 0)
					s = "rangking darkelf male1";
				else
					s = "rangking darkelf female1";
			} else if (pc.isDragonknight()) {
				if (pc.get_sex() == 0)
					s = "rangking dragonknight male1";
				else
					s = "rangking dragonknight male1";
			} else if (pc.isBlackwizard()) {
				if (pc.get_sex() == 0)
					s = "rangking illusionist male1";
				else
					s = "rangking illusionist male1";
			} else if (pc.isWarrior()) {
				if (pc.get_sex() == 0)
					s = "rangking warrior male1";
				else
					s = "rangking warrior female1";
			}
		}
		if (s.startsWith("rangking ")) {
			if (!RankUserLoader.getInstance().isRankPoly(pc))
				return false;
		}
		if (s.startsWith("maple")) {
			if (!pc.isPolyRingMaster())
				return false;
		}
		if (s.equalsIgnoreCase("girtas")) {
			if (pc.getAccount().getInfo_kir_poly() != 1){
				pc.sendPackets("코드 :" + pc.getAccount().getInfo_kir_poly());
				return false;
			}
		}
		L1PolyMorph poly = PolyTable.getInstance().getTemplate(s);
		if (pc.isGm()) {
		      SC_SystemMessage.send(pc, "\\f:변신이름 >> " + s);
		    }
		
		if (poly != null || s.equals("")) {
			if (s.equals("")) {
				int spriteId = pc.getCurrentSpriteId();
				if (spriteId == 6034 || spriteId == 6035) {
					return true;
				} else {
					pc.removeSkillEffect(SHAPE_CHANGE);
					if (pc.hasSkillEffect(L1SkillId.POLY_RING_MASTER)) {
						pc.removeSkillEffect(L1SkillId.POLY_RING_MASTER);
					}
				//	L1NeigeBugCheck.shapechange(pc);
					return true;
				}
			} else if (poly.getMinLevel() <= pc.getLevel() || pc.isGm()) {
				if (((item_id == 40008 || item_id == 140008 || item_id == 40410 ) && pc.isPolyRingMaster()) || item_id == 900075 ) {
					ring = true;
				}
				L1PolyMorph.doPoly(pc, poly.getPolyId(), time, L1PolyMorph.MORPH_BY_ITEMMAGIC, ring);
			///.	L1NeigeBugCheck.shapechange(pc);
				try
		        {
		          if (pc.isGm()) {
		            SC_SystemMessage.send(pc, "\\f:변신번호  >> " + pc.getCurrentSpriteId());
		          }
		        }
		        catch (Exception localException) {}
				
				return true;
			} else {
				return false;
			}
		} else {
			return false;
		}
	}

	public static void usePolyPotion(L1PcInstance pc, int itemId) {
		int polyId = 0;
		if ((pc.getLevel() >= 83)) {
			pc.sendPackets("해당 아이템은 82 레벨까지만 사용 가능합니다.");
			return;
		}
		if (itemId == 41143) {
			polyId = 6086;
		} else if (itemId == 41144) {
			polyId = 6087;
		} else if (itemId == 41145) {
			polyId = 6088;
		} else if (itemId == 30057) {
			polyId = 10429;
		} else if (itemId == 30058) {
			polyId = 10431;
		} else if (itemId == 30059) {
			polyId = 10430;
		} else if (itemId == 8000) {
			polyId = 12792;
		} else if (itemId == 8001) { // 7580랜스마스터변신
			polyId = 12237;
		} else if (itemId == 8002) { // 82진데스나이트-완전빠름
			polyId = 12015;
		} else if (itemId == 42655) { // 신규영웅주문서.
			if (pc.isKnight() || pc.isDragonknight() || pc.isWarrior() || pc.isCrown()) {
				polyId = 12283;
			} else if (pc.isDarkelf()) {
				polyId = 12280;
			} else if (pc.isWizard()) {
				polyId = 12295;
			} else if (pc.isBlackwizard()) {
				polyId = 12286;
			} else if (pc.isElf()) {
				polyId = 12314;
			}
		} else if (itemId == 4100290) { // 진 변신 주문서
			if (pc.isKnight() || pc.isWarrior() || pc.isCrown()) {
				polyId = 17541;
			} else if (pc.isDragonknight()) {
				polyId = 17549;
			} else if (pc.isDarkelf()) {
				polyId = 17531;
			} else if (pc.isWizard()) {
				polyId = 17515;
			} else if (pc.isBlackwizard()) {
				polyId = 12286;
			} else if (pc.isElf()) {
				polyId = 17535;
			}
		} else if (itemId == 4100284) {// 진 데스나이트 변신 주문서
			polyId = 17541;
		} else if (itemId == 4100285) {// 진 쉐도우 변신 주문서
			polyId = 17531;
		} else if (itemId == 4100286) {// 진 랜스마스터 변신 주문서
			polyId = 17545;
		} else if (itemId == 4100287) {// 진 바포메트 변신 주문서
			polyId = 17515;
		} else if (itemId == 4100288) {// 진 경비병(활) 변신 주문서
			polyId = 17535;
		} else if (itemId == 4100289) {// 진 경비병(창) 변신 주문서
			polyId = 17549;
		} else if (itemId == 4200100) {// 도펠 주문서
			polyId = 20524;
		} else if (itemId == 4200200) {// 도펠 주문서
			polyId = 18255;
		} else if (itemId == 4200300) {// 도펠 주문서
			polyId = 18260;
		} else if (itemId == 4200400) {// 도펠 주문서
			polyId = 14491;
		} else if (itemId == 4200500) {// 도펠 주문서
			polyId = 19267;
		} else if (itemId == 5922901) {// 도펠 주문서
					polyId = 18402;
			
	}
		L1PolyMorph.doPoly(pc, polyId, 1800, L1PolyMorph.MORPH_BY_ITEMMAGIC, false);
	//	L1NeigeBugCheck.shapechange(pc);
	}

	public static void useLevelPolyScroll(L1PcInstance pc, int itemId) {
		int polyId = 0;
		if (itemId == 210097) { // 30
			if (pc.isCrown()) {
				if (pc.get_sex() == 0) {
					polyId = 6822;
				} else {
					polyId = 6823;
				}
			} else if (pc.isKnight()) {
				if (pc.get_sex() == 0) {
					polyId = 6824;
				} else {
					polyId = 6825;
				}
			} else if (pc.isElf()) {
				if (pc.get_sex() == 0) {
					polyId = 6826;
				} else {
					polyId = 6827;
				}
			} else if (pc.isWizard()) {
				if (pc.get_sex() == 0) {
					polyId = 6828;
				} else {
					polyId = 6829;
				}
			} else if (pc.isDarkelf()) {
				if (pc.get_sex() == 0) {
					polyId = 6830;
				} else {
					polyId = 6831;
				}
			} else if (pc.isDragonknight()) {
				if (pc.get_sex() == 0) {
					polyId = 7139;
				} else {
					polyId = 7140;
				}
			} else if (pc.isBlackwizard()) {
				if (pc.get_sex() == 0) {
					polyId = 7141;
				} else {
					polyId = 7142;
				}
			} else if (pc.isWarrior()) {
				if (pc.get_sex() == 0) {
					polyId = 12490;
				} else {
					polyId = 12494;
				}
			}
		} else if (itemId == 210098) { // 40
			if (pc.isCrown()) {
				if (pc.get_sex() == 0) {
					polyId = 6832;
				} else {
					polyId = 6833;
				}
			} else if (pc.isKnight()) {
				if (pc.get_sex() == 0) {
					polyId = 6834;
				} else {
					polyId = 6835;
				}
			} else if (pc.isElf()) {
				if (pc.get_sex() == 0) {
					polyId = 6836;
				} else {
					polyId = 6837;
				}
			} else if (pc.isWizard()) {
				if (pc.get_sex() == 0) {
					polyId = 6838;
				} else {
					polyId = 6839;
				}
			} else if (pc.isDarkelf()) {
				if (pc.get_sex() == 0) {
					polyId = 6840;
				} else {
					polyId = 6841;
				}
			} else if (pc.isDragonknight()) {
				if (pc.get_sex() == 0) {
					polyId = 7143;
				} else {
					polyId = 7144;
				}
			} else if (pc.isBlackwizard()) {
				if (pc.get_sex() == 0) {
					polyId = 7145;
				} else {
					polyId = 7146;
				}
			} else if (pc.isWarrior()) {
				if (pc.get_sex() == 0) {
					polyId = 12490;
				} else {
					polyId = 12494;
				}
			}
		} else if (itemId == 210099) { // 52
			if (pc.isCrown()) {
				if (pc.get_sex() == 0) {
					polyId = 6842;
				} else {
					polyId = 6843;
				}
			} else if (pc.isKnight()) {
				if (pc.get_sex() == 0) {
					polyId = 6844;
				} else {
					polyId = 6845;
				}
			} else if (pc.isElf()) {
				if (pc.get_sex() == 0) {
					polyId = 6846;
				} else {
					polyId = 6847;
				}
			} else if (pc.isWizard()) {
				if (pc.get_sex() == 0) {
					polyId = 6848;
				} else {
					polyId = 6849;
				}
			} else if (pc.isDarkelf()) {
				if (pc.get_sex() == 0) {
					polyId = 6850;
				} else {
					polyId = 6851;
				}
			} else if (pc.isDragonknight()) {
				if (pc.get_sex() == 0) {
					polyId = 7147;
				} else {
					polyId = 7148;
				}
			} else if (pc.isBlackwizard()) {
				if (pc.get_sex() == 0) {
					polyId = 7149;
				} else {
					polyId = 7150;
				}
			} else if (pc.isWarrior()) {
				if (pc.get_sex() == 0) {
					polyId = 12490;
				} else {
					polyId = 12494;
				}
			}
		} else if (itemId == 210100) { // 55
			if (pc.isCrown()) {
				if (pc.get_sex() == 0) {
					polyId = 6852;
				} else {
					polyId = 6853;
				}
			} else if (pc.isKnight()) {
				if (pc.get_sex() == 0) {
					polyId = 6854;
				} else {
					polyId = 6855;
				}
			} else if (pc.isElf()) {
				if (pc.get_sex() == 0) {
					polyId = 6856;
				} else {
					polyId = 6857;
				}
			} else if (pc.isWizard()) {
				if (pc.get_sex() == 0) {
					polyId = 6858;
				} else {
					polyId = 6859;
				}
			} else if (pc.isDarkelf()) {
				if (pc.get_sex() == 0) {
					polyId = 6860;
				} else {
					polyId = 6861;
				}
			} else if (pc.isDragonknight()) {
				if (pc.get_sex() == 0) {
					polyId = 7151;
				} else {
					polyId = 7152;
				}
			} else if (pc.isBlackwizard()) {
				if (pc.get_sex() == 0) {
					polyId = 7153;
				} else {
					polyId = 7154;
				}
			} else if (pc.isWarrior()) {
				if (pc.get_sex() == 0) {
					polyId = 12490;
				} else {
					polyId = 12494;
				}
			}
		} else if (itemId == 210101) { // 60
			if (pc.isCrown()) {
				if (pc.get_sex() == 0) {
					polyId = 6862;
				} else {
					polyId = 6863;
				}
			} else if (pc.isKnight()) {
				if (pc.get_sex() == 0) {
					polyId = 6864;
				} else {
					polyId = 6865;
				}
			} else if (pc.isElf()) {
				if (pc.get_sex() == 0) {
					polyId = 6866;
				} else {
					polyId = 6867;
				}
			} else if (pc.isWizard()) {
				if (pc.get_sex() == 0) {
					polyId = 6868;
				} else {
					polyId = 6869;
				}
			} else if (pc.isDarkelf()) {
				if (pc.get_sex() == 0) {
					polyId = 6870;
				} else {
					polyId = 6871;
				}
			} else if (pc.isDragonknight()) {
				if (pc.get_sex() == 0) {
					polyId = 7155;
				} else {
					polyId = 7156;
				}
			} else if (pc.isBlackwizard()) {
				if (pc.get_sex() == 0) {
					polyId = 7157;
				} else {
					polyId = 7158;
				}
			} else if (pc.isWarrior()) {
				if (pc.get_sex() == 0) {
					polyId = 12490;
				} else {
					polyId = 12494;
				}
			}
		} else if (itemId == 210102) { // 65
			if (pc.isCrown()) {
				if (pc.get_sex() == 0) {
					polyId = 6872;
				} else {
					polyId = 6873;
				}
			} else if (pc.isKnight()) {
				if (pc.get_sex() == 0) {
					polyId = 6874;
				} else {
					polyId = 6875;
				}
			} else if (pc.isElf()) {
				if (pc.get_sex() == 0) {
					polyId = 6876;
				} else {
					polyId = 6877;
				}
			} else if (pc.isWizard()) {
				if (pc.get_sex() == 0) {
					polyId = 6878;
				} else {
					polyId = 6879;
				}
			} else if (pc.isDarkelf()) {
				if (pc.get_sex() == 0) {
					polyId = 6880;
				} else {
					polyId = 6881;
				}
			} else if (pc.isDragonknight()) {
				if (pc.get_sex() == 0) {
					polyId = 7159;
				} else {
					polyId = 7160;
				}
			} else if (pc.isBlackwizard()) {
				if (pc.get_sex() == 0) {
					polyId = 7161;
				} else {
					polyId = 7162;
				}
			} else if (pc.isWarrior()) {
				if (pc.get_sex() == 0) {
					polyId = 12490;
				} else {
					polyId = 12494;
				}
			}
		} else if (itemId == 210103) { // 70
			if (pc.isCrown()) {
				if (pc.get_sex() == 0) {
					polyId = 6882;
				} else {
					polyId = 6883;
				}
			} else if (pc.isKnight()) {
				if (pc.get_sex() == 0) {
					polyId = 6884;
				} else {
					polyId = 6885;
				}
			} else if (pc.isElf()) {
				if (pc.get_sex() == 0) {
					polyId = 6886;
				} else {
					polyId = 6887;
				}
			} else if (pc.isWizard()) {
				if (pc.get_sex() == 0) {
					polyId = 6888;
				} else {
					polyId = 6889;
				}
			} else if (pc.isDarkelf()) {
				if (pc.get_sex() == 0) {
					polyId = 6890;
				} else {
					polyId = 6891;
				}
			} else if (pc.isDragonknight()) {
				if (pc.get_sex() == 0) {
					polyId = 7163;
				} else {
					polyId = 7164;
				}
			} else if (pc.isBlackwizard()) {
				if (pc.get_sex() == 0) {
					polyId = 7165;
				} else {
					polyId = 7166;
				}
			} else if (pc.isWarrior()) {
				if (pc.get_sex() == 0) {
					polyId = 12490;
				} else {
					polyId = 12494;
				}
			}
		} else if (itemId == 210116) { // 75
			if (pc.isCrown()) {
				if (pc.get_sex() == 0) {
					polyId = 10987;
				} else {
					polyId = 10988;
				}
			} else if (pc.isKnight()) {
				if (pc.get_sex() == 0) {
					polyId = 10989;
				} else {
					polyId = 10990;
				}
			} else if (pc.isElf()) {
				if (pc.get_sex() == 0) {
					polyId = 10991;
				} else {
					polyId = 10992;
				}
			} else if (pc.isWizard()) {
				if (pc.get_sex() == 0) {
					polyId = 10993;
				} else {
					polyId = 10994;
				}
			} else if (pc.isDarkelf()) {
				if (pc.get_sex() == 0) {
					polyId = 10995;
				} else {
					polyId = 10996;
				}
			} else if (pc.isDragonknight()) {
				if (pc.get_sex() == 0) {
					polyId = 10997;
				} else {
					polyId = 10998;
				}
			} else if (pc.isBlackwizard()) {
				if (pc.get_sex() == 0) {
					polyId = 10999;
				} else {
					polyId = 11000;
				}
			} else if (pc.isWarrior()) {
				if (pc.get_sex() == 0) {
					polyId = 12490;
				} else {
					polyId = 12494;
				}
			}
		} else if (itemId == 210117) { // 80
			if (pc.isCrown()) {
				if (pc.get_sex() == 0) {
					polyId = 11001;
				} else {
					polyId = 11002;
				}
			} else if (pc.isKnight()) {
				if (pc.get_sex() == 0) {
					polyId = 11003;
				} else {
					polyId = 11004;
				}
			} else if (pc.isElf()) {
				if (pc.get_sex() == 0) {
					polyId = 11005;
				} else {
					polyId = 11006;
				}
			} else if (pc.isWizard()) {
				if (pc.get_sex() == 0) {
					polyId = 11007;
				} else {
					polyId = 11008;
				}
			} else if (pc.isDarkelf()) {
				if (pc.get_sex() == 0) {
					polyId = 11009;
				} else {
					polyId = 11010;
				}
			} else if (pc.isDragonknight()) {
				if (pc.get_sex() == 0) {
					polyId = 11011;
				} else {
					polyId = 11012;
				}
			} else if (pc.isBlackwizard()) {
				if (pc.get_sex() == 0) {
					polyId = 11013;
				} else {
					polyId = 11014;
				}
			} else if (pc.isWarrior()) {
				if (pc.get_sex() == 0) {
					polyId = 12490;
				} else {
					polyId = 12494;
				}
				// } else if (itemId == 813) { // 수련자 영웅 변신 주문서
				// if (pc.isCrown()) {
				// polyId = 12283;
				// } else if (pc.isKnight()) {
				// polyId = 12283;
				// } else if (pc.isElf()) {
				// polyId = 12314;
				// } else if (pc.isWizard()) {
				// polyId = 12286;
				// } else if (pc.isDarkelf()) {
				// polyId = 12280;
				// } else if (pc.isDragonknight()) {
				// polyId = 12283;
				// } else if (pc.isBlackwizard()) {
				// polyId = 12286;
				// } else if (pc.is전사()) {
				// polyId = 12283;
				// }
			}
		}
		L1PolyMorph.doPoly(pc, polyId, 1800, L1PolyMorph.MORPH_BY_ITEMMAGIC, false);
	//	L1NeigeBugCheck.shapechange(pc);
	}

	public static int RandomELevel(L1ItemInstance item, int itemId) {
		int j = _random.nextInt(100) + 1;
		if (itemId == L1ItemId.B_SCROLL_OF_ENCHANT_ARMOR || itemId == L1ItemId.B_SCROLL_OF_ENCHANT_WEAPON
				|| itemId == L1ItemId.Inadril_T_ScrollB || itemId == L1ItemId.Inadril_T_ScrollB2
				|| itemId == L1ItemId.C_SCROLL_OF_ENCHANT_ARMOR6) {
//			if (item.getItem().get_safeenchant() == 0) {
//				return 1;
//			}
//			if (item.getItem().get_safeenchant() == 0) {	//집행 레전드 legend
//				if (j <= 40) {
//					return 1;
//				} else if (j >= 41 && j <= 74) {
//					return 2;
//				} else if (j >= 75 && j <= 100) {
//					return 3;// 원본3
//				}
//				
//			}
			
			if (item.getEnchantLevel() <= -1) {
				return 1;
				
			} else if (item.getEnchantLevel() <= 2) {
				if (j < 30) {
					return 1;
				} else if (j >= 31 && j <= 70) {
					return 2;
				} else if (j >= 71 && j <= 100) {
					return 3;// 원본3
				}
			} else if (item.getEnchantLevel() >= 3 && item.getEnchantLevel() <= 5) {
				if (j < 50) {
					return 2;
				} else {
					return 1;
				}
			}
			
			if (item.getItem().get_safeenchant() == 0) {
				
			}
			return 1;
		} else if (itemId == 140129 || itemId == 140130) {
			if (item.getEnchantLevel() < 0) {
				if (j < 30) {
					return 2;
				} else {
					return 1;
				}
			} else if (item.getEnchantLevel() <= 2) {
				if (j < 32) {
					return 1;
				} else if (j >= 33 && j <= 60) {
					return 2;
				} else if (j >= 61 && j <= 100) {
					return 3;
				}
			} else if (item.getEnchantLevel() >= 3 && item.getEnchantLevel() <= 5) {
				if (j < 60) {
					return 2;
				} else {
					return 1;
				}
			}
			return 1;
		}
		return 1;
	}

	public static void polyAction(L1PcInstance attacker, L1Character cha, int itemId, String s) {
		boolean isSameClan = false;
		if (cha instanceof L1PcInstance) {
			L1PcInstance pc = (L1PcInstance) cha;
			if (pc.getClanid() != 0 && attacker.getClanid() == pc.getClanid()) {
				isSameClan = true;
			}

			if (attacker.getId() != pc.getId() && pc.hasSkillEffect(L1SkillId.POLY_RING_MASTER)) {
				// 대상이 변신 지배 반지로 변신했을경우
				SC_SkillSound.send(pc, pc.getId(), 15846);
				SC_SkillSound.broadcast(pc, pc.getId(), 15846);
				SC_ServerMessage.send(attacker, 280);
				return;
			}
		}
		if (cha instanceof L1MonsterInstance) {
			return;
		}
		if (attacker.getId() != cha.getId() && !isSameClan) {
			int probability = 3 * (attacker.getLevel() - cha.getLevel()) - cha.getResistance().getEffectedMrBySkill();
			int rnd = _random.nextInt(100) + 1;
			if (rnd > probability) {
				SC_ServerMessage.send(attacker, 280);
				return;
			}
		}

		int[] polyArray = { 29, 979, 1037, 1039, 3860, 3861, 3862, 3863, 3864, 3865, 3904, 3906, 95, 146, 2374, 2376,
				2377, 2378, 3866, 3867, 3868, 3869, 3870, 3871, 3872, 3873, 3874, 3875, 3876, 3882, 3883, 3884, 3885,
				11358, 11396, 11397, 12225, 12226, 11399, 11398, 12227 }; // 단풍막대
		// 리뉴얼로
		// 추가

		int pid = _random.nextInt(polyArray.length);
		int polyId = polyArray[pid];

		if (cha instanceof L1PcInstance) {
			L1PcInstance pc = (L1PcInstance) cha;
			if (pc.getInventory().checkEquipped(20281) || pc.isPolyRingMaster()) {
				if (usePolyScroll(pc, itemId, s)) {
				} else {
					SC_ServerMessage.send(pc, 181);
				}
			} else {
				L1Skills skillTemp = SkillsTable.getInstance().getTemplate(SHAPE_CHANGE);
				L1PolyMorph.doPoly(pc, polyId, skillTemp.getBuffDuration(), L1PolyMorph.MORPH_BY_ITEMMAGIC, false);
				if (attacker.getId() != pc.getId()) {
					SC_ServerMessage.send(pc, 241, attacker.getName()); // 누구가
					// 당신을
					// 변신시켰습니다.
				}
			}
		} else if (cha instanceof L1MonsterInstance) {
			L1MonsterInstance mob = (L1MonsterInstance) cha;
			if (mob.getLevel() < 50) {
				int npcId = mob.getNpcTemplate().get_npcId();
				if (npcId != 45338 && npcId != 45370 && npcId != 45456 && npcId != 45464 && npcId != 45473
						&& npcId != 45488 && npcId != 45497 && npcId != 45516 && npcId != 45529 && npcId != 45458) {
					L1Skills skillTemp = SkillsTable.getInstance().getTemplate(SHAPE_CHANGE);
					L1PolyMorph.doPoly(mob, polyId, skillTemp.getBuffDuration(), L1PolyMorph.MORPH_BY_ITEMMAGIC, false);
				}
			}
		}
	}

}
