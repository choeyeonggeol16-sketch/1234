package I1j.server.server.model.Thread;

import l1j.server.server.model.L1World;
import l1j.server.server.model.Instance.L1PcInstance;

public class CharacterQuickCheckThread extends Thread {
	
	private static CharacterQuickCheckThread _instance;
	
	private static final int SLEEP = 60000;
	
	public static CharacterQuickCheckThread getInstance() {
		if (_instance == null) {
			_instance = new CharacterQuickCheckThread();
			_instance.start();
		}
		return _instance;
	}
	public CharacterQuickCheckThread() {
		super("server.threads.pc.CharacterQuickCheckThread");
	}

	public void run() {
		while (true) {
			try {
				for (L1PcInstance _client : L1World.getInstance().getAllPlayers()) {
					if (_client.isPrivateShop() || _client.noPlayerck2 || _client.getNetConnection() == null) { 
						continue;
					} else {
						try {
							if (_client.getNetConnection().isClosed()) {
								System.out.println(_client.getName() + " << ����ȵ� : �̸�Ʈ�� ���ÿ� �������� �ߴ��� Ȯ��.");
								_client.logout();
								_client.getNetConnection().close();
							}
						} catch (Exception e) {
						}
					}
				}
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				try {
					Thread.sleep(SLEEP);//1��
				} catch (InterruptedException e) {
					// TODO �ڵ� ������ catch ����
					e.printStackTrace();
				}
			}
		}
	}
}
