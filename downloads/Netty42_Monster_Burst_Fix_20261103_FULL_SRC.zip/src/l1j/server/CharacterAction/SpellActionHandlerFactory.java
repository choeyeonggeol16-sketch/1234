package l1j.server.CharacterAction;

import java.util.HashMap;

import l1j.server.CharacterAction.Magic.BackgroundActionHandler;
import l1j.server.CharacterAction.Magic.DirectionActionHandler;
import l1j.server.CharacterAction.Magic.RunNCallClanActionHandler;
import l1j.server.CharacterAction.Magic.SkillActionHandler;
import l1j.server.CharacterAction.Magic.SummonMonsterActionHandler;
import l1j.server.CharacterAction.Magic.TeleportActionHandler;
import l1j.server.CharacterAction.Magic.TruetargetActionHandler;
import l1j.server.server.model.skill.SkillId;

public class SpellActionHandlerFactory {
	private static final HashMap<Integer, SkillActionHandler> _handlers;
	static{
		_handlers = new HashMap<Integer, SkillActionHandler>(256);
		for(int i=256; i>0; --i) {
			switch(i){
			case SkillId.��_Ŭ��: case SkillId.��_Ŭ��:
				_handlers.put(i, new RunNCallClanActionHandler());
				break;
			case SkillId.Ʈ��_Ÿ��:
				_handlers.put(i, new TruetargetActionHandler());
				break;
			case SkillId.�ڷ���Ʈ: case SkillId.�Ž�_�ڷ���Ʈ:
				_handlers.put(i, new TeleportActionHandler());
				break;
			case SkillId.����_����:
				_handlers.put(i, new SummonMonsterActionHandler());
				break;
			case SkillId.���̾�_��: case SkillId.������_��Ʈ��:
				_handlers.put(i, new BackgroundActionHandler());
				break;
			default:
				_handlers.put(i, new DirectionActionHandler());
				break;
			}
		}
	}
	
	public static SkillActionHandler create(int skillId){
		SkillActionHandler default_handler = _handlers.get(skillId);
		if(default_handler == null) {
			return null;
		}
		return default_handler.copy().setSkillId(skillId);
	}
}
