package l1j.server.ItemSkill.Model.Attack;

import l1j.server.commons;
import l1j.server.ItemSkill.Model.ItemSkillModel;
import l1j.server.server.model.L1Character;
import l1j.server.server.model.Instance.ItemInstance;
import l1j.server.server.model.skill.SkillId;
import l1j.server.server.serverpackets.S_SkillIconWindShackle;
import l1j.server.server.serverpackets.S_SkillSound;
import l1j.server.server.utils.CommonUtil;
import l1j.server.server.utils.SkillUtil;

public class Magic_Weapon_Pumpkin_Curse extends ItemSkillModel {
	public double get(L1Character attacker, L1Character defender, ItemInstance t_item, double dwd) {
		
		double dmg = 0.0D;
		
		// ��ų Ȯ��, ��ų �ߵ�, ��ų ���� ���� 
		if(!isProbability(attacker, t_item) || defender.hasSkillEffect(SkillId.����_��Ŭ) || commons.isLock(defender)) {
			return 0.0D;
		}
		// ī�� ����  üũ 
		if(is_counter) {
			if(SkillUtil.isCounterMagic(defender)) {
				return 0.0D;
			}
		}
		// ���� üũ
		if (is_magic) {	
			int time =  CommonUtil.random(min_dmg) + 1;
			if (time > 0) {				
				defender.setSkillEffect(SkillId.����_��Ŭ, time);
				defender.sendPackets(new S_SkillIconWindShackle(defender.getId(), time), true);
			}		
		}
		if (eff_id > 0) {
			broadcast(defender, S_SkillSound.get(defender.getId(), eff_id)); 
		}
		return dmg;
	}
}
