package l1j.server.ItemSkill.Model.Attack;

import l1j.server.commons;
import l1j.server.ItemSkill.Model.ItemSkillModel;
import l1j.server.server.model.L1Character;
import l1j.server.server.model.Instance.ItemInstance;
import l1j.server.server.model.Instance.MonsterInstance;
import l1j.server.server.model.Instance.L1PcInstance;
import l1j.server.server.utils.SkillUtil;

public class Melee_Weapon_Magic_Dagger extends ItemSkillModel {
	public double get(L1Character attacker, L1Character defender, ItemInstance t_item, double dwd) {
		
		double dmg = 0.0D;
		
		// ��ų ���� ���� 
		if(commons.isLock(defender)) {
			return 0.0D;
		}		
		if (is_magic) {	
			// Ÿ���� �ǽ� �ΰ�� 
			if(defender instanceof L1PcInstance) {
				L1PcInstance targetpc = (L1PcInstance) defender;
				int targetMr = targetpc.getResistance().getMr();
				if(targetMr <= 100) {
					dmg = 1.0D;
				} else {
					dmg = 0;
				}		
			} // Ÿ���� ���� �� ��� 
			else if(defender instanceof MonsterInstance) {
				MonsterInstance targetnpc = (MonsterInstance) defender;
				int targetMr = targetnpc.getResistance().getMr();
				if(targetMr <= 50) {
					dmg = 1.0D;
				} else {
					dmg = 0;
				}		
			}
		}
		// �̷����� ���� ���� ó�� 
		if(is_erase) {
			SkillUtil.cancelEraseMagic(defender);
		}		
		// ���� üũ 
		if(defender.getCurrentMp() < dmg) {
			dmg = defender.getCurrentMp();
		}	
		// ������ ����
		defender.setCurrentMp((int) (defender.getCurrentMp() - dmg));
		attacker.setCurrentMp((int) (attacker.getCurrentMp() + dmg));
		return dmg;
	}
}
