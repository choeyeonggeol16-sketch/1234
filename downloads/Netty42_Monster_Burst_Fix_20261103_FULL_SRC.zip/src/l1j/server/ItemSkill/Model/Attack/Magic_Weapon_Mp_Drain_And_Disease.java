package l1j.server.ItemSkill.Model.Attack;

import l1j.server.commons;
import l1j.server.ItemSkill.Model.ItemSkillModel;
import l1j.server.server.model.L1Character;
import l1j.server.server.model.Instance.ItemInstance;
import l1j.server.server.model.skill.SkillId;
import l1j.server.server.serverpackets.S_SkillSound;
import l1j.server.server.utils.CommonUtil;
import l1j.server.server.utils.SkillUtil;

public class Magic_Weapon_Mp_Drain_And_Disease extends ItemSkillModel {
	public double get(L1Character attacker, L1Character defender, ItemInstance t_item, double dwd) {
		double dmg = 0.0D;	
		// ��ų ���� ���� 
		if(commons.isLock(defender)) {
			return 0.0D;
		}
		// Ÿ���� mr üũ
		if (is_magic) {	
			dmg = CommonUtil.randomRange(1, 9);		
			
			int targetMr = defender.getResistance().getMr();
		    if(targetMr >= 100) {
		    	dmg /= 2;
		    }
		}
		// �̷����� ���� ���� ó�� 
		if(is_erase) {
			SkillUtil.cancelEraseMagic(defender);
		}		
		// ���� üũ 
		if(defender.getCurrentMp() < dmg) {
			dmg = defender.getCurrentMp();
		}	
		// ������ ����
		defender.setCurrentMp((int) (defender.getCurrentMp() - dmg));
		attacker.setCurrentMp((int) (attacker.getCurrentMp() + dmg));
		
		if(!isProbability(attacker, t_item) || defender.hasSkillEffect(SkillId.������)) {
			return 0.0D;
		}
		// ī���� ���� ����
		if(is_counter) {
			if(SkillUtil.isCounterMagic(defender)) {
				return 0.0D;
			}
		}	
		// ���� ����
		int targetMr = defender.getResistance().getMr();
	    if(targetMr >= 100) {
	    	return 0.0D;
	    }
		
		int t = min_dmg;
		defender.addMeleeHit(-6);
		defender.getAC().addAc(12);
		defender.setSkillEffect(SkillId.������, t);
		// ����Ʈ ó��
		if (eff_id > 0) {
			broadcast(defender, S_SkillSound.get(defender.getId(), eff_id)); 
		}
		return 0.0D;
	}
}

