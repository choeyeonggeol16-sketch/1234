package l1j.server.ItemSkill.Model.Attack;

import l1j.server.commons;
import l1j.server.ItemSkill.Model.ItemSkillModel;
import l1j.server.configure.Config;
import l1j.server.server.model.L1Character;
import l1j.server.server.model.Instance.ItemInstance;
import l1j.server.server.model.Instance.L1PcInstance;
import l1j.server.server.model.skill.SkillId;
import l1j.server.server.serverpackets.S_ServerMessage;
import l1j.server.server.serverpackets.S_SkillSound;
import l1j.server.server.utils.EffectUtil;

public class Melee_Weapon_DiceDagger extends ItemSkillModel {
	public double get(L1Character attacker, L1Character defender, ItemInstance t_item, double dwd) {
		
		// ��ų Ȯ�� �Ǻ� , ��ų ���� ���� 
		if(!isProbability(attacker, t_item) || commons.isLock(defender)) {
			return 0.0D;
		}
		int hp = defender.getCurrentHp();
		if (hp <= 0) {
			return 0.0D;
		}
		double dmg = hp;
		// ���� �Ǻ�
		if(is_magic) {		
			dmg /= 2;	
			remove(attacker, t_item);
		}
		// �Ƹ� �극��ũ ������ ó�� 
		if(defender instanceof L1PcInstance) {
			L1PcInstance targetPc = (L1PcInstance) defender;
			if (targetPc != null && targetPc.hasSkillEffect(SkillId.�Ƹ�_�극��ũ)) {
				dmg *= Config.�Ƹ�_�극��ũ;
			}
		}	
		// ī���� ���� ó�� 
		if(is_counter) {
			if(defender.hasSkillEffect(SkillId.ī����_����)) {
				defender.removeSkillEffect(SkillId.ī����_����);
				S_SkillSound s = S_SkillSound.get(defender.getId(), EffectUtil.ī����_����);
				defender.sendPackets(s, false);
				defender.broadcastPacket(s);
				dmg = 0;
				remove(attacker, t_item);
			}
		}	
		// Ÿ���� ������ ������ ó�� 
		if(defender instanceof L1PcInstance) {
			L1PcInstance targetPc = (L1PcInstance) defender;
			
			if(targetPc.hasSkillEffect(SkillId.������_�Ƹ�)) {
				int targetLevel = targetPc.getLevel() < 50 ? 50 : targetPc.getLevel();
				dmg -= (targetLevel - 50) / 5 + 1;
			}		
		    dmg -= targetPc.getDamageReduction();
		    
			if (targetPc != null && targetPc.hasSkillEffect(SkillId.�̹�_����)) {
				dmg *= Config.IMMNUE_TO_HARM_RATE;
			}		
		}
		return dmg;
	}

	private void remove(L1Character c, ItemInstance item) {
		c.sendPackets(new S_ServerMessage(158, item.getLogName()));
		c.getInventory().removeItem(item, 1);
	}
}
