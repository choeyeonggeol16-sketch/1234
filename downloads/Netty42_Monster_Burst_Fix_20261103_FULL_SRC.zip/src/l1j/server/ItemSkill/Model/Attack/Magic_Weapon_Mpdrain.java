package l1j.server.ItemSkill.Model.Attack;

import l1j.server.commons;
import l1j.server.ItemSkill.Model.ItemSkillModel;
import l1j.server.server.model.L1Character;
import l1j.server.server.model.Instance.ItemInstance;
import l1j.server.server.utils.CommonUtil;
import l1j.server.server.utils.SkillUtil;

public class Magic_Weapon_Mpdrain extends ItemSkillModel {
	public double get(L1Character attacker, L1Character defender, ItemInstance t_item, double dwd) {
		
		double dmg = 0.0D;	
		
		// ��ų ���� ���� 
		if(commons.isLock(defender)) {
			return 0.0D;
		}		
		// Ÿ���� mr üũ
		if (is_magic) {	
			dmg = CommonUtil.randomRange(1, 9);		
			
			int targetMr = defender.getResistance().getMr();
		    if(targetMr >= 100) {
		    	dmg /= 2;
		    }
		}
		// �̷����� ���� ���� ó�� 
		if(is_erase) {
			SkillUtil.cancelEraseMagic(defender);
		}		
		// ���� üũ 
		if(defender.getCurrentMp() < dmg) {
			dmg = defender.getCurrentMp();
		}	
		// ������ ����
		defender.setCurrentMp((int) (defender.getCurrentMp() - dmg));
		attacker.setCurrentMp((int) (attacker.getCurrentMp() + dmg));
	
		return 0.0D;
	}
	

}
