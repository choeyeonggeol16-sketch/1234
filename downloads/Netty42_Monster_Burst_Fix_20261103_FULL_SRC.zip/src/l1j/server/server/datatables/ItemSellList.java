package l1j.server.server.datatables;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

import l1j.server.L1DatabaseFactory;
import l1j.server.server.model.Instance.ItemInstance;
import l1j.server.server.model.Instance.L1PcInstance;
import l1j.server.server.utils.SQLUtil;

public class ItemSellList {

	private static Logger _log = Logger.getLogger(ItemSellList.class.getName());

	private volatile static ItemSellList _instance;

	private ItemSellList() {
	}

	public static synchronized ItemSellList getInstance() {

		if (_instance == null) {
			_instance = new ItemSellList();
		}
		return _instance;
	}

	public void writeTopic(L1PcInstance player, String date, ItemInstance item, int count) {
		int counts = 0;

		Connection con = null;
		PreparedStatement pstm1 = null;
		ResultSet rs = null;
		PreparedStatement pstm2 = null;
		try {
			con = L1DatabaseFactory.getInstance().getConnection();
			pstm1 = con.prepareStatement("SELECT * FROM board_item ORDER BY id DESC");
			rs = pstm1.executeQuery();
			if (rs.next()) {
				counts = rs.getInt("id");
			}

			pstm2 = con.prepareStatement(
					"INSERT INTO board_item SET id=?, name=?, item_id=?, item_name=?, item_enchantlvl=?, count=?, AccountName=?, date=?, UpClick=?,bless=?, bless_type=?, bless_type_value=?");
			pstm2.setInt(1, (counts + 1));
			pstm2.setString(2, player.getName());
			pstm2.setInt(3, item.getItemId());
			pstm2.setString(4, item.getName());
			pstm2.setInt(5, item.getEnchantLevel());
			pstm2.setInt(6, count);
			pstm2.setString(7, player.getAccountName());
			pstm2.setString(8, date);
			pstm2.setInt(9, item.getAttrEnchantLevel());
			pstm2.setInt(10, item.getBless());
			pstm2.setInt(11, item.getBlessType());
			pstm2.setInt(12, item.getBlessTypeValue());
			  
			pstm2.execute(); 

		} catch (SQLException e) {
			_log.log(Level.SEVERE, e.getLocalizedMessage(), e);
		} finally {
			SQLUtil.close(rs);
			SQLUtil.close(pstm1);
			SQLUtil.close(pstm2);
			SQLUtil.close(con);
		}
	}

	public void boardclear() {
		Connection con = null;
		PreparedStatement pstm = null;

		try {
			con = L1DatabaseFactory.getInstance().getConnection();
			pstm = con.prepareStatement("DELETE FROM board_item");
			pstm.execute();

		} catch (SQLException e) {
			_log.info("�Խ���  ���� ����4!");
		} finally {

			SQLUtil.close(pstm);
			SQLUtil.close(con);

		}

	}

	public void deleteTopic(int number) {
		Connection con = null;
		PreparedStatement pstm = null;
		try {

			con = L1DatabaseFactory.getInstance().getConnection();
			pstm = con.prepareStatement("DELETE FROM board_item WHERE id=?");
			pstm.setInt(1, number);
			pstm.execute();
		} catch (SQLException e) {
			_log.log(Level.SEVERE, e.getLocalizedMessage(), e);
		} finally {
			SQLUtil.close(pstm);
			SQLUtil.close(con);
		}
	}

}
