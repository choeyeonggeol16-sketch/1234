package l1j.server.server.command.executor;

import java.util.StringTokenizer;

import l1j.server.server.datatables.ExpTable;
import l1j.server.server.model.L1World;
import l1j.server.server.model.Instance.L1PcInstance;
import l1j.server.server.utils.IntRange;

public class L1Level implements L1CommandExecutor {

	private L1Level() {
	}

	public static L1CommandExecutor getInstance() {
		return new L1Level();
	}

	public void execute(L1PcInstance pc, String cmdName, String poby) {
		try {
			StringTokenizer token = new StringTokenizer(poby);
			String name = token.nextToken();
			int level = Integer.parseInt(token.nextToken());

			L1PcInstance target = L1World.getInstance().getPlayer(name);
			if (target == null) {
				pc.sendPackets("�ش� ���̰� �����ϴ�.");
				return;
			}

			if (!IntRange.includes(level, 1, 127)) {
				pc.sendPackets("�Է��� ������ ������ ������ϴ�. (1~99)");
				return;
			}
			int percent = 0;
			if (token.hasMoreTokens()) {
				percent = Integer.parseInt(token.nextToken());
			}
			if (!IntRange.includes(percent, 0, 127)) {
				pc.sendPackets("�Է��� �ۼ�Ʈ�� ������ ������ϴ�. (0~99)");
				return;
			}

			int exp = ExpTable.getExpByLevel(level);
			exp = (int) (exp + percent * 0.01D * ExpTable.getNeedExpNextLevel(level));
			target.setExp(exp);
			pc.sendPackets("(���� ����) " + target.getName() + " - Lv. " + level + " / Exp. " + percent + "%");
		} catch (Exception e) {
			// e.printStackTrace();
			pc.sendPackets("." + cmdName + " (ĳ���͸�) (����:1-127) (�ۼ�Ʈ:0-99)");
		}
	}
}