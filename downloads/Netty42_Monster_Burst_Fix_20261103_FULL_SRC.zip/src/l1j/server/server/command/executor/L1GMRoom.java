/*
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2, or (at your option)
 * any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.   See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
 * 02111-1307, USA.
 *
 * http://www.gnu.org/copyleft/gpl.html
 */
package l1j.server.server.command.executor;

import l1j.server.server.GMCommandsConfig;
import l1j.server.server.model.L1Location;
import l1j.server.server.model.Instance.L1PcInstance;
import l1j.server.server.serverpackets.S_SystemMessage;

public class L1GMRoom implements L1CommandExecutor {

	private L1GMRoom() {
	}

	public static L1CommandExecutor getInstance() {
		return new L1GMRoom();
	}

	@Override
	public void execute(L1PcInstance pc, String cmdName, String arg) {
		try {
			int i = 0;
			try {
				i = Integer.parseInt(arg);
			} catch (NumberFormatException e) {
			}
            // �������� ���� ����
			switch (i) {
			case 1: pc.teleport(32737, 32796, (short) 99, pc.getHeading(), 169, false, false); break;
			case 2: pc.teleport(33440, 32805, (short) 4, pc.getHeading(), 169, false, false); break;
			case 3: pc.teleport(33082, 33390, (short) 4, pc.getHeading(), 169, false, false); break;
			case 4: pc.teleport(34055, 32290, (short) 4, pc.getHeading(), 169, false, false); break;
			case 5: pc.teleport(33723, 32495, (short) 4, pc.getHeading(), 169, false, false); break;
			case 6: pc.teleport(32614, 32788, (short) 4, pc.getHeading(), 169, false, false); break;
			case 7: pc.teleport(32678, 32857, (short) 2005, pc.getHeading(), 169, false, false); break;
			case 8: pc.teleport(33515, 32858, (short) 4, pc.getHeading(), 169, false, false); break;
			case 9: pc.teleport(32763, 32817, (short) 622, pc.getHeading(), 169, false, false); break;
			case 10: pc.teleport(32572, 32944, (short) 0, pc.getHeading(), 169, false, false); break;
			case 11: pc.teleport(32736, 32796, (short) 16896, pc.getHeading(), 169, false, false); break;
			case 12: pc.teleport(32783, 32865, (short) 621, pc.getHeading(), 169, false, false); break;
			case 13: pc.teleport(32805, 32814, (short) 5490, pc.getHeading(), 169, false, false); break;
			case 14: pc.teleport(32736, 32787, (short) 15, pc.getHeading(), 169, false, false); break;
			case 15: pc.teleport(32735, 32788, (short) 29, pc.getHeading(), 169, false, false); break;
			case 16: pc.teleport(32730, 32802, (short) 52, pc.getHeading(), 169, false, false); break;
			case 17: pc.teleport(32572, 32826, (short) 64, pc.getHeading(), 169, false, false); break;
			case 18: pc.teleport(32895, 32533, (short) 300, pc.getHeading(), 169, false, false); break;
			case 19: pc.teleport(33168, 32779, (short) 4, pc.getHeading(), 169, false, false); break;
			case 20: pc.teleport(32623, 33379, (short) 4, pc.getHeading(), 169, false, false); break;	
			case 21: pc.teleport(33630, 32677, (short) 4, pc.getHeading(), 169, false, false); break;
			case 22: pc.teleport(33524, 33394, (short) 4, pc.getHeading(), 169, false, false); break;
			case 23: pc.teleport(34090, 33260, (short) 4, pc.getHeading(), 169, false, false); break;
			case 24: pc.teleport(32424, 33068, (short) 440, pc.getHeading(), 169, false, false); break;
			case 25: pc.teleport(32800, 32868, (short) 1001, pc.getHeading(), 169, false, false); break;
			case 26: pc.teleport(32800, 32856, (short) 1000, pc.getHeading(), 169, false, false); break;
			case 27: pc.teleport(32630, 32903, (short) 780, pc.getHeading(), 169, false, false); break;
			case 28: pc.teleport(32743, 32799, (short) 781, pc.getHeading(), 169, false, false); break;
			case 29: pc.teleport(32735, 32830, (short) 782, pc.getHeading(), 169, false, false); break;
			case 30: pc.teleport( 32734, 32270, (short) 4, pc.getHeading(), 169, false, false); break;		
			case 31: pc.teleport( 32699, 32819, (short) 82, pc.getHeading(), 169, false, false); break;
			case 32: pc.teleport( 32769, 32770, (short) 56, pc.getHeading(), 169, false, false); break;
			case 33: pc.teleport( 32929, 32995, (short) 410, pc.getHeading(), 169, false, false); break;	
			case 34: pc.teleport( 32791, 32691, (short) 1005, pc.getHeading(), 169, false, false); break;
			case 35: pc.teleport( 32960, 32840,(short) 1011, pc.getHeading(), 169, false, false); break;		
			case 36: pc.teleport( 32849, 32876, (short) 1017, pc.getHeading(), 169, false, false); break;		
			case 37: pc.teleport( 32725, 32800, (short) 67, pc.getHeading(), 169, false, false); break;
			case 38: pc.teleport(  32771, 32831, (short) 65, pc.getHeading(), 169, false, false); break;			
			case 39: pc.teleport(  32696, 32824, (short) 37, pc.getHeading(), 169, false, false); break;
			case 40: pc.teleport( 32922, 32812, (short) 430, pc.getHeading(), 169, false, false); break;
			case 41: pc.teleport( 32737, 32834,  (short) 2004, pc.getHeading(), 169, false, false); break;		
			case 42: pc.teleport( 32707, 32846, (short) 2, pc.getHeading(), 169, false, false); break;		
			case 43: pc.teleport( 32772, 32861, (short) 400, pc.getHeading(), 169, false, false); break;			
			case 44: pc.teleport( 32982, 32808, (short) 244, pc.getHeading(), 169, false, false); break;		
			case 45: pc.teleport( 32837, 32770, (short) 479, pc.getHeading(), 169, false, false); break;		
			case 46: pc.teleport(  32724, 32792, (short) 536, pc.getHeading(), 169, false, false); break;			
			case 47: pc.teleport( 32847, 32793,(short) 532, pc.getHeading(), 169, false, false); break;
			case 48: pc.teleport( 32843, 32693,(short) 550, pc.getHeading(), 169, false, false); break;
			case 49: pc.teleport(  32781, 32801, (short) 558, pc.getHeading(), 169, false, false); break;
			case 50: pc.teleport( 32731, 32862, (short) 784, pc.getHeading(), 169, false, false); break;		
			case 51: pc.teleport( 32728, 32704, (short) 4, pc.getHeading(), 169, false, false); break;		
			case 52: pc.teleport( 32827, 32658, (short) 4, pc.getHeading(), 169, false, false); break;		
			case 53: pc.teleport( 32852, 32713, (short) 4, pc.getHeading(), 169, false, false); break;		
			case 54: pc.teleport( 32914, 33427, (short) 4, pc.getHeading(), 169, false, false); break;		
			case 55: pc.teleport( 32962, 33251,  (short) 4, pc.getHeading(), 169, false, false); break;		
			case 56: pc.teleport( 32908, 33183,(short) 4, pc.getHeading(), 169, false, false); break;		
			case 57: pc.teleport( 34272, 33361, (short) 4, pc.getHeading(), 169, false, false); break;		
			case 58: pc.teleport(  34258, 33202, (short) 4, pc.getHeading(), 169, false, false); break;
			case 59: pc.teleport( 34225, 33313, (short) 4, pc.getHeading(), 169, false, false); break;
			case 60: pc.teleport( 32682, 32892, (short) 5167, pc.getHeading(), 169, false, false); break;			
			case 61: pc.teleport( 33052, 32339, (short) 4, pc.getHeading(), 169, false, false); break;
			case 62: pc.teleport( 32769, 32827, (short) 610, pc.getHeading(), 169, false, false); break;
			case 63: pc.teleport( 32736, 32796, (short) 16896, pc.getHeading(), 169, false, false);
			break;
			default:
				L1Location loc = GMCommandsConfig.ROOMS.get(arg.toLowerCase());
				if (loc == null) {
					pc.sendPackets(new S_SystemMessage("==================<��ȯ ���>==================="));
					pc.sendPackets(new S_SystemMessage("1.gm�� 2.��� 3.���� 4.���� 5.���� 6.�۷�� 7.����"));
					pc.sendPackets(new S_SystemMessage("8.������ 9.���и� 10.���� 11.���� 12.���� 13.����"));
					pc.sendPackets(new S_SystemMessage("14.��Ʈ�� 15.���ټ� 16.����� 17.���̼� 18.�Ƶ���"));
					pc.sendPackets(new S_SystemMessage("19.��ȣž 20.��ȣž 21.��ȣž 22.��ȣž 23.��ȣž"));
					pc.sendPackets(new S_SystemMessage("24.�ؼ� 25.������ 26.�Ǻ����� 27.�׺� 28.�Ƕ�̵�"));
					pc.sendPackets(new S_SystemMessage("29.�Ƕ�̵� 30.�Ǵн� 31.���� 32.�Ⱘ4�� 33.������"));
					pc.sendPackets(new S_SystemMessage("34.��Ÿ 35.��Ǫ 36.���� 37.�߶� 38.����Ǫ 39.����"));
					pc.sendPackets(new S_SystemMessage("40.���� 41.���� 42.����2�� 43.���빫�� 44.����"));
					pc.sendPackets(new S_SystemMessage("45.����߾� 46.���3�� 47.���4�� 48.���� 49.����"));
					pc.sendPackets(new S_SystemMessage("50.���극�� 51~59.�տ� 60.�Ǹ����� 61.������"));
					pc.sendPackets(new S_SystemMessage("62.(����) 63.VIP����")); 
					return;
				}
				pc.teleport(loc.getX(), loc.getY(), (short) loc.getMapId(), pc.getHeading(), 169, false, false);
				break;
			}
			if (i > 0 && i < 33) {
				pc.sendPackets(new S_SystemMessage("��� ��ȯ(" + i + ")������ �̵��߽��ϴ�."));
			}
		} catch (Exception exception) {
			pc.sendPackets(new S_SystemMessage(".��ȯ [��Ҹ�]�� �Է� ���ּ���.(��Ҹ��� GMCommands.xml�� ����)"));
		}
	}
}
