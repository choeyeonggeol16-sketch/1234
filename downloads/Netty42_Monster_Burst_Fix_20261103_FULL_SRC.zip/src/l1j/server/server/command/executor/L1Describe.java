/*
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2, or (at your option)
 * any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.   See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
 * 02111-1307, USA.
 *
 * http://www.gnu.org/copyleft/gpl.html
 */
package l1j.server.server.command.executor;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.StringTokenizer;
import l1j.server.L1DatabaseFactory;
import l1j.server.server.Account;
import l1j.server.server.datatables.ExpTable;
import l1j.server.server.model.L1World;
import l1j.server.server.model.Instance.L1PcInstance;
import l1j.server.server.serverpackets.S_ServerMessage;
import l1j.server.server.serverpackets.S_SystemMessage;
import l1j.server.server.utils.CalcUtil;
import l1j.server.server.utils.SQLUtil;

public class L1Describe implements L1CommandExecutor {

	private L1Describe() {
	}

	public static L1CommandExecutor getInstance() {
		return new L1Describe();
	}

	public void execute(L1PcInstance pc, String cmdName, String arg) {
		try {
			StringTokenizer st = new StringTokenizer(arg);
			String name = st.nextToken();
			L1PcInstance target = L1World.getInstance().getPlayer(name);
			if (target == null) {
				pc.sendPackets(new S_ServerMessage(73, name)); // \f1%0�� ������ �ϰ� ���� �ʽ��ϴ�.
				return;
			}
			
			Connection con = null;
			PreparedStatement pstm = null;
			ResultSet rs = null;

			//String password = null;
			String quiz = null;
			//String ip = null;
			//String host = null;
			//boolean banned = false;
			try {

				con = L1DatabaseFactory.getInstance().getConnection();
				
				pstm = con.prepareStatement("select password, quiz, ip, host, banned from accounts where login='" + target.getAccountName() + "'");			
				rs = pstm.executeQuery();
				
				if(rs.next())
				{
					//password = rs.getString("password");
					quiz = rs.getString("quiz");
					//ip = rs.getString("ip");
					//host = rs.getString("host");
					//banned = rs.getInt("banned") == 1 ? true : false;
				}
			} catch(Exception e) {
			} finally {
				SQLUtil.close(rs);
				SQLUtil.close(pstm);
				SQLUtil.close(con);
			}
			
			
			int lv = target.getLevel();
			int currentLvExp = ExpTable.getExpByLevel(lv);
			int nextLvExp = ExpTable.getExpByLevel(lv + 1);
			double neededExp = nextLvExp - currentLvExp;
			double currentExp = target.getExp() - currentLvExp;
			int per = (int) ((currentExp / neededExp) * 100.0);

			String typeName = null;
			switch (target.getType()) {
			case 0:
				typeName = "����";
				break;

			case 1:
				typeName = "���";
				break;

			case 2:
				typeName = "����";
				break;

			case 3:
				typeName = "������";
				break;

			case 4:
				typeName = "��ũ����";
				break;

			default:
				typeName = "????";
			}

			String clan_name = target.getClanname() != null ? target.getClanname() : "\\f5[!]���;���";
			String account_password = target.getAccountName().equalsIgnoreCase("�ΰ�����") ? "�ΰ�����"
					: Account.load(target.getAccountName()).get_Password();
			String ip_address = target.getAccountName().equalsIgnoreCase("�ΰ�����") ? "�ΰ�����" : target.getNetConnection().getIp();
		
			pc.sendPackets(new S_SystemMessage("--------------------------------------------------"));
			pc.sendPackets(
					new S_SystemMessage("[ " + target.getName() + " ] ����:" + typeName + ", ����:" + clan_name + " ���� : " + quiz));
			pc.sendPackets(new S_SystemMessage(
					"����: " + target.getAccountName() + " /  ���: " + account_password + "   IP: " + ip_address));
			pc.sendPackets(new S_SystemMessage("--------------------------------------------------"));
			pc.sendPackets(new S_SystemMessage(" Lv: " + lv + " (" + per + "%)" + "   ���: "
					+ target.getAC().getAc() + "   ���� ��� : " + (int) (target.getResistance().getMr())));
			int hpr = target.getHpr();
			int mpr = target.getMpr();
			int sp = Math.max(0, target.getSp() - target.getTrueSp());
			
			int dmgup = ((int) target.getMeleeWeaponDmg() + target.getMeleeDmg() + CalcUtil.getMeleeDmgStat(target.getAbility().getTotalStr()));  //--�ٰŸ� ������ 
			int hitup = (target.getMeleeHit() + CalcUtil.getMeleeHitStat(target.getAbility().getTotalStr()));  //-- �ٰŸ� ����
			int Bowdmg = ((int) target.getRangedWeaponDmg() + target.getRangedDmg() + CalcUtil.getRangedDmgStat(target.getAbility().getTotalDex()));  //--���Ÿ� ������
			int Bowhit = (target.getRangedHit() + (int) CalcUtil.getRangedHitStat(target.getAbility().getTotalDex()));  //--���Ÿ� ����
			
			pc.sendPackets(new S_SystemMessage("* ��: " + target.getCurrentHp() + '/' + target.getMaxHp() + " (ƽ: "
					+ hpr + ')' + "   ��: " + target.getCurrentMp() + '/' + target.getMaxMp() + " (ƽ: " + mpr + ')'));
			pc.sendPackets(new S_SystemMessage(
					"* ��: " + target.getAbility().getTotalStr() + "  " + "��: " + target.getAbility().getTotalDex()
							+ "  " + "��: " + target.getAbility().getTotalCon() + "   " + "��: "
							+ target.getAbility().getTotalInt() + "   " + "��: " + target.getAbility().getTotalWis()
							+ "  " + "ī: " + target.getAbility().getTotalCha()));
			pc.sendPackets(new S_SystemMessage(
					"* �� : " + target.getResistance().getFire() + "  �� : " + target.getResistance().getWater() + "  �ٶ� : "
							+ target.getResistance().getWind() + "  �� : " + target.getResistance().getEarth()));
			pc.sendPackets(new S_SystemMessage("* ���� ȸ���� : " + (target.getPotionRecoveryAmount() + "  ���� ȸ���� ���� : "+ (target.getPotionRecovery())))); 
			pc.sendPackets(new S_SystemMessage("* ����(��)����� : " + CalcUtil.getMeleeDmgStat(target.getAbility().getTotalStr()) + " ����(��)���� : " + CalcUtil.getMeleeHitStat(target.getAbility().getTotalStr())));
			pc.sendPackets(new S_SystemMessage("* ����(��)����� : " + CalcUtil.getRangedDmgStat(target.getAbility().getTotalDex()) + " ����(��)���� : " + CalcUtil.getRangedHitStat(target.getAbility().getTotalDex())));
			pc.sendPackets(new S_SystemMessage("--------------------------------------------------"));
			pc.sendPackets(new S_SystemMessage("\\fW* (��)�����: " + (dmgup) + "  (��)����: "+ (hitup) + "  (��)ġ��Ÿ: " + (target.getMeleeCritical()))); 
			pc.sendPackets(new S_SystemMessage("\\fW* (��)�����: " + (Bowdmg) + "  (��)����: "+ (Bowhit) + "  (��)ġ��Ÿ: " + (target.getRangedCritical())));
			pc.sendPackets(new S_SystemMessage("\\fW* ��������: " + target.getMagicHit() + "  ����: " + sp + "  ����ġ��Ÿ: " + target.getMagicCritical()));
			pc.sendPackets(new S_SystemMessage("\\fR* ���������: " + target.getDamageReduction() + " PVP�����: " + target.getDmgupPvP() + "  PVP���������: " + target.getDmgDownPvP()));
			pc.sendPackets(new S_SystemMessage("\\fS* ���ϳ���: " + target.getResistance().getregist_technology() + " ��������: " + target.getResistance().gettechnique_hit() + "\\fT ���ɳ���: " + target.getResistance().getregist_spirit() + " ��������: " + target.getResistance().getspirit_hit()));
			pc.sendPackets(new S_SystemMessage("\\fY* �������ݷ�: " + target.LawfulAT +  " �ֹ���: " + target.LawfulSP +  " \\fU����: " + target.LawfulAC +  " ����: " + target.LawfulMR));
			
			
			pc.sendPackets(new S_SystemMessage("--------------------------------------------------"));
		} catch (Exception e) {
			pc.sendPackets(new S_SystemMessage(".���� [ĳ����]���� �Է�."));
		}
	}
}
