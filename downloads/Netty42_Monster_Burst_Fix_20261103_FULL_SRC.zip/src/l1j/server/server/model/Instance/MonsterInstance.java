package l1j.server.server.model.Instance;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.PriorityQueue;
import java.util.Random;
import java.util.logging.Logger;
import l1j.server.BonusDropSystem.BonusDropSystemInfo;
import l1j.server.BonusDropSystem.BonusDropSystemLoader;
import l1j.server.BonusMaps.BonusMapInfo;
import l1j.server.BonusMaps.BonusMapTable;
import l1j.server.MagicDollEventMonster.MagicDollEventMonsterLoader;
import l1j.server.Template.LORnd;
import l1j.server.Template.ArrangeHelper.MJArrangeParseeFactory;
import l1j.server.Template.ArrangeHelper.MJArrangeParser;
import l1j.server.Templates.L1Npc;
import l1j.server.configure.Config;
import l1j.server.server.ActionCodes;
import l1j.server.server.GeneralThreadPool;
import l1j.server.server.datatables.DropTable;
import l1j.server.server.datatables.ItemTable;
import l1j.server.server.model.Attack;
import l1j.server.server.model.L1Character;
import l1j.server.server.model.L1Object;
import l1j.server.server.model.L1World;
import l1j.server.server.model.skill.SkillId;
import l1j.server.server.serverpackets.S_DoActionGFX;
import l1j.server.server.serverpackets.S_Karma;
import l1j.server.server.serverpackets.S_RemoveObject;
import l1j.server.server.serverpackets.S_ServerMessage;
import l1j.server.server.serverpackets.S_SkillBrave;
import l1j.server.server.serverpackets.S_WorldObject;
import l1j.server.server.utils.CalcExp;

public class MonsterInstance extends L1NpcInstance {

	private static final long serialVersionUID = 1L;

	private static Logger _log = Logger.getLogger(MonsterInstance.class
			.getName());

	private static Random _random = new Random();

	private boolean _storeDroped; // ��� �������� ������ �Ϸ��ߴ���

	// ������ ��� ó��
	@Override
	public void onItemUse() {
		if (!isActived() && _target != null) {
			useItem(USEITEM_HASTE, 40); // 40%�� Ȯ���� ���� �ľ� �Ϻ� ���
			// �������� �ƴ����� ���� ó��
			if (getNpcTemplate().is_doppel() && _target instanceof L1PcInstance) {
				L1PcInstance targetPc = (L1PcInstance) _target;
				setName(_target.getName());
				setNameId(_target.getName());
				setTitle(_target.getTitle());
				setTempLawful(_target.getLawful());
				setCurrentSprite(targetPc.getClassId());
				for (L1PcInstance pc : L1World.getInstance().getRecognizePlayer(this)) {
					pc.sendPackets(S_RemoveObject.get(this));
					pc.removeKnownObject(this);
					pc.updateObject();
				}
			}
		}
		if (getCurrentHp() * 100 / getMaxHp() < 40) { // HP�� 40%
			useItem(USEITEM_HEAL, 30); // 30%�� Ȯ���� ȸ�� �Ϻ� ���
		}
	}

	@Override
	public void onPerceive(L1PcInstance perceivedFrom) {
		perceivedFrom.addKnownObject(this);
		if (0 < getCurrentHp()) {
			if (getHiddenStatus() == HIDDEN_STATUS_SINK) {
				perceivedFrom.sendPackets(S_DoActionGFX.get(getId(), ActionCodes.ACTION_Hide));
			} else if (getHiddenStatus() == HIDDEN_STATUS_FLY) {
				perceivedFrom.sendPackets(S_DoActionGFX.get(getId(), ActionCodes.ACTION_Moveup));
			}
			perceivedFrom.sendPackets(S_WorldObject.npc(this));
			onNpcAI(); // monster�� AI�� ����
			if (getBraveSpeed() == 1) { // ����� �� ����� �𸥴�
				S_SkillBrave s =  S_SkillBrave.get(getId(), 1, 600000);		
				perceivedFrom.sendPackets(s);
				perceivedFrom.broadcastPacket(s);
			}
		}
	}

	// Ÿ���� ã�´�
	public static int[][] _classGfxId = { { 0, 1 }, { 48, 61 }, { 37, 138 }, { 734, 1186 }, { 2786, 2796 } };

	@Override
	public void searchTarget() {
		L1PcInstance targetPlayer = null;
		MonsterInstance targetMonster = null;

		Collection<L1PcInstance> col = L1World.getInstance().getVisiblePlayer(this);

		if(col.size() > 0){
			PriorityQueue<L1PcInstance> target_q = new PriorityQueue<L1PcInstance>(col.size(), new TargetSorter());
			for (L1PcInstance pc : col) {
				if (pc == null || pc.getCurrentHp() <= 0 || pc.isDead() || pc.isGm() || pc.isMonitor() || pc.isGhost()) {
					continue;
				}

				int mapId = getMapId();
				if (mapId == 88 || mapId == 98 || mapId == 92 || mapId == 91 || mapId == 95) {
					if (!pc.isInvisble() || getNpcTemplate().is_agrocoi()) {
						target_q.offer(pc);
						continue;
					}
				}

				if ((getNpcTemplate().getKarma() < 0 && pc.getKarmaLevel() >= 1)
						|| (getNpcTemplate().getKarma() > 0 && pc.getKarmaLevel() <= -1)) {
					continue;
				}

				int spriteId = pc.getCurrentSpriteId();
				// ���� �� �־��� ������� ���� ����Ʈ�� ��������, �� ������ monster�κ��� ���� ���ݹ��� �ʴ´�
				if (spriteId == 6034 && getNpcTemplate().getKarma() < 0
						|| spriteId == 6035 && getNpcTemplate().getKarma() > 0
						|| spriteId == 6035 && getNpcTemplate().get_npcId() == 46070
						|| spriteId == 6035 && getNpcTemplate().get_npcId() == 46072) {
					continue;
				}

				if (!getNpcTemplate().is_agro() && !getNpcTemplate().is_agrososc() && getNpcTemplate().is_agrogfxid1() < 0
						&& getNpcTemplate().is_agrogfxid2() < 0) {
					if (pc.getLawful() < -1000) {
						target_q.offer(pc);
						continue;
					}
					continue;
				}

				if (!pc.isInvisble() || getNpcTemplate().is_agrocoi()) { // �κ���üũ
					if (pc.hasSkillEffect(SkillId.������_ü����)) { // �����ϰ� �ִ�
						if (getNpcTemplate().is_agrososc()) { // ���ſ� ���ؼ� ��Ƽ��
							target_q.offer(pc);
							continue;
						}
					} else if (getNpcTemplate().is_agro()) { // ��Ƽ�� monster
						target_q.offer(pc);
						continue;
					}

					if (getNpcTemplate().is_agrogfxid1() >= 0 && getNpcTemplate().is_agrogfxid1() <= 4) {
						if (_classGfxId[getNpcTemplate().is_agrogfxid1()][0] == pc.getCurrentSpriteId()
								|| _classGfxId[getNpcTemplate().is_agrogfxid1()][1] == pc.getCurrentSpriteId()) {
							target_q.offer(pc);
							continue;
						}
					} else if (pc.getCurrentSpriteId() == getNpcTemplate().is_agrogfxid1()) {
						target_q.offer(pc);
						continue;
					}

					if (getNpcTemplate().is_agrogfxid2() >= 0 && getNpcTemplate().is_agrogfxid2() <= 4) {
						if (_classGfxId[getNpcTemplate().is_agrogfxid2()][0] == pc.getCurrentSpriteId()
								|| _classGfxId[getNpcTemplate().is_agrogfxid2()][1] == pc.getCurrentSpriteId()) {
							target_q.offer(pc);
							continue;
						}
					} else if (pc.getCurrentSpriteId() == getNpcTemplate().is_agrogfxid2()) {
						target_q.offer(pc);
						continue;
					}
				}
			}
			target_q.comparator();
			while (!target_q.isEmpty()) {
				L1PcInstance target = target_q.poll();
				if(target != null && !target.isDead())
					targetPlayer = target;
					break;
			}
		}
		
		/**
		 * @������// �߰� ���Ŀ����������� 1.Monster vs Monster 2.Monster vs Guard 3.Monster vs Guardian 4.Monster vs Npc ���Ͱ��� ��Ȳ�� ���� ������Ʈ�� �ҷ������� �߰� ����� 1���������� �ҽ��� �����ϰ� ������Ʈ�� �ν��Ͻ�of�� �������ָ�ǰԲ� ����
		 * 
		 */
		for (L1Object obj : L1World.getInstance().getVisibleObjects(this)) {
			if (obj instanceof MonsterInstance) {
				MonsterInstance mon = (MonsterInstance) obj;
				if (mon.getHiddenStatus() != 0 || mon.isDead()) {
					continue;
				}
				if (this.getNpcTemplate().get_npcId() == 45570) { // ���� �ν��� ����(����)
					if (mon.getNpcTemplate().get_npcId() == 45391 || mon.getNpcTemplate().get_npcId() == 45450
							|| mon.getNpcTemplate().get_npcId() == 45482 || mon.getNpcTemplate().get_npcId() == 45569
							|| mon.getNpcTemplate().get_npcId() == 45579 || mon.getNpcTemplate().get_npcId() == 45315
							|| mon.getNpcTemplate().get_npcId() == 45647) { // ������ �νĵɸ��� (�߷���)
						targetMonster = mon;
						break;
					}
				}

				if (this.getNpcTemplate().get_npcId() == 45571) { // ���� �ν��� ����(����)
					if (mon.getNpcTemplate().get_npcId() == 45391 || mon.getNpcTemplate().get_npcId() == 45450
							|| mon.getNpcTemplate().get_npcId() == 45482 || mon.getNpcTemplate().get_npcId() == 45569
							|| mon.getNpcTemplate().get_npcId() == 45579 || mon.getNpcTemplate().get_npcId() == 45315
							|| mon.getNpcTemplate().get_npcId() == 45647) { // ������ �νĵɸ��� (�߷���)
						targetMonster = mon;
						break;
					}
				}

				if (this.getNpcTemplate().get_npcId() == 45582) { // ���� �ν��� ����(����)
					if (mon.getNpcTemplate().get_npcId() == 45391 || mon.getNpcTemplate().get_npcId() == 45450
							|| mon.getNpcTemplate().get_npcId() == 45482 || mon.getNpcTemplate().get_npcId() == 45569
							|| mon.getNpcTemplate().get_npcId() == 45579 || mon.getNpcTemplate().get_npcId() == 45315
							|| mon.getNpcTemplate().get_npcId() == 45647) { // ������ �νĵɸ��� (�߷���)
						targetMonster = mon;
						break;
					}
				}

				if (this.getNpcTemplate().get_npcId() == 45587) { // ���� �ν��� ����(����)
					if (mon.getNpcTemplate().get_npcId() == 45391 || mon.getNpcTemplate().get_npcId() == 45450
							|| mon.getNpcTemplate().get_npcId() == 45482 || mon.getNpcTemplate().get_npcId() == 45569
							|| mon.getNpcTemplate().get_npcId() == 45579 || mon.getNpcTemplate().get_npcId() == 45315
							|| mon.getNpcTemplate().get_npcId() == 45647) { // ������ �νĵ� ���� (�߷���)
						targetMonster = mon;
						break;
					}
				}

				if (this.getNpcTemplate().get_npcId() == 45605) { // ���� �ν��� ����(����)
					if (mon.getNpcTemplate().get_npcId() == 45391 || mon.getNpcTemplate().get_npcId() == 45450
							|| mon.getNpcTemplate().get_npcId() == 45482 || mon.getNpcTemplate().get_npcId() == 45569
							|| mon.getNpcTemplate().get_npcId() == 45579 || mon.getNpcTemplate().get_npcId() == 45315
							|| mon.getNpcTemplate().get_npcId() == 45647) { // ������ �νĵ� ���� (�߷���)
						targetMonster = mon;
						break;
					}
				}

				if (this.getNpcTemplate().get_npcId() == 45685) { // ���� �ν��� ����(����)
					if (mon.getNpcTemplate().get_npcId() == 45391 || mon.getNpcTemplate().get_npcId() == 45450
							|| mon.getNpcTemplate().get_npcId() == 45482 || mon.getNpcTemplate().get_npcId() == 45569
							|| mon.getNpcTemplate().get_npcId() == 45579 || mon.getNpcTemplate().get_npcId() == 45315
							|| mon.getNpcTemplate().get_npcId() == 45647) { // ������ �νĵ� ���� (�߷���)
						targetMonster = mon;
						break;
					}
				}

				if (this.getNpcTemplate().get_npcId() == 45391) { // ���� �ν��� ����(�߷�)
					if (mon.getNpcTemplate().get_npcId() == 45570 || mon.getNpcTemplate().get_npcId() == 45571
							|| mon.getNpcTemplate().get_npcId() == 45582 || mon.getNpcTemplate().get_npcId() == 45587
							|| mon.getNpcTemplate().get_npcId() == 45605) { // ������ �νĵ� ���� (����)
						targetMonster = mon;
						break;
					}
				}

				if (this.getNpcTemplate().get_npcId() == 45450) { // ���� �ν��� ����(�߷�)
					if (mon.getNpcTemplate().get_npcId() == 45570 || mon.getNpcTemplate().get_npcId() == 45571
							|| mon.getNpcTemplate().get_npcId() == 45582 || mon.getNpcTemplate().get_npcId() == 45587
							|| mon.getNpcTemplate().get_npcId() == 45605) { // ������ �ν� �ɸ��� (����)
						targetMonster = mon;
						break;
					}
				}

				if (this.getNpcTemplate().get_npcId() == 45482) { // ���� �ν���
																	// ����(�߷�)
					if (mon.getNpcTemplate().get_npcId() == 45570 || mon.getNpcTemplate().get_npcId() == 45571
							|| mon.getNpcTemplate().get_npcId() == 45582 || mon.getNpcTemplate().get_npcId() == 45587
							|| mon.getNpcTemplate().get_npcId() == 45605) { // ������
																			// �νĵɸ���
																			// (����)
						targetMonster = mon;
						break;
					}
				}

				if (this.getNpcTemplate().get_npcId() == 45569) { // ���� �ν���
																	// ����(�߷�)
					if (mon.getNpcTemplate().get_npcId() == 45570 || mon.getNpcTemplate().get_npcId() == 45571
							|| mon.getNpcTemplate().get_npcId() == 45582 || mon.getNpcTemplate().get_npcId() == 45587
							|| mon.getNpcTemplate().get_npcId() == 45605) { // ������
																			// �νĵɸ���
																			// (����)
						targetMonster = mon;
						break;
					}
				}

				if (this.getNpcTemplate().get_npcId() == 45579) { // ���� �ν��� ����(�߷�)
					if (mon.getNpcTemplate().get_npcId() == 45570 || mon.getNpcTemplate().get_npcId() == 45571
							|| mon.getNpcTemplate().get_npcId() == 45582 || mon.getNpcTemplate().get_npcId() == 45587
							|| mon.getNpcTemplate().get_npcId() == 45605) { // ������ �νĵ� ���� (����)
						targetMonster = mon;
						break;
					}
				}

				if (this.getNpcTemplate().get_npcId() == 45315) { // ���� �ν��� ����(�߷�)
					if (mon.getNpcTemplate().get_npcId() == 45570 || mon.getNpcTemplate().get_npcId() == 45571
							|| mon.getNpcTemplate().get_npcId() == 45582 || mon.getNpcTemplate().get_npcId() == 45587
							|| mon.getNpcTemplate().get_npcId() == 45605) { // ������ �ν� �ɸ��� (����)
						targetMonster = mon;
						break;
					}
				}

				if (this.getNpcTemplate().get_npcId() == 45647) { // ���� �ν��� ����(�߷�)
					if (mon.getNpcTemplate().get_npcId() == 45570 || mon.getNpcTemplate().get_npcId() == 45571
							|| mon.getNpcTemplate().get_npcId() == 45582 || mon.getNpcTemplate().get_npcId() == 45587
							|| mon.getNpcTemplate().get_npcId() == 45605) { // ������ �νĵ� ���� (����)
						targetMonster = mon;
						break;
					}
				}
			}
		}
		
		if (getMap().getBaseMapId() == 1936 && targetPlayer != null) {
			targetPlayer = null;
		}
		
		if (targetPlayer != null) {
			_hateList.add(targetPlayer, 0);
			_target = targetPlayer;
		}
		if (targetMonster != null) {
			_hateList.add(targetMonster, 0);
			_target = targetMonster;
		}
	}

	// ��ũ�� ����
	@Override
	public void setLink(L1Character cha) {
		if (cha != null && _hateList.isEmpty()) { // Ÿ���� ���� ��츸 �߰�
			_hateList.add(cha, 0);
			checkTarget();
		}
	}

	public MonsterInstance(L1Npc template) {
		super(template);
		_storeDroped = false;
	}

	@Override
	public void onNpcAI() {
		if (isAiRunning()) {
			return;
		}
		if (!_storeDroped) // �������� ������Ʈ ID�� �������� �ʰ� ���⼭ ��Ʈ
		{
			DropTable.getInstance().setDrop(this, getInventory());
			getInventory().shuffle();
			_storeDroped = true;
		}
		setActived(false);
		startAI();
		startChat(CHAT_TIMING_APPEARANCE); // ä�� ����
	}

	@Override
	public void onAction(L1PcInstance pc) {
		if (pc == null)
			return;
		if (getCurrentHp() > 0 && !isDead()) {
			Attack attack = new Attack(pc, this);
			if (attack.calcHit()) {
				attack.calcDamage();
			}
			attack.action();
			attack.commit();
		}
	}

	@Override
	public void ReceiveManaDamage(L1Character attacker, int mpDamage) { 
		if (mpDamage > 0 && !isDead()) {
			setHate(attacker, mpDamage);
			onNpcAI();

			if (attacker instanceof L1PcInstance) { // �����ǽ��� ������ monster�� Ÿ������  ����
				serchLink((L1PcInstance) attacker, getNpcTemplate().get_family());
			}
			int newMp = getCurrentMp() - mpDamage;
			if (newMp < 0) {
				newMp = 0;
			}
			setCurrentMp(newMp);
		}
	}

	@Override
	public void receiveDamage(L1Character attacker, int damage) { // �������� HP�� ����

		// ���� ���⸦ ���
		if (getCurrentHp() > 0 && !isDead()) {
			if (getHiddenStatus() != HIDDEN_STATUS_NONE) {
				return;
			}
			if (damage > 0) {
				setHate(attacker, damage);
				removeSkillEffect(SkillId.����_����_������);
			}
			onNpcAI();

			if (attacker instanceof L1PcInstance) { // �����ǽ��� ������ monster�� Ÿ������ ����
				serchLink((L1PcInstance) attacker, getNpcTemplate().get_family());
			}
			if (attacker instanceof L1PcInstance && damage > 0) {
				L1PcInstance player = (L1PcInstance) attacker;
				player.setPetTarget(this);
				
				BonusDropItem(player);
				BonusMapDropItems(player);

			}
			int newHp = getCurrentHp() - damage;
			if (newHp <= 0 && !isDead()) {
				int transformId = getNpcTemplate().getTransformId();
				// �������� �ʴ� monster
				if (transformId == -1) {
					if (attacker instanceof L1PcInstance) {
						L1PcInstance pc = (L1PcInstance) attacker;
						if (MagicDollEventMonsterLoader.getInstance().ChangeMonster(pc, this)) {
							return;
						}
					}
					setCurrentHpDirect(0);
					setDead(true);
					Death death = new Death(attacker);
					GeneralThreadPool.getInstance().execute(death);
				} else {
					transform(transformId);
				}
			}
			if (newHp > 0) {
				setCurrentHp(newHp);
				hide();
			}
		} else if (!isDead()) { // ������ ����
			setDead(true);
			_log.warning("�����NPC�� HP���� ó���� �ùٸ��� �������� ���� ���Ұ� �ֽ��ϴ�.��Ȥ�� ���ʺ��� HP0");
			Death death = new Death(attacker);
			GeneralThreadPool.getInstance().execute(death);
		}
	}

	@Override
	public void setCurrentHp(int i) {
		int currentHp = i;
		if (currentHp >= getMaxHp()) {
			currentHp = getMaxHp();
		}
		setCurrentHpDirect(currentHp);

		if (getMaxHp() > getCurrentHp()) {
			startHpRegeneration();
		}
	}

	@Override
	public void setCurrentMp(int i) {
		int currentMp = i;
		if (currentMp >= getMaxMp()) {
			currentMp = getMaxMp();
		}
		setCurrentMpDirect(currentMp);

		if (getMaxMp() > getCurrentMp()) {
			startMpRegeneration();
		}
	}

	class Death implements Runnable {
		L1Character _lastAttacker;

		public Death(L1Character lastAttacker) {
			_lastAttacker = lastAttacker;
		}

		@Override
		public void run() {
			setDeathProcessing(true);
			setCurrentHpDirect(0);
			setDead(true);
			int targetobjid = getId();
			getMap().setPassable(getLocation(), true);
			broadcastPacket(S_DoActionGFX.get(targetobjid, ActionCodes.ACTION_Die));
			startChat(CHAT_TIMING_DEAD);
			if (_lastAttacker != null) {
				distributeExpDropKarma(_lastAttacker);
			}
			setDeathProcessing(false);
			setExp(0);
			setKarma(0);
			allTargetClear();
			startDeleteTimer();
			if (_lastAttacker instanceof L1PcInstance) {
				L1PcInstance pc = (L1PcInstance) _lastAttacker;
				BonusDropItem(pc);
				BonusMapDropItems(pc);
			}

		}
	}

	private void distributeExpDropKarma(L1Character lastAttacker) {
		try {
			if (lastAttacker == null) {
				return;
			}
			L1PcInstance pc = null;
			if (lastAttacker instanceof L1PcInstance) {
				pc = (L1PcInstance) lastAttacker;
			} else if (lastAttacker instanceof PetInstance) {
				pc = (L1PcInstance) ((PetInstance) lastAttacker).getMaster();
			} else if (lastAttacker instanceof SummonInstance) {
				pc = (L1PcInstance) ((SummonInstance) lastAttacker)
						.getMaster();
			}

			if (pc != null && !pc.isDead()) {
				ArrayList<L1Character> targetList = _hateList
						.toTargetArrayList();
				ArrayList<Integer> hateList = _hateList.toHateArrayList();
				int exp = getExp();

				if (isDead()) {
					distributeDrop(pc);
					giveKarma(pc);
				}

				CalcExp.calcExp(pc, getId(), targetList, hateList, exp); // ������
				// ��Ż
				// exp

			//} else if (lastAttacker instanceof EffectInstance) {
			} else if (lastAttacker instanceof EffectInstance) {
				ArrayList<L1Character> targetList = _hateList
						.toTargetArrayList();
				ArrayList<Integer> hateList = _hateList.toHateArrayList();
				if (hateList.size() != 0) {
					int maxHate = 0;
					for (int i = hateList.size() - 1; i >= 0; i--) {
						if (maxHate < ((Integer) hateList.get(i))) {
							maxHate = (hateList.get(i));
							lastAttacker = targetList.get(i);
						}
					}
					if (lastAttacker instanceof L1PcInstance) {
						pc = (L1PcInstance) lastAttacker;
					} else if (lastAttacker instanceof PetInstance) {
						pc = (L1PcInstance) ((PetInstance) lastAttacker)
								.getMaster();
					} else if (lastAttacker instanceof SummonInstance) {
						pc = (L1PcInstance) ((SummonInstance) lastAttacker)
								.getMaster();
					}
					int exp = getExp();
					if (isDead()) {
						distributeDrop(pc);
						giveKarma(pc);
					}
					CalcExp.calcExp(pc, getId(), targetList, hateList, exp); // ������
					// ��Ż
					// exp
				}
			}
		} catch (Exception e) {
		}
	}

	private void distributeDrop(L1PcInstance pc) {
		ArrayList<L1Character> dropTargetList = _dropHateList
				.toTargetArrayList();
		ArrayList<Integer> dropHateList = _dropHateList.toHateArrayList();
		try {
			if (isResurrect()) {
				return;
			}
			int npcId = getNpcTemplate().get_npcId();
			if (npcId != 45640 || (npcId == 45640 && getCurrentSpriteId() == 2332)) {
				DropTable.getInstance().dropShare(MonsterInstance.this,
						dropTargetList, dropHateList, pc);
			}
		} catch (Exception e) {
			System.out.println(e);
		}
	}

	private void giveKarma(L1PcInstance pc) {
		int karma = getKarma();
		if (karma != 0) {
			int karmaSign = Integer.signum(karma);
			int pcKarmaLevel = pc.getKarmaLevel();
			int pcKarmaLevelSign = Integer.signum(pcKarmaLevel);
			if (pcKarmaLevelSign != 0 && karmaSign != pcKarmaLevelSign) {
				karma *= 5;
			}
			pc.addKarma((int) (karma * Config.RATE_KARMA));
			pc.sendPackets(new S_Karma(pc));
		}
	}

	public boolean is_storeDroped() {
		return _storeDroped;
	}

	public void set_storeDroped(boolean flag) {
		_storeDroped = flag;
	}

	private int _ubSealCount = 0; // UB���� ���Ͱ� ����������, �����ڿ��� �־����� ������ ǥ�� ����

	public int getUbSealCount() {
		return _ubSealCount;
	}

	public void setUbSealCount(int i) {
		_ubSealCount = i;
	}

	private int _ubId = 0; // UBID

	public int getUbId() {
		return _ubId;
	}

	public void setUbId(int i) {
		_ubId = i;
	}

	private void hide() {
		int npcid = getNpcTemplate().get_npcId();
		if (npcid == 45061 // ī��彺�ĸ�Ʈ��
				|| npcid == 45161 // ���ĸ�Ʈ��
				|| npcid == 45181 // ���ĸ�Ʈ��
				|| npcid == 45455) { // ���� ���� �� ����
			if (getMaxHp() / 3 > getCurrentHp()) {
				int rnd = _random.nextInt(10);
				if (1 > rnd) {
					allTargetClear();
					setHiddenStatus(HIDDEN_STATUS_SINK);
					broadcastPacket(S_DoActionGFX.get(getId(), ActionCodes.ACTION_Hide));
					setStatus(13);
					broadcastPacket(S_WorldObject.npc(this));
				}
			}
		} else if (npcid == 45067 // �ٷ�������
				|| npcid == 45264 // ����
				|| npcid == 45452 // ����
				|| npcid == 45090 // �ٷ��̱׸���
				|| npcid == 45321 // �׸���
				|| npcid == 45445) { // �׸���
			if (getMaxHp() / 3 > getCurrentHp()) {
				int rnd = _random.nextInt(10);
				if (1 > rnd) {
					allTargetClear();
					setHiddenStatus(HIDDEN_STATUS_FLY);
					broadcastPacket(S_DoActionGFX.get(getId(), ActionCodes.ACTION_Moveup));
					setStatus(4);
					broadcastPacket(S_WorldObject.npc(this));
				}
			}
		}
	}

	public void initHide() {
		// ���� ���İ� ���� ����
		// ��������� MOB�� ������ Ȯ���� �������� ���¿�,
		// ���� MOB�� �� ���·� �� �д�
		int npcid = getNpcTemplate().get_npcId();
		if (npcid == 45061 // ���� �ذ�
				|| npcid == 45161 // ��������
				|| npcid == 45181 // ��������
				|| npcid == 45455) { // ������ ��������
			int rnd = _random.nextInt(3);
			if (1 > rnd) {
				setHiddenStatus(L1NpcInstance.HIDDEN_STATUS_SINK);
				setStatus(13);
			}
		} else if (npcid == 45067 // ��� ����
				|| npcid == 45264 // ����
				|| npcid == 45452 // ����
				|| npcid == 45090 // ��� �׸���
				|| npcid == 45321 // �׸���
				|| npcid == 45445) { // �׸���
			setHiddenStatus(L1NpcInstance.HIDDEN_STATUS_FLY);
			setStatus(4);
		}
	}

	public void initHideForMinion(L1NpcInstance leader) {
		// �׷쿡 ���ϴ� ������ ���� ���� ����� ���� (�����ڿ� �����ϰ� �����Ѵ�)
		int npcid = getNpcTemplate().get_npcId();
		if (leader.getHiddenStatus() == L1NpcInstance.HIDDEN_STATUS_SINK) {
			if (npcid == 45061 // ī�����������
					|| npcid == 45161 // ����������
					|| npcid == 45181 // ����������
					|| npcid == 45455) { // ����������������
				setHiddenStatus(L1NpcInstance.HIDDEN_STATUS_SINK);
				setStatus(13);
			} else if (npcid == 45045 // �����̰�����
					|| npcid == 45126 // ���䤤������
					|| npcid == 45134 // ���䤤������
					|| npcid == 45281) { // ������䤤������
				setHiddenStatus(L1NpcInstance.HIDDEN_STATUS_SINK);
				setStatus(4);
			}
		} else if (leader.getHiddenStatus() == L1NpcInstance.HIDDEN_STATUS_FLY) {
			if (npcid == 45067 // �ٷ��ϻ�
					|| npcid == 45264 // ����
					|| npcid == 45452 // ����
					|| npcid == 45090 // �ٷ�����ȣ��
					|| npcid == 45321 // Griffon
					|| npcid == 45445) { // Griffon
				setHiddenStatus(L1NpcInstance.HIDDEN_STATUS_FLY);
				setStatus(4);
			}
		}
	}

	public void re() {
		setDeathProcessing(true);
		setCurrentHp(0);
		setDead(true);
		getMap().setPassable(getLocation(), true);
		setDeathProcessing(false);
		setExp(0);
		setKarma(0);
		setLawful(0);
		allTargetClear();
		deleteMe();
	}

	@Override
	public void transform(int transformId) {
		super.transform(transformId);
		// DROP�� �缳��
		getInventory().clearItems();
		DropTable.getInstance().setDrop(this, getInventory());
		getInventory().shuffle();
	}

	private void BonusDropItem(L1PcInstance player) {
		BonusDropSystemInfo bInfo = BonusDropSystemLoader.getInstance()
				.getBonusDropSystemInfo(this.getNpcId());
		if (bInfo != null) {
			if (player.getBonusDropNpc() != this.getId())
				player.setBonusDropNpc(this.getId());

			if (this.isDead()) {
				for (L1PcInstance pc : L1World.getInstance().getVisiblePlayer(
						this, 30)) {
					if (pc.isDead()) {
						continue;
					}
					if (pc.getBonusDropNpc() != this.getId())
						continue;
					if (LORnd.isWinning(1000000, bInfo.calc_probability(pc))) {
						ItemInstance bonusitem = ItemTable.getInstance()
								.createItem(bInfo.get_item_id());
						bonusitem.setCount(bInfo.calc_count(pc));
						bonusitem.setEnchantLevel(bInfo.get_item_enchant());
						bonusitem.setIdentified(true);//
						pc.sendPackets(new S_ServerMessage(143, this.getName(),
								bonusitem.getLogName()));
						pc.getInventory().storeTradeItem(bonusitem);
					}
					pc.setBonusDropNpc(0);
				}
			}
		}
	}

	private void BonusMapDropItems(L1PcInstance pc) {
		try {
			int mapId = getMapId();
			BonusMapInfo bInfo = BonusMapTable.getInstance().getBonusMapInfo(
					mapId);
			if (bInfo != null) {
				if (this.isDead()) {
					String[] itemid = (String[]) MJArrangeParser.parsing(
							bInfo.get_item_id(), ",",
							MJArrangeParseeFactory.createStringArrange())
							.result();
					for (int i = 0; i < itemid.length; i++) {
						if (pc.isDead()) {
							continue;
						}
						if (LORnd.isWinning(1000000, bInfo.calc_probability(i))) {
							ItemInstance dropitem = ItemTable.getInstance()
									.createItem(Integer.parseInt(itemid[i]));
							if (dropitem != null) {
								dropitem.setCount(bInfo.calc_count(i));
								pc.sendPackets(new S_ServerMessage(143, this
										.getName(), dropitem.getLogName()));

								ItemInstance inventoryItem = pc.getInventory()
										.findItemId(40308);
								int inventoryItemCount = 0;
								if (inventoryItem != null) {
									inventoryItemCount = inventoryItem
											.getCount();
								}
								if (inventoryItemCount > 1800000000) {
									if (pc.getInventory().consumeItem(40308,
											1500000000)) {
										pc.getInventory().storeItem(46010, 15);
									}
								}
								pc.getInventory().storeTradeItem(dropitem);
							}
						}
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	class TargetSorter implements Comparator<L1PcInstance> {
		@Override
		public int compare(L1PcInstance o1, L1PcInstance o2) {
			int law1 = o1.getLawful();
			int law2 = o2.getLawful();
			if (law1 < 0 || law2 < 0) {
				if (law1 != law2)
					return law1 > law2 ? 1 : -1;
			}

			int dir1 = getLocation().getTileLineDistance(o1.getLocation());
			int dir2 = getLocation().getTileLineDistance(o2.getLocation());
			if (dir1 == dir2) {
				return LORnd.isBoolean() ? 1 : -1;
			}
			return dir1 > dir2 ? 1 : -1;
		}
	}
}
