package l1j.server.server.model.Instance;

import java.util.Arrays;
import java.util.List;
import java.util.concurrent.ScheduledFuture;
import java.util.Random;

import l1j.server.Templates.L1Npc;
import l1j.server.server.ActionCodes;
import l1j.server.server.GeneralThreadPool;
import l1j.server.server.IdFactory;
import l1j.server.server.datatables.DropTable;
import l1j.server.server.datatables.NpcTable;
import l1j.server.server.model.Attack;
import l1j.server.server.model.L1Character;
import l1j.server.server.model.L1Inventory;
import l1j.server.server.model.L1World;
import l1j.server.server.model.skill.SkillId;
import l1j.server.server.serverpackets.S_DoActionGFX;
import l1j.server.server.serverpackets.S_HPMeter;
import l1j.server.server.serverpackets.S_PetMenuPacket;
import l1j.server.server.serverpackets.S_ServerMessage;
import l1j.server.server.serverpackets.S_SkillSound;
import l1j.server.server.serverpackets.S_WorldObject;

public class SummonInstance extends L1NpcInstance {
	private static final long serialVersionUID = 1L;

	private ScheduledFuture<?> _summonFuture;
	private static final long SUMMON_TIME = 3600000L;
	private int _currentPetStatus;
	private boolean _tamed;
	private boolean _isReturnToNature = false;
	private static Random _random = new Random();

	// Ÿ���� ���� ����� ó��
	@Override
	public boolean noTarget() {
		if (_currentPetStatus == 3) {
			// �� �ް��� ���
			return true;
		} else if (_currentPetStatus == 4) {
			// �� ��ġ�� ���
			if (_master != null
					&& _master.getMapId() == getMapId()
					&& getLocation().getTileLineDistance(_master.getLocation()) < 5) {
				int dir = targetReverseDirection(_master.getX(), _master.getY());
				dir = checkObject(getX(), getY(), getMapId(), dir);
				setDirectionMove(dir);
			} else {
				// ������ ������ 5 �Ž� �̻��� �� �� ������(��) �ް� ���¿�
				_currentPetStatus = 3;
				return true;
			}
		} else if (_currentPetStatus == 5) {
			// �� ����� ���� Ȩ��
			if (Math.abs(getHomeX() - getX()) > 1
					|| Math.abs(getHomeY() - getY()) > 1) {
				int dir = moveDirection(getHomeX(), getHomeY());
				if (dir == -1) {
					// Ȩ�� �ʹ� �־����� ������(��) �������� Ȩ
					setHomeX(getX());
					setHomeY(getY());
				} else {
					setDirectionMove(dir);
					//setSleepTime(calcSleepTime(getPassispeed(), MOVE_SPEED));
				}
			}
		} else if (_master != null && _master.getMapId() == getMapId()) {
			// �������� ����
			if (getLocation().getTileLineDistance(_master.getLocation()) > 2) {
				int dir = moveDirection(_master.getX(), _master.getY());
				if (dir == -1) {
					// ������ �ʹ� ��������(��) �ް� ���¿�
					_currentPetStatus = 3;
					return true;
				} else {
					setDirectionMove(dir);
					//setSleepTime(calcSleepTime(getPassispeed(), MOVE_SPEED));
				}
			}
		} else {
			// �� ������ ������(��) �ް� ���¿�
			_currentPetStatus = 3;
			return true;
		}
		return false;
	}

	// 1�ð� ������
	class SummonTimer implements Runnable {
		@Override
		public void run() {
			if (_destroyed) { // �̹� �ı�Ǿ� ���� ������ üũ
				return;
			}
			if (_tamed) {
				// ���ָ̹�Ÿ, Ŭ���� �� ������ �ع�
				liberate();
			} else {
				// ����� �ػ�
				Death(null);
			}
		}
	}

	// ����Ÿ��
	public SummonInstance(L1Npc template, L1Character master) {
		super(template);
		setId(IdFactory.getInstance().nextId());

		_summonFuture = GeneralThreadPool.getInstance().schedule(
				new SummonTimer(), SUMMON_TIME);

		setMaster(master);
		setX(master.getX() + _random.nextInt(5) - 2);
		setY(master.getY() + _random.nextInt(5) - 2);
		setMap(master.getMapId());
		setHeading(5);
		setLightSize(template.getLightSize());

		_currentPetStatus = 3;
		_tamed = false;

		L1World.getInstance().storeObject(this);
		L1World.getInstance().addVisibleObject(this);
		for (L1PcInstance pc : L1World.getInstance().getRecognizePlayer(this)) {
			onPerceive(pc);
		}
		master.addPet(this);
	}

	// ���ָ̹�Ÿ, Ŭ���� �� �����
	public SummonInstance(L1NpcInstance target, L1Character master,
			boolean createZombie) {
		super(null);
		setId(IdFactory.getInstance().nextId());

		if (createZombie) {// Ŭ���� �� ����
		
			L1Npc template = NpcTable.getInstance().getTemplate(45065).clone(); // ���� ���� ���̽��� �ۼ�
			setting_template(template);
		} else // ���ָ̹�Ÿ
		{
			setting_template(target.getNpcTemplate());
			setCurrentHpDirect(target.getCurrentHp());
			setCurrentMpDirect(target.getCurrentMp());
		}

		_summonFuture = GeneralThreadPool.getInstance().schedule(
				new SummonTimer(), SUMMON_TIME);

		setMaster(master);
		setX(target.getX());
		setY(target.getY());
		setMap(target.getMapId());
		setHeading(target.getHeading());
		setLightSize(target.getLightSize());
		setPetcost(6);

		if (target instanceof MonsterInstance
				&& !((MonsterInstance) target).is_storeDroped()) {
			DropTable.getInstance().setDrop(target, target.getInventory());
		}
		setInventory(target.getInventory());
		target.setInventory(null);

		_currentPetStatus = 3;
		_tamed = true;

		// �ֿϵ����� �������̾��� ��� ���߰� �Ѵ�
		for (L1NpcInstance each : master.getPetList().values()) {
			each.targetRemove(target);
		}

		target.deleteMe();
		L1World.getInstance().storeObject(this);
		L1World.getInstance().addVisibleObject(this);
		for (L1PcInstance pc : L1World.getInstance().getRecognizePlayer(this)) {
			onPerceive(pc);
		}
		master.addPet(this);
	}

	@Override
	public void receiveDamage(L1Character attacker, int damage) { // �������� HP�� ���� ���� ���⸦ ���
		if (getCurrentHp() > 0) {
			if (damage > 0) {
				setHate(attacker, 0); // ����� ����Ʈ ����
				removeSkillEffect(SkillId.����_����_������);
			}

			if (!isExsistMaster()) {
				_currentPetStatus = 1;
				setTarget(attacker);
			}

			if (attacker instanceof L1PcInstance && damage > 0) {
				L1PcInstance player = (L1PcInstance) attacker;
				player.setPetTarget (this);
			}

			int newHp = getCurrentHp() - damage;
			if (newHp <= 0) {
				Death(attacker);
			} else {
				setCurrentHp(newHp);
			}
		} else if (!isDead()) // ������ ����
		{
			System.out.println("���������� HP���� ó���� �ùٸ��� �������� ���� ���Ұ� �ֽ��ϴ�.��Ȥ�� ���ʺ��� HP0");
			Death(attacker);
		}
	}

	public synchronized void Death(L1Character lastAttacker) {
		if (!isDead()) {
			setDead(true);
			setCurrentHp(0);

			getMap().setPassable(getLocation(), true);

			// ������ �ع� ó��
			L1Inventory targetInventory = _master.getInventory();
			List<ItemInstance> items = _inventory.getItems();
			for (ItemInstance item : items) {
				if (_master.getInventory().checkAddItem( // �뷮 �߷� Ȯ�� �� �޼��� �۽�
						item, item.getCount()) == L1Inventory.OK) {
					_inventory
							.tradeItem(item, item.getCount(), targetInventory);
					// \f1%0��%1�� �־����ϴ�.
					((L1PcInstance) _master).sendPackets(new S_ServerMessage(
							143, getName(), item.getLogName()));
				} else { // ���� ��  ���� ������ �߹ؿ� ����߸���
					targetInventory = L1World.getInstance().getInventory(
							getX(), getY(), getMapId());
					_inventory
							.tradeItem(item, item.getCount(), targetInventory);
				}
			}

			if (_tamed) {
				broadcastPacket(S_DoActionGFX.get(getId(), ActionCodes.ACTION_Die));
				startDeleteTimer();
			} else {
				deleteMe();
			}
		}
	}

	public synchronized void returnToNature() {
		_isReturnToNature = true;
		if (!_tamed) {
			getMap().setPassable(getLocation(), true);
			// ��ǰ �ع� ó��
			L1Inventory targetInventory = _master.getInventory();
			List<ItemInstance> items = _inventory.getItems();
			for (ItemInstance item : items) {
				if (_master.getInventory().checkAddItem( // �뷮 ���� Ȯ�� �� �޽��� ����
						item, item.getCount()) == L1Inventory.OK) {
					_inventory
							.tradeItem(item, item.getCount(), targetInventory);
					// \f1 % 0 % 1���־����ϴ�.
					((L1PcInstance) _master).sendPackets(new S_ServerMessage(
							143, getName(), item.getLogName()));
				} else { // ���� �� ���� ������ �ߵ ������
					targetInventory = L1World.getInstance().getInventory(
							getX(), getY(), getMapId());
					_inventory
							.tradeItem(item, item.getCount(), targetInventory);
				}
			}
			deleteMe();
		} else {
			liberate();
		}
	}

	// ������Ʈ �Ұ� ó��
	@Override
	public synchronized void deleteMe() {
		if (_destroyed) {
			return;
		}
		if (!_tamed && !_isReturnToNature) {
			broadcastPacket(S_SkillSound.get(getId(), 169));
		}
		_master.getPetList().remove(getId());
		super.deleteMe();

		if (_summonFuture != null) {
			_summonFuture.cancel(false);
			_summonFuture = null;
		}
	}

	// ���ָ̹�Ÿ, Ŭ���� �� ������ �ع� ó��
	public void liberate() {
		MonsterInstance monster = new MonsterInstance(getNpcTemplate());
		monster.setId(IdFactory.getInstance().nextId());

		monster.setX(getX());
		monster.setY(getY());
		monster.setMap(getMapId());
		monster.setHeading(getHeading());
		monster.set_storeDroped(true);
		monster.setInventory(getInventory());
		setInventory(null);
		monster.setCurrentHpDirect(getCurrentHp());
		monster.setCurrentMpDirect(getCurrentMp());
		monster.setExp(0);

		deleteMe();
		L1World.getInstance().storeObject(monster);
		L1World.getInstance().addVisibleObject(monster);
	}

	public void setTarget(L1Character target) {
		if (target != null
				&& (_currentPetStatus == 1 || _currentPetStatus == 2 || _currentPetStatus == 5)) {
			setHate(target, 0);
			if (!isAiRunning()) {
				startAI();
			}
		}
	}

	public void setMasterTarget(L1Character target) {
		if (target != null
				&& (_currentPetStatus == 1 || _currentPetStatus == 5)) {
			setHate(target, 0);
			if (!isAiRunning()) {
				startAI();
			}
		}
	}

	@Override
	public void onAction(L1PcInstance attacker) {
		// XXX:NullPointerException ȸ��.onAction�� �μ��� ���´� L1Character ���� ����?
		if (attacker == null) {
			return;
		}
		L1Character cha = this.getMaster();
		if (cha == null) {
			return;
		}
		L1PcInstance master = (L1PcInstance) cha;
		if (master.getTeleport()) {
			// �ڷ���Ʈ ó����
			return;
		}
		if ((getZoneType() == 1 || attacker.getZoneType() == 1)
				&& isExsistMaster()) {
			// ���ݹ޴� ���� ������Ƽ ��
			// ���� ��� �۽�
			Attack attack_mortion = new Attack(attacker, this);
			attack_mortion.action();
			return;
		}

		if (attacker.checkNonPvP(attacker, this)) {
			return;
		}

		Attack attack = new Attack(attacker, this);
		if (attack.calcHit()) {
			attack.calcDamage();
		}
		attack.action();
		attack.commit();
	}

	@Override
	public void onTalkAction(L1PcInstance player) {
		if (isDead()) {
			return;
		}
		if (_master.equals(player)) {
			player.sendPackets(new S_PetMenuPacket(this, 0));
		}
	}

	@Override
	public void onFinalAction(L1PcInstance player, String action) {
		int status = ActionType(action);
		if (status == 0) {
			return;
		}
		if (status == 6) {
			if (_tamed) {
				// ���ָ̹�Ÿ, Ŭ���� �� ������ �ع�
				liberate();
			} else {
				// ����� �ػ�
				Death(null);
			}
		} else {
			// ���� ������ �ֿϵ��� ���¸� ��� ����
			Object[] petList = _master.getPetList().values().toArray();
			for (Object petObject : petList) {
				if (petObject instanceof SummonInstance) {
					// ����Ÿ
					SummonInstance summon = (SummonInstance) petObject;
					summon.set_currentPetStatus(status);
				} else {
					// �ֿϵ���
				}
			}
		}
	}

	@Override
	public void onPerceive(L1PcInstance perceivedFrom) {
		perceivedFrom.addKnownObject(this);
		perceivedFrom.sendPackets(S_WorldObject.summon(this, perceivedFrom));
	}

	@Override
	public void onItemUse() {
		if (!isActived()) {
			// 100%�� Ȯ���� ���� �ľ� �Ϻ� ���
			useItem(USEITEM_HASTE, 100);
		}
		if (getCurrentHp() * 100 / getMaxHp() < 40) {
			// HP�� 40%
			// 100%�� Ȯ���� ȸ�� �Ϻ� ���
			useItem(USEITEM_HEAL, 100);
		}
	}

	@Override
	public void onGetItem(ItemInstance item) {
		if (getNpcTemplate().get_digestitem() > 0) {
			setDigestItem(item);
		}
		Arrays.sort(healPotions);
		Arrays.sort(haestPotions);
		if (Arrays.binarySearch(healPotions, item.getItem().getItemId()) >= 0) {
			if (getCurrentHp() != getMaxHp()) {
				useItem(USEITEM_HEAL, 100);
			}
		} else if (Arrays
				.binarySearch(haestPotions, item.getItem().getItemId()) >= 0) {
			useItem(USEITEM_HASTE, 100);
		}
	}

	private int ActionType(String action) {
		
		int status = 0;
		if (action.equalsIgnoreCase("aggressive")) { // ���� �¼�
			
			status = 1;
		} else if (action.equalsIgnoreCase("defensive")) { // ��� �¼�
			status = 2;
		} else if (action.equalsIgnoreCase("stay")) { // �ް�
			status = 3;
		} else if (action.equalsIgnoreCase("extend")) { // ��ġ
			status = 4;
		} else if (action.equalsIgnoreCase("alert")) { // ���
			status = 5;
		} else if (action.equalsIgnoreCase("dismiss")) { // �ػ�
			status = 6;
		}
		return status;
	}

	@Override
	public void setCurrentHp(int i) {
		int currentHp = i;
		if (currentHp >= getMaxHp()) {
			currentHp = getMaxHp();
		}
		setCurrentHpDirect(currentHp);

		if (getMaxHp() > getCurrentHp()) {
			startHpRegeneration();
		}

		if (_master instanceof L1PcInstance) {
			int HpRatio = 100 * currentHp / getMaxHp();
			L1PcInstance Master = (L1PcInstance) _master;
			Master.sendPackets(new S_HPMeter(getId(), HpRatio));
		}
	}

	@Override
	public void setCurrentMp(int i) {
		int currentMp = i;
		if (currentMp >= getMaxMp()) {
			currentMp = getMaxMp();
		}
		setCurrentMpDirect(currentMp);

		if (getMaxMp() > getCurrentMp()) {
			startMpRegeneration();
		}
	}

	public void set_currentPetStatus(int i) {
		_currentPetStatus = i;
		if (_currentPetStatus == 5) {
			setHomeX(getX());
			setHomeY(getY());
		}

		if (_currentPetStatus == 3) {
			allTargetClear();
		} else {
			if (!isAiRunning()) {
				startAI();
			}
		}
	}

	public int get_currentPetStatus() {
		return _currentPetStatus;
	}

	public boolean isExsistMaster() {
		boolean isExsistMaster = true;
		if (this.getMaster() != null) {
			String masterName = this.getMaster().getName();
			if (L1World.getInstance().getPlayer(masterName) == null) {
				isExsistMaster = false;
			}
		}
		return isExsistMaster;
	}

}