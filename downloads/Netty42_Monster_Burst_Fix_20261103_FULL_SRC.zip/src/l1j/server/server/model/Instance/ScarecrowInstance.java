package l1j.server.server.model.Instance;

import java.util.ArrayList;
import l1j.server.Templates.L1Npc;
import l1j.server.server.model.Attack;
import l1j.server.server.model.skill.SkillId;
import l1j.server.server.serverpackets.S_ChangeHeading;
import l1j.server.server.serverpackets.S_SystemMessage;
import l1j.server.server.utils.CalcExp;

public class ScarecrowInstance extends L1NpcInstance {

	private static final long serialVersionUID = 1L;

	public ScarecrowInstance(L1Npc template) {
		super(template);
	}

	@Override
	public void onAction(L1PcInstance player) {
		Attack attack = new Attack(player, this);
		if (player.isInParty() || player.isDead()) {  
			player.sendPackets(new S_SystemMessage("��Ƽ�߿��� ����ƺ� ĥ�� �����ϴ�."));
			return;
		}
		if (attack.calcHit()) {
			if (player.getLevel() < 99) { // LV���� ���� ���� ���⸦ ����
				ArrayList<L1PcInstance> targetList = new ArrayList<L1PcInstance>();

				targetList.add(player);
				ArrayList<Integer> hateList = new ArrayList<Integer>();
				hateList.add(1);
				CalcExp.calcExp(player, getId(), targetList, hateList, getExp());
			}
			if (this.getNpcId() == 45003 || this.getNpcId() == 10345796) {
				int dmgList = attack.calcDamage();
				if (!player.hasSkillEffect(SkillId.SPR_TIME)) {
					player.setSkillEffect(SkillId.SPR_TIME, 300 * 1000);
				}
				player.setPcDmg(dmgList);
				if (player.getMinDmg() == 0) {
					player.setMinDmg(player.getPcDmg());
				}
				if (player.getMinDmg() > player.getPcDmg()) {
					player.setMinDmg(player.getPcDmg());
				}
				if (player.getMaxDmg() < player.getPcDmg()) {
					player.setMaxDmg(player.getPcDmg());
				}
				player.setDmgPesent(player.getDmgPesent() + player.getPcDmg());
				player.setDmgCount(player.getDmgCount() +1);
				int dmg = 0;
				dmg = player.getDmgPesent() / player.getDmgCount();
				int sec = 0;
				sec = 300 - player.getSkillEffectTimeSec(SkillId.SPR_TIME);
				long start = System.nanoTime();
				player.setStartTime(start);
				long check = player.getStartTime() - player.getEndTime();
				double sec2 = check / 1000000000.0;
				String speed = "";
				if (sec2 > 1.2) {
					speed = "����!";
					player.setMinTime(0);
				} else {
					speed = String.format("%.3f", sec2)+"��";
				}
				
				if (player.getMinTime() == 0 || player.getMinTime() < sec2 - 0.1) {
					player.setMinTime(sec2);
				}
				if (player.getMinTime() > sec2) {
					player.setMinTime(sec2);
				}
				
				if (player.getMaxTime() > player.getMinTime() + 0.15) {
					player.setMaxTime(sec2);
				}
				if (player.getMaxTime() < sec2) {
					player.setMaxTime(sec2);
				}
				
				double minsec = player.getMinTime();
				double maxsec = player.getMaxTime();
				String minSpeed = "";
				if (minsec > 1.2) {
					minSpeed = "����!";
				} else {
					minSpeed = String.format("%.3f", minsec);
				}
				String maxSpeed = "";
				if (maxsec > 1.2) {
					maxSpeed = "����!";
				} else {
					maxSpeed = String.format("%.3f", maxsec);
				}
				
				if (player.isGm()) {
					player.sendPackets(new S_SystemMessage("\\fRDMG[\\fY"+player.getPcDmg()+"\\fR]�ּ�[\\fY"+player.getMinDmg()+"\\fR]�ִ�[\\fY"+player.getMaxDmg()+"\\fR]"));
					player.sendPackets(new S_SystemMessage("\\fRȽ��[\\fT"+player.getDmgCount()+"\\fR]��Ÿ[\\fY"+dmg+"\\fR]�ð�[\\fV"+sec+"\\fR]"));
					player.sendPackets(new S_SystemMessage("\\fR����[\\fU"+speed+"\\fR]�ּ�[\\fU"+minSpeed+"\\fR]�ִ�[\\fU"+maxSpeed+"\\fR]"));
				} else {
					player.sendPackets(new S_SystemMessage("\\fR����[\\fT+"+player.getEquipSlot().getWeapon().getEnchantLevel()+player.getEquipSlot().getWeapon().getName()+"\\fR]"));
					player.sendPackets(new S_SystemMessage("\\fRDMG[\\fY"+player.getPcDmg()+"\\fR]�ּ�[\\fY"+player.getMinDmg()+"\\fR]�ִ�[\\fY"+player.getMaxDmg()+"\\fR]"));
					player.sendPackets(new S_SystemMessage("\\fR����[\\fU"+speed+"\\fR]�ּ�[\\fU"+minSpeed+"\\fR]�ִ�[\\fU"+maxSpeed+"\\fR]"));
				}
				//if (player.isDmgViewer) { attack.DmgViewer(); }
			}
			long end = System.nanoTime();
			player.setEndTime(end);
			/*if (this.getNpcId() == 10345796) {
				int dmg = attack.calcDamage();
				// String chatId = "���� �������� " + dmg + " �Դϴ�!";
				// Broadcaster.broadcastPacket(this, new S_NpcChatPacket(this, chatId, 0));
				// ����ϱ� ������ ������ ��� �Ʒ��� ���
				player.sendPackets(new S_SystemMessage("damaged : " + dmg + "."));
			}*/
			if (getHeading() < 7) { // ������ ������ ���
				setHeading(getHeading() + 1); // ������ ������ ����
			} else {
				setHeading(0); // ������ ������ 7 �̻��� �Ǹ�(��) ������ ������ 0�� �ǵ�����
			}
			broadcastPacket(S_ChangeHeading.get(this)); // ������ ����
		}
		attack.action();
	}

	@Override
	public void onTalkAction(L1PcInstance l1pcinstance) {

	}

	public void onFinalAction() {

	}

	public void doFinalAction() {
	}
}
