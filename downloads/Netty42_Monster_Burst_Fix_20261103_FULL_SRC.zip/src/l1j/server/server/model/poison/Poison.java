package l1j.server.server.model.poison;

import l1j.server.server.model.L1Character;
import l1j.server.server.model.Instance.L1PcInstance;
import l1j.server.server.model.skill.SkillId;
import l1j.server.server.serverpackets.S_ServerMessage;

public abstract class Poison {
	public static int POISON_DAMAGE = 1;
	public static int POISON_SILENCE = 2;
	public static int POISON_PARALYSIS = 4;
	private int _poisonType;

	protected static boolean isValidTarget(L1Character cha, int poisonType) {
		// Ÿ�� üũ
		if (cha == null) {
			return false;
		}
		// ���� ������ ���϶�  
		if (cha.getPoison() != null && cha.getPoison().getPoisonType() == poisonType) {
			return false;
		}
		// Ÿ���� �ǽð� �ƴҶ�
		if (!(cha instanceof L1PcInstance)) {
			return true;
		}
		// ��ų üũ
		if (cha.hasSkillEffect(SkillId.���̽�_����) || cha.hasSkillEffect(SkillId.�_���ε�)
				|| cha.hasSkillEffect(SkillId.�ۼַ�Ʈ_�踮��) || cha.hasSkillEffect(SkillId.����_����)) {
			return false;
		}
		// �� �����ۿ� ���õ� �� üũ
		L1PcInstance pc = (L1PcInstance) cha;		
		if (pc.toArmorEquipped().isPoisonRegistArmor() || pc.hasSkillEffect(SkillId.����_������Ʈ)) {
			return false;
		}
		return true;
	}

	protected static void sendMessageIfPlayer(L1Character cha, int msgId) {
		if (!(cha instanceof L1PcInstance)) {
			return;
		}
		L1PcInstance player = (L1PcInstance) cha;
		player.sendPackets(new S_ServerMessage(msgId), true);
	}
	
	public int getPoisonType() {
		return this._poisonType;
	}

	public void setPoisonType(int poisonType) {
		this._poisonType = poisonType;
	}

	public abstract int getEffectId();

	public abstract void cure();
}
