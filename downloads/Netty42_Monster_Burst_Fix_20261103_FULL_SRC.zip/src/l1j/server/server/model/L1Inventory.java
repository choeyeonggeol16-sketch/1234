/*
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2, or (at your option)
 * any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
 * 02111-1307, USA.
 *
 * http://www.gnu.org/copyleft/gpl.html
 */
package l1j.server.server.model;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Random;
import java.util.concurrent.CopyOnWriteArrayList;

import l1j.server.Templates.L1Item;
import l1j.server.configure.Config;
import l1j.server.server.IdFactory;
import l1j.server.server.datatables.FurnitureSpawnTable;
import l1j.server.server.datatables.ItemTable;
import l1j.server.server.datatables.LetterTable;
import l1j.server.server.datatables.PetTable;
import l1j.server.server.model.Instance.FurnitureInstance;
import l1j.server.server.model.Instance.ItemInstance;
import l1j.server.server.model.Warehouse.Warehouse;

public class L1Inventory extends L1Object {

	private static final long serialVersionUID = 1L;

	protected List<ItemInstance> _items = new CopyOnWriteArrayList<ItemInstance>();

	public static final int MAX_AMOUNT = 2000000000; // 2G
	
	public static final int MAX_SIZE = 8;
	
	public static final int MAX_WEIGHT = 1500;

	public L1Inventory() {
		//
	}

	// �κ�Ʈ������ �������� �Ѽ�
	public int getSize() {
		return _items.size();
	}

	// �κ�Ʈ������ ��� ������
	public List<ItemInstance> getItems() {
		return _items;
	}

	// �κ�Ʈ������ ���߷�
	public int getWeight() {
		int weight = 0;

		for (ItemInstance item : _items) {
			weight += item.getWeight();
		}
		return weight;
	}

	// �μ��� �������� �߰��ص� �뷮�� �߷��� �������� Ȯ�� �� �޼����� �۽�
	public static final int OK = 0;

	public static final int SIZE_OVER = 1;

	public static final int WEIGHT_OVER = 2;

	public static final int AMOUNT_OVER = 3;
	
 

	public int checkAddItem(ItemInstance item, int count) {
		if (item == null) {
			return -1;
		}
		if (getSize() > MAX_SIZE
				|| (getSize() == MAX_SIZE && (!item.isStackable() || !checkItem(item.getItem().getItemId())))) { // �뷮 Ȯ��
			return SIZE_OVER;
		}

		int weight = getWeight() + item.getItem().getWeight() * count / 1000 + 1;
		if (weight > (MAX_WEIGHT * Config.RATE_WEIGHT_LIMIT_PET)) { // �� ���� �߷� Ȯ��(�ַ� ���� �ֿϵ���)
			return WEIGHT_OVER;
		}

		ItemInstance itemExist = findItemId(item.getItemId());
		if (itemExist != null && (itemExist.getCount() + count) > MAX_AMOUNT) {
			return AMOUNT_OVER;
		}
		
		return OK;
	}

	// ���ο� �������� �ݳ�
	public ItemInstance storeItem(int id, int count) {
		L1Item temp = ItemTable.getInstance().getTemplate(id);
		if (temp == null) {
			return null;
		}

		if (temp.isStackable()) {
			ItemInstance item = new ItemInstance(temp, count); 
			if (findItemId(id) == null) { // ���Ӱ� ������ �ʿ䰡 �ִ� ��츸 ID�� ����� L1World���� ����� �ǽ��Ѵ�
				item.setId(IdFactory.getInstance().nextId());
				item.setCount(count);
				item.setBless(temp.getBless());
				item.setAttrEnchantLevel(0);
				if (!temp.isStackable() || findItemId(id) == null) {// ���Ӱ� ������ �ʿ䰡 �ִ� ��츸 ID�� ����� L1World���� ����� �ǽ��Ѵ�
					item.setId(IdFactory.getInstance().nextId());
					L1World.getInstance().storeObject(item);
				}
			}

			return storeItem(item);
		}

		// ���� �� �� ���� �������� ���
		ItemInstance result = null;
		for (int i = 0; i < count; i++) {
			ItemInstance item = new ItemInstance(temp, 1);
			item.setId(IdFactory.getInstance().nextId());
			item.setBless(temp.getBless());
			item.setAttrEnchantLevel(0);
			L1World.getInstance().storeObject(item); 
			storeItem(item);
			result = item;
		}
		// �������� ���� �������� �����ش�. �迭�� �ǵ�������(����) �޼ҵ� ���Ǹ� �����ϴ� ���� �������� �𸥴�.
		return result;
	}

	// DROP, ����, GMĿ���� �Լ��� ���ο� �������� �ݳ�
	public synchronized ItemInstance storeItemBless(ItemInstance item) {
		if (item.getCount() <= 0) {
			return null;
		}
		
		if (item.isStackable()) {
			ItemInstance findItem = findItemId(item.getItem().getItemId());
			if (findItem != null) {
				findItem.setCount(findItem.getCount() + item.getCount());
				updateItem(findItem);
				return findItem;
			}
		}
		item.setX(getX());
		item.setY(getY());
		item.setMap(getMapId());
		int chargeCount = item.getItem().getMaxChargeCount();
		if (item.getItem().getItemId() == 40006 || item.getItem().getItemId() == 40007
				|| item.getItem().getItemId() == 40008 || item.getItem().getItemId() == 140006
				|| item.getItem().getItemId() == 140008 || item.getItem().getItemId() == 41401) {
			Random random = new Random();
			chargeCount -= random.nextInt(5);
		}
		if (item.getItem().getItemId() == 20383) {
			chargeCount = 50;
		}
		item.setChargeCount(chargeCount); 
		if (item.getItem().getType2() == 0 && item.getItem().getType() == 2) { // light
			item.setRemainingTime(item.getItem().getLightFuel());
		} else {
			item.setRemainingTime(item.getItem().getMaxUseTime());
		}
		
		item.setBless(item.getBless());
		_items.add(item);
		insertItem(item);
		return item;
	}
	
	public synchronized ItemInstance storeItem(ItemInstance item) {
		if (item.getCount() <= 0) {
			return null;
		}
		if (item.isStackable()) {
			ItemInstance findItem = findItemId(item.getItem().getItemId());
			if (findItem != null) {
				findItem.setCount(findItem.getCount() + item.getCount());
				updateItem(findItem);
				return findItem;
			}
		}
		item.setX(getX());
		item.setY(getY());
		item.setMap(getMapId());
		int chargeCount = item.getItem().getMaxChargeCount();
		if (item.getItem().getItemId() == 40006 || item.getItem().getItemId() == 40007
				|| item.getItem().getItemId() == 40008 || item.getItem().getItemId() == 140006
				|| item.getItem().getItemId() == 140008 || item.getItem().getItemId() == 41401) {
			Random random = new Random();
			chargeCount -= random.nextInt(5);
		}
		if (item.getItem().getItemId() == 20383) {
			chargeCount = 50;
		}
		item.setChargeCount(chargeCount); 
		if (item.getItem().getType2() == 0 && item.getItem().getType() == 2) { // light
			item.setRemainingTime(item.getItem().getLightFuel());
		} else {
			item.setRemainingTime(item.getItem().getMaxUseTime());
		}
		
		item.setBless(item.getItem().getBless());
		_items.add(item);
		insertItem(item);
		return item;
	}
	
	public synchronized ItemInstance storeItem(int id, int count, int enchant) {
		if (count <= 0) {
			return null;
		}
		
		L1Item temp = ItemTable.getInstance().getTemplate(id);
		if (temp == null) {
			return null;
		}
		if (temp.isStackable()) {
			ItemInstance item = new ItemInstance(temp, count);
			if (findItemId(id) == null) {
				item.setId(IdFactory.getInstance().nextId());
				L1World.getInstance().storeObject(item);
			}
			return storeItem(item);
		}

		ItemInstance result = null;
		ItemInstance item = null;
		for (int i = 0; i < count; i++) {
			item = new ItemInstance(temp, 1);
			item.setId(IdFactory.getInstance().nextId());
			item.setEnchantLevel(enchant);
			item.setIdentified(true);
			L1World.getInstance().storeObject(item);
			storeItem(item);
			result = item;
		}
		return result;
	}
	 

	// /trade, â���κ��� �Լ��� �������� �ݳ�
	public synchronized ItemInstance storeTradeItem(ItemInstance item) {
		 
		if (item.isStackable()) {
			ItemInstance findItem = findItemId(item.getItem().getItemId());
			if (findItem != null) {
				findItem.setCount(findItem.getCount() + item.getCount());
				updateItem(findItem); 
				return findItem;
			}
		}
		item.setX(getX());
		item.setY(getY());
		item.setMap(getMapId());
		_items.add(item);
		insertItem(item);
		return item;
	}

	/**
	 * ������κ��� ������ ������ ID�� �������� �����Ѵ�. L1ItemInstance���� ����
	 * (��)�� �ִ� ���� removeItem�� (��)���� ����ϴ� ���� ����.  (������ ȭ���̶���� �����̶���� Ư���� �������� �Һ��ų �� ����Ѵ�)
	 * 
	 * @param itemid -
	 *            �����ϴ� �������� itemid(objid�� �ƴϴ�)
	 * @param count -
	 *            �����ϴ� ����
	 * @return ������ �����Ǿ��� ���� true�� �����ش�.
	 */
	
	public boolean consumeItem(int itemid) {
		ItemInstance item = findItemId(itemid);
		if (item != null) {
			removeItem(item, item.getCount());
			return true;
		}
		return false;
	}
	
	public boolean consumeItem(int itemid, int count) {
		L1Item tem = ItemTable.getInstance().getTemplate(itemid);
		if (tem == null) {
			return false;
		}
		if (count <= 0) {
			return false;
		}
		if (tem.isStackable()) {
			ItemInstance item = findItemId(itemid);
			if (item != null && item.getCount() >= count) {
				removeItem(item, count);
				return true;
			}
		} else {
			ItemInstance[] itemList = findItemsId(itemid);
			if (itemList.length == count) {
				for (int i = 0; i < count; i++) {
					removeItem(itemList[i], 1);
				}
				return true;
			} else if (itemList.length > count) {
				DataComparator dc = new DataComparator();
				extracted(itemList, dc);
				for (int i = 0; i < count; i++) {
					removeItem(itemList[i], 1);
				}
				return true;
			}
		}
		return false;
	}
	
    public boolean consumeItem(ItemInstance item, int count) {
        ItemInstance find = findItemObjId(item.getId());
        if (find == null || find.getCount() < count) {
            return false;
        }
        removeItem(item, count);
        return true;
    }
	
	public boolean consumeItem(ItemInstance[] items, int[] counts) {
		int size = items.length;
		for (int i = size - 1; i >= 0; --i) {
			ItemInstance item = items[i];
			int count = counts[i];
			ItemInstance find = findItemObjId(item.getId());
			if (find == null || find.getCount() < count)
				return false;
		}

		for (int i = size - 1; i >= 0; --i) {
			removeItem(items[i], counts[i]);
		}
		return true;
	}
	
	public ItemInstance findItemObjId(int id) {
		for (ItemInstance item : this._items) {
			if (item == null)
				continue;
			if (item.getId() == id) {
				return item;
			}
		}
		return null;
	}

	@SuppressWarnings("rawtypes")
	public class DataComparator implements java.util.Comparator {
		public int compare(Object item1, Object item2) {
			return ((ItemInstance) item1).getEnchantLevel() - ((ItemInstance) item2).getEnchantLevel();
		}
	}

	// ������ ���������κ��� ���� ������ ����(����ϰų� �������뿡 �������� ��) ��ȯ���������� ������ ��
	public int removeItem(int objectId) {
		ItemInstance item = getItem(objectId);
		return removeItem(item, item.getCount());
	}

	public int removeItem(int objectId, int count) {
		ItemInstance item = getItem(objectId);
		return removeItem(item, count);
	}
	public int removeItem(ItemInstance item) {
		return removeItem(item, item.getCount());
	}

	public int removeItem(ItemInstance item, int count) {
		if (item == null) {
			return 0;
		}
		if (item.getCount() <= 0 || count <= 0) {
			return 0;
		}
		if (item.getCount() < count) {
			count = item.getCount();
		}
		if (item.getCount() == count) {
			int itemId = item.getItem().getItemId();
			if (itemId == 40314 || itemId == 40316) { // �� �����
				PetTable.getInstance().deletePet(item.getId());
			} else if (itemId >= 49016 && itemId <= 49025) { // ������
				LetterTable lettertable = new LetterTable();
				lettertable.deleteLetter(item.getId());
			} else if (itemId >= 41383 && itemId <= 41400) { // ����
				for (L1Object l1object : L1World.getInstance().getObject()) {
					if (l1object == null)
						continue;
					if (l1object instanceof FurnitureInstance) {
						FurnitureInstance furniture = (FurnitureInstance) l1object;
						if (furniture.getItemObjId() == item.getId()) { // �̹� ������ �ִ� ����
							FurnitureSpawnTable.getInstance()
									.deleteFurniture(furniture);
						}
					}
				}
			}
			deleteItem(item);
			L1World.getInstance().removeObject(item);
		} else {
			item.setCount(item.getCount() - count);
			updateItem(item);
		}
		return count;
	}

	// _items�κ��� ���� ������Ʈ�� ����(L1PcInstance, L1DwarfInstance, L1GroundInstance�� �� �κ��� ���ٶ��̵� �Ѵ�)
	public void deleteItem(ItemInstance item) {
		_items.remove(item);
	}

	public synchronized ItemInstance tradeItem(int objectId, int count, Warehouse inventory) {
		ItemInstance item = getItem(objectId);
		 
		return tradeItem(item, count, inventory);
	}
	
	// �μ��� �κ�Ʈ���� �������� �̾�
	public synchronized ItemInstance tradeItem(int objectId, int count, L1Inventory inventory) {
		ItemInstance item = getItem(objectId);
		return tradeItem(item, count, inventory);
	}
	
	public synchronized ItemInstance tradeItem(ItemInstance item, int count, Warehouse inventory) {
		if (item == null) {
			return null;
		}
		if (item.getCount() <= 0 || count <= 0) {
			return null;
		}
		if (item.isEquipped()) {
			return null;
		}
		if (!checkItem(item.getItem().getItemId(), count)) {
			return null;
		}
		 

		
		ItemInstance carryItem;
		// �������� ���� ���� �߰�
		if (item.getCount() <= count || count < 0) {
			deleteItem(item);
			carryItem = item;
		} else {
			
			
			item.setCount(item.getCount() - count);
			updateItem(item);
			carryItem = ItemTable.getInstance().createItem(item.getItem().getItemId());
			carryItem.setCount(count);
			carryItem.setEnchantLevel(item.getEnchantLevel());
			carryItem.setIdentified(item.isIdentified());
			carryItem.setDurability(item.getDurability());
			carryItem.setChargeCount(item.getChargeCount());
			carryItem.setRemainingTime(item.getRemainingTime());
			carryItem.setLastUsed(item.getLastUsed());
			carryItem.setBless(item.getItem().getBless());
			carryItem.setAttrEnchantLevel(item.getAttrEnchantLevel());
			carryItem.setBlessType(item.getBlessType());
			carryItem.setBlessTypeValue(item.getBlessTypeValue());
		}
		return inventory.storeTradeItem(carryItem);
	}

	public ItemInstance tradeItem(ItemInstance item, int count, L1Inventory inventory) {
		if (item == null) {
			return null;
		}
		if (item.getCount() <= 0 || count <= 0) {
			return null;
		}
		if (item.isEquipped()) {
			return null;
		}
		if (!checkItem(item.getItem().getItemId(), count)) {
			return null;
		}
		if (item.getCount() < count) {
			return null;
		}
		int over_count = count + inventory.countItems(40308);
		if (over_count > 1800000000) {
			if (inventory.consumeItem(40308, 1500000000)) {
				inventory.storeItem(46010, 15);
			}
		}
		ItemInstance carryItem;
		if (item.getCount() <= count || count < 0) {
			deleteItem(item);
			carryItem = item;
		} else {
			item.setCount(item.getCount() - count);
			updateItem(item);
			carryItem = ItemTable.getInstance().createItem(item.getItem().getItemId());
			carryItem.setCount(count);
			carryItem.setEnchantLevel(item.getEnchantLevel());
			carryItem.setIdentified(item.isIdentified());
			carryItem.setDurability(item.getDurability());
			carryItem.setChargeCount(item.getChargeCount());
			carryItem.setLastUsed(item.getLastUsed());
			carryItem.setBless(item.getItem().getBless());
			carryItem.setAttrEnchantLevel(item.getAttrEnchantLevel());
			carryItem.setEndTime(item.getEndTime());
			carryItem.setBlessType(item.getBlessType());
			carryItem.setBlessTypeValue(item.getBlessTypeValue());
			
		}
		return inventory.storeTradeItem(carryItem);
	}

	/*
	 * �������� �ջ󡤼ո��Ű��(���⡤���� �ⱸ�� �����Ѵ�) �������� ���, �ո��̹Ƿ� ���̳ʽ� ������ ���⡤���� �ⱸ�� �ջ󵵸� ��Ÿ���Ƿ� �÷����� �Ѵ�.
	 */
	public ItemInstance receiveDamage(int objectId) {
		ItemInstance item = getItem(objectId);
		return receiveDamage(item);
	}

	public ItemInstance receiveDamage(ItemInstance item) {
		return receiveDamage(item, 1);
	}

	public ItemInstance receiveDamage(ItemInstance item, int count) {
		if (item == null) {
			return null;
		}
		int itemType = item.getItem().getType2();
		int currentDurability = item.getDurability(); 

		if ((currentDurability == 0 && itemType == 0) || currentDurability < 0) {
			item.setDurability(0);
			return null;
		}

		// ���⡤���� �ⱸ�� �ջ󵵸� �÷���
		if (itemType == 0) {
			int minDurability = (item.getEnchantLevel() + 5) * -1;
			int durability = currentDurability - count;
			if (durability < minDurability) {
				durability = minDurability;
			}
			if (currentDurability > durability) {
				item.setDurability(durability);
			}
		} else {
			int maxDurability = item.getEnchantLevel() + 5;
			int durability = currentDurability + count;
			if (durability > maxDurability) {
				durability = maxDurability;
			}
			if (currentDurability < durability) {
				item.setDurability(durability);
			}
		}

		updateItem(item, L1PcInventory.COL_DURABILITY);
		return item;
	}

	public ItemInstance recoveryDamage(ItemInstance item) {
		if (item == null) {
			return null;
		}
		int itemType = item.getItem().getType2();
		int durability = item.getDurability(); 

		if ((durability == 0 && itemType != 0) || durability < 0) {
			item.setDurability(0);
			return null;
		}

		if (itemType == 0) {
			// �������� �÷��� �ϰ� �ִ�.
			item.setDurability(durability + 1);
		} else {
			// �ջ󵵸� ���̳ʽ� �ϰ� �ִ�.
			item.setDurability(durability - 1);
		}

		updateItem(item, L1PcInventory.COL_DURABILITY);
		return item;
	}

	// ������ ID�κ��� �˻�
	public ItemInstance findItemId(int id) {
		for (ItemInstance item : _items) { 
			if (item.getItem().getItemId() == id) {
				return item;
			}
		}
		return null;
	}

	public ItemInstance[] findItemsId(int id) {
		ArrayList<ItemInstance> itemList = new ArrayList<ItemInstance>();
		for (ItemInstance item : _items) {
			if (item.getItemId() == id) {
				itemList.add(item);
			}
		}
		return itemList.toArray(new ItemInstance[] {});
	}
	public ItemInstance[] findItemsIdNotEquipped(int id) {
		ArrayList<ItemInstance> itemList = new ArrayList<ItemInstance>();
		for (ItemInstance item : _items) {
			if (item.getItemId() == id) {
				if (!item.isEquipped()) {
					itemList.add(item);
				}
			}
		}
		return itemList.toArray(new ItemInstance[] {});
	}

	// ������Ʈ ID�κ��� �˻�
	public ItemInstance getItem(int objectId) {
		for (Object itemObject : _items) {
			ItemInstance item = (ItemInstance) itemObject;
			if (item.getId() == objectId) {
				return item;
			}
		}
		return null;
	}

	// Ư���� �������� ������ ���� �̻� �����ϰ� ������ Ȯ��(ȭ���̶���� ������ Ȯ��)
	public boolean checkItem(int id) {
		return checkItem(id, 1);
	}

	public boolean checkItem(int id, int count) {
		if (count < 0) {
			return false;
		}
		if (count == 0) {
			return true;
		}
		if (ItemTable.getInstance().getTemplate(id).isStackable()) {
			ItemInstance item = findItemId(id);
			if (item != null && item.getCount() >= count) {
				return true;
			}
		} else {
			Object[] itemList = findItemsId(id);
			if (itemList.length >= count) {
				return true;
			}
		}
		return false;
	}

	// Ư���� �������� ������ ���� �̻� �����ϰ� ������ Ȯ��
	// ������� �������� �����ϰ� ���� ������ �Ǻ��Ѵ�
	public boolean checkItemNotEquipped(int id, int count) {
		if (count == 0) {
			return true;
		}
		return count <= countItems(id);
	}

	// Ư���� �������� ��� �ʿ��� ���� �����ϰ� ������ Ȯ��(�̺�Ʈ������ ������ �������� �����ϰ� ������ Ȯ���ϱ� ����(������))
	public boolean checkItem(int[] ids) {
		int len = ids.length;
		int[] counts = new int[len];
		for (int i = 0; i < len; i++) {
			counts[i] = 1;
		}
		return checkItem(ids, counts);
	}

	public boolean checkItem(int[] ids, int[] counts) {
		for (int i = 0; i < ids.length; i++) {
			if (!checkItem(ids[i], counts[i])) {
				return false;
			}
		}
		return true;
	}

	/**
	 * �� �κ�Ʈ������ �ִ�, ������ ID�� �������� ���� ����.
	 * 
	 * @return
	 */
	public int countItems(int id) {
		if (ItemTable.getInstance().getTemplate(id).isStackable()) {
			ItemInstance item = findItemId(id);
			if (item != null) {
				return item.getCount();
			}
		} else {
			Object[] itemList = findItemsIdNotEquipped(id);
			return itemList.length;
		}
		return 0;
	}

	public void shuffle() {
		Collections.shuffle(_items);
	}

	// �κ�Ʈ������ ��� �������� �����(�����ڸ� ���� �� ��)
	public void clearItems() {
		for (Object itemObject : _items) {
			ItemInstance item = (ItemInstance) itemObject;
			L1World.getInstance().removeObject(item);
		}
		_items.clear();
	}

	// �������̵�(override)��
	public void loadItems() {
	}

	public void insertItem(ItemInstance item) {
	}

	public void updateItem(ItemInstance item) {
	}

	public void updateItem(ItemInstance item, int colmn) {
	}
	
	public int checkAddItem(L1Item item, int count) {
		if (item == null) {
			return -1;
		}

		if (count < 0 || count > MAX_AMOUNT) {
			return AMOUNT_OVER;
		}

		if (getSize() > 180 || (getSize() == 180 && (!item.isStackable() || !checkItem(item.getItemId()))))
			return SIZE_OVER;

		int weight = getWeight() + item.getWeight() * count / 1000 + 1;
		if (weight < 0 || (item.getWeight() * count / 1000) < 0)
			return WEIGHT_OVER;

		ItemInstance itemExist = findItemId(item.getItemId());
		if (itemExist != null && ((itemExist.getCount() + count) < 0 || (itemExist.getCount() + count) > MAX_AMOUNT))
			return AMOUNT_OVER;
		
		return OK;
	}
	@SuppressWarnings("unchecked")
	private void extracted(ItemInstance[] itemList, DataComparator dc) {
		Arrays.sort(itemList, dc);
	}
	
	public ItemInstance[] findItemsIdNotEquippedCraftBless(int id, int enchant, int bless) {
		ArrayList<ItemInstance> itemList = new ArrayList<ItemInstance>();
		for (ItemInstance item : _items) {
			if (item == null)
				continue;
			if (item.getItemId() == id) {
				if (!item.isEquipped() && item.getEnchantLevel() == enchant && item.getBless() == bless) {
					itemList.add(item);
				}
			}
		}
		return itemList.toArray(new ItemInstance[] {});
	}
	
	public ItemInstance[] findItemsIdNotEquippedBless(int id, int bless) {
		ArrayList<ItemInstance> itemList = new ArrayList<ItemInstance>();
		for (ItemInstance item : _items) {
			if (item.getItemId() == id && item.getBless() == bless) {
				if (!item.isEquipped()) {
					itemList.add(item);
				}
			}
		}
		return itemList.toArray(new ItemInstance[] {});
	}
	
	public ItemInstance findItemIdBless(int id, int bless) {
		for (ItemInstance item : _items) {
			if (item.getItem().getItemId() == id && item.getBless() == bless) {
				return item;
			}
		}
		return null;
	}
}
