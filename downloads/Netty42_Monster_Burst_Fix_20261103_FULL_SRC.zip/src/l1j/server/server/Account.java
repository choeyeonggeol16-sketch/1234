/*
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2, or (at your option)
 * any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
 * 02111-1307, USA.
 *
 * http://www.gnu.org/copyleft/gpl.html
 */
package l1j.server.server;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.Calendar;
import java.util.logging.Level;
import java.util.logging.Logger;

import l1j.server.L1DatabaseFactory;
import l1j.server.Template.SqlHelper.Executors.Updator;
import l1j.server.Template.SqlHelper.Handler.Handler;
import l1j.server.configure.Config;
import l1j.server.server.model.Instance.L1PcInstance;
import l1j.server.server.utils.IntRange;
import l1j.server.server.utils.SQLUtil;

/**
 * �α����� ���� �������� �������̽��� �����Ѵ�.
 */
public class Account {
	/** ��ī��Ʈ��. */
	private String _name;

	/** ����ó�� IP�ּ�. */
	private String _ip;

	/** �н�����(��ȣȭ�ǰ� �ִ�). */
	private String _password;

	/** ���� ��Ƽ����. */
	private Timestamp _lastActive;

	/** �׼��� ����(GM�ΰ�?). */
	private int _accessLevel;

	/** ����ó�� ȣ��Ʈ��. */
	private String _host;

	/** �׼��� ������ ����(True�� ����). */
	private boolean _banned;

	/** ��ī��Ʈ�� ��ȿ�Ѱ� �ƴѰ�(True�� ��ȿ). */
	private boolean _isValid = false;
	
	/** ĳ���� ����(�°��ǿ���) */
	private int _charslot;
	
	private String _mjct_char_name;
	
	/** �޼��� �α׿�. */
	private static Logger _log = Logger.getLogger(Account.class.getName());
 

	/**
	 * ��ī��Ʈ�� �ű� �ۼ��Ѵ�.
	 * @param name        ��ī��Ʈ��
	 * @param rawPassword ���н�����
	 * @param ip          ����ó�� IP�ּ�
	 * @param host        ����ó�� ȣ��Ʈ��
	 * @return Account
	 */
	public static Account create(final String name, final String rawPassword, final String ip, final String host) {
		Calendar cal = Calendar.getInstance();
		int �ð� = Calendar.HOUR;
		int �� = Calendar.MINUTE;
		/** 0 ���� , 1 ���� * */
		String �������� = "����";
		if (cal.get(Calendar.AM_PM) == 0) {
			�������� = "����";
		}
		Connection con = null;
		PreparedStatement pstm = null;
		try {

			Account account = new Account();
			account._name = name;
			account._password = rawPassword;		
			account._ip = ip;
			account._host = host;
			account._banned = false;
			account._lastActive = new Timestamp(System.currentTimeMillis());

			con = L1DatabaseFactory.getInstance().getConnection();
			String sqlstr = "INSERT INTO accounts SET login=?,password=?,lastactive=?,access_level=?,ip=?,host=?,banned=?,charslot=?,mjct_charname=?";
			pstm = con.prepareStatement(sqlstr);
			pstm.setString(1, account._name);
			pstm.setString(2, account._password);
			pstm.setTimestamp(3, account._lastActive);
			pstm.setInt(4, 0);
			pstm.setString(5, account._ip);
			pstm.setString(6, account._host);
			pstm.setInt(7, account._banned ? 1 : 0);
			pstm.setInt(8, 6); 
			pstm.setString(9, "");
			pstm.execute();
			System.out.println("" + �������� + " " + cal.get(�ð�) + "��" + cal.get(��) + "��" + "   �� �ű� ����: [" + name + "] �����Ϸ��");
			return account;
		} catch (SQLException e) {
			System.out.println(e);
		} finally {
			SQLUtil.close(pstm);
			SQLUtil.close(con);
		}
		return null;
	}

	/**
	 * ��ī��Ʈ ������ DB�κ��� �����Ѵ�.
	 *
	 * @param name ��ī��Ʈ��
	 * @return Account
	 */
	public static Account load(final String name) {
		Connection con = null;
		PreparedStatement pstm = null;
		ResultSet rs = null;

		Account account = null;
		try {
			con = L1DatabaseFactory.getInstance().getConnection();
			String sqlstr = "SELECT * FROM accounts WHERE login=? LIMIT 1";
			pstm = con.prepareStatement(sqlstr);
			pstm.setString(1, name);
			rs = pstm.executeQuery();
			if (!rs.next()) {
				return null;
			}
			account = new Account();
			account._name = rs.getString("login");
			account._password = rs.getString("password");
			account._lastActive = rs.getTimestamp("lastactive");
			account._accessLevel = rs.getInt("access_level");
			account._ip = rs.getString("ip");
			account._host = rs.getString("host");
			account._banned = rs.getInt("banned") == 0 ? false : true;
			account._charslot = rs.getInt("charslot");
			account._mjct_char_name = rs.getString("mjct_charname");
			account._blessOfAin = rs.getInt("bless_of_ain");

			_log.fine("account exists");
		} catch (SQLException e) {
			_log.log(Level.SEVERE, e.getLocalizedMessage(), e);
		} finally {
			SQLUtil.close(rs);
			SQLUtil.close(pstm);
			SQLUtil.close(con);
		}

		return account;
	}

	/**
	 * ���� �α������� DB�� �ݿ��Ѵ�.
	 *
	 * @param account ��ī��Ʈ
	 */
	public static void updateLastActive(final Account account) {
		Connection con = null;
		PreparedStatement pstm = null;
		Timestamp ts = new Timestamp(System.currentTimeMillis());

		try {
			con = L1DatabaseFactory.getInstance().getConnection();
			String sqlstr = "UPDATE accounts SET lastactive=? WHERE login = ?";
			pstm = con.prepareStatement(sqlstr);
			pstm.setTimestamp(1, ts);
			pstm.setString(2, account.getName());
			pstm.execute();
			account._lastActive = ts;
			_log.fine("update lastactive for " + account.getName());
		} catch (Exception e) {
			_log.log(Level.SEVERE, e.getLocalizedMessage(), e);
		} finally {
			SQLUtil.close(pstm);
			SQLUtil.close(con);
		}
	}

	/**
	 * ĳ���� �������� ī��Ʈ �Ѵ�.
	 *
	 * @return int
	 */
	public int countCharacters() {
		int result = 0;
		Connection con = null;
		PreparedStatement pstm = null;
		ResultSet rs = null;
		try {
			con = L1DatabaseFactory.getInstance().getConnection();
			String sqlstr = "SELECT count(*) as cnt FROM characters WHERE account_name=?";
			pstm = con.prepareStatement(sqlstr);
			pstm.setString(1, _name);
			rs = pstm.executeQuery();
			if (rs.next()) {
				result = rs.getInt("cnt");
			}
		} catch (SQLException e) {
			_log.log(Level.SEVERE, e.getLocalizedMessage(), e);
		} finally {
			SQLUtil.close(rs);
			SQLUtil.close(pstm);
			SQLUtil.close(con);
		}
		return result;
	}

	/**
	 * ��ī��Ʈ�� ��ȿ�� �Ѵ�.
	 *
	 * @param login ��ī��Ʈ��
	 */
	public static void ban(final String login) {
		Connection con = null;
		PreparedStatement pstm = null;
		try {
			con = L1DatabaseFactory.getInstance().getConnection();
			String sqlstr = "UPDATE accounts SET banned=1 WHERE login=?";
			pstm = con.prepareStatement(sqlstr);
			pstm.setString(1, login);
			pstm.execute();
		} catch (SQLException e) {
			_log.log(Level.SEVERE, e.getLocalizedMessage(), e);
		} finally {
			SQLUtil.close(pstm);
			SQLUtil.close(con);
		}
	}

	/**
	 * �Էµ� �н������ DB���� �н����带 �����Ѵ�.
	 *
	 * @param rawPassword ���н�����
	 * @return boolean
	 */
	public boolean validatePassword(String accountName, final String rawPassword) {
		try {
			_isValid = _password.equals(rawPassword); // (_password.equals(rawPassword) || checkPassword(accountName, _password, rawPassword));
			return _isValid;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return false;
	}

	/**
	 * ��ī��Ʈ�� ��ȿ�Ѱ� ����� �����ش�(True�� ��ȿ).
	 *
	 * @return boolean
	 */
	public boolean isValid() {
		return _isValid;
	}

	/**
	 * ��ī��Ʈ�� ���� �������ΰ� ��� �����ش�(True�� ���� ������).
	 *
	 * @return boolean
	 */
	public boolean isGameMaster() {
		return 0 < _accessLevel;
	}

	/**
	 * ��ī��Ʈ���� ����Ѵ�.
	 *
	 * @return String
	 */
	public String getName() {
		return _name;
	}
	public String get_Password() {
		return _password;
	}
	/**
	 * ����ó�� IP�ּҸ� ����Ѵ�.
	 *
	 * @return String
	 */
	public String getIp() {
		return _ip;
	}

	/**
	 * ���� �α������� ����Ѵ�.
	 */
	public Timestamp getLastActive() {
		return _lastActive;
	}

	/**
	 * �׼��� ������ ����Ѵ�.
	 *
	 * @return int
	 */
	public int getAccessLevel() {
		return _accessLevel;
	}

	/**
	 * ȣ��Ʈ���� ����Ѵ�.
	 *
	 * @return String
	 */
	public String getHost() {
		return _host;
	}

	/**
	 * �׼��� ���� ������ ����Ѵ�.
	 *
	 * @return boolean
	 */
	public boolean isBanned() {
		return _banned;
	}
	
	public int getCharSlot() {
		return _charslot;
	}	

//## A62 IP�� ���� ���� ���� 
	public static boolean Check_LoginIP(String ip) {
		int num = 0;
		Connection con = null;
		PreparedStatement pstm = null;
		ResultSet rs = null;
		try {
			con = L1DatabaseFactory.getInstance().getConnection();
			pstm = con.prepareStatement("SELECT count(ip) as cnt FROM accounts WHERE ip=?");
			pstm.setString(1, ip);
			rs = pstm.executeQuery();
			if (rs.next()) {
				num = rs.getInt("cnt");
			}
			SQLUtil.close(rs);
			SQLUtil.close(pstm);
			SQLUtil.close(con);
			if (num < Config.ACCOUNT_LIMIT) {
				return false;
			} else {
				return true;
			}
		} catch (Exception e) {
			_log.log(Level.SEVERE, e.getLocalizedMessage(), e);
		} finally {
			SQLUtil.close(rs);
			SQLUtil.close(pstm);
			SQLUtil.close(con);
		}
		return false;
	}
//## A62 IP�� ���� ���� ���� 
	
	public void setCharSlot(GameClient client, int i) {
		Connection con = null;
		PreparedStatement pstm = null;
		try {
			con = L1DatabaseFactory.getInstance().getConnection();
			String sqlstr = "UPDATE accounts SET charslot=? WHERE login = ?";
			pstm = con.prepareStatement(sqlstr);
			pstm.setInt(1, i);
			pstm.setString(2, client.getAccount().getName());
			pstm.execute();
			client.getAccount()._charslot = i;
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			SQLUtil.close(pstm);
			SQLUtil.close(con);
		}
	}
	

	public String getMJCT_Char_Name() {
		return _mjct_char_name;
	}
	
	public void setMJCT_Char_Name(String value) {
		_mjct_char_name = value; 
		Updator.exec(
				"UPDATE accounts SET mjct_charname=? WHERE login=?",
				new Handler() {
					@Override
					public void handle(PreparedStatement pstm) throws Exception {
						pstm.setString(1, value);
						pstm.setString(2, getName());
					}
				});
	}
	
	public static boolean checkLoginBanIP(String ip) {
		int num = 0;
		Connection con = null;
		PreparedStatement pstm = null;
		ResultSet rs = null;

		try {
			con = L1DatabaseFactory.getInstance().getConnection();
			pstm = con.prepareStatement("SELECT count(ip) as cnt FROM ban_ip WHERE ip=?");

			pstm.setString(1, ip);
			rs = pstm.executeQuery();

			if (rs.next()) {
				num = rs.getInt("cnt");
			}

			SQLUtil.close(rs);
			SQLUtil.close(pstm);
			SQLUtil.close(con);

			// Ban IP�� 1�� �̻��ΰ��
			if (num >= 1) {
				return true;
			} else {
				return false;
			}
		} catch (Exception e) {
			_log.log(Level.SEVERE, e.getLocalizedMessage(), e);
		} finally {
			SQLUtil.close(rs);
			SQLUtil.close(pstm);
			SQLUtil.close(con);
		}
		return false;
	}
	
	private int _blessOfAin;
	
	public int getBlessOfAin() {
		return _blessOfAin;
	}

	public void setBlessOfAin(int i) {
		_blessOfAin = i;
	}

	public void addBlessOfAin(int i) {
		_blessOfAin = IntRange.ensure(_blessOfAin + i, 0, 15000000);
	}
	
	public void addBlessOfAin(L1PcInstance pc, int i) {
		this._blessOfAin = IntRange.ensure(_blessOfAin + i, 0, 15000000);

	}

	public void updateBlessOfAin() {
		Connection con = null;
		PreparedStatement pstm = null;
		try {
			con = L1DatabaseFactory.getInstance().getConnection();
			String sqlstr = "UPDATE accounts SET bless_of_ain=? WHERE login = ?";
			pstm = con.prepareStatement(sqlstr);
			pstm.setInt(1, _blessOfAin);
			pstm.setString(2, getName());
			pstm.execute();
		} catch (Exception e) {
			_log.log(Level.SEVERE, e.getLocalizedMessage(), e);
		} finally {
			SQLUtil.close(pstm);
			SQLUtil.close(con);
		}
	}
}
