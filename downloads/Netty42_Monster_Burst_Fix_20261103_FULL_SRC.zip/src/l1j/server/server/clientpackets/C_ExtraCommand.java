/*
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2, or (at your option)
 * any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
 * 02111-1307, USA.
 *
 * http://www.gnu.org/copyleft/gpl.html
 */

package l1j.server.server.clientpackets;

import l1j.server.server.GameClient;
import l1j.server.server.model.Instance.L1PcInstance;
import static l1j.server.server.model.skill.SkillId.*;
import l1j.server.server.serverpackets.S_DoActionGFX;

public class C_ExtraCommand extends ClientBasePacket {
	private static final String C_EXTRA_COMMAND = "[C] C_ExtraCommand";

	
	public C_ExtraCommand(byte abyte0[], GameClient client)
			throws Exception {
		super(abyte0);
		int actionId = readC();
		L1PcInstance pc = client.getActiveChar();
		if (pc == null) {
			return;
		}
		if (pc.isGhost()) {
			return;
		}
		if (pc.isInvisble()) { // �κ�����Ƽ, ����ε����̵����
			return;
		}
		if (pc.getTeleport()) { // �ڷ���Ʈ ó����
			return;
		}
		if (pc.hasSkillEffect(������_ü����)) { // ������ ����, �������� Ÿ�÷��̾ �۽����� �ʴ´�
			return;
		}
		pc.broadcastPacket(S_DoActionGFX.get(pc.getId(), actionId)); // ������ �÷��̾ �۽�
	}

	@Override
	public String getType() {
		return C_EXTRA_COMMAND;
	}
}
