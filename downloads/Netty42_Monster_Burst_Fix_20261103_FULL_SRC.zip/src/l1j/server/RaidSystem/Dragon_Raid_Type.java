package l1j.server.RaidSystem;

import java.sql.ResultSet;

import l1j.server.RaidSystem.Objects.Dragon_Raid_Antaras;
import l1j.server.RaidSystem.Objects.Dragon_Raid_Fafurion;
import l1j.server.server.model.Instance.L1PcInstance;

public class Dragon_Raid_Type {
	
	public static final String 	NAME 		= "raid_types";
	
	/** ���̵� ID�� ��Ÿ����. **/
	public static final int		RID_ANTARAS 	= 1;	// ��Ÿ��
	public static final int		RID_FAFURION	= 2;	// ��Ǫ����
	
	private int 	_id;		// raid id.
	private String 	_name;		// raid name.
	private int		_portalId;	// ���̵忡 �����ϱ� ���� �Ű�ü npc�� id.
	private int		_maxUser;	// ���̵忡 ������ �� �ִ� �ִ� �ο� ��.
	private int		_inputMid;	// ���� �� �̵� �� mapId
	private int		_inputX;	// ���� �� �̵� �� X��ǥ
	private int		_inputY;	// ���� �� �̵� �� Y��ǥ
	private int		_outMid;	// �ƿ� �� �̵� �� mapId.
	private int		_outX;		// �ƿ� �� �̵� �� x
	private int		_outY;		// �ƿ� �� �̵� �� y
	private int		_movX;		// ��� �濡�� ���̵� ��ҷ� �̵� �� �̵� �� X��ǥ
	private int		_movY;		// ��� �濡�� ���̵� ��ҷ� �̵� �� �̵� �� Y��ǥ
	private long	_raidTime;	// ���̵� �ð�.
	
	
	public boolean setInformation(ResultSet rs) {
		String column = null;
		try{
			column		= "id";
			_id 		= rs.getInt(column);
			
			column 		= "name";
			_name		= rs.getString(column);
			
			column		= "portal_id";
			_portalId	= rs.getInt(column);
			
			column		= "max_user";
			_maxUser	= rs.getInt(column);
			
			column		= "input_mapId";
			_inputMid	= rs.getInt(column);
			
			column		= "input_x";
			_inputX		= rs.getInt(column);
			
			column		= "input_y";
			_inputY		= rs.getInt(column);
			
			column		= "out_mapId";
			_outMid		= rs.getInt(column);
			
			column		= "out_x";
			_outX		= rs.getInt(column);
			
			column		= "out_y";
			_outY		= rs.getInt(column);
			
			column		= "mov_x";
			_movX		= rs.getInt(column);
			
			column		= "mov_y";
			_movY		= rs.getInt(column);
			
			column		= "raid_time";
			_raidTime	= rs.getLong(column);
		}catch(Exception e){
			StringBuilder sb = new StringBuilder();
			sb.append("RaidType at setInformation()...invalid column! ").append(column);
			System.out.println(sb.toString());
			e.printStackTrace();
			return false;
		}
		return true;
	}
	
	public int getId(){
		return _id;
	}
	public void setId(int i){
		_id = i;
	}
	
	public String getName(){
		return _name;
	}
	public void setName(String s){
		_name = s;
	}
	
	public int getPortalId(){
		return _portalId;
	}
	
	public int getMaxUser(){
		return _maxUser;
	}
	
	public long getRaidTime(){
		return _raidTime;
	}
	
	public int getInputMapId(){
		return _inputMid;
	}
	
	public int getInputX() {
		return _inputX;
	}
	
	public int getInputY() {
		return _inputY;
	}
	
	public int getOutMapId() {
		return _outMid;
	}
	
	public int getOutX(){
		return _outX;
	}
	
	public int getOutY(){
		return _outY;
	}
	
	public void inputRaid(L1PcInstance pc, int mid) {
		pc.teleport(_inputX, _inputY, (short) mid, 5, 169, true, false);
	}
	
	public void outRaid(L1PcInstance pc) {
		pc.teleport(_outX, _outY, (short) _outMid, 5, 169, true, false);
	}
	
	public void move(L1PcInstance pc, int mid) {
		pc.teleport(_movX, _movY, (short) mid, 5, 169, true, false);
	}
	
	public void create(L1PcInstance pc) {
		Dragon_Raid_Object obj = null;
		switch(_id){
		case RID_ANTARAS:
			obj = new Dragon_Raid_Antaras(pc, this);
			break;
		case RID_FAFURION:
			obj = new Dragon_Raid_Fafurion(pc, this);
			break;
		default:
			break;
		}	
		if(obj != null) {
			Dragon_Raid_Space.getInstance().startInstance(obj);
		}		
	}
	
	@Override
	public String toString(){
		StringBuilder sb = new StringBuilder(128);
		sb.append("raid id : ").append(_id).append("\n");
		sb.append("raid name : ").append(_name).append("\n");
		sb.append("portal id : ").append(_portalId).append("\n");
		sb.append("max user : ").append(_maxUser).append("\n");
		sb.append("input map id : ").append(_inputMid).append("\n");
		sb.append("input X : ").append(_inputX).append("\n");
		sb.append("input Y : ").append(_inputY).append("\n");
		sb.append("out map id : ").append(_outMid).append("\n");
		sb.append("out X : ").append(_outX).append("\n");
		sb.append("out y : ").append(_outY).append("\n");
		sb.append("raid time : ").append(_raidTime).append("\n");
		return sb.toString();
	}
	
}


