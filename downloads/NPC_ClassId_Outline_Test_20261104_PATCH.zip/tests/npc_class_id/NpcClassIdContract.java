package l1j.server.server.datatables;

import java.io.ByteArrayOutputStream;
import java.lang.reflect.*;
import java.nio.file.*;
import java.sql.ResultSetMetaData;
import java.util.*;
import sun.misc.Unsafe;
import l1j.server.server.templates.L1Npc;
import l1j.server.server.model.Instance.*;
import l1j.server.server.model.network.core.CIOClient;
import l1j.server.server.model.network.core.sc.packet.SC_WorldPutObject;
import l1j.server.server.packets.Protocol.Packet.SC_WorldPutObjectNoti;

public class NpcClassIdContract {
    static L1Npc template;
    static int passed;
    static void check(boolean ok,String why){if(!ok)throw new AssertionError(why);}
    static final class Monster extends L1MonsterInstance {
        Monster(){super(null);}
        @Override public L1Npc getNpcTemplate(){return template;}
        @Override public int getId(){return 12345;}
        @Override public int getNpcId(){return 7310054;}
        @Override public int getX(){return 32768;}
        @Override public int getY(){return 32769;}
        @Override public int getLongLocationReverse(){return getX()|(getY()<<16);}
        @Override public int getCurrentSpriteId(){return 15595;}
        @Override public String getNameId(){return "$19927";}
        @Override public boolean isPassObject(){return true;}
    }
    static final class OtherNpc extends L1NpcInstance {
        OtherNpc(){super(null);}
        @Override public L1Npc getNpcTemplate(){return template;}
        @Override public int getId(){return 12345;}
        @Override public int getNpcId(){return 7310054;}
        @Override public int getX(){return 32768;}
        @Override public int getY(){return 32769;}
        @Override public int getLongLocationReverse(){return getX()|(getY()<<16);}
        @Override public int getCurrentSpriteId(){return 15595;}
        @Override public String getNameId(){return "$19927";}
        @Override public boolean isPassObject(){return true;}
    }
    static <T> T allocate(Class<T> type)throws Exception {
        Field f=Unsafe.class.getDeclaredField("theUnsafe");f.setAccessible(true);
        return type.cast(((Unsafe)f.get(null)).allocateInstance(type));
    }
    static byte[] send(int route,L1NpcInstance npc) {
        CIOClient c=new CIOClient();
        if(route==0)check(SC_WorldPutObject.sendNpc(c,npc),"actual world sender refused");
        if(route==1)check(SC_WorldPutObjectNoti.sendNewInstance(c,npc),"direct proto factory refused");
        if(route==2)c.sendPacket(SC_WorldPutObjectNoti.newInstance(npc));
        check(c.socket.active==0 && c.socket.commits==1,"frame lease leak");
        return c.socket.lastBytes;
    }
    static long varint(byte[] bytes,int[] at) {
        long value=0;int shift=0;
        do {int b=bytes[at[0]++]&255;value|=(long)(b&127)<<shift;if((b&128)==0)return value;shift+=7;}while(shift<70);
        throw new AssertionError("bad varint");
    }
    record Wire(Integer classId,byte[] rest){}
    static Wire decode(byte[] bytes) {
        check(bytes.length>3 && (bytes[1]&255)==0x77 && bytes[2]==0,"wrong protocol ID");
        ByteArrayOutputStream rest=new ByteArrayOutputStream();rest.write(bytes,0,3);
        int[] at={3};Integer classId=null;
        while(at[0]<bytes.length) {
            int begin=at[0];long tag=varint(bytes,at);
            if(tag==0){rest.write(bytes,begin,bytes.length-begin);break;}
            long value=0;
            if((tag&7)==0)value=varint(bytes,at);
            else if((tag&7)==2){int length=(int)varint(bytes,at);at[0]+=length;}
            else throw new AssertionError("unexpected wire type "+tag);
            if((tag>>>3)==39){check(classId==null,"duplicate field 39");classId=(int)value;}
            else rest.write(bytes,begin,at[0]-begin);
        }
        return new Wire(classId,rest.toByteArray());
    }
    static ResultSetMetaData columns(String... labels) {
        return (ResultSetMetaData)Proxy.newProxyInstance(NpcClassIdContract.class.getClassLoader(),new Class[]{ResultSetMetaData.class},(p,m,args)->{
            if(m.getName().equals("getColumnCount"))return labels.length;
            if(m.getName().equals("getColumnLabel"))return labels[(Integer)args[0]-1];
            throw new AssertionError("unexpected metadata call "+m.getName());
        });
    }
    public static void main(String[] args)throws Exception {
        var map=NpcClassIdConfig.loadOverrides(Path.of(args[0]));
        check(map.get(7310054)==10030,"candidate mapping absent");
        check(NpcClassIdConfig.resolve(7310054,99,map)==10030,"file must override optional DB value");
        check(NpcClassIdConfig.resolve(1,99,map)==99,"unmapped DB value changed");
        check(NpcClassIdConfig.resolve(1,99,Map.of(1,0))==0,"zero must disable mapping");
        check(NpcClassIdConfig.resolve(1,-99,Map.of())==0,"negative DB value leaked");
        check(NpcClassIdConfig.findClassIdColumn(columns("npcid","gfxid"))==0,"old DB rejected");
        check(NpcClassIdConfig.findClassIdColumn(columns("npcid","CLASS_ID"))==2,"optional DB column not detected");
        check(NpcClassIdConfig.loadOverrides(Path.of("missing.properties")).isEmpty(),"missing file must be optional");
        Path bad=Path.of("bad.properties");Files.writeString(bad,"bad=10030\n2=-1\n3=2147483648\n4=0\n");
        check(NpcClassIdConfig.loadOverrides(bad).equals(Map.of(4,0)),"invalid overrides accepted");
        System.out.println("PASS config: candidate 7310054=10030, DB/file precedence, absent column/file, zero, invalid IDs");
        template=new L1Npc();template.set_npcId(7310054);
        Monster monster=allocate(Monster.class);OtherNpc other=allocate(OtherNpc.class);
        for(int route=0;route<3;route++) {
            template.set_class_id(0);Wire original=decode(send(route,monster));check(original.classId==null,"zero field must remain absent");
            for(int classId:new int[]{1,127,128,10030,Integer.MAX_VALUE}) {
                template.set_class_id(classId);Wire added=decode(send(route,monster));
                check(added.classId==classId,"wrong class ID on route "+route);
                check(Arrays.equals(original.rest,added.rest),"unrelated packet bytes changed on route "+route);
                passed++;
            }
            template.set_class_id(10030);check(decode(send(route,other)).classId==null,"non-monster test mapping leaked");
            System.out.println("PASS sender route "+route+": field 39, varint boundaries, zero omission, unchanged other bytes, non-monster exclusion");
        }
        System.out.println("PASS actual sender/writer cases="+passed+"; client rendering/Windows/DB startup require integration testing");
    }
}
