-- Read-only checks for the test target; no schema/data changes.
SELECT npcid,name,nameid,gfxid FROM npc WHERE npcid=7310054;
SELECT criteria_id,npc_id,npc_name,week_difficulty,week_completed_count FROM tb_mbook_information WHERE npc_id=7310054;
SELECT difficulty,col1,col2,col3 FROM tb_mbook_wq_decks WHERE col1=648 OR col2=648 OR col3=648;
