package l1j.server.server.datatables;

import java.io.IOException;
import java.io.Reader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;

/** Startup-only client NPC kind IDs. These are not server NPC, sprite or quest IDs. */
final class NpcClassIdConfig {
    private static final Logger LOG = Logger.getLogger(NpcClassIdConfig.class.getName());

    private NpcClassIdConfig() {}

    static Map<Integer, Integer> loadOverrides(Path path) {
        if (Files.notExists(path)) return Map.of();
        Properties properties = new Properties();
        try (Reader reader = Files.newBufferedReader(path, StandardCharsets.UTF_8)) {
            properties.load(reader);
        } catch (IOException | IllegalArgumentException failure) {
            LOG.log(Level.WARNING, "Cannot load NPC class ID overrides: " + path, failure);
            return Map.of();
        }
        Map<Integer, Integer> result = new HashMap<>();
        for (String key : properties.stringPropertyNames()) {
            try {
                int npcId = Integer.parseInt(key.trim());
                int classId = Integer.parseInt(properties.getProperty(key).trim());
                if (npcId <= 0 || classId < 0) throw new NumberFormatException("Invalid ID range");
                result.put(npcId, classId);
            } catch (NumberFormatException failure) {
                LOG.warning("Ignoring invalid NPC class ID override: " + key);
            }
        }
        return Map.copyOf(result);
    }

    /** Absent class_id is valid for the existing 19205 database. Checked once per load. */
    static int findClassIdColumn(ResultSetMetaData metadata) throws SQLException {
        for (int i = 1; i <= metadata.getColumnCount(); i++) {
            if ("class_id".equalsIgnoreCase(metadata.getColumnLabel(i))) return i;
        }
        return 0;
    }

    /** An explicit zero override disables the field even when the DB contains a value. */
    static int resolve(int npcId, int databaseClassId, Map<Integer, Integer> overrides) {
        Integer override = overrides.get(npcId);
        return Math.max(0, override == null ? databaseClassId : override);
    }
}
