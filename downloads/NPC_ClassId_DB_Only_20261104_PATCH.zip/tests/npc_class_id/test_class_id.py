#!/usr/bin/env python3
"""Actual NPC senders/writers and startup mapping; session/world/JDBC metadata doubles."""
from pathlib import Path
import argparse,os,subprocess,tempfile,shutil
ROOT=Path(__file__).resolve().parents[2]
p=argparse.ArgumentParser();p.add_argument('--classes',type=Path,default=Path('/workspace/builds/monster-outline-db-only/classes'));a=p.parse_args()
deps=Path(os.environ.get('ITEM_DEPS_DIR','/workspace/dependencies/item-processing'))
cp=os.pathsep.join([str(a.classes),*map(str,deps.glob('*.jar'))])
HERE=Path(__file__).resolve().parent
with tempfile.TemporaryDirectory() as temp:
 d=Path(temp);sources=[]
 for f in (HERE/'stubs').rglob('*.java'):sources.append(str(f))
 base=ROOT/'src/l1j/server/server'
 for rel in ['packets/Protocol/Proto.java','packets/Protocol/ProtoWriter.java','packets/Protocol/ProtoPacket.java','packets/Protocol/ProtoPacketWriter.java','model/network/buffer/WriteBuffer.java','model/network/core/sc/packet/SC_WorldPutObject.java','packets/Protocol/Packet/SC_WorldPutObjectNoti.java','datatables/NpcTable.java']:
  sources.append(str(base/rel))
 sources.append(str(HERE/'NpcClassIdContract.java'))
 subprocess.run(['java','-m','jdk.compiler/com.sun.tools.javac.Main','--enable-preview','-source','21','-target','21','-encoding','UTF-8','-cp',cp,'-d',temp,*sources],check=True,timeout=60)
 subprocess.run(['java','--enable-preview','-ea','-cp',temp+os.pathsep+cp,'l1j.server.server.datatables.NpcClassIdContract'],check=True,timeout=60,cwd=temp)
