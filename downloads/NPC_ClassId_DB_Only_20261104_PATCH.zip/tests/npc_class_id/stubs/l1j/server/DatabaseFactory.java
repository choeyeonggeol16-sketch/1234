package l1j.server;
import java.lang.reflect.*;
import java.sql.*;

/** Test-only JDBC, without real databases or credentials. */
public final class DatabaseFactory {
    public static int classId=14606,gfxId=16853;
    public static boolean hasClassId=true;
    private static final DatabaseFactory ONE=new DatabaseFactory();
    public static DatabaseFactory getInstance(){return ONE;}
    public Connection getConnection(){return proxy(Connection.class,(p,m,a)->{
        if(m.getName().equals("prepareStatement"))return statement((String)a[0]);
        if(m.getName().equals("close"))return null;
        throw new AssertionError(m.getName());
    });}
    private static PreparedStatement statement(String sql){return proxy(PreparedStatement.class,(p,m,a)->{
        if(m.getName().equals("executeQuery"))return rows(sql.equals("SELECT * FROM npc"));
        if(m.getName().equals("close"))return null;
        throw new AssertionError(m.getName());
    });}
    private static ResultSet rows(boolean npc){
        int[] index={0};
        return proxy(ResultSet.class,(p,m,a)->{
            String method=m.getName();
            if(method.equals("close"))return null;
            if(method.equals("next"))return npc && index[0]++==0;
            if(method.equals("getMetaData"))return proxy(ResultSetMetaData.class,(p2,m2,a2)->{
                if(m2.getName().equals("getColumnCount"))return hasClassId?4:3;
                if(m2.getName().equals("getColumnLabel"))return new String[]{"npcid","name","gfxid","CLASS_ID"}[(Integer)a2[0]-1];
                throw new AssertionError(m2.getName());
            });
            String key=a!=null && a.length>0?String.valueOf(a[0]):"";
            if(method.equals("getString"))return switch(key){
                case "name"->"어둠의 흑기사";case "nameid"->"$19927";case "impl"->"L1Monster";
                case "size"->"small";case "use_action"->"move and action";default->"";
            };
            if(method.equals("getInt"))return switch(key){case "npcid"->7310054;case "4","class_id"->classId;case "gfxid"->gfxId;default->0;};
            if(method.equals("getByte"))return (byte)0;
            if(method.equals("getShort"))return (short)0;
            if(method.equals("getLong"))return 0L;
            if(method.equals("getBoolean"))return false;
            throw new AssertionError(method);
        });
    }
    @SuppressWarnings("unchecked") private static <T>T proxy(Class<T> type,InvocationHandler handler){
        return (T)Proxy.newProxyInstance(DatabaseFactory.class.getClassLoader(),new Class[]{type},handler);
    }
}
