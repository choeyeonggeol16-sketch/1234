package l1j.server.server.model.item.function;

import l1j.server.server.model.Instance.L1ItemInstance;
import l1j.server.server.model.Instance.L1PcInstance;
import l1j.server.server.model.item.Card.L1CardAdd;
import l1j.server.server.model.item.Card.L1CardCollection;
import l1j.server.server.model.item.function.CItemUse;
import l1j.server.server.model.item.function.ItemUseAdminPackage;
import l1j.server.server.model.item.function.ItemUseEconomyRewards;
import l1j.server.server.model.network.core.sc.packet.SC_ChatPacket;
import l1j.server.server.model.network.core.sc.packet.SC_ServerMessage;
import l1j.server.server.model.network.core.sc.packet.SC_SkillSound;
import l1j.server.server.model.network.core.sc.packet.SC_SystemMessage;
import static l1j.server.server.model.item.function.ItemUseCreature._random;
import static l1j.server.server.model.item.function.ItemUseDurable.UseDurableConsume;
import static l1j.server.server.model.item.function.ItemUseDurable.UseDurableTwoInput;

/** Item-specific Rewards effects; selected once by ItemUseDispatcher. */
final class ItemUseRewardsCases {
    private ItemUseRewardsCases() {}

    static ItemUseResult handleConvertAinGems(ItemUseContext use) {
        L1PcInstance pc = use.player();
        L1ItemInstance item = use.item();
        L1ItemInstance targetItem = use.targetItem();
        {
            if (targetItem == null || targetItem == item
                    || pc.getInventory().getItem(targetItem.getId()) != targetItem
                    || (targetItem.getItemId() != 1000004
                            && targetItem.getItemId() != 410064)) {
                SC_ServerMessage.send(pc, 79);
                return ItemUseResult.COMPLETE;
            }
            UseDurableTwoInput(pc, item, targetItem, 7241, 2,
                    () -> SC_SystemMessage.send(pc,
                            "드래곤의 다이아몬드/에메랄드를 드래곤의 토파즈 2개로 변환."));
            return ItemUseResult.COMPLETE;
        }
    }

    static ItemUseResult handleClassPackage(ItemUseContext use) {
        L1PcInstance pc = use.player();
        L1ItemInstance item = use.item();
        ItemUseEconomyRewards.useClassPackage(pc, item);
        return ItemUseResult.STOP;
    }

    static ItemUseResult handleConvertAdena(ItemUseContext use) {
        L1PcInstance pc = use.player();
        L1ItemInstance item = use.item();
        ItemUseEconomyRewards.convertAdena(pc, item);
        return ItemUseResult.STOP;
    }

    static ItemUseResult handleUnlockCollection(ItemUseContext use) {
        L1PcInstance pc = use.player();
        L1ItemInstance item = use.item();
        pc.getAccount().setInfo_kir_poly(pc.getAccount().getInfo_kir_poly()+1);
        pc.getInventory().removeItem(item, 1);
        pc.getAccount().updateKir();
        pc.getAccount().setInfo_col_y(1);
        pc.getAccount().updateCollection();
        L1CardCollection.solejoin(pc);
        SC_ChatPacket.sendDirect(pc, pc, "\\aD[유일]지배자 기르타스 (이)가 변신 컬렉션에 등록되었습니다.");
        return ItemUseResult.COMPLETE;
    }

    static ItemUseResult handleSelectCollection(ItemUseContext use) {
        L1PcInstance pc = use.player();
        L1ItemInstance item = use.item();
        pc.setCollecItem(item);
        L1CardAdd.myth(pc);
            return ItemUseResult.COMPLETE;
    }

    static ItemUseResult handleSelectCollectionGroup2(ItemUseContext use) {
        L1PcInstance pc = use.player();
        L1ItemInstance item = use.item();
        pc.setCollecItem(item);
        L1CardAdd.legend1(pc);
        return ItemUseResult.COMPLETE;
    }

    static ItemUseResult handleSelectCollectionGroup3(ItemUseContext use) {
        L1PcInstance pc = use.player();
        L1ItemInstance item = use.item();
        pc.setCollecItem(item);
        L1CardAdd.legend2(pc);
        return ItemUseResult.COMPLETE;
    }

    static ItemUseResult handleSelectCollectionGroup4(ItemUseContext use) {
        L1PcInstance pc = use.player();
        L1ItemInstance item = use.item();
        pc.setCollecItem(item);
        L1CardAdd.hero1(pc);
        return ItemUseResult.COMPLETE;
    }

    static ItemUseResult handleSelectCollectionGroup5(ItemUseContext use) {
        L1PcInstance pc = use.player();
        L1ItemInstance item = use.item();
        pc.setCollecItem(item);
        L1CardAdd.hero2(pc);
        return ItemUseResult.COMPLETE;
    }

    static ItemUseResult handleSelectCollectionGroup6(ItemUseContext use) {
        L1PcInstance pc = use.player();
        L1ItemInstance item = use.item();
        pc.setCollecItem(item);
        L1CardAdd.SkillTree(pc);
        return ItemUseResult.COMPLETE;
    }

    static ItemUseResult handleOpenAdminPackage(ItemUseContext use) {
        L1PcInstance pc = use.player();
        L1ItemInstance item = use.item();
        ItemUseAdminPackage.open(pc, item);
        return ItemUseResult.STOP;
    }

    static ItemUseResult handleOpenExperienceBox(ItemUseContext use) {
        L1PcInstance pc = use.player();
        L1ItemInstance item = use.item();
        {
            long now = System.currentTimeMillis() / 1000;
            if (pc.getQuizTime() + 1 > now) {
                long sec = (pc.getQuizTime() + 1) - now;
                SC_ChatPacket.sendDirect(pc, pc, sec + "초 후에 가능합니다.");
                return ItemUseResult.STOP;
            }
            UseDurableConsume(pc, item, () -> {
                SC_SystemMessage.send(pc, "당신의 MP가 회복 되었습니다.");
                pc.setCurrentMp(pc.getCurrentMp() + 300);
                SC_SkillSound.send(pc, pc.getId(), 190);
            });
            return ItemUseResult.COMPLETE;
        }
    }

    static ItemUseResult handleExchangeAdenaVoucher(ItemUseContext use) {
        L1PcInstance pc = use.player();
        L1ItemInstance item = use.item();
        CItemUse.use(pc, item);
        return ItemUseResult.STOP;
    }

    static ItemUseResult handleOpenLegacyGift(ItemUseContext use) {
        L1PcInstance pc = use.player();
        L1ItemInstance item = use.item();
        int 랜덤 = _random.nextInt(120) + 1;
        pc.getInventory().storeItem(40308, 500000);
        SC_SystemMessage.send(pc, "아데나 (500,000)을 얻었습니다.");
        if (랜덤 >= 1 && 랜덤 <= 12) {
            pc.getInventory().storeItem(20315, 1);
            SC_SystemMessage.send(pc, "영양 만점 허리끈 을 얻었습니다.");
        } else if (랜덤 >= 13 && 랜덤 <= 24) {
            pc.getInventory().storeItem(20262, 1);
            SC_SystemMessage.send(pc, "영양 만점 목걸이 을 얻었습니다.");
        } else if (랜덤 >= 25 && 랜덤 <= 36) {
            pc.getInventory().storeItem(20291, 1);
            SC_SystemMessage.send(pc, "영양 만점 반지 을 얻었습니다.");
        } else if (랜덤 >= 37 && 랜덤 <= 48) {
            pc.getInventory().storeItem(40087, 1);
            SC_SystemMessage.send(pc, "무기 마법 주문서 을 얻었습니다.");
        } else if (랜덤 >= 49 && 랜덤 <= 59) {
            pc.getInventory().storeItem(40074, 1);
            SC_SystemMessage.send(pc, "갑옷 마법 주문서 을 얻었습니다.");
        } else if (랜덤 >= 60 && 랜덤 <= 65) {
            pc.getInventory().storeItem(41248, 1);
            SC_SystemMessage.send(pc, "마법인형(버그베어) 을 얻었습니다.");
        } else if (랜덤 >= 66 && 랜덤 <= 71) {
            pc.getInventory().storeItem(210096, 1);
            SC_SystemMessage.send(pc, "마법인형(에티) 을 얻었습니다.");
        } else if (랜덤 >= 72 && 랜덤 <= 74) {
            pc.getInventory().storeItem(210105, 1);
            SC_SystemMessage.send(pc, "마법인형(코카트리스) 을 얻었습니다.");
        } else if (랜덤 >= 75 && 랜덤 <= 77) {
            pc.getInventory().storeItem(20422, 1);
            SC_SystemMessage.send(pc, "빛나는 고대 목걸이 을 얻었습니다.");
        } else if (랜덤 >= 78 && 랜덤 <= 79) {
            pc.getInventory().storeItem(22000, 1);
            SC_SystemMessage.send(pc, "고대명궁가더 을 얻었습니다.");
        } else if (랜덤 >= 80 && 랜덤 <= 81) {
            pc.getInventory().storeItem(22003, 1);
            SC_SystemMessage.send(pc, "고대투사가더 을 얻었습니다.");
        } else if (랜덤 >= 82 && 랜덤 <= 86) {
            pc.getInventory().storeItem(30127, 1);
            SC_SystemMessage.send(pc, "52레벨 퀘스트 아이템 상자를 얻었습니다.");
        } else {
            SC_SystemMessage.send(pc, "아이템을 획득하지 못하였습니다.");
        }
        pc.getInventory().removeItem(item, 1);
        return ItemUseResult.COMPLETE;
    }

    static ItemUseResult handleOpenLegacyGiftGroup2(ItemUseContext use) {
        L1PcInstance pc = use.player();
        L1ItemInstance item = use.item();
        int 랜덤1 = _random.nextInt(170) + 1;
        pc.getInventory().storeItem(40308, 5000000);
        SC_SystemMessage.send(pc, "아데나 (5,000,000)을 얻었습니다.");
        if (랜덤1 >= 1 && 랜덤1 <= 25) {
            pc.getInventory().storeItem(41249, 1);
            SC_SystemMessage.send(pc, "마법인형(서큐버스) 을 얻었습니다.");
        } else if (랜덤1 >= 26 && 랜덤1 <= 51) {
            pc.getInventory().storeItem(41250, 1);
            SC_SystemMessage.send(pc, "마법인형(늑대인간) 을 얻었습니다.");
        } else if (랜덤1 >= 52 && 랜덤1 <= 77) {
            pc.getInventory().storeItem(210070, 1);
            SC_SystemMessage.send(pc, "마법인형(돌 골렘) 을 얻었습니다.");
        } else if (랜덤1 >= 78 && 랜덤1 <= 88) {
            pc.getInventory().storeItem(40038, 1);
            SC_SystemMessage.send(pc, "엘릭서(CHA) 을 얻었습니다.");
        } else if (랜덤1 >= 89 && 랜덤1 <= 99) {
            pc.getInventory().storeItem(140087, 1);
            SC_SystemMessage.send(pc, "축복받은 무기 마법 주문서 을 얻었습니다.");
        } else if (랜덤1 >= 100 && 랜덤1 <= 110) {
            pc.getInventory().storeItem(140074, 1);
            SC_SystemMessage.send(pc, "축복받은 갑옷 마법 주문서 을 얻었습니다.");
        } else if (랜덤1 >= 111 && 랜덤1 <= 112) {
            pc.getInventory().storeItem(202002, 1);
            SC_SystemMessage.send(pc, "붉은 기사의 대검 을 얻었습니다.");
        } else if (랜덤1 >= 113 && 랜덤1 <= 114) {
            pc.getInventory().storeItem(504, 1);
            SC_SystemMessage.send(pc, "흑요석 키링크 을 얻었습니다.");
        } else if (랜덤1 >= 115 && 랜덤1 <= 116) {
            pc.getInventory().storeItem(205, 1);
            SC_SystemMessage.send(pc, "달의 장궁 을 얻었습니다.");
        } else if (랜덤1 >= 117 && 랜덤1 <= 118) {
            pc.getInventory().storeItem(20165, 1);
            SC_SystemMessage.send(pc, "데몬의 장갑 을 얻었습니다.");
        } else if (랜덤1 >= 119 && 랜덤1 <= 120) {
            pc.getInventory().storeItem(20197, 1);
            SC_SystemMessage.send(pc, "데몬의 부츠 을 얻었습니다.");
        } else if (랜덤1 >= 121 && 랜덤1 <= 122) {
            pc.getInventory().storeItem(20160, 1);
            SC_SystemMessage.send(pc, "흑장로의 로브 을 얻었습니다.");
        } else if (랜덤1 >= 123 && 랜덤1 <= 124) {
            pc.getInventory().storeItem(20218, 1);
            SC_SystemMessage.send(pc, "흑장로의 샌달 을 얻었습니다.");
        } else if (랜덤1 >= 125 && 랜덤1 <= 126) {
            pc.getInventory().storeItem(20298, 1);
            SC_SystemMessage.send(pc, "제니스의 반지 을 얻었습니다.");
        } else if (랜덤1 >= 127 && 랜덤1 <= 131) {
            pc.getInventory().storeItem(30127, 1);
            SC_SystemMessage.send(pc, "52레벨 퀘스트 아이템 상자를 얻었습니다.");
        } else {
            SC_SystemMessage.send(pc, "아이템을 획득하지 못하였습니다.");
        }
        pc.getInventory().removeItem(item, 1);
        return ItemUseResult.COMPLETE;
    }
}
