package l1j.server.server.model.item.function;

import java.sql.Timestamp;
import l1j.server.server.model.Instance.L1ItemInstance;
import l1j.server.server.model.Instance.L1PcInstance;
import l1j.server.server.model.L1ItemDelay;
import l1j.server.server.model.L1PcInventory;

/** Legacy normal-return charge, last-used and item-delay tail. Early exits never call this. */
final class ItemUseCompletion {
    private ItemUseCompletion() {}

    static void finish(ItemUseContext use) {
        L1PcInstance pc = use.player();
        L1ItemInstance item = use.item();
        int itemId = use.itemId();
        boolean isDelayEffect = use.delayEffect();
        if (isDelayEffect) {
            if (itemId == 410008 || itemId == 40414 || itemId == 700012 || itemId == 30043 || itemId == 30045
                     || itemId == 30026 || itemId == 4100131 || itemId == 4100132) {
                int chargeCount = item.getChargeCount();
                Timestamp ts = new Timestamp(System.currentTimeMillis());
                item.setChargeCount(item.getChargeCount() - 1);
                if (chargeCount <= 1) {
                    pc.getInventory().removeItem(item, 1);
                } else {
                    item.setLastUsed(ts);
                    pc.getInventory().updateItem(item, L1PcInventory.COL_CHARGE_COUNT);
                    pc.getInventory().saveItem(item, L1PcInventory.COL_CHARGE_COUNT);
                }
            } else {
                Timestamp ts = new Timestamp(System.currentTimeMillis());
                item.setLastUsed(ts);
                pc.getInventory().updateItem(item, L1PcInventory.COL_DELAY_EFFECT);
                pc.getInventory().saveItem(item, L1PcInventory.COL_DELAY_EFFECT);
            }
        }
        L1ItemDelay.onItemUse(pc, item);
    }
}
