package l1j.server.server.model.item.function;
import l1j.server.server.model.network.core.cs.packet.CDB;
import l1j.server.server.model.network.core.cs.packet.User;

import java.util.logging.Level;
import java.util.logging.Logger;

import l1j.server.server.model.L1InventoryTransaction;
import l1j.server.server.model.Instance.L1ItemInstance;
import l1j.server.server.model.Instance.L1PcInstance;
import l1j.server.server.model.item.L1ItemId;
import l1j.server.server.model.network.core.sc.packet.SC_SkillSound;
import l1j.server.server.model.network.core.sc.packet.SC_SystemMessage;
import l1j.server.server.model.network.core.sc.packet.SC_PacketBox;
import l1j.server.server.storage.CacheD;

/** Receipt-backed multi-reward and currency exchanges; no inventory mutation before commit. */
public final class ItemUseEconomyRewards {
    private static final Logger LOG = Logger.getLogger(ItemUseEconomyRewards.class.getName());

    private ItemUseEconomyRewards() {}

    public static void useClassPackage(L1PcInstance pc, L1ItemInstance packageItem) {
        if (pc == null || packageItem == null || packageItem.getItemId() != 77799
                || pc.getInventory().getItem(packageItem.getId()) != packageItem) return;
        final int type = pc.getType();
        final int classItem;
        switch (type) {
        case 0: case 1: case 4: case 5: case 7:
            classItem = 600209;
            break;
        case 2:
            classItem = pc.getAbility().getBaseDex() >= 18 ? 600210 : 600209;
            break;
        case 3: case 6:
            classItem = 600211;
            break;
        default:
            pc.sendPackets("사용이 불가능한 클래스 입니다.");
            return;
        }
        try (L1InventoryTransaction tx = User.CheckAndSetPendingUseETCItem(pc,
                CacheD.accountOrderKey("item-use:", pc.getId()))) {
            if (!tx.debit(packageItem, 1)) return;
            // Exactly the old package: class item, four materials, two 600202, one 600204.
            if (tx.grant(classItem, 1) == null
                    || tx.grant(600198, 1) == null
                    || tx.grant(600199, 1) == null
                    || tx.grant(600200, 1) == null
                    || tx.grant(600201, 1) == null
                    || tx.grant(600202, 1) == null
                    || tx.grant(600202, 1) == null
                    || tx.grant(600204, 1) == null) {
                SC_SystemMessage.send(pc, "아이템 보상을 소지할 수 없습니다.");
                return;
            }
            tx.onFailure(() -> SC_SystemMessage.send(pc, "아이템 보상 저장에 실패했습니다."));
            CDB.RequestUseItem(pc, tx, null);
        } catch (RuntimeException failure) {
            LOG.log(Level.WARNING, "Class package exchange failed: " + pc.getId(), failure);
            SC_SystemMessage.send(pc, "아이템 보상을 처리하지 못했습니다.");
        }
    }

    /** Sealed TOI charms and Chronos belt; input and identified reward are one receipt. */
    public static void exchangeLegacyItem(L1PcInstance pc, L1ItemInstance source) {
        if (pc == null || source == null
                || pc.getInventory().getItem(source.getId()) != source) return;
        final int id = source.getItemId();
        final int rewardId;
        if (id >= 40280 && id <= 40288) {
            rewardId = id + 9;
        } else if (id >= 830032 && id <= 830041) {
            rewardId = id - 20;
        } else if (id == 3000063) {
            rewardId = 900007;
        } else {
            return;
        }
        try (L1InventoryTransaction tx = User.CheckAndSetPendingUseETCItem(pc,
                CacheD.accountOrderKey("item-use:", pc.getId()))) {
            if (!tx.debit(source, 1)) return;
            final L1ItemInstance reward = tx.grant(rewardId, 1);
            if (reward == null) {
                SC_SystemMessage.send(pc, "아이템을 소지할 수 없습니다.");
                return;
            }
            tx.onFailure(() -> SC_SystemMessage.send(pc, "아이템 교환 저장에 실패했습니다."));
            CDB.RequestUseItem(pc, tx, () ->
                    l1j.server.server.model.network.core.sc.packet.SC_ServerMessage.send(pc, 403,
                            reward.getLogName()));
        } catch (RuntimeException failure) {
            LOG.log(Level.WARNING, "Sealed item exchange failed: " + pc.getId() + " / " + id,
                    failure);
            SC_SystemMessage.send(pc, "아이템 교환을 처리하지 못했습니다.");
        }
    }

    public static void convertAdena(L1PcInstance pc, L1ItemInstance bank) {
        if (pc == null || bank == null
                || pc.getInventory().getItem(bank.getId()) != bank) return;
        final int id = bank.getItemId();
        if (id != 400253 && id != 875640445) return;
        final int cost = id == 400253 ? 100_000_000 : 10_000_000;
        final int reward = id == 400253 ? 400254 : 600254;
        final L1ItemInstance adena = pc.getInventory().findItemId(L1ItemId.ADENA);
        if (adena == null || adena.getCount() < cost
                || pc.getInventory().getItem(adena.getId()) != adena) {
            SC_SystemMessage.send(pc, id == 400253
                    ? "100,000,000원 아데나가 부족합니다."
                    : "10,000,000원 아데나가 부족합니다.");
            return;
        }
        if (adena.getBless() >= 128) {
            SC_SystemMessage.send(pc, "봉인된 아데나로는 수표전환이 불가합니다.");
            SC_PacketBox.send(pc, SC_PacketBox.GREEN_MESSAGE, "봉인된 아데나로는 수표전환이 불가합니다.");
            return;
        }
        try (L1InventoryTransaction tx = User.CheckAndSetPendingUseETCItem(pc,
                CacheD.accountOrderKey("item-use:", pc.getId()))) {
            if (!tx.debit(adena, cost)) return;
            if (tx.grant(reward, 1) == null) {
                SC_SystemMessage.send(pc, "수표를 소지할 수 없습니다.");
                return;
            }
            tx.onFailure(() -> SC_SystemMessage.send(pc, "아데나 수표 전환 저장에 실패했습니다."));
            CDB.RequestUseItem(pc, tx, () -> {
                SC_SkillSound.send(pc, pc.getId(), 470);
                SC_SystemMessage.send(pc, id == 400253
                        ? "1억 아데나가 수표로 전환 되었습니다."
                        : "1천만 아데나가 수표로 전환 되었습니다.");
            });
        } catch (RuntimeException failure) {
            LOG.log(Level.WARNING, "Adena conversion failed: " + pc.getId() + " / " + id, failure);
            SC_SystemMessage.send(pc, "아데나 수표 전환을 처리하지 못했습니다.");
        }
    }
}
