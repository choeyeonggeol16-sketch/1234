package l1j.server.server.model.item.function;



import l1j.server.server.model.network.core.sc.packet.SC_SkillSound;
import static l1j.server.server.model.character.skill.L1SkillId.ABSOLUTE_BARRIER;
import static l1j.server.server.model.character.skill.L1SkillId.COUNTER_MAGIC;
import static l1j.server.server.model.character.skill.L1SkillId.CURSE_BLIND;
import static l1j.server.server.model.character.skill.L1SkillId.DANCING_BLADES;
import static l1j.server.server.model.character.skill.L1SkillId.DARKNESS;
import static l1j.server.server.model.character.skill.L1SkillId.DECAY_POTION;
import static l1j.server.server.model.character.skill.L1SkillId.DRAGON_PUPLE;
import static l1j.server.server.model.character.skill.L1SkillId.DRAGON_TOPAZ;
import static l1j.server.server.model.character.skill.L1SkillId.EARTH_BIND;
import static l1j.server.server.model.character.skill.L1SkillId.EXP_POTION;
import static l1j.server.server.model.character.skill.L1SkillId.FOCUS_WAVE;
import static l1j.server.server.model.character.skill.L1SkillId.GREATER_HASTE;
import static l1j.server.server.model.character.skill.L1SkillId.HASTE;
import static l1j.server.server.model.character.skill.L1SkillId.HOLY_WALK;
import static l1j.server.server.model.character.skill.L1SkillId.HURRICANE;
import static l1j.server.server.model.character.skill.L1SkillId.ICE_LANCE;
import static l1j.server.server.model.character.skill.L1SkillId.LINDBIOR_SPIRIT_EFFECT;
import static l1j.server.server.model.character.skill.L1SkillId.MOVING_ACCELERATION;
import static l1j.server.server.model.character.skill.L1SkillId.SAND_STORM;
import static l1j.server.server.model.character.skill.L1SkillId.SHAPE_CHANGE;
import static l1j.server.server.model.character.skill.L1SkillId.SHOCK_STUN;
import static l1j.server.server.model.character.skill.L1SkillId.SLOW;
import static l1j.server.server.model.character.skill.L1SkillId.STATUS_BLUE_POTION;
import static l1j.server.server.model.character.skill.L1SkillId.STATUS_BLUE_POTION2;
import static l1j.server.server.model.character.skill.L1SkillId.STATUS_BRAVE;
import static l1j.server.server.model.character.skill.L1SkillId.STATUS_CASHSCROLL;
import static l1j.server.server.model.character.skill.L1SkillId.STATUS_CASHSCROLL2;
import static l1j.server.server.model.character.skill.L1SkillId.STATUS_CASHSCROLL3;
import static l1j.server.server.model.character.skill.L1SkillId.STATUS_CASHSCROLL4;
import static l1j.server.server.model.character.skill.L1SkillId.STATUS_CASHSCROLL5;
import static l1j.server.server.model.character.skill.L1SkillId.STATUS_CASHSCROLL6;
import static l1j.server.server.model.character.skill.L1SkillId.STATUS_ELFBRAVE;
import static l1j.server.server.model.character.skill.L1SkillId.STATUS_FLOATING_EYE;
import static l1j.server.server.model.character.skill.L1SkillId.STATUS_FREEZE;
import static l1j.server.server.model.character.skill.L1SkillId.STATUS_FRUIT;
import static l1j.server.server.model.character.skill.L1SkillId.STATUS_HASTE;
import static l1j.server.server.model.character.skill.L1SkillId.STATUS_HOLY_MITHRIL_POWDER;
import static l1j.server.server.model.character.skill.L1SkillId.STATUS_HOLY_WATER;
import static l1j.server.server.model.character.skill.L1SkillId.STATUS_HOLY_WATER_OF_EVA;
import static l1j.server.server.model.character.skill.L1SkillId.STATUS_UNDERWATER_BREATH;
import static l1j.server.server.model.character.skill.L1SkillId.STATUS_WISDOM_POTION;

import java.util.concurrent.ThreadLocalRandom;
import java.util.logging.Logger;
import l1j.server.Config;
import l1j.server.server.storage.CacheD;
import l1j.server.server.model.Instance.L1ItemInstance;
import l1j.server.server.model.Instance.L1PcInstance;



import l1j.server.server.model.network.core.sc.packet.SC_ServerMessage;
import l1j.server.server.model.network.core.sc.packet.SC_SystemMessage;


import l1j.server.server.model.network.core.cs.packet.User;
import l1j.server.server.model.network.core.cs.packet.CDB;


import static l1j.server.server.model.item.function.ItemUseEnchantments.*;
import static l1j.server.server.model.item.function.ItemUsePotions.*;
import static l1j.server.server.model.item.function.ItemUseTransformation.*;
import static l1j.server.server.model.item.function.ItemUseSpellBooks.*;
import static l1j.server.server.model.item.function.ItemUseWorldHelpers.*;
import static l1j.server.server.model.item.function.ItemUseSpecialEnchant.*;
import static l1j.server.server.model.item.function.ItemUseMiscActions.*;
import static l1j.server.server.model.item.function.ItemUseEquipment.*;
import static l1j.server.server.model.item.function.ItemUseDurable.*;
import static l1j.server.server.model.item.function.ItemUseCombatAbilities.*;
import static l1j.server.server.model.item.function.ItemUseDollEffects.*;

import static l1j.server.server.model.item.function.ItemUseCreature.*;

public final class ItemUseSpecialEnchant {
    private static final Logger ITEM_USE2_LOG = ItemUseCreature.ITEM_USE2_LOG;
    private ItemUseSpecialEnchant() {}
	public static void 악세인챈(L1PcInstance pc, L1ItemInstance scroll, L1ItemInstance target) {
        if (!isOwnedScrollTarget(pc, scroll, target)) return;
        if (target.getBless() >= 128) {
            pc.sendPackets("봉인된 아이템에는 사용할 수 없습니다.");
            return;
        }
        if (!isAccessoryEnchantTarget(target)) {
            pc.sendPackets("반지,목걸이에만 강화가 가능합니다.");
            return;
        }
        if (target.isEquipped()) {
            SC_ServerMessage.send(pc, 4302);
            return;
        }
        if (target.get_bless_level() == 5) {
            pc.sendPackets("더 이상 강화는 불가능합니다.");
            return;
        }
        final boolean success = ThreadLocalRandom.current().nextInt(100) < Config.악세축복1단;
        final String name = target.getLogName();
        try (l1j.server.server.model.L1InventoryTransaction tx =
                User.CheckAndSetPendingUseETCItem(pc,
                        l1j.server.server.storage.CacheD.accountOrderKey("item-use:", pc.getId()))) {
            if (!tx.debit(scroll, 1)) return;
            if (success) tx.change(target, image -> {
                image.setBless(0);
                image.set_bless_level(7);
            });
            tx.onFailure(() -> SC_SystemMessage.send(pc, "악세 강화 주문서 저장에 실패했습니다."));
            CDB.RequestUseItem(pc, tx, () -> {
                pc.sendPackets(name + (success
                        ? "\\aL에 축복의 기운 1단계가 스며듭니다."
                        : "\\fH에 축복의 기운이 스며들지 못했습니다."));
                if (success) SC_SkillSound.send(pc, pc.getId(), 8857);
            });
        } catch (RuntimeException failure) {
            ITEM_USE2_LOG.log(java.util.logging.Level.WARNING,
                    "Accessory enchant prepare failed: " + pc.getId(), failure);
            SC_SystemMessage.send(pc, "악세 강화 주문서를 처리하지 못했습니다.");
        }
    }

public static void 악세인챈100(L1PcInstance pc, L1ItemInstance scroll, L1ItemInstance target) {
    if (!isOwnedScrollTarget(pc, scroll, target)) return;
    if (target.getBless() >= 128) {
        pc.sendPackets("봉인된 아이템에는 사용할 수 없습니다.");
        return;
    }
    if (!isAccessoryEnchantTarget(target)) {
        pc.sendPackets("반지,목걸이에만 강화가 가능합니다.");
        return;
    }
    if (target.isEquipped()) {
        SC_ServerMessage.send(pc, 4302);
        return;
    }
    if (target.get_bless_level() == 5) {
        pc.sendPackets("더 이상 강화는 불가능합니다.");
        return;
    }
    final boolean higher = ThreadLocalRandom.current().nextInt(100) < Config.악세축복3단;
    final int nextLevel = higher ? 8 : 7;
    final String name = target.getLogName();
    try (l1j.server.server.model.L1InventoryTransaction tx =
            User.CheckAndSetPendingUseETCItem(pc,
                    l1j.server.server.storage.CacheD.accountOrderKey("item-use:", pc.getId()))) {
        if (!tx.debit(scroll, 1)) return;
        tx.change(target, image -> {
            image.setBless(0);
            image.set_bless_level(nextLevel);
        });
        tx.onFailure(() -> SC_SystemMessage.send(pc, "악세 강화 주문서 저장에 실패했습니다."));
        CDB.RequestUseItem(pc, tx, () -> {
            pc.sendPackets(name + (higher
                    ? "\\aL에 축복의 기운 2단계가 스며듭니다."
                    : "\\aL에 축복의 기운 1단계가 스며듭니다."));
            SC_SkillSound.send(pc, pc.getId(), 8857);
        });
    } catch (RuntimeException failure) {
        ITEM_USE2_LOG.log(java.util.logging.Level.WARNING,
                "Accessory enchant 100 prepare failed: " + pc.getId(), failure);
        SC_SystemMessage.send(pc, "악세 강화 주문서를 처리하지 못했습니다.");
    }
}
public static void 집행진화주문서(L1PcInstance pc, L1ItemInstance scroll, L1ItemInstance target) {
		if (scroll == null || target == null || scroll == target
				|| pc.getInventory().getItem(scroll.getId()) != scroll
				|| pc.getInventory().getItem(target.getId()) != target) return;
		if (target.getBless() >= 128) {
			pc.sendPackets("봉인된 아이템에는 사용할 수 없습니다.");
			return;
		}
		if (target.isEquipped()) {
			SC_ServerMessage.send(pc, 4302);
			return;
		}
		if (target.getEnchantLevel() < Config.qqq) {
			pc.sendPackets("+" + Config.qqq + "이하 인첸트는 진화 불가 합니다.");
			return;
		}

		// The original random <= 100 test is always true for random(100).
		// Preserve the eight 100%-success mappings without the repeated checks.
		final int rewardId;
		switch (target.getItemId()) {
		case 61: rewardId = 14061; break;
		case 12: rewardId = 14012; break;
		case 134: rewardId = 14134; break;
		case 86: rewardId = 14086; break;
		case 202011: rewardId = 2202011; break;
		case 202012: rewardId = 2202012; break;
		case 202013: rewardId = 2202013; break;
		case 202014: rewardId = 2202014; break;
		default: rewardId = 0; break;
		}
		final String name = target.getLogName();
		if (rewardId != 0) {
			// One scroll and one target: one receipt-backed COMMIT, then notify.
			// The old success path removed the scroll twice and could split the
			// item debit and reward INSERT into separate DB operations.
			UseDurableTwoInput(pc, scroll, target, rewardId, () -> {
				pc.sendPackets(name + "\\aL이 진화에 성공 하였습니다.");
				SC_SkillSound.send(pc, pc.getId(), 8857);
			});
			return;
		}

		// Preserve the original unsupported-target failure: spend one scroll.
		// Unlike the old live removeItem(), it is durable before the notice.
		try (l1j.server.server.model.L1InventoryTransaction tx =
				User.CheckAndSetPendingUseETCItem(pc,
						l1j.server.server.storage.CacheD.accountOrderKey("item-use:", pc.getId()))) {
			if (!tx.debit(scroll, 1)) return;
			tx.onFailure(() -> SC_SystemMessage.send(pc, "진화 주문서 소모를 저장하지 못했습니다."));
			CDB.RequestUseItem(pc, tx, () -> pc.sendPackets(name + "\\fH을 진화에 실패 하였습니다."));
		} catch (RuntimeException failure) {
			ITEM_USE2_LOG.log(java.util.logging.Level.WARNING,
					"Item evolution failure prepare failed: " + pc.getId(), failure);
			SC_SystemMessage.send(pc, "진화 주문서를 처리하지 못했습니다.");
		}
	}
public static void 방어구축복100(L1PcInstance pc, L1ItemInstance scroll, L1ItemInstance target) {
    if (!isOwnedScrollTarget(pc, scroll, target)) return;
    if (target.getBless() >= 128) {
        pc.sendPackets("봉인된 아이템에는 사용할 수 없습니다.");
        return;
    }
    if (target.getItem().getType2() != 2 || isAccessoryEnchantTarget(target)
            || target.getItem().getType() == 12) {
        pc.sendPackets("방어구에만 강화가 가능합니다 (반지,목걸이,귀걸이 제외)");
        return;
    }
    if (target.isEquipped()) {
        SC_ServerMessage.send(pc, 4302);
        return;
    }
    final int roll = ThreadLocalRandom.current().nextInt(100);
    final int nextLevel;
    if (roll < Config.방어구축복6단) nextLevel = 6; else if (roll < Config.방어구축복5단) nextLevel = 5; else nextLevel = 4;
    final String targetName = target.getLogName();
    try (l1j.server.server.model.L1InventoryTransaction tx =
            User.CheckAndSetPendingUseETCItem(pc,
                    l1j.server.server.storage.CacheD.accountOrderKey("item-use:", pc.getId()))) {
        if (!tx.debit(scroll, 1)) return;
        if (nextLevel != 0) tx.change(target, image -> {
            image.setBless(0);
            image.set_bless_level(nextLevel);
        });
        tx.onFailure(() -> SC_SystemMessage.send(pc, "방어구 축복 주문서 저장에 실패했습니다."));
        CDB.RequestUseItem(pc, tx, () -> {
            pc.sendPackets(targetName + (nextLevel != 0
                    ? "\\aL에 축복의 기운이 스며듭니다."
                    : "\\fH에 축복의 기운이 스며들지 못했습니다."));
            if (nextLevel != 0) SC_SkillSound.send(pc, pc.getId(), 8857);
        });
    } catch (RuntimeException failure) {
        ITEM_USE2_LOG.log(java.util.logging.Level.WARNING,
                "Armor blessing prepare failed: " + pc.getId(), failure);
        SC_SystemMessage.send(pc, "방어구 축복 주문서를 처리하지 못했습니다.");
    }
}
public static void 방어구축복(L1PcInstance pc, L1ItemInstance scroll, L1ItemInstance target) {
    if (!isOwnedScrollTarget(pc, scroll, target)) return;
    if (target.getBless() >= 128) {
        pc.sendPackets("봉인된 아이템에는 사용할 수 없습니다.");
        return;
    }
    if (target.getItem().getType2() != 2 || isAccessoryEnchantTarget(target)
            || target.getItem().getType() == 12) {
        pc.sendPackets("방어구에만 강화가 가능합니다 (반지,목걸이,귀걸이 제외)");
        return;
    }
    if (target.isEquipped()) {
        SC_ServerMessage.send(pc, 4302);
        return;
    }
    final int roll = ThreadLocalRandom.current().nextInt(100);
    final int nextLevel;
    if (roll < Config.방어구축복1단) nextLevel = 1; else if (roll < Config.방어구축복2단) nextLevel = 2; else if (roll < Config.방어구축복3단) nextLevel = 3; else nextLevel = 0;
    final String targetName = target.getLogName();
    try (l1j.server.server.model.L1InventoryTransaction tx =
            User.CheckAndSetPendingUseETCItem(pc,
                    l1j.server.server.storage.CacheD.accountOrderKey("item-use:", pc.getId()))) {
        if (!tx.debit(scroll, 1)) return;
        if (nextLevel != 0) tx.change(target, image -> {
            image.setBless(0);
            image.set_bless_level(nextLevel);
        });
        tx.onFailure(() -> SC_SystemMessage.send(pc, "방어구 축복 주문서 저장에 실패했습니다."));
        CDB.RequestUseItem(pc, tx, () -> {
            pc.sendPackets(targetName + (nextLevel != 0
                    ? "\\aL에 축복의 기운이 스며듭니다."
                    : "\\fH에 축복의 기운이 스며들지 못했습니다."));
            if (nextLevel != 0) SC_SkillSound.send(pc, pc.getId(), 8857);
        });
    } catch (RuntimeException failure) {
        ITEM_USE2_LOG.log(java.util.logging.Level.WARNING,
                "Armor blessing prepare failed: " + pc.getId(), failure);
        SC_SystemMessage.send(pc, "방어구 축복 주문서를 처리하지 못했습니다.");
    }
}
	public static void 무기축복(L1PcInstance pc, L1ItemInstance scroll, L1ItemInstance target) {
        if (!isOwnedScrollTarget(pc, scroll, target)) return;
        if (target.getBless() >= 128) {
            pc.sendPackets("봉인된 아이템에는 사용할 수 없습니다.");
            return;
        }
        if (target.getItem().getType2() != 1) {
            pc.sendPackets("무기에만 사용할 수 있습니다.");
            return;
        }
        if (target.isEquipped()) {
            SC_ServerMessage.send(pc, 4302);
            return;
        }
        final int level = target.get_bless_level();
        if (level == 5) {
            pc.sendPackets("더 이상 강화는 불가능합니다.");
            return;
        }
        if (level < 0 || level > 5) return;
        final int roll = ThreadLocalRandom.current().nextInt(100);
        final boolean success = (level == 0 ? roll < Config.축복1단
                : level == 1 ? roll < Config.축복2단
                : level == 2 ? roll < Config.축복3단
                : level == 3 ? roll < Config.축복4단
                : roll < Config.축복5단);
        final String itemName = target.getLogName();
        try (l1j.server.server.model.L1InventoryTransaction tx =
                User.CheckAndSetPendingUseETCItem(pc,
                        l1j.server.server.storage.CacheD.accountOrderKey("item-use:", pc.getId()))) {
            if (!tx.debit(scroll, 1)) return;
            if (success) tx.change(target, image -> {
                image.setBless(0);
                image.set_bless_level(level + 1);
            });
            tx.onFailure(() -> SC_SystemMessage.send(pc, "무기 축복 주문서 저장에 실패했습니다."));
            CDB.RequestUseItem(pc, tx, () -> {
                pc.sendPackets(itemName + (success
                        ? "\\aL에 축복의 기운 " + (level + 1) + "단계가 스며듭니다."
                        : "\\fH에 축복의 기운이 스며들지 못했습니다."));
                if (success) SC_SkillSound.send(pc, pc.getId(), 8857);
            });
        } catch (RuntimeException failure) {
            ITEM_USE2_LOG.log(java.util.logging.Level.WARNING,
                    "Weapon blessing prepare failed: " + pc.getId(), failure);
            SC_SystemMessage.send(pc, "무기 축복 주문서를 처리하지 못했습니다.");
        }
    }
	public static void 무기축복100(L1PcInstance pc, L1ItemInstance scroll, L1ItemInstance target) {
        if (!isOwnedScrollTarget(pc, scroll, target)) return;
        if (target.getBless() >= 128) {
            pc.sendPackets("봉인된 아이템에는 사용할 수 없습니다.");
            return;
        }
        if (target.getItem().getType2() != 1) {
            pc.sendPackets("무기에만 사용할 수 있습니다.");
            return;
        }
        if (target.isEquipped()) {
            SC_ServerMessage.send(pc, 4302);
            return;
        }
        final int level = target.get_bless_level();
        if (level == 5) {
            pc.sendPackets("더 이상 강화는 불가능합니다.");
            return;
        }
        if (level < 0 || level > 5) return;
        final String itemName = target.getLogName();
        try (l1j.server.server.model.L1InventoryTransaction tx =
                User.CheckAndSetPendingUseETCItem(pc,
                        l1j.server.server.storage.CacheD.accountOrderKey("item-use:", pc.getId()))) {
            if (!tx.debit(scroll, 1)) return;
            tx.change(target, image -> {
                image.setBless(0);
                image.set_bless_level(level + 1);
            });
            tx.onFailure(() -> SC_SystemMessage.send(pc, "무기 축복 주문서 저장에 실패했습니다."));
            CDB.RequestUseItem(pc, tx, () -> {
                pc.sendPackets(itemName + "\\aL에 축복의 기운 " + (level + 1) + "단계가 스며듭니다.");
                SC_SkillSound.send(pc, pc.getId(), 8857);
            });
        } catch (RuntimeException failure) {
            ITEM_USE2_LOG.log(java.util.logging.Level.WARNING,
                    "Weapon blessing prepare failed: " + pc.getId(), failure);
            SC_SystemMessage.send(pc, "무기 축복 주문서를 처리하지 못했습니다.");
        }
    }
public static boolean isOwnedScrollTarget(L1PcInstance pc, L1ItemInstance scroll, L1ItemInstance target) {
    return pc != null && scroll != null && target != null && scroll != target
            && target.getItem() != null
            && pc.getInventory().getItem(scroll.getId()) == scroll
            && pc.getInventory().getItem(target.getId()) == target;
}

public static boolean isAccessoryEnchantTarget(L1ItemInstance target) {
    if (target == null || target.getItem() == null || target.getItem().getType2() != 2) return false;
    final int type = target.getItem().getType();
    return type == 9 || type == 11 || type == 8;
}

public static int qualityBonus(int roll) {
    if (roll >= 30) return 15;
    if (roll >= 20) return 30;
    if (roll >= 10) return 60;
    if (roll >= 5) return 80;
    return -1;
}

public static void 옵션부여(L1PcInstance pc, L1ItemInstance scroll, L1ItemInstance target) {
    if (!isOwnedScrollTarget(pc, scroll, target)) return;
    if (target.getBless() >= 128) {
        pc.sendPackets("봉인된 아이템에는 사용할 수 없습니다.");
        return;
    }
    if (target.getItem().getType2() != 2) {
        pc.sendPackets("방어구 및 악세에만 사용이 가능합니다.");
        return;
    }
    if (target.isEquipped()) {
        SC_ServerMessage.send(pc, 4302);
        return;
    }
    final boolean success = ThreadLocalRandom.current().nextInt(100) < Config.랜덤부여주문서;
    final int nextLevel = success ? 10 + ThreadLocalRandom.current().nextInt(17) : 0;
    final String name = target.getLogName();
    try (l1j.server.server.model.L1InventoryTransaction tx =
            User.CheckAndSetPendingUseETCItem(pc,
                    l1j.server.server.storage.CacheD.accountOrderKey("item-use:", pc.getId()))) {
        if (!tx.debit(scroll, 1)) return;
        if (success) tx.change(target, image -> {
            image.setBless(0);
            image.set_bless_level(nextLevel);
        });
        tx.onFailure(() -> SC_SystemMessage.send(pc, "옵션부여 주문서 저장에 실패했습니다."));
        CDB.RequestUseItem(pc, tx, () -> {
            pc.sendPackets(name + (success
                    ? "\\aL에 축복의 기운이 스며듭니다."
                    : "\\fH에 축복의 기운이 스며들지 못했습니다."));
            if (success) SC_SkillSound.send(pc, pc.getId(), 8857);
        });
    } catch (RuntimeException failure) {
        ITEM_USE2_LOG.log(java.util.logging.Level.WARNING,
                "Option scroll prepare failed: " + pc.getId(), failure);
        SC_SystemMessage.send(pc, "옵션부여 주문서를 처리하지 못했습니다.");
    }
}

public static void 품질부여주문서(L1PcInstance pc, L1ItemInstance scroll, L1ItemInstance target) {
    if (!isOwnedScrollTarget(pc, scroll, target)) return;
    if (target.getBless() >= 128) {
        pc.sendPackets("봉인된 아이템에는 사용할 수 없습니다.");
        return;
    }
    if (target.getItem().getMaterial() == 8) {
        pc.sendPackets("인형에는 품질부여가 불가능 합니다.");
        return;
    }
    if (target.isEquipped()) {
        SC_ServerMessage.send(pc, 4302);
        return;
    }
    final ThreadLocalRandom rnd = ThreadLocalRandom.current();
    final boolean gate = rnd.nextInt(100) < Config.랜덤부여주문서;
    final int bonus = gate ? qualityBonus(rnd.nextInt(100)) : -1;
    final int nextQuality = bonus < 0 ? -1 : rnd.nextInt(20) + bonus;
    final boolean success = nextQuality >= 0 && nextQuality > target.get_bless_level2();
    final String name = target.getLogName();
    try (l1j.server.server.model.L1InventoryTransaction tx =
            User.CheckAndSetPendingUseETCItem(pc,
                    l1j.server.server.storage.CacheD.accountOrderKey("item-use:", pc.getId()))) {
        if (!tx.debit(scroll, 1)) return;
        if (success) tx.change(target, image -> image.set_bless_level2(nextQuality));
        tx.onFailure(() -> SC_SystemMessage.send(pc, "품질부여 주문서 저장에 실패했습니다."));
        CDB.RequestUseItem(pc, tx, () -> {
            pc.sendPackets(name + (success
                    ? "\\aL의 품질강화에 성공했습니다.품질 : " + nextQuality
                    : "\\fH의 품질강화에 실패하였습니다."));
            if (success) SC_SkillSound.send(pc, pc.getId(), 8857);
        });
    } catch (RuntimeException failure) {
        ITEM_USE2_LOG.log(java.util.logging.Level.WARNING,
                "Quality scroll prepare failed: " + pc.getId(), failure);
        SC_SystemMessage.send(pc, "품질부여 주문서를 처리하지 못했습니다.");
    }
}

}
