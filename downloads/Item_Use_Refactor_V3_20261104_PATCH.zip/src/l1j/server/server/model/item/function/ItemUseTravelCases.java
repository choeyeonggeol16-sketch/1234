package l1j.server.server.model.item.function;

import l1j.server.Stadium.StadiumManager;
import l1j.server.server.ActionCodes;
import l1j.server.server.model.Instance.L1CompanionInstance;
import l1j.server.server.model.Instance.L1ItemInstance;
import l1j.server.server.model.Instance.L1NpcInstance;
import l1j.server.server.model.Instance.L1PcInstance;
import l1j.server.server.model.Instance.L1PetInstance;
import l1j.server.server.model.Instance.L1TowerInstance;
import l1j.server.server.model.L1CastleLocation;
import l1j.server.server.model.L1Character;
import l1j.server.server.model.L1Object;
import l1j.server.server.model.L1PcInventory;
import l1j.server.server.model.L1World;
import l1j.server.server.model.network.core.sc.packet.SC_AttackStatus;
import l1j.server.server.model.network.core.sc.packet.SC_MessageYN;
import l1j.server.server.model.network.core.sc.packet.SC_ServerMessage;
import l1j.server.server.model.network.core.sc.packet.SC_SystemMessage;
import static l1j.server.server.model.item.function.ItemUseCreature._random;
import static l1j.server.server.model.item.function.ItemUseCreature.cancelAbsoluteBarrier;
import static l1j.server.server.model.item.function.ItemUseDurable.UseDurableConsume;
import static l1j.server.server.model.item.function.ItemUseTransformation.polyAction;

/** Item-specific Travel effects; selected once by ItemUseDispatcher. */
final class ItemUseTravelCases {
    private ItemUseTravelCases() {}

    static ItemUseResult handleTeleportCompanions(ItemUseContext use) {
        L1PcInstance pc = use.player();
        L1ItemInstance item = use.item();
        int itemId = use.itemId();
        int spellTargetId = use.spellTargetId();
        if(StadiumManager.getInstance().is_on_stadium(pc.getMapId())){
            pc.sendPackets("사용할 수 없는 지역입니다.");
            return ItemUseResult.STOP;
        }

        if (L1World.getInstance().findObject(spellTargetId) instanceof L1Character) {
            L1Character resobject = (L1Character) L1World.getInstance().findObject(spellTargetId);
            if (resobject != null) {
                if (resobject instanceof L1PcInstance) {
                    L1PcInstance target = (L1PcInstance) resobject;
                    if (pc.getId() == target.getId()) {
                        return ItemUseResult.STOP;
                    }

                    int castle_id = L1CastleLocation.getCastleIdByArea(pc);
                    if (castle_id != 0) {
                        SC_SystemMessage.send(pc, "사용할 수 없는 지역입니다.");
                        return ItemUseResult.STOP;
                    }

                    if (L1World.getInstance().getVisiblePlayer(target, 0).size() > 0) {
                        for (L1PcInstance visiblePc : L1World.getInstance().getVisiblePlayer(target, 0)) {
                            if (!visiblePc.isDead()) {

                                SC_ServerMessage.send(pc, 592);
                                return ItemUseResult.STOP;
                            }
                        }
                    }
                    if (target.getCurrentHp() == 0 && target.isDead() == true) {
                        if (pc.getMap().isUseResurrection()) {
                            target.setTempID(pc.getId());
                            if (itemId == 40089 || itemId == 30074) {

                                SC_MessageYN.send(target, 321, "");
                            } else if (itemId == 140089) {

                                SC_MessageYN.send(target, 322, "");
                            }
                        } else {
                            return ItemUseResult.STOP;
                        }
                    }
                } else if (resobject instanceof L1NpcInstance) {
                    if (!(resobject instanceof L1TowerInstance)) {
                        L1NpcInstance npc = (L1NpcInstance) resobject;
                        int npcId = npc.getNpcId();
                        if (npcId == 0) {
                            pc.sendPackets("부활 할 수 없습니다.");
                            return ItemUseResult.STOP;
                        }

                        if ((npc instanceof L1PetInstance || npc instanceof L1CompanionInstance) && L1World.getInstance().getVisiblePlayer(npc, 0).size() > 0) {
                            for (L1PcInstance visiblePc : L1World.getInstance().getVisiblePlayer(npc, 0)) {
                                if (!visiblePc.isDead()) {
                                    SC_ServerMessage.send(pc, 592);
                                    return ItemUseResult.STOP;
                                }
                            }
                        } else if (npc.getNpcTemplate().isCantResurrect() && !(npc instanceof L1PetInstance || npc instanceof L1CompanionInstance)) {
                            pc.getInventory().removeItem(item, 1);
                            return ItemUseResult.STOP;
                        }
                        if ((npc instanceof L1PetInstance || npc instanceof L1CompanionInstance) && L1World.getInstance().getVisiblePlayer(npc, 0).size() > 0) {
                            for (L1PcInstance visiblePc : L1World.getInstance().getVisiblePlayer(npc, 0)) {
                                if (!visiblePc.isDead()) {

                                    SC_ServerMessage.send(pc, 592);
                                    return ItemUseResult.STOP;
                                }
                            }
                        }
                        if (npc.getCurrentHp() == 0 && npc.isDead()) {
                            npc.resurrect(npc.getMaxHp() / 4);
                            npc.setResurrect(true);
                            npc.occupyNpcTileNow();
                        }
                    }
                }
            }
            pc.getInventory().removeItem(item, 1);
        }

        return ItemUseResult.COMPLETE;
    }

    static ItemUseResult handleReturnFromSpecialMap(ItemUseContext use) {
        L1PcInstance pc = use.player();
        L1ItemInstance item = use.item();
        if (pc.getMapId() >= 1708 && pc.getMapId() == 1712 ||
            pc.getMapId() == 7783 || pc.getMapId() == 3 ||
            pc.getMapId() == 13004 || pc.getMapId() == 12152 ||
            pc.getMapId() == 12149 || pc.getMapId() == 12154 ||
            pc.getMapId() == 12358 || pc.getMapId() == 12153 ||
            pc.getMapId() == 12146 || pc.getMapId() == 12147 ||
            pc.getMapId() == 12148 || pc.getMapId() == 12258 ||
            pc.getMapId() == 12150 || pc.getMapId() == 12257 ||
            pc.getMapId() == 12358) {
            SC_SystemMessage.send(pc, "해당 위치 및 맵에서는 사용이 불가능 합니다.");
            return ItemUseResult.STOP;
        }

        if (pc.getMap().isEscapable() || pc.isGm()) {
            final int rx = _random.nextInt(7);
            final int ux = 32768 + rx;
            final int uy = 32834 + rx;
            UseDurableConsume(pc, item, () -> {
                pc.start_teleport(ux, uy, 622, pc.getHeading(), 169, true, pc.getAutoHunt());
                cancelAbsoluteBarrier(pc);
            });
        } else {
            SC_ServerMessage.send(pc, 647);
            cancelAbsoluteBarrier(pc);
        }
        return ItemUseResult.COMPLETE;
    }

    static ItemUseResult handleResurrectionScroll(ItemUseContext use) {
        L1PcInstance pc = use.player();
        L1ItemInstance item = use.item();
        int itemId = use.itemId();
        String text = use.text();
        int spellTargetId = use.spellTargetId();
        if (pc.getMapId() == 552 || pc.getMapId() == 555 || pc.getMapId() == 557 || pc.getMapId() == 558
                || pc.getMapId() == 779) {

            SC_ServerMessage.send(pc, 563);
        } else {
            SC_AttackStatus.sendAndBroadcast(pc, 0, ActionCodes.ACTION_Wand, false);
            int chargeCount = item.getChargeCount();
            int spriteId = pc.getCurrentSpriteId();
            if (chargeCount <= 0 && itemId != 40410 || spriteId == 6034 || spriteId == 6035) {
                SC_ServerMessage.send(pc, 79);
                return ItemUseResult.STOP;
            }
            L1Object target = L1World.getInstance().findObject(spellTargetId);
            if (spellTargetId == pc.getId() || (target != null && target instanceof L1Character)) {
                L1Character cha = spellTargetId == pc.getId() ? pc : (L1Character) target;
                polyAction(pc, cha, itemId, text);
                cancelAbsoluteBarrier(pc);
                if (itemId == 40008 || itemId == 140008) {
                    item.setChargeCount(item.getChargeCount() - 1);
                    if (item.getChargeCount() == 0) {
                        pc.getInventory().removeItem(item);
                    } else {
                        pc.getInventory().updateItem(item, L1PcInventory.COL_CHARGE_COUNT);
                    }
                } else {
                    pc.getInventory().removeItem(item, 1);
                }
            } else {
                SC_ServerMessage.send(pc, 79);
            }
        }
        return ItemUseResult.COMPLETE;
    }
}
