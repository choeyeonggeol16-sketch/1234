package l1j.server.server.model.item.function;
import l1j.server.server.model.network.core.cs.packet.CDB;
import l1j.server.server.model.network.core.cs.packet.User;
import java.util.logging.Logger;

import l1j.server.server.model.network.core.sc.packet.SC_ItemStatus;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.logging.Level;
import l1j.server.DatabaseFactory;
import l1j.server.server.datatables.ItemTable;
import l1j.server.server.model.Instance.L1ItemInstance;
import l1j.server.server.model.Instance.L1PcInstance;
import l1j.server.server.model.network.core.sc.packet.SC_PacketBox;
import l1j.server.server.model.network.core.sc.packet.SC_SystemMessage;
import l1j.server.server.templates.L1Item;

final class ItemUseTimedRewards {
    private static final Logger _log = Logger.getLogger(CItemUse.class.getName());
    private ItemUseTimedRewards() {}

    private static final class TimeItemRow {
        final int itemId, count, enchant, bless;
        final String activate;

        TimeItemRow(int itemId, int count, int enchant, int bless, String activate) {
            this.itemId = itemId;
            this.count = count;
            this.enchant = enchant;
            this.bless = bless;
            this.activate = activate;
        }
    }

    private static volatile TimeItemRow[][] timeItems = {
        new TimeItemRow[0], new TimeItemRow[0], new TimeItemRow[0]
    };
    private static volatile boolean timeItemsLoaded;

    // Static reward settings: load once on the existing server boot thread.
    static void preloadTimeItems() {
        final TimeItemRow[][] next = new TimeItemRow[3][];
        try {
            for (int i = 0; i < next.length; i++) {
                final String table = i == 0 ? "시간제아이템1" : (i == 1 ? "시간제아이템2" : "시간제아이템3");
                final ArrayList<TimeItemRow> rows = new ArrayList<>();
                try (Connection con = DatabaseFactory.getInstance().getConnection();
                     PreparedStatement ps = con.prepareStatement(
                         "SELECT itemid,count,enchantlvl,bless,activate FROM " + table);
                     ResultSet rs = ps.executeQuery()) {
                    while (rs.next()) {
                        final String activate = rs.getString("activate");
                        rows.add(new TimeItemRow(rs.getInt("itemid"), rs.getInt("count"),
                                rs.getInt("enchantlvl"), rs.getInt("bless"),
                                activate == null ? "" : activate.trim()));
                    }
                }
                next[i] = rows.toArray(new TimeItemRow[rows.size()]);
            }
            timeItems = next;
            timeItemsLoaded = true;
        } catch (SQLException ex) {
            _log.log(Level.SEVERE, "Timed item reward configuration preload failed; previous snapshot retained", ex);
        }
    }

    static void grantTimedItems(L1PcInstance pc, L1ItemInstance ticket,
            int group, int durationSec) {
        if (pc == null || ticket == null || pc.getInventory().getItem(ticket.getId()) != ticket)
            return;
        if (!timeItemsLoaded) {
            SC_SystemMessage.send(pc, "시간제 아이템 지급 정보를 불러오지 못했습니다.");
            return;
        }
        final String clazz;
        if (pc.isCrown()) clazz = "P";
        else if (pc.isKnight()) clazz = "K";
        else if (pc.isElf()) clazz = "E";
        else if (pc.isWizard()) clazz = "W";
        else if (pc.isDarkelf()) clazz = "D";
        else if (pc.isDragonknight()) clazz = "T";
        else if (pc.isBlackwizard()) clazz = "B";
        else if (pc.isWarrior()) clazz = "J";
        else clazz = "A";

        final TimeItemRow[] rows = timeItems[group];
        final Timestamp expiry = new Timestamp(System.currentTimeMillis() + (long) durationSec * 1000L);
        final ArrayList<L1ItemInstance> rewards = new ArrayList<>();
        final ArrayList<L1ItemInstance> announcements = new ArrayList<>();
        try (l1j.server.server.model.L1InventoryTransaction tx =
                User.CheckAndSetPendingUseETCItem(pc,
                        l1j.server.server.storage.CacheD.accountOrderKey("item-use:", pc.getId()))) {
            if (!tx.debit(ticket, 1)) return;
            for (int i = 0; i < rows.length; i++) {
                final TimeItemRow row = rows[i];
                if (!"A".equals(row.activate) && !clazz.equals(row.activate)) continue;
                final L1Item template = ItemTable.getInstance().getTemplate(row.itemId);
                if (template == null || template.isStackable() || row.count <= 0) {
                    SC_SystemMessage.send(pc, "시간제 아이템 보상 설정을 확인해 주세요.");
                    return;
                }
                // All rewards are prepared without registering live/world items.
                // Inventory capacity is checked for the entire batch at commit.
                L1ItemInstance last = null;
                for (int j = 0; j < row.count; j++) {
                    last = tx.grant(row.itemId, 1);
                    if (last == null) throw new IllegalStateException("Timed item grant failed");
                    last.setEnchantLevel(row.enchant);
                    last.setBless(row.bless);
                    last.setIdentified(true);
                    last.setEndTime(expiry);
                    rewards.add(last);
                }
                announcements.add(last);
            }
            if (rewards.isEmpty()) {
                SC_SystemMessage.send(pc, "지급할 시간제 아이템이 없습니다.");
                return;
            }
            tx.onFailure(() -> SC_SystemMessage.send(pc,
                    "시간제 아이템 지급 저장에 실패했습니다. 아이템을 확인해 주세요."));
            CDB.RequestUseItem(pc, tx, () -> {
                for (int i = 0; i < rewards.size(); i++) {
                    final L1ItemInstance item = pc.getInventory().getItem(rewards.get(i).getId());
                    if (item == null) continue;
                    SC_ItemStatus.send(pc, item);
                    SC_PacketBox.send(pc, SC_PacketBox.ITEM_ENCHANT_UPDATE, item);
                }
                for (int i = 0; i < announcements.size(); i++) {
                    final L1ItemInstance item = pc.getInventory().getItem(announcements.get(i).getId());
                    if (item != null) SC_SystemMessage.send(pc, "\\aG[" + item.getLogName() + "] [획득]");
                }
            });
        } catch (RuntimeException failure) {
            _log.log(Level.WARNING, "Timed item package prepare failed: " + pc.getId()
                    + ", group=" + group, failure);
            SC_SystemMessage.send(pc, "시간제 아이템을 지급하지 못했습니다. 아이템을 확인해 주세요.");
        }
    }

}
