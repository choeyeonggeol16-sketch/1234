package l1j.server.server.model.item.function;

import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import l1j.server.server.IdFactory;
import l1j.server.server.datatables.ItemTable;
import l1j.server.server.model.L1InventoryTransaction;
import l1j.server.server.model.Instance.L1ItemInstance;
import l1j.server.server.model.Instance.L1PcInstance;
import l1j.server.server.model.network.core.sc.packet.SC_ServerMessage;
import l1j.server.server.storage.CacheD;
import l1j.server.server.templates.L1Item;
import l1j.server.server.utils.CommonUtil;

public class additem {

	private static final Logger LOG = Logger.getLogger(additem.class.getName());

	public static void clickItem(L1PcInstance pc, int itemId, L1ItemInstance input) {
		if (pc == null || input == null || input.getItemId() != itemId
				|| pc.getInventory().getItem(input.getId()) != input
				|| !pc.getInventory().checkItem(itemId, 1)) return;
		try (L1InventoryTransaction tx = L1InventoryTransaction.begin(
				pc, CacheD.accountOrderKey("item-use:", pc.getId()))) {
			if (!tx.debit(input, 1)) return;
			final ArrayList<String> messages = new ArrayList<>(2);
		switch (itemId) {
		case 4100164:// 반놀자 지원 상자
			if (pc.getInventory().checkItem(4100164, 1)) { // 체크 되는 아이템과 수량


				if (pc.isWarrior()) {
					stageReward(tx, messages, 3000573, 1, 0, 129, 0, true);
				}
				if (pc.isKnight()) {
					stageReward(tx, messages, 3000572, 1, 0, 129, 0, true);
				}
				if (pc.isDragonknight()) {
					stageReward(tx, messages, 3000578, 1, 0, 129, 0, true);
				}
				if (pc.isCrown()) {
					stageReward(tx, messages, 3000579, 1, 0, 129, 0, true);
				}
				if (pc.isWizard()) {
					stageReward(tx, messages, 3000575, 1, 0, 129, 0, true);
				}
				if (pc.isBlackwizard()) {
					stageReward(tx, messages, 3000576, 1, 0, 129, 0, true);
				}
				if (pc.isElf()) {
					stageReward(tx, messages, 3000574, 1, 0, 129, 0, true);
				}
				if (pc.isDarkelf()) {
					stageReward(tx, messages, 3000577, 1, 0, 129, 0, true);
				}
			}
			break;
		case 4100165:// 반하자 지원상자
			if (pc.getInventory().checkItem(4100165, 1)) { // 체크 되는 아이템과 수량


				if (pc.isWarrior()) {
					stageReward(tx, messages, 4200090, 1, 0, 129, 0, true);
				}
				if (pc.isKnight()) {
					stageReward(tx, messages, 4200091, 1, 0, 129, 0, true);
				}
				if (pc.isDragonknight()) {
					stageReward(tx, messages, 4200092, 1, 0, 129, 0, true);
				}
				if (pc.isCrown()) {
					stageReward(tx, messages, 4200093, 1, 0, 129, 0, true);
				}
				if (pc.isWizard()) {
					stageReward(tx, messages, 4200094, 1, 0, 129, 0, true);
				}
				if (pc.isBlackwizard()) {
					stageReward(tx, messages, 4200095, 1, 0, 129, 0, true);
				}
				if (pc.isElf()) {
					stageReward(tx, messages, 4200096, 1, 0, 129, 0, true);
				}
				if (pc.isDarkelf()) {
					stageReward(tx, messages, 4200097, 1, 0, 129, 0, true);
				}
			}
			break;
		case 3000035:// 하자 지원 상자
			if (pc.getInventory().checkItem(3000035, 1)) { // 체크 되는 아이템과 수량				


				if (pc.isWarrior()) {
					stageReward(tx, messages, 4100087, 1, 0, 129, 0, true);
				}
				if (pc.isKnight()) {
					stageReward(tx, messages, 4100088, 1, 0, 129, 0, true);
				}
				if (pc.isDragonknight()) {
					stageReward(tx, messages, 4100089, 1, 0, 129, 0, true);
				}
				if (pc.isCrown()) {
					stageReward(tx, messages, 4100090, 1, 0, 129, 0, true);
				}
				if (pc.isWizard()) {
					stageReward(tx, messages, 4100091, 1, 0, 129, 0, true);
				}
				if (pc.isBlackwizard()) {
					stageReward(tx, messages, 4100092, 1, 0, 129, 0, true);
				}
				if (pc.isElf()) {
					stageReward(tx, messages, 4100093, 1, 0, 129, 0, true);
				}
				if (pc.isDarkelf()) {
					stageReward(tx, messages, 4100094, 1, 0, 129, 0, true);
				}
			}
			break;
		case 68088:
			if (pc.getInventory().checkItem(68088, 1)) { // 체크 되는 아이템과 수량

				stageSealedReward(tx, messages, 68096, 1, 0, 1, 0, true); // 마력의 고서(90)
				if (pc.isWarrior()) {
					stageSealedReward(tx, messages, 900145, 1, 0, 1, 0, true); // 힘의 엘릭서 룬(90)
				}
				if (pc.isKnight()) {
					stageSealedReward(tx, messages, 900145, 1, 0, 1, 0, true); // 힘의 엘릭서 룬(90)
				}
				if (pc.isDragonknight()) {
					stageSealedReward(tx, messages, 900145, 1, 0, 1, 0, true); // 힘의 엘릭서 룬(90)
				}
				if (pc.isCrown()) {
					stageSealedReward(tx, messages, 900145, 1, 0, 1, 0, true); // 힘의 엘릭서 룬(90)
				}
				if (pc.isWizard()) {
					stageSealedReward(tx, messages, 900145, 1, 0, 1, 0, true); // 힘의 엘릭서 룬(90)
				}
				if (pc.isBlackwizard()) {
					stageSealedReward(tx, messages, 900145, 1, 0, 1, 0, true); // 힘의 엘릭서 룬(90)
				}
				if (pc.isElf()) {
					stageSealedReward(tx, messages, 900145, 1, 0, 1, 0, true); // 힘의 엘릭서 룬(90)
				}
				if (pc.isDarkelf()) {
					stageSealedReward(tx, messages, 900145, 1, 0, 1, 0, true); // 힘의 엘릭서 룬(90)
				}
			}
			break;
		case 68089:
			if (pc.getInventory().checkItem(68089, 1)) { // 체크 되는 아이템과 수량

				stageSealedReward(tx, messages, 68096, 1, 0, 1, 0, true); // 마력의 고서(90)
				if (pc.isWarrior()) {
					stageSealedReward(tx, messages, 900146, 1, 0, 1, 0, true); // 민첩의 엘릭서 룬(90)
				}
				if (pc.isKnight()) {
					stageSealedReward(tx, messages, 900146, 1, 0, 1, 0, true); // 민첩의 엘릭서 룬(90)
				}
				if (pc.isDragonknight()) {
					stageSealedReward(tx, messages, 900146, 1, 0, 1, 0, true); // 민첩의 엘릭서 룬(90)
				}
				if (pc.isCrown()) {
					stageSealedReward(tx, messages, 900146, 1, 0, 1, 0, true); // 민첩의 엘릭서 룬(90)
				}
				if (pc.isWizard()) {
					stageSealedReward(tx, messages, 900146, 1, 0, 1, 0, true); // 민첩의 엘릭서 룬(90)
				}
				if (pc.isBlackwizard()) {
					stageSealedReward(tx, messages, 900146, 1, 0, 1, 0, true); // 민첩의 엘릭서 룬(90)
				}
				if (pc.isElf()) {
					stageSealedReward(tx, messages, 900146, 1, 0, 1, 0, true); // 민첩의 엘릭서 룬(90)
				}
				if (pc.isDarkelf()) {
					stageSealedReward(tx, messages, 900146, 1, 0, 1, 0, true); // 민첩의 엘릭서 룬(90)
				}
			}
			break;
		case 68090:
			if (pc.getInventory().checkItem(68090, 1)) { // 체크 되는 아이템과 수량

				stageSealedReward(tx, messages, 68096, 1, 0, 1, 0, true); // 마력의 고서(90)
				if (pc.isWarrior()) {
					stageSealedReward(tx, messages, 900147, 1, 0, 1, 0, true); // 체력의 엘릭서 룬(90)
				}
				if (pc.isKnight()) {
					stageSealedReward(tx, messages, 900147, 1, 0, 1, 0, true); // 체력의 엘릭서 룬(90)
				}
				if (pc.isDragonknight()) {
					stageSealedReward(tx, messages, 900147, 1, 0, 1, 0, true); // 체력의 엘릭서 룬(90)
				}
				if (pc.isCrown()) {
					stageSealedReward(tx, messages, 900147, 1, 0, 1, 0, true); // 체력의 엘릭서 룬(90)
				}
				if (pc.isWizard()) {
					stageSealedReward(tx, messages, 900147, 1, 0, 1, 0, true); // 체력의 엘릭서 룬(90)
				}
				if (pc.isBlackwizard()) {
					stageSealedReward(tx, messages, 900147, 1, 0, 1, 0, true); // 체력의 엘릭서 룬(90)
				}
				if (pc.isElf()) {
					stageSealedReward(tx, messages, 900147, 1, 0, 1, 0, true); // 체력의 엘릭서 룬(90)
				}
				if (pc.isDarkelf()) {
					stageSealedReward(tx, messages, 900147, 1, 0, 1, 0, true); // 체력의 엘릭서 룬(90)
				}
			}
			break;
		case 68091:
			if (pc.getInventory().checkItem(68091, 1)) { // 체크 되는 아이템과 수량

				stageSealedReward(tx, messages, 68096, 1, 0, 1, 0, true); // 마력의 고서(90)
				if (pc.isWarrior()) {
					stageSealedReward(tx, messages, 900148, 1, 0, 1, 0, true); // 지식의 엘릭서 룬(90)
				}
				if (pc.isKnight()) {
					stageSealedReward(tx, messages, 900148, 1, 0, 1, 0, true); // 지식의 엘릭서 룬(90)
				}
				if (pc.isDragonknight()) {
					stageSealedReward(tx, messages, 900148, 1, 0, 1, 0, true); // 지식의 엘릭서 룬(90)
				}
				if (pc.isCrown()) {
					stageSealedReward(tx, messages, 900148, 1, 0, 1, 0, true); // 지식의 엘릭서 룬(90)
				}
				if (pc.isWizard()) {
					stageSealedReward(tx, messages, 900148, 1, 0, 1, 0, true); // 지식의 엘릭서 룬(90)
				}
				if (pc.isBlackwizard()) {
					stageSealedReward(tx, messages, 900148, 1, 0, 1, 0, true); // 지식의 엘릭서 룬(90)
				}
				if (pc.isElf()) {
					stageSealedReward(tx, messages, 900148, 1, 0, 1, 0, true); // 지식의 엘릭서 룬(90)
				}
				if (pc.isDarkelf()) {
					stageSealedReward(tx, messages, 900148, 1, 0, 1, 0, true); // 지식의 엘릭서 룬(90)
				}
			}
			break;
		case 68092:
			if (pc.getInventory().checkItem(68092, 1)) { // 체크 되는 아이템과 수량

				stageSealedReward(tx, messages, 68096, 1, 0, 1, 0, true); // 마력의 고서(90)
				if (pc.isWarrior()) {
					stageSealedReward(tx, messages, 900149, 1, 0, 1, 0, true); // 지혜의 엘릭서 룬(90)
				}
				if (pc.isKnight()) {
					stageSealedReward(tx, messages, 900149, 1, 0, 1, 0, true); // 지혜의 엘릭서 룬(90)
				}
				if (pc.isDragonknight()) {
					stageSealedReward(tx, messages, 900149, 1, 0, 1, 0, true); // 지혜의 엘릭서 룬(90)
				}
				if (pc.isCrown()) {
					stageSealedReward(tx, messages, 900149, 1, 0, 1, 0, true); // 지혜의 엘릭서 룬(90)
				}
				if (pc.isWizard()) {
					stageSealedReward(tx, messages, 900149, 1, 0, 1, 0, true); // 지혜의 엘릭서 룬(90)
				}
				if (pc.isBlackwizard()) {
					stageSealedReward(tx, messages, 900149, 1, 0, 1, 0, true); // 지혜의 엘릭서 룬(90)
				}
				if (pc.isElf()) {
					stageSealedReward(tx, messages, 900149, 1, 0, 1, 0, true); // 지혜의 엘릭서 룬(90)
				}
				if (pc.isDarkelf()) {
					stageSealedReward(tx, messages, 900149, 1, 0, 1, 0, true); // 지혜의 엘릭서 룬(90)
				}
			}
			break;
		case 68083:
			if (pc.getInventory().checkItem(68083, 1)) { // 체크 되는 아이템과 수량

				stageSealedReward(tx, messages, 68095, 1, 0, 1, 0, true); // 마력의 고서(85)
				if (pc.isWarrior()) {
					stageSealedReward(tx, messages, 900140, 1, 0, 1, 0, true); // 힘의 엘릭서 룬(85)
				}
				if (pc.isKnight()) {
					stageSealedReward(tx, messages, 900140, 1, 0, 1, 0, true); // 힘의 엘릭서 룬(85)
				}
				if (pc.isDragonknight()) {
					stageSealedReward(tx, messages, 900140, 1, 0, 1, 0, true); // 힘의 엘릭서 룬(85)
				}
				if (pc.isCrown()) {
					stageSealedReward(tx, messages, 900140, 1, 0, 1, 0, true); // 힘의 엘릭서 룬(85)
				}
				if (pc.isWizard()) {
					stageSealedReward(tx, messages, 900140, 1, 0, 1, 0, true); // 힘의 엘릭서 룬(85)
				}
				if (pc.isBlackwizard()) {
					stageSealedReward(tx, messages, 900140, 1, 0, 1, 0, true); // 힘의 엘릭서 룬(85)
				}
				if (pc.isElf()) {
					stageSealedReward(tx, messages, 900140, 1, 0, 1, 0, true); // 힘의 엘릭서 룬(85)
				}
				if (pc.isDarkelf()) {
					stageSealedReward(tx, messages, 900140, 1, 0, 1, 0, true); // 힘의 엘릭서 룬(85)
				}
			}
			break;
		case 68084:
			if (pc.getInventory().checkItem(68084, 1)) { // 체크 되는 아이템과 수량

				stageSealedReward(tx, messages, 68095, 1, 0, 1, 0, true); // 마력의 고서(85)
				if (pc.isWarrior()) {
					stageSealedReward(tx, messages, 900141, 1, 0, 1, 0, true); // 민첩의 엘릭서 룬(85)
				}
				if (pc.isKnight()) {
					stageSealedReward(tx, messages, 900141, 1, 0, 1, 0, true); // 민첩의 엘릭서 룬(85)
				}
				if (pc.isDragonknight()) {
					stageSealedReward(tx, messages, 900141, 1, 0, 1, 0, true); // 민첩의 엘릭서 룬(85)
				}
				if (pc.isCrown()) {
					stageSealedReward(tx, messages, 900141, 1, 0, 1, 0, true); // 민첩의 엘릭서 룬(85)
				}
				if (pc.isWizard()) {
					stageSealedReward(tx, messages, 900141, 1, 0, 1, 0, true); // 민첩의 엘릭서 룬(85)
				}
				if (pc.isBlackwizard()) {
					stageSealedReward(tx, messages, 900141, 1, 0, 1, 0, true); // 민첩의 엘릭서 룬(85)
				}
				if (pc.isElf()) {
					stageSealedReward(tx, messages, 900141, 1, 0, 1, 0, true); // 민첩의 엘릭서 룬(85)
				}
				if (pc.isDarkelf()) {
					stageSealedReward(tx, messages, 900141, 1, 0, 1, 0, true); // 민첩의 엘릭서 룬(85)
				}
			}
			break;
		case 68085:
			if (pc.getInventory().checkItem(68085, 1)) { // 체크 되는 아이템과 수량

				stageSealedReward(tx, messages, 68095, 1, 0, 1, 0, true); // 마력의 고서(85)
				if (pc.isWarrior()) {
					stageSealedReward(tx, messages, 900142, 1, 0, 1, 0, true); // 체력의 엘릭서 룬(85)
				}
				if (pc.isKnight()) {
					stageSealedReward(tx, messages, 900142, 1, 0, 1, 0, true); // 체력의 엘릭서 룬(85)
				}
				if (pc.isDragonknight()) {
					stageSealedReward(tx, messages, 900142, 1, 0, 1, 0, true); // 체력의 엘릭서 룬(85)
				}
				if (pc.isCrown()) {
					stageSealedReward(tx, messages, 900142, 1, 0, 1, 0, true); // 체력의 엘릭서 룬(85)
				}
				if (pc.isWizard()) {
					stageSealedReward(tx, messages, 900142, 1, 0, 1, 0, true); // 체력의 엘릭서 룬(85)
				}
				if (pc.isBlackwizard()) {
					stageSealedReward(tx, messages, 900142, 1, 0, 1, 0, true); // 체력의 엘릭서 룬(85)
				}
				if (pc.isElf()) {
					stageSealedReward(tx, messages, 900142, 1, 0, 1, 0, true); // 체력의 엘릭서 룬(85)
				}
				if (pc.isDarkelf()) {
					stageSealedReward(tx, messages, 900142, 1, 0, 1, 0, true); // 체력의 엘릭서 룬(85)
				}
			}
			break;
		case 68086:
			if (pc.getInventory().checkItem(68086, 1)) { // 체크 되는 아이템과 수량

				stageSealedReward(tx, messages, 68095, 1, 0, 1, 0, true); // 마력의 고서(85)
				if (pc.isWarrior()) {
					stageSealedReward(tx, messages, 900143, 1, 0, 1, 0, true); // 지식의 엘릭서 룬(85)
				}
				if (pc.isKnight()) {
					stageSealedReward(tx, messages, 900143, 1, 0, 1, 0, true); // 지식의 엘릭서 룬(85)
				}
				if (pc.isDragonknight()) {
					stageSealedReward(tx, messages, 900143, 1, 0, 1, 0, true); // 지식의 엘릭서 룬(85)
				}
				if (pc.isCrown()) {
					stageSealedReward(tx, messages, 900143, 1, 0, 1, 0, true); // 지식의 엘릭서 룬(85)
				}
				if (pc.isWizard()) {
					stageSealedReward(tx, messages, 900143, 1, 0, 1, 0, true); // 지식의 엘릭서 룬(85)
				}
				if (pc.isBlackwizard()) {
					stageSealedReward(tx, messages, 900143, 1, 0, 1, 0, true); // 지식의 엘릭서 룬(85)
				}
				if (pc.isElf()) {
					stageSealedReward(tx, messages, 900143, 1, 0, 1, 0, true); // 지식의 엘릭서 룬(85)
				}
				if (pc.isDarkelf()) {
					stageSealedReward(tx, messages, 900143, 1, 0, 1, 0, true); // 지식의 엘릭서 룬(85)
				}
			}
			break;
		case 68087:
			if (pc.getInventory().checkItem(68087, 1)) { // 체크 되는 아이템과 수량

				stageSealedReward(tx, messages, 68095, 1, 0, 1, 0, true); // 마력의 고서(85)
				if (pc.isWarrior()) {
					stageSealedReward(tx, messages, 900144, 1, 0, 1, 0, true); // 지혜의 엘릭서 룬(85)
				}
				if (pc.isKnight()) {
					stageSealedReward(tx, messages, 900144, 1, 0, 1, 0, true); // 지혜의 엘릭서 룬(85)
				}
				if (pc.isDragonknight()) {
					stageSealedReward(tx, messages, 900144, 1, 0, 1, 0, true); // 지혜의 엘릭서 룬(85)
				}
				if (pc.isCrown()) {
					stageSealedReward(tx, messages, 900144, 1, 0, 1, 0, true); // 지혜의 엘릭서 룬(85)
				}
				if (pc.isWizard()) {
					stageSealedReward(tx, messages, 900144, 1, 0, 1, 0, true); // 지혜의 엘릭서 룬(85)
				}
				if (pc.isBlackwizard()) {
					stageSealedReward(tx, messages, 900144, 1, 0, 1, 0, true); // 지혜의 엘릭서 룬(85)
				}
				if (pc.isElf()) {
					stageSealedReward(tx, messages, 900144, 1, 0, 1, 0, true); // 지혜의 엘릭서 룬(85)
				}
				if (pc.isDarkelf()) {
					stageSealedReward(tx, messages, 900144, 1, 0, 1, 0, true); // 지혜의 엘릭서 룬(85)
				}
			}
			break;
		case 68078:
			if (pc.getInventory().checkItem(68078, 1)) { // 체크 되는 아이템과 수량

				stageSealedReward(tx, messages, 68094, 1, 0, 1, 0, true); // 마력의 고서(80)
				if (pc.isWarrior()) {
					stageSealedReward(tx, messages, 900135, 1, 0, 1, 0, true); // 힘의 엘릭서 룬(80)
				}
				if (pc.isKnight()) {
					stageSealedReward(tx, messages, 900135, 1, 0, 1, 0, true); // 힘의 엘릭서 룬(80)
				}
				if (pc.isDragonknight()) {
					stageSealedReward(tx, messages, 900135, 1, 0, 1, 0, true); // 힘의 엘릭서 룬(80)
				}
				if (pc.isCrown()) {
					stageSealedReward(tx, messages, 900135, 1, 0, 1, 0, true); // 힘의 엘릭서 룬(80)
				}
				if (pc.isWizard()) {
					stageSealedReward(tx, messages, 900135, 1, 0, 1, 0, true); // 힘의 엘릭서 룬(80)
				}
				if (pc.isBlackwizard()) {
					stageSealedReward(tx, messages, 900135, 1, 0, 1, 0, true); // 힘의 엘릭서 룬(80)
				}
				if (pc.isElf()) {
					stageSealedReward(tx, messages, 900135, 1, 0, 1, 0, true); // 힘의 엘릭서 룬(80)
				}
				if (pc.isDarkelf()) {
					stageSealedReward(tx, messages, 900135, 1, 0, 1, 0, true); // 힘의 엘릭서 룬(80)
				}
			}
			break;
		case 68079:
			if (pc.getInventory().checkItem(68079, 1)) { // 체크 되는 아이템과 수량

				stageSealedReward(tx, messages, 68094, 1, 0, 1, 0, true); // 마력의 고서(80)
				if (pc.isWarrior()) {
					stageSealedReward(tx, messages, 900136, 1, 0, 1, 0, true); // 민첩의 엘릭서 룬(80)
				}
				if (pc.isKnight()) {
					stageSealedReward(tx, messages, 900136, 1, 0, 1, 0, true); // 민첩의 엘릭서 룬(80)
				}
				if (pc.isDragonknight()) {
					stageSealedReward(tx, messages, 900136, 1, 0, 1, 0, true); // 민첩의 엘릭서 룬(80)
				}
				if (pc.isCrown()) {
					stageSealedReward(tx, messages, 900136, 1, 0, 1, 0, true); // 민첩의 엘릭서 룬(80)
				}
				if (pc.isWizard()) {
					stageSealedReward(tx, messages, 900136, 1, 0, 1, 0, true); // 민첩의 엘릭서 룬(80)
				}
				if (pc.isBlackwizard()) {
					stageSealedReward(tx, messages, 900136, 1, 0, 1, 0, true); // 민첩의 엘릭서 룬(80)
				}
				if (pc.isElf()) {
					stageSealedReward(tx, messages, 900136, 1, 0, 1, 0, true); // 민첩의 엘릭서 룬(80)
				}
				if (pc.isDarkelf()) {
					stageSealedReward(tx, messages, 900136, 1, 0, 1, 0, true); // 민첩의 엘릭서 룬(80)
				}
			}
			break;
		case 68080:
			if (pc.getInventory().checkItem(68080, 1)) { // 체크 되는 아이템과 수량

				stageSealedReward(tx, messages, 68094, 1, 0, 1, 0, true); // 마력의 고서(80)
				if (pc.isWarrior()) {
					stageSealedReward(tx, messages, 900137, 1, 0, 1, 0, true); // 체력의 엘릭서 룬(80)
				}
				if (pc.isKnight()) {
					stageSealedReward(tx, messages, 900137, 1, 0, 1, 0, true); // 체력의 엘릭서 룬(80)
				}
				if (pc.isDragonknight()) {
					stageSealedReward(tx, messages, 900137, 1, 0, 1, 0, true); // 체력의 엘릭서 룬(80)
				}
				if (pc.isCrown()) {
					stageSealedReward(tx, messages, 900137, 1, 0, 1, 0, true); // 체력의 엘릭서 룬(80)
				}
				if (pc.isWizard()) {
					stageSealedReward(tx, messages, 900137, 1, 0, 1, 0, true); // 체력의 엘릭서 룬(80)
				}
				if (pc.isBlackwizard()) {
					stageSealedReward(tx, messages, 900137, 1, 0, 1, 0, true); // 체력의 엘릭서 룬(80)
				}
				if (pc.isElf()) {
					stageSealedReward(tx, messages, 900137, 1, 0, 1, 0, true); // 체력의 엘릭서 룬(80)
				}
				if (pc.isDarkelf()) {
					stageSealedReward(tx, messages, 900137, 1, 0, 1, 0, true); // 체력의 엘릭서 룬(80)
				}
			}
			break;
		case 68081:
			if (pc.getInventory().checkItem(68081, 1)) { // 체크 되는 아이템과 수량

				stageSealedReward(tx, messages, 68094, 1, 0, 1, 0, true); // 마력의 고서(80)
				if (pc.isWarrior()) {
					stageSealedReward(tx, messages, 900138, 1, 0, 1, 0, true); // 지식의 엘릭서 룬(80)
				}
				if (pc.isKnight()) {
					stageSealedReward(tx, messages, 900138, 1, 0, 1, 0, true); // 지식의 엘릭서 룬(80)
				}
				if (pc.isDragonknight()) {
					stageSealedReward(tx, messages, 900138, 1, 0, 1, 0, true); // 지식의 엘릭서 룬(80)
				}
				if (pc.isCrown()) {
					stageSealedReward(tx, messages, 900138, 1, 0, 1, 0, true); // 지식의 엘릭서 룬(80)
				}
				if (pc.isWizard()) {
					stageSealedReward(tx, messages, 900138, 1, 0, 1, 0, true); // 지식의 엘릭서 룬(80)
				}
				if (pc.isBlackwizard()) {
					stageSealedReward(tx, messages, 900138, 1, 0, 1, 0, true); // 지식의 엘릭서 룬(80)
				}
				if (pc.isElf()) {
					stageSealedReward(tx, messages, 900138, 1, 0, 1, 0, true); // 지식의 엘릭서 룬(80)
				}
				if (pc.isDarkelf()) {
					stageSealedReward(tx, messages, 900138, 1, 0, 1, 0, true); // 지식의 엘릭서 룬(80)
				}
			}
			break;
		case 68082:
			if (pc.getInventory().checkItem(68082, 1)) { // 체크 되는 아이템과 수량

				stageSealedReward(tx, messages, 68094, 1, 0, 1, 0, true); // 마력의 고서(80)
				if (pc.isWarrior()) {
					stageSealedReward(tx, messages, 900139, 1, 0, 1, 0, true); // 지혜의 엘릭서 룬(80)
				}
				if (pc.isKnight()) {
					stageSealedReward(tx, messages, 900139, 1, 0, 1, 0, true); // 지혜의 엘릭서 룬(80)
				}
				if (pc.isDragonknight()) {
					stageSealedReward(tx, messages, 900139, 1, 0, 1, 0, true); // 지혜의 엘릭서 룬(80)
				}
				if (pc.isCrown()) {
					stageSealedReward(tx, messages, 900139, 1, 0, 1, 0, true); // 지혜의 엘릭서 룬(80)
				}
				if (pc.isWizard()) {
					stageSealedReward(tx, messages, 900139, 1, 0, 1, 0, true); // 지혜의 엘릭서 룬(80)
				}
				if (pc.isBlackwizard()) {
					stageSealedReward(tx, messages, 900139, 1, 0, 1, 0, true); // 지혜의 엘릭서 룬(80)
				}
				if (pc.isElf()) {
					stageSealedReward(tx, messages, 900139, 1, 0, 1, 0, true); // 지혜의 엘릭서 룬(80)
				}
				if (pc.isDarkelf()) {
					stageSealedReward(tx, messages, 900139, 1, 0, 1, 0, true); // 지혜의 엘릭서 룬(80)
				}
			}
			break;
		case 60041:
			if (pc.getInventory().checkItem(60041, 1)) { // 체크 되는 아이템과 수량

				stageSealedReward(tx, messages, 68093, 1, 0, 1, 0, true); // 마력의 고서(70)
				if (pc.isWarrior()) {
					stageSealedReward(tx, messages, 222316, 1, 0, 1, 0, true); // 힘의 엘릭서 룬(70레벨)
				}
				if (pc.isKnight()) {
					stageSealedReward(tx, messages, 222316, 1, 0, 1, 0, true); // 힘의 엘릭서 룬(70레벨)
				}
				if (pc.isDragonknight()) {
					stageSealedReward(tx, messages, 222316, 1, 0, 1, 0, true); // 힘의 엘릭서 룬(70레벨)
				}
				if (pc.isCrown()) {
					stageSealedReward(tx, messages, 222316, 1, 0, 1, 0, true); // 힘의 엘릭서 룬(70레벨)
				}
				if (pc.isWizard()) {
					stageSealedReward(tx, messages, 222316, 1, 0, 1, 0, true); // 힘의 엘릭서 룬(70레벨)
				}
				if (pc.isBlackwizard()) {
					stageSealedReward(tx, messages, 222316, 1, 0, 1, 0, true); // 힘의 엘릭서 룬(70레벨)
				}
				if (pc.isElf()) {
					stageSealedReward(tx, messages, 222316, 1, 0, 1, 0, true); // 힘의 엘릭서 룬(70레벨)
				}
				if (pc.isDarkelf()) {
					stageSealedReward(tx, messages, 222316, 1, 0, 1, 0, true); // 힘의 엘릭서 룬(70레벨)
				}
			}
			break;
		case 60042:
			if (pc.getInventory().checkItem(60042, 1)) { // 체크 되는 아이템과 수량

				stageSealedReward(tx, messages, 68093, 1, 0, 1, 0, true); // 마력의 고서(70)
				if (pc.isWarrior()) {
					stageSealedReward(tx, messages, 222312, 1, 0, 1, 0, true); // 민첩의 엘릭서 룬(70레벨)
				}
				if (pc.isKnight()) {
					stageSealedReward(tx, messages, 222312, 1, 0, 1, 0, true); // 민첩의 엘릭서 룬(70레벨)
				}
				if (pc.isDragonknight()) {
					stageSealedReward(tx, messages, 222312, 1, 0, 1, 0, true); // 민첩의 엘릭서 룬(70레벨)
				}
				if (pc.isCrown()) {
					stageSealedReward(tx, messages, 222312, 1, 0, 1, 0, true); // 민첩의 엘릭서 룬(70레벨)
				}
				if (pc.isWizard()) {
					stageSealedReward(tx, messages, 222312, 1, 0, 1, 0, true); // 민첩의 엘릭서 룬(70레벨)
				}
				if (pc.isBlackwizard()) {
					stageSealedReward(tx, messages, 222312, 1, 0, 1, 0, true); // 민첩의 엘릭서 룬(70레벨)
				}
				if (pc.isElf()) {
					stageSealedReward(tx, messages, 222312, 1, 0, 1, 0, true); // 민첩의 엘릭서 룬(70레벨)
				}
				if (pc.isDarkelf()) {
					stageSealedReward(tx, messages, 222312, 1, 0, 1, 0, true); // 민첩의 엘릭서 룬(70레벨)
				}
			}
			break;
		case 60043:
			if (pc.getInventory().checkItem(60043, 1)) { // 체크 되는 아이템과 수량

				stageSealedReward(tx, messages, 68093, 1, 0, 1, 0, true); // 마력의 고서(70)
				if (pc.isWarrior()) {
					stageSealedReward(tx, messages, 222313, 1, 0, 1, 0, true); // 민첩의 엘릭서 룬(70레벨)
				}
				if (pc.isKnight()) {
					stageSealedReward(tx, messages, 222313, 1, 0, 1, 0, true); // 민첩의 엘릭서 룬(70레벨)
				}
				if (pc.isDragonknight()) {
					stageSealedReward(tx, messages, 222313, 1, 0, 1, 0, true); // 민첩의 엘릭서 룬(70레벨)
				}
				if (pc.isCrown()) {
					stageSealedReward(tx, messages, 222313, 1, 0, 1, 0, true); // 민첩의 엘릭서 룬(70레벨)
				}
				if (pc.isWizard()) {
					stageSealedReward(tx, messages, 222313, 1, 0, 1, 0, true); // 민첩의 엘릭서 룬(70레벨)
				}
				if (pc.isBlackwizard()) {
					stageSealedReward(tx, messages, 222313, 1, 0, 1, 0, true); // 민첩의 엘릭서 룬(70레벨)
				}
				if (pc.isElf()) {
					stageSealedReward(tx, messages, 222313, 1, 0, 1, 0, true); // 민첩의 엘릭서 룬(70레벨)
				}
				if (pc.isDarkelf()) {
					stageSealedReward(tx, messages, 222313, 1, 0, 1, 0, true); // 민첩의 엘릭서 룬(70레벨)
				}
			}
			break;
		case 60044:
			if (pc.getInventory().checkItem(60044, 1)) { // 체크 되는 아이템과 수량

				stageSealedReward(tx, messages, 68093, 1, 0, 1, 0, true); // 마력의 고서(70)
				if (pc.isWarrior()) {
					stageSealedReward(tx, messages, 222314, 1, 0, 1, 0, true); // 민첩의 엘릭서 룬(70레벨)
				}
				if (pc.isKnight()) {
					stageSealedReward(tx, messages, 222314, 1, 0, 1, 0, true); // 민첩의 엘릭서 룬(70레벨)
				}
				if (pc.isDragonknight()) {
					stageSealedReward(tx, messages, 222314, 1, 0, 1, 0, true); // 민첩의 엘릭서 룬(70레벨)
				}
				if (pc.isCrown()) {
					stageSealedReward(tx, messages, 222314, 1, 0, 1, 0, true); // 민첩의 엘릭서 룬(70레벨)
				}
				if (pc.isWizard()) {
					stageSealedReward(tx, messages, 222314, 1, 0, 1, 0, true); // 민첩의 엘릭서 룬(70레벨)
				}
				if (pc.isBlackwizard()) {
					stageSealedReward(tx, messages, 222314, 1, 0, 1, 0, true); // 민첩의 엘릭서 룬(70레벨)
				}
				if (pc.isElf()) {
					stageSealedReward(tx, messages, 222314, 1, 0, 1, 0, true); // 민첩의 엘릭서 룬(70레벨)
				}
				if (pc.isDarkelf()) {
					stageSealedReward(tx, messages, 222314, 1, 0, 1, 0, true); // 민첩의 엘릭서 룬(70레벨)
				}
			}
			break;
		case 60045:
			if (pc.getInventory().checkItem(60045, 1)) { // 체크 되는 아이템과 수량

				stageSealedReward(tx, messages, 68093, 1, 0, 1, 0, true); // 마력의 고서(70)
				if (pc.isWarrior()) {
					stageSealedReward(tx, messages, 222315, 1, 0, 1, 0, true); // 지혜의 엘릭서 룬(70레벨)
				}
				if (pc.isKnight()) {
					stageSealedReward(tx, messages, 222315, 1, 0, 1, 0, true); // 지혜의 엘릭서 룬(70레벨)
				}
				if (pc.isDragonknight()) {
					stageSealedReward(tx, messages, 222315, 1, 0, 1, 0, true); // 지혜의 엘릭서 룬(70레벨)
				}
				if (pc.isCrown()) {
					stageSealedReward(tx, messages, 222315, 1, 0, 1, 0, true); // 지혜의 엘릭서 룬(70레벨)
				}
				if (pc.isWizard()) {
					stageSealedReward(tx, messages, 222315, 1, 0, 1, 0, true); // 지혜의 엘릭서 룬(70레벨)
				}
				if (pc.isBlackwizard()) {
					stageSealedReward(tx, messages, 222315, 1, 0, 1, 0, true); // 지혜의 엘릭서 룬(70레벨)
				}
				if (pc.isElf()) {
					stageSealedReward(tx, messages, 222315, 1, 0, 1, 0, true); // 지혜의 엘릭서 룬(70레벨)
				}
				if (pc.isDarkelf()) {
					stageSealedReward(tx, messages, 222315, 1, 0, 1, 0, true); // 지혜의 엘릭서 룬(70레벨)
				}
			}
			break;
		case 60036:
			if (pc.getInventory().checkItem(60036, 1)) { // 체크 되는 아이템과 수량

				stageSealedReward(tx, messages, 60033, 1, 0, 1, 0, true); // 빛바랜 고서
				if (pc.isWarrior()) {
					stageSealedReward(tx, messages, 222299, 1, 0, 1, 0, true); // 힘의 엘릭서 룬: 55레벨
				}
				if (pc.isKnight()) {
					stageSealedReward(tx, messages, 222299, 1, 0, 1, 0, true); // 힘의 엘릭서 룬: 55레벨
				}
				if (pc.isDragonknight()) {
					stageSealedReward(tx, messages, 222299, 1, 0, 1, 0, true); // 힘의 엘릭서 룬: 55레벨
				}
				if (pc.isCrown()) {
					stageSealedReward(tx, messages, 222299, 1, 0, 1, 0, true); // 힘의 엘릭서 룬: 55레벨
				}
				if (pc.isWizard()) {
					stageSealedReward(tx, messages, 222299, 1, 0, 1, 0, true); // 힘의 엘릭서 룬: 55레벨
				}
				if (pc.isBlackwizard()) {
					stageSealedReward(tx, messages, 222299, 1, 0, 1, 0, true); // 힘의 엘릭서 룬: 55레벨
				}
				if (pc.isElf()) {
					stageSealedReward(tx, messages, 222299, 1, 0, 1, 0, true); //힘의 엘릭서 룬: 55레벨
				}
				if (pc.isDarkelf()) {
					stageSealedReward(tx, messages, 222299, 1, 0, 1, 0, true); // 힘의 엘릭서 룬: 55레벨
				}
			}
			break;
		case 60037:
			if (pc.getInventory().checkItem(60037, 1)) { // 체크 되는 아이템과 수량

				stageSealedReward(tx, messages, 60033, 1, 0, 1, 0, true); // 빛바랜 고서
				if (pc.isWarrior()) {
					stageSealedReward(tx, messages, 222295, 1, 0, 1, 0, true); // 민첩의 엘릭서 룬: 55레벨
				}
				if (pc.isKnight()) {
					stageSealedReward(tx, messages, 222295, 1, 0, 1, 0, true); // 민첩의 엘릭서 룬: 55레벨
				}
				if (pc.isDragonknight()) {
					stageSealedReward(tx, messages, 222295, 1, 0, 1, 0, true); // 민첩의 엘릭서 룬: 55레벨
				}
				if (pc.isCrown()) {
					stageSealedReward(tx, messages, 222295, 1, 0, 1, 0, true); // 민첩의 엘릭서 룬: 55레벨
				}
				if (pc.isWizard()) {
					stageSealedReward(tx, messages, 222295, 1, 0, 1, 0, true); // 민첩의 엘릭서 룬: 55레벨
				}
				if (pc.isBlackwizard()) {
					stageSealedReward(tx, messages, 222295, 1, 0, 1, 0, true); // 민첩의 엘릭서 룬: 55레벨
				}
				if (pc.isElf()) {
					stageSealedReward(tx, messages, 222295, 1, 0, 1, 0, true); // 민첩의 엘릭서 룬: 55레벨
				}
				if (pc.isDarkelf()) {
					stageSealedReward(tx, messages, 222295, 1, 0, 1, 0, true); // 민첩의 엘릭서 룬: 55레벨
				}
			}
			break;
		case 60038:
			if (pc.getInventory().checkItem(60038, 1)) { // 체크 되는 아이템과 수량

				stageSealedReward(tx, messages, 60033, 1, 0, 1, 0, true); // 빛바랜 고서
				if (pc.isWarrior()) {
					stageSealedReward(tx, messages, 222296, 1, 0, 1, 0, true); // 체력의 엘릭서 룬: 55레벨
				}
				if (pc.isKnight()) {
					stageSealedReward(tx, messages, 222296, 1, 0, 1, 0, true); // 체력의 엘릭서 룬: 55레벨
				}
				if (pc.isDragonknight()) {
					stageSealedReward(tx, messages, 222296, 1, 0, 1, 0, true); // 체력의 엘릭서 룬: 55레벨
				}
				if (pc.isCrown()) {
					stageSealedReward(tx, messages, 222296, 1, 0, 1, 0, true); // 체력의 엘릭서 룬: 55레벨
				}
				if (pc.isWizard()) {
					stageSealedReward(tx, messages, 222296, 1, 0, 1, 0, true); // 체력의 엘릭서 룬: 55레벨
				}
				if (pc.isBlackwizard()) {
					stageSealedReward(tx, messages, 222296, 1, 0, 1, 0, true); // 체력의 엘릭서 룬: 55레벨
				}
				if (pc.isElf()) {
					stageSealedReward(tx, messages, 222296, 1, 0, 1, 0, true); // 체력의 엘릭서 룬: 55레벨
				}
				if (pc.isDarkelf()) {
					stageSealedReward(tx, messages, 222296, 1, 0, 1, 0, true); // 체력의 엘릭서 룬: 55레벨
				}
			}
			break;
		case 60039:
			if (pc.getInventory().checkItem(60039, 1)) { // 체크 되는 아이템과 수량

				stageSealedReward(tx, messages, 60033, 1, 0, 1, 0, true); // 빛바랜 고서
				if (pc.isWarrior()) {
					stageSealedReward(tx, messages, 222297, 1, 0, 1, 0, true); // 지식의 엘릭서 룬: 55레벨
				}
				if (pc.isKnight()) {
					stageSealedReward(tx, messages, 222297, 1, 0, 1, 0, true); // 지식의 엘릭서 룬: 55레벨
				}
				if (pc.isDragonknight()) {
					stageSealedReward(tx, messages, 222297, 1, 0, 1, 0, true); // 지식의 엘릭서 룬: 55레벨
				}
				if (pc.isCrown()) {
					stageSealedReward(tx, messages, 222297, 1, 0, 1, 0, true); // 지식의 엘릭서 룬: 55레벨
				}
				if (pc.isWizard()) {
					stageSealedReward(tx, messages, 222297, 1, 0, 1, 0, true); // 지식의 엘릭서 룬: 55레벨
				}
				if (pc.isBlackwizard()) {
					stageSealedReward(tx, messages, 222297, 1, 0, 1, 0, true); // 지식의 엘릭서 룬: 55레벨
				}
				if (pc.isElf()) {
					stageSealedReward(tx, messages, 222297, 1, 0, 1, 0, true); // 지식의 엘릭서 룬: 55레벨
				}
				if (pc.isDarkelf()) {
					stageSealedReward(tx, messages, 222297, 1, 0, 1, 0, true); // 지식의 엘릭서 룬: 55레벨
				}
			}
			break;
		case 60040:
			if (pc.getInventory().checkItem(60040, 1)) { // 체크 되는 아이템과 수량

				stageSealedReward(tx, messages, 60033, 1, 0, 1, 0, true); // 빛바랜 고서
				if (pc.isWarrior()) {
					stageSealedReward(tx, messages, 222298, 1, 0, 1, 0, true); // 지혜의 엘릭서 룬: 55레벨
				}
				if (pc.isKnight()) {
					stageSealedReward(tx, messages, 222298, 1, 0, 1, 0, true); // 지혜의 엘릭서 룬: 55레벨
				}
				if (pc.isDragonknight()) {
					stageSealedReward(tx, messages, 222298, 1, 0, 1, 0, true); // 지혜의 엘릭서 룬: 55레벨
				}
				if (pc.isCrown()) {
					stageSealedReward(tx, messages, 222298, 1, 0, 1, 0, true); // 지혜의 엘릭서 룬: 55레벨
				}
				if (pc.isWizard()) {
					stageSealedReward(tx, messages, 222298, 1, 0, 1, 0, true); // 지혜의 엘릭서 룬: 55레벨
				}
				if (pc.isBlackwizard()) {
					stageSealedReward(tx, messages, 222298, 1, 0, 1, 0, true); // 지혜의 엘릭서 룬: 55레벨
				}
				if (pc.isElf()) {
					stageSealedReward(tx, messages, 222298, 1, 0, 1, 0, true); // 지혜의 엘릭서 룬: 55레벨
				}
				if (pc.isDarkelf()) {
					stageSealedReward(tx, messages, 222298, 1, 0, 1, 0, true); // 지혜의 엘릭서 룬: 55레벨
				}
			}
			break;
		}
			// Unknown class/reward configuration: do not consume the input.
			if (messages.isEmpty()) return;
			tx.onFailure(() -> SC_ServerMessage.send(pc, 82));
			tx.commit(() -> {
				for (int i = 0; i < messages.size(); i++)
					SC_ServerMessage.send(pc, 403, messages.get(i));
			});
		} catch (RuntimeException failure) {
			LOG.log(Level.WARNING, "Support box receipt preparation failed: " + itemId, failure);
			SC_ServerMessage.send(pc, 82);
		}
	}

	/** Prepare a detached reward. Never publish or announce it before the receipt commits. */
	static void stageReward(L1InventoryTransaction tx, ArrayList<String> notices, int itemId,
			int count, int enchant, int bless, int attr, boolean identified) {
		stage(tx, notices, itemId, count, enchant, bless, attr, true, true);
	}
	private static void stageSealedReward(L1InventoryTransaction tx, ArrayList<String> notices, int itemId,
			int count, int enchant, int bless, int attr, boolean identified) {
		stage(tx, notices, itemId, count, enchant, bless, attr, false, false);
	}
	private static void stage(L1InventoryTransaction tx, ArrayList<String> notices, int itemId,
			int count, int enchant, int bless, int attr, boolean identified, boolean expiry) {
		L1Item template = ItemTable.getInstance().getTemplate(itemId);
		if (template == null || count <= 0) throw new IllegalStateException("Missing box reward: " + itemId);
		L1ItemInstance reward = new L1ItemInstance(template, count);
		reward.setId(IdFactory.getInstance().nextId());
		reward.setEnchantLevel(enchant);
		reward.setBless(bless);
		reward.setAttrEnchantLevel(attr);
		reward.setIdentified(identified);
		if (expiry && !reward.isStackable()) CommonUtil.SetTodayDeleteTime(reward, 4320);
		if (tx.grant(reward) == null) throw new IllegalStateException("Unable to stage reward: " + itemId);
		notices.add(reward.getLogName());
	}
}
