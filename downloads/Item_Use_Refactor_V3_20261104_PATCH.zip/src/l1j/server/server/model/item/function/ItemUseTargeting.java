package l1j.server.server.model.item.function;

import l1j.server.MJCTSystem.Loader.MJCTLoadManager;
import l1j.server.server.model.Instance.L1PcInstance;
import l1j.server.server.model.network.core.sc.packet.SC_NPCTalkReturn;
import l1j.server.server.model.network.core.sc.packet.SC_SkillSound;

/** Legacy target decoding and pre-admission selection UI; explicit-ID rules precede use-type rules. */
final class ItemUseTargeting {
    private ItemUseTargeting() {}

    static final int NONE=0, NAME=1, ITEM=2, BLANK=3, TARGET=4, BOOK=5,
            BOOKMARK=6, FISHING=7, TARGET_NAME=8, POINT=9, STORED=10, COOKING=11, DEFAULT=12;

    static int modeOf(int itemId, int useType) {
        return switch(itemId) {
            case 40088, 140088, 875640379 -> NONE;
            case 40096, 210112, 900075 -> NAME;
            case 300000, 40074, 40087, 724, 5991, 3000546, 3000547, 4100034,
                    40660, 40128, 40127, 814, 30027, 30028, 7004, 30068,
                    30069, 446666, 40077, 40078, 40126, 40098, 40129, 40130,
                    140129, 140130, 140074, 140087, 240074, 240087, 41029, 411029,
                    411040, 411044, 40317, 41036, 41245, 442455, 30087, 210073,
                    210077, 500205, 500207, 210082, 210084, 210085, 40964, 41030,
                    50020, 50021, 210064, 210065, 210066, 210067, 310064, 310065,
                    310066, 310067, 310068, 210068, 41048, 41049, 41050, 41051,
                    41052, 41053, 41054, 41055, 41056, 41057, 40925, 40926,
                    40927, 40928, 40929, 40931, 40932, 40933, 40934, 40935,
                    40936, 40937, 40938, 40939, 40940, 40941, 40942, 40943,
                    40944, 40945, 40946, 40947, 40948, 40949, 40950, 40951,
                    40952, 40953, 40954, 40955, 40956, 40957, 40958, 410017,
                    100001, 1000021, 1000022, 1000023, 1000024, 1000025, 1000026, 1000027,
                    1000028, 1000029, 1000030, 1000031, 1000032, 1000033, 1000034, 1000035,
                    1000036, 1000037, 1000038, 1000039, 1000040, 1000012, 3000160, 3000161,
                    3000162, 410066, 410067, 410068, 410083, 410089, 3000430, 410094,
                    30107, 30108, 30109, 30110, 30111, 30112, 30113, 30114,
                    30115, 30116, 30117, 68076, 68077, 98077, 3000380, 3000428,
                    4000428, 4000430, 4000546, 4000547, 810003, 4100148, 127000, 560030,
                    560031, 560032, 560033, 410140, 410141, 410142, 810012, 810013,
                    7024, 87056, 87057, 4100292, 600228, 3000065, 3000256, 3110509,
                    3000509, 4100446, 3000100, 4000517, 4000518, 3000517, 3000518, 7011,
                    7010, 9010, 9011, 5922910, 5922911, 622910, 633910, 3000255,
                    3000217, 3000218, 3000219, 3000224, 8010, 8011, 110002 -> ITEM;
            case 40090, 40091, 40092, 40093, 40094 -> BLANK;
            case 40895, 40870, 40879, 40089, 140089, 30074 -> TARGET;
            case 560025, 560027, 560028, 560029, 4100135 -> BOOK;
            case 150100, 140100, 40100, 40099, 40086, 40863 -> BOOKMARK;
            case 41293, 41294, 41305, 41306, 4100293, 4200293, 600229, 87058,
                    87059, 9991 -> FISHING;
            case 40008, 140008 -> TARGET_NAME;
            default -> {
                if(useType==30) yield TARGET;
                if(itemId==600226 || itemId==600227 || itemId==3000235
                        || itemId==MJCTLoadManager.CTSYSTEM_STORE_ID) yield STORED;
                if(useType==5 || useType==17) yield POINT;
                if(itemId>=41255 && itemId<=41259) yield COOKING;
                yield DEFAULT;
            }
        };
    }

    static boolean showSelection(L1PcInstance pc, int itemId) {
        if(itemId==40088 || itemId==140088 || itemId==875640379) {
            SC_SkillSound.send(pc,pc.getId(),21174);
            if(pc.isInvisble()) {
                pc.sendPackets("지금은 사용할 수 없는 상태입니다.");
                return false;
            }
            SC_NPCTalkReturn.send(pc,pc.getId(),"neigetele4");
        }
        return true;
    }
}
