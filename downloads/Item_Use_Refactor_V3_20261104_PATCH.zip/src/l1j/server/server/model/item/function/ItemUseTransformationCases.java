package l1j.server.server.model.item.function;

import l1j.server.Config;
import l1j.server.server.model.Instance.L1ItemInstance;
import l1j.server.server.model.Instance.L1PcInstance;
import l1j.server.server.model.network.core.sc.packet.SC_ServerMessage;
import l1j.server.server.model.network.core.sc.packet.SC_ShowPolyList;
import l1j.server.server.model.network.core.sc.packet.SC_SystemMessage;
import static l1j.server.server.model.item.function.ItemUseDurable.UseDurableConsume;
import static l1j.server.server.model.item.function.ItemUseTransformation.useLevelPolyScroll;
import static l1j.server.server.model.item.function.ItemUseTransformation.usePolyPotion;
import static l1j.server.server.model.item.function.ItemUseTransformation.usePolyScroll;

/** Item-specific Transformation effects; selected once by ItemUseDispatcher. */
final class ItemUseTransformationCases {
    private ItemUseTransformationCases() {}

    static ItemUseResult handleShowPixieForms(ItemUseContext use) {
        L1PcInstance pc = use.player();
        int itemId = use.itemId();
        SC_ShowPolyList.send(pc, pc.getId(), "pixies");
        if (!pc.isMagicItem()) {
            pc.setMagicItem(true);
            pc.setMagicItemId(itemId);
        }
        return ItemUseResult.COMPLETE;
    }

    static ItemUseResult handleShowTamForms(ItemUseContext use) {
        L1PcInstance pc = use.player();
        int itemId = use.itemId();
        SC_ShowPolyList.send(pc, pc.getId(), "tam60");
        if (!pc.isMagicItem()) {
            pc.setMagicItem(true);
            pc.setMagicItemId(itemId);
        }
        return ItemUseResult.COMPLETE;
    }

    static ItemUseResult handlePolyScroll(ItemUseContext use) {
        L1PcInstance pc = use.player();
        L1ItemInstance item = use.item();
        int itemId = use.itemId();
        String text = use.text();
        if (usePolyScroll(pc, itemId, text)) {
            pc.getInventory().removeItem(item, 1);
        } else {
            SC_ServerMessage.send(pc, 181);
        }
        return ItemUseResult.COMPLETE;
    }

    static ItemUseResult handleEventPolyScroll(ItemUseContext use) {
        L1PcInstance pc = use.player();
        L1ItemInstance item = use.item();
        if (!Config.POLY_EVENT) {
            SC_SystemMessage.send(pc, "변신이벤트중일때만 사용가능합니다.");
            return ItemUseResult.STOP;
        }
        UseDurableConsume(pc, item, () -> SC_ShowPolyList.send(pc, pc.getId()));
        return ItemUseResult.COMPLETE;
    }

    static ItemUseResult handleBlessedPolyScroll(ItemUseContext use) {
        L1PcInstance pc = use.player();
        L1ItemInstance item = use.item();
        int itemId = use.itemId();
        String text = use.text();
        if (usePolyScroll(pc, itemId, text)) {
            pc.getInventory().removeItem(item, 1);
        } else {
            SC_ServerMessage.send(pc, 181);

        }
        return ItemUseResult.COMPLETE;
    }

    static ItemUseResult handleTrainingPolyScroll(ItemUseContext use) {
        L1PcInstance pc = use.player();
        L1ItemInstance item = use.item();
        int itemId = use.itemId();
        if (!(pc.getMapId() == 7783 || pc.getMapId() == 12152 || pc.getMapId() == 12149
                || pc.getMapId() == 3 || pc.getMapId() == 12154 || pc.getMapId() == 12358
                || pc.getMapId() == 12153 || pc.getMapId() == 12146 || pc.getMapId() == 12147
                || pc.getMapId() == 12148 || pc.getMapId() == 12258 || pc.getMapId() == 12150
                || pc.getMapId() == 12257 || pc.getMapId() == 12358)) {
            SC_SystemMessage.send(pc, "클라우디아 맵에서만 사용이 가능합니다.");
            return ItemUseResult.STOP;
        }
        usePolyPotion(pc, itemId);
        pc.getInventory().removeItem(item, 1);
        return ItemUseResult.COMPLETE;
    }

    static ItemUseResult handlePolyPotion(ItemUseContext use) {
        L1PcInstance pc = use.player();
        L1ItemInstance item = use.item();
        int itemId = use.itemId();
        usePolyPotion(pc, itemId);
        pc.getInventory().removeItem(item, 1);
        return ItemUseResult.COMPLETE;
    }

    static ItemUseResult handleLevelPolyScroll(ItemUseContext use) {
        L1PcInstance pc = use.player();
        L1ItemInstance item = use.item();
        int itemId = use.itemId();
        useLevelPolyScroll(pc, itemId);
        pc.getInventory().removeItem(item, 1);
        return ItemUseResult.COMPLETE;
    }
}
