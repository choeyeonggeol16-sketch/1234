package l1j.server.server.model.item.function;

import java.util.logging.Level;

import l1j.server.server.model.Instance.L1ItemInstance;
import l1j.server.server.model.Instance.L1PcInstance;
import l1j.server.server.model.L1InventoryTransaction;
import l1j.server.server.model.network.core.cs.packet.CDB;
import l1j.server.server.model.network.core.cs.packet.User;
import l1j.server.server.model.network.core.sc.packet.SC_SystemMessage;
import l1j.server.server.storage.CacheD;

/** Shared admission, debit and failure handling; effects remain in their
 * original handlers. A prepared debit never changes the live input item.
 */
public final class ItemUseTransactions {
    private ItemUseTransactions() {}

    public static void consume(L1PcInstance pc, L1ItemInstance input, Runnable effect) {
        if (!owned(pc, input)) return;
        consumeInputs(pc, input, null, effect);
    }

    public static void consumeTwo(L1PcInstance pc, L1ItemInstance first,
                                  L1ItemInstance second, Runnable effect) {
        if (first == second || !owned(pc, first) || !owned(pc, second)) return;
        consumeInputs(pc, first, second, effect);
    }

    private static boolean owned(L1PcInstance pc, L1ItemInstance input) {
        return pc != null && input != null && pc.getInventory().getItem(input.getId()) == input;
    }

    private static void consumeInputs(L1PcInstance pc, L1ItemInstance first,
                                      L1ItemInstance second, Runnable effect) {
        try (L1InventoryTransaction tx = User.CheckAndSetPendingUseETCItem(pc,
                CacheD.accountOrderKey("item-use:", pc.getId()))) {
            if (!tx.debit(first, 1) || (second != null && !tx.debit(second, 1))) return;
            tx.onFailure(() -> SC_SystemMessage.send(pc, "재료 소모 저장에 실패했습니다."));
            CDB.RequestUseItem(pc, tx, effect);
        } catch (RuntimeException failure) {
            ItemUseCreature.ITEM_USE2_LOG.log(Level.WARNING,
                    "Item consume prepare failed: " + pc.getId(), failure);
            SC_SystemMessage.send(pc, "아이템 사용을 처리하지 못했습니다.");
        }
    }
}
