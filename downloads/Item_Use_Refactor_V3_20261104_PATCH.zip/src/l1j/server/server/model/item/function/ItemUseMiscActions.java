package l1j.server.server.model.item.function;


import l1j.server.server.model.network.core.sc.packet.SC_AddSkill;
import l1j.server.server.model.network.core.sc.packet.SC_Paralysis;
import l1j.server.server.model.network.core.sc.packet.SC_Serchdrop2;

import l1j.server.server.model.network.core.sc.packet.SC_EffectLocation;
import l1j.server.server.model.network.core.sc.packet.SC_SkillSound;
import static l1j.server.server.model.character.skill.L1SkillId.ABSOLUTE_BARRIER;
import static l1j.server.server.model.character.skill.L1SkillId.COUNTER_MAGIC;
import static l1j.server.server.model.character.skill.L1SkillId.CURSE_BLIND;
import static l1j.server.server.model.character.skill.L1SkillId.DANCING_BLADES;
import static l1j.server.server.model.character.skill.L1SkillId.DARKNESS;
import static l1j.server.server.model.character.skill.L1SkillId.DECAY_POTION;
import static l1j.server.server.model.character.skill.L1SkillId.DRAGON_PUPLE;
import static l1j.server.server.model.character.skill.L1SkillId.DRAGON_TOPAZ;
import static l1j.server.server.model.character.skill.L1SkillId.EARTH_BIND;
import static l1j.server.server.model.character.skill.L1SkillId.EXP_POTION;
import static l1j.server.server.model.character.skill.L1SkillId.FOCUS_WAVE;
import static l1j.server.server.model.character.skill.L1SkillId.GREATER_HASTE;
import static l1j.server.server.model.character.skill.L1SkillId.HASTE;
import static l1j.server.server.model.character.skill.L1SkillId.HOLY_WALK;
import static l1j.server.server.model.character.skill.L1SkillId.HURRICANE;
import static l1j.server.server.model.character.skill.L1SkillId.ICE_LANCE;
import static l1j.server.server.model.character.skill.L1SkillId.LINDBIOR_SPIRIT_EFFECT;
import static l1j.server.server.model.character.skill.L1SkillId.MOVING_ACCELERATION;
import static l1j.server.server.model.character.skill.L1SkillId.SAND_STORM;
import static l1j.server.server.model.character.skill.L1SkillId.SHAPE_CHANGE;
import static l1j.server.server.model.character.skill.L1SkillId.SHOCK_STUN;
import static l1j.server.server.model.character.skill.L1SkillId.SLOW;
import static l1j.server.server.model.character.skill.L1SkillId.STATUS_BLUE_POTION;
import static l1j.server.server.model.character.skill.L1SkillId.STATUS_BLUE_POTION2;
import static l1j.server.server.model.character.skill.L1SkillId.STATUS_BRAVE;
import static l1j.server.server.model.character.skill.L1SkillId.STATUS_CASHSCROLL;
import static l1j.server.server.model.character.skill.L1SkillId.STATUS_CASHSCROLL2;
import static l1j.server.server.model.character.skill.L1SkillId.STATUS_CASHSCROLL3;
import static l1j.server.server.model.character.skill.L1SkillId.STATUS_CASHSCROLL4;
import static l1j.server.server.model.character.skill.L1SkillId.STATUS_CASHSCROLL5;
import static l1j.server.server.model.character.skill.L1SkillId.STATUS_CASHSCROLL6;
import static l1j.server.server.model.character.skill.L1SkillId.STATUS_ELFBRAVE;
import static l1j.server.server.model.character.skill.L1SkillId.STATUS_FLOATING_EYE;
import static l1j.server.server.model.character.skill.L1SkillId.STATUS_FREEZE;
import static l1j.server.server.model.character.skill.L1SkillId.STATUS_FRUIT;
import static l1j.server.server.model.character.skill.L1SkillId.STATUS_HASTE;
import static l1j.server.server.model.character.skill.L1SkillId.STATUS_HOLY_MITHRIL_POWDER;
import static l1j.server.server.model.character.skill.L1SkillId.STATUS_HOLY_WATER;
import static l1j.server.server.model.character.skill.L1SkillId.STATUS_HOLY_WATER_OF_EVA;
import static l1j.server.server.model.character.skill.L1SkillId.STATUS_UNDERWATER_BREATH;
import static l1j.server.server.model.character.skill.L1SkillId.STATUS_WISDOM_POTION;

import java.lang.reflect.Constructor;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.Random;
import java.util.logging.Logger;
import l1j.server.Config;
import l1j.server.server.storage.CacheD;
import l1j.server.DogFight.Instance.MJDogFightInstance;
import l1j.server.server.ActionCodes;
import l1j.server.server.IdFactory;
import l1j.server.server.datatables.NpcTable;
import l1j.server.server.datatables.SkillsTable;
import l1j.server.server.model.L1Character;
import l1j.server.server.model.L1EffectSpawn;
import l1j.server.server.model.L1Object;
import l1j.server.server.model.L1PcInventory;
import l1j.server.server.model.L1PinkName;
import l1j.server.server.model.L1World;
import l1j.server.server.model.Instance.L1DoorInstance;
import l1j.server.server.model.Instance.L1ItemInstance;
import l1j.server.server.model.Instance.L1MonsterInstance;
import l1j.server.server.model.Instance.L1NpcInstance;
import l1j.server.server.model.Instance.L1PcInstance;
import l1j.server.server.model.Instance.L1PetInstance;
import l1j.server.server.model.Instance.L1SummonInstance;
import l1j.server.server.model.character.skill.L1SkillId;
import l1j.server.server.model.character.skill.L1SkillUse;

import l1j.server.server.model.network.core.sc.packet.SC_ActionUI;
import l1j.server.server.model.network.core.sc.packet.SC_AttackPacket;
import l1j.server.server.model.network.core.sc.packet.SC_AttackStatus;
import l1j.server.server.model.network.core.sc.packet.SC_ChatPacket;
import l1j.server.server.model.network.core.sc.packet.SC_DoActionGFX;

import l1j.server.server.model.network.core.sc.packet.SC_InventoryIcon;

import l1j.server.server.model.network.core.sc.packet.SC_PacketBox;
import l1j.server.server.model.network.core.sc.packet.SC_ServerMessage;
import l1j.server.server.model.network.core.sc.packet.SC_SystemMessage;
import l1j.server.server.templates.L1Npc;
import l1j.server.server.templates.L1Skills;
import l1j.server.server.utils.MJCommons;

import l1j.server.server.model.network.core.sc.packet.SC_SkillIconGFX;

import l1j.server.server.model.network.core.cs.packet.User;
import l1j.server.server.model.network.core.cs.packet.CDB;


import static l1j.server.server.model.item.function.ItemUseEnchantments.*;
import static l1j.server.server.model.item.function.ItemUsePotions.*;
import static l1j.server.server.model.item.function.ItemUseTransformation.*;
import static l1j.server.server.model.item.function.ItemUseSpellBooks.*;
import static l1j.server.server.model.item.function.ItemUseWorldHelpers.*;
import static l1j.server.server.model.item.function.ItemUseSpecialEnchant.*;
import static l1j.server.server.model.item.function.ItemUseMiscActions.*;
import static l1j.server.server.model.item.function.ItemUseEquipment.*;
import static l1j.server.server.model.item.function.ItemUseDurable.*;
import static l1j.server.server.model.item.function.ItemUseCombatAbilities.*;
import static l1j.server.server.model.item.function.ItemUseDollEffects.*;

import static l1j.server.server.model.item.function.ItemUseCreature.*;

public final class ItemUseMiscActions {
    private static final Logger ITEM_USE2_LOG = ItemUseCreature.ITEM_USE2_LOG;
    private ItemUseMiscActions() {}
	public static void useFieldObjectRemovalWand1(L1PcInstance pc, int targetId, L1ItemInstance item) {
		SC_AttackPacket.send(pc.getNetConnection(), pc, 0, ActionCodes.ACTION_Wand);
		SC_AttackPacket.broadcast(pc, 0, ActionCodes.ACTION_Wand);
		L1Object target = L1World.getInstance().findObject(targetId);
		if (target != null && target instanceof L1NpcInstance) {
			L1NpcInstance npc = (L1NpcInstance) target;
			SC_SystemMessage.send(pc, "\\f;NPC이름: \\aA"+npc.getName());
			SC_SystemMessage.send(pc, "\\f;NPC번호: \\aA"+npc.getNpcId()+"  \\f;이미지번호(GfxId) : \\aA"+npc.getCurrentSpriteId());
			SC_SystemMessage.send(pc, "\\f;해당위치: \\aAX - " + npc.getX() + " \\f;/ \\aAY - " + npc.getY() + " \\f;/ \\aAMap - " + npc.getMapId());
			
			
//			(new SC_ChatPacket(pc,"번호 : (" + npc.getNpcId() + "-" + targetId + ") // " + "이름 : (" + npc.getName() + ")")).send(pc);
//			(new SC_ChatPacket(pc, "위치 : " + "(x:" + npc.getX() + "), (y:" + npc.getY() + "), (" + "Map:"+ npc.getMapId() + ") // GfxId : (" + npc.getCurrentSpriteId() + ")")).send(pc);
//			
//			
//			(new SC_ChatPacket(pc,"번호 : (" + npc.getNpcId() + "-" + targetId + ") // " + "이름 : (" + npc.getName() + ")")).send(pc);
//			(new SC_ChatPacket(pc, "위치 : " + "(x:" + npc.getX() + "), (y:" + npc.getY() + "), (" + "Map:"+ npc.getMapId() + ") // GfxId : (" + npc.getCurrentSpriteId() + ")")).send(pc);
			pc.getInventory().updateItem(item, L1PcInventory.COL_CHARGE_COUNT);
		}
	}
	public static void 매직실드(L1PcInstance pc) {
		
		
		if (pc.getType() == 2 && pc.getLevel() >= 85) {
		if (pc.hasSkillEffect(L1SkillId.매직실드대기)) {
			
			int n = pc.getSkillEffectTimeSec(L1SkillId.매직실드대기);
			SC_SystemMessage.send(pc, String.format("\\fY매직실드대기 대기시간 : %d초 후에 사용가능합니다.", n));
			return;
		}

		if (MJCommons.isNonAction(pc)) {
			return;
		}

		
		if (pc.isInvisble()) {
			SC_SystemMessage.send(pc, "매직실드는 투명상태로 시전이 불가능합니다.");
			return;
		}

		if (!pc.getInventory().checkItem(40319, 5)) {
			SC_SystemMessage.send(pc, "마법재료가 부족합니다.");
			return;
		}
		if (pc.getCurrentMp() < 20) {
			SC_ServerMessage.send(pc, 278); // \f1MP가 부족해 마법을 사용할
			return;
		}
		
		if (pc.hasSkillEffect(L1SkillId.매직실드1)) {
			pc.removeSkillEffect(L1SkillId.매직실드1);
		}
		if (pc.hasSkillEffect(L1SkillId.매직실드2)) {
			pc.removeSkillEffect(L1SkillId.매직실드2);
		}
		
		pc.setSkillEffect(L1SkillId.매직실드대기, Config.매직실드대기 * 1000);
		pc.setSkillEffect(L1SkillId.매직실드1, Config.매직실드지속 * 1000);
		pc.setSkillEffect(L1SkillId.매직실드2, Config.매직실드지속 * 1000);
		SC_InventoryIcon.icoNew(pc, L1SkillId.매직실드2, 3156, Config.매직실드지속, true);
		pc.setCurrentMp(pc.getCurrentMp() - 20);
		pc.getInventory().consumeItem(40319, 5);
		SC_SkillSound.send(pc, pc.getId(), 14102);
		SC_SkillSound.broadcast(pc, pc.getId(), 14102);
		
		L1SkillUse.cast(pc, L1SkillId.보조버프, pc.getId(), pc.getX(),
				pc.getY(), null, 0, L1SkillUse.TYPE_SPELLSC);

	} else {
		SC_SystemMessage.send(pc, "사용할 수 없는 클래스이거나 적정레벨이 아닙니다.");
	}
	}
	public static void 투견조작(L1PcInstance pc, int targetId, L1ItemInstance item) {
		SC_AttackPacket.send(pc.getNetConnection(), pc, 0, ActionCodes.ACTION_Wand);
		SC_AttackPacket.broadcast(pc, 0, ActionCodes.ACTION_Wand);
		L1Object target = L1World.getInstance().findObject(targetId);
		
		if (target != null && target instanceof MJDogFightInstance) {
			
			((MJDogFightInstance)target).set_min_damage(((MJDogFightInstance)target).get_min_damage() + Config.투견최소랜덤데미지);
			((MJDogFightInstance)target).set_max_damage(((MJDogFightInstance)target).get_max_damage() + Config.투견최대랜덤데미지);
			((MJDogFightInstance)target).set_attackdelay_reduce(((MJDogFightInstance)target).get_attackdelay_reduce() + Config.투견공속);
			SC_ChatPacket.sendDirect(pc, pc, "해당 투견의 [공격력: 최소범위 +"+Config.투견최소랜덤데미지+" / 최대범위 +"+Config.투견최대랜덤데미지+"] [공속: "+Config.투견공속+"] 증가하였습니다");
			
			pc.getInventory().updateItem(item, L1PcInventory.COL_CHARGE_COUNT);
		} else {
			SC_ChatPacket.sendDirect(pc, pc, "투견에만 사용가능합니다.");
		}
	}

	public static void serchdroplist2(L1PcInstance pc, int targetId, L1ItemInstance item) {
		long curtime = System.currentTimeMillis() / 1000;

		SC_AttackPacket.send(pc.getNetConnection(), pc, 0, ActionCodes.ACTION_Wand);
		SC_AttackPacket.broadcast(pc, 0, ActionCodes.ACTION_Wand);
		L1Object target = L1World.getInstance().findObject(targetId);
		if (target != null && target instanceof L1MonsterInstance) {
			L1MonsterInstance npc = (L1MonsterInstance) target;

			int transformId = npc.getNpcTemplate().getTransformId();
			if (transformId == -1) {
				SC_Serchdrop2.send(pc, npc.getNpcId());
				pc.setQuizTime(curtime);
			} else {
				SC_Serchdrop2.send(pc, transformId);
				pc.setQuizTime(curtime);
			}
		}
	}
	
	public static void 비전텔레포트(L1PcInstance pc, int spellsc_x, int spellsc_y ) {
	int tx = spellsc_x;
	int ty = spellsc_y;
	if (!pc.glanceCheck(tx, ty) ) {
		
		SC_PacketBox.send(pc, SC_PacketBox.GREEN_MESSAGE, "\\fY장애물로 인해 이동할 수 없습니다.");
		SC_SystemMessage.send(pc, "\\fY장애물로 인해 이동할 수 없습니다.");
	return;	
	}
	int diffLocX = Math.abs(pc.getX() - spellsc_x);
	int diffLocY = Math.abs(pc.getY() - spellsc_y);
	
	if (pc.isstop() || pc.hasSkillEffect(L1SkillId.SHOCK_STUN) || pc.hasSkillEffect(L1SkillId.DESPERADO) || pc.hasSkillEffect(L1SkillId.쉐도우제약)|| pc.hasSkillEffect(L1SkillId.이터디스) || pc.hasSkillEffect(L1SkillId.버닝샷) ) {
		SC_SystemMessage.send(pc, "\\fY사용할 수 없는 상태입니다.");
		return;
	}
	if (pc.isSkillDelay()) {
		SC_SystemMessage.send(pc, "\\f3스킬 딜레이중이므로 사용할 수 없습니다");
		return;
	}
	if (diffLocX > 7 || diffLocY > 7) {
		
		SC_PacketBox.send(pc, SC_PacketBox.GREEN_MESSAGE, "\\fY거리가 멀어서 사용할 수 없습니다.");
		SC_SystemMessage.send(pc, "\\fY거리가 멀어서 사용할 수 없습니다.");
		return;
	}
	if (pc.hasSkillEffect(L1SkillId.비전텔레포트)) {
		int n = pc.getSkillEffectTimeSec(L1SkillId.비전텔레포트);
		SC_SystemMessage.send(pc, String.format("\\fY비전 텔레포트 대기시간 : %d초 후에 사용가능합니다.", n));
		return;
	}
	if (pc.getCurrentMp() < Config.비전엠피) {
		SC_ServerMessage.send(pc, 278); // \f1MP가 부족해 마법을 사용할
		return;
	}
	if (pc.getZoneType() == 1) {
		SC_SystemMessage.send(pc, "\\fY세이프티존에서는 사용할 수 없습니다");
		return;
	}
	
	if (pc.getType() == 3 || pc.isGm()) {
	pc.setSkillEffect(L1SkillId.비전텔레포트, Config.비전대기시간 * 1000);
	pc.setCurrentMp(pc.getCurrentMp() - Config.비전엠피);
	pc.start_teleport(spellsc_x, spellsc_y, pc.getMapId(), pc.getHeading(), 169, false, pc.getAutoHunt());
	SC_EffectLocation.send(pc, pc.getX(), pc.getY(), 2235);
	SC_EffectLocation.broadcast(pc, pc.getX(), pc.getY(), 2235);
	} else {
		SC_SystemMessage.send(pc, "\\fY해당 스킬을 사용할 수 없는 클래스입니다.");
	}
	
}
	public static void useNpcSpownWand(L1PcInstance pc, int targetId, L1ItemInstance item) {
		SC_AttackStatus.sendAndBroadcast(pc, 0, ActionCodes.ACTION_Wand, false);
		int chargeCount = item.getChargeCount();
		if (chargeCount <= 0) {
			return;
		}

		try {
			L1Npc l1npc = NpcTable.getInstance().getTemplate(targetId);
			String s = l1npc.getImpl();
			Constructor<?> constructor = Class.forName("l1j.server.server.model.Instance." + s + "Instance")
					.getConstructors()[0];
			Object aobj[] = { l1npc };
			L1NpcInstance npc = (L1NpcInstance) constructor.newInstance(aobj);
			npc.setId(IdFactory.getInstance().nextId());
			npc.setMap(pc.getMapId());
			npc.setX(pc.getX());
			npc.setY(pc.getY());
			npc.setHomeX(pc.getX());
			npc.setHomeY(pc.getY());
			npc.setMap(pc.getMapId());
			npc.setHeading(2);
			L1World.getInstance().storeAndEnterWorld(npc);
			
			npc.startTimedDelete(60000);  
		} catch (Exception e) {
			e.printStackTrace();
		}
		item.setChargeCount(item.getChargeCount() - 1);
		if (item.getChargeCount() == 0) {
			pc.getInventory().removeItem(item);
		} else {
			pc.getInventory().updateItem(item, L1PcInventory.COL_CHARGE_COUNT);
		}
	}

    public static void 군주광역스턴(L1PcInstance pc) {
        if (pc.isCrown() || pc.isGm()) {
            if (pc.hasSkillEffect(L1SkillId.DELAY)) { // 딜레이
                SC_SystemMessage.send(pc, "아직 광역 스턴을 사용할 수 없습니다.");
                return;
            }
            if (pc.isInvisble()) {
                SC_SystemMessage.send(pc, "광역 스턴은 투명상태로 시전이 불가능합니다.");
                return;
            }
            if (pc.getMapId() == 800) {
                SC_SystemMessage.send(pc, "광역 스턴은 시장에서 시전이 불가능합니다.");
                return;
            }
            if (pc.getZoneType() == 1) {
                SC_SystemMessage.send(pc, "광역 스턴은 마을에서 시전이 불가능합니다.");
                return;
            }
            if (pc.getCurrentMp() < 30) {
                SC_ServerMessage.send(pc, 278); // \f1MP가 부족해 마법을 사용할
                // 수 있지 않습니다.
                return;
            }
            pc.setCurrentMp(pc.getCurrentMp() - 30);
            SC_SystemMessage.send(pc, "광역 스턴을 시전 합니다.");
            pc.setSkillEffect(L1SkillId.DELAY, 10 * 1000);
            SC_SkillIconGFX.send(pc, 74, 3);

            int actionId = ActionCodes.ACTION_SkillBuff;
            SC_DoActionGFX.send(
                    pc.getNetConnection(),
                    pc.getId(),
                    actionId);
            SC_DoActionGFX.broadcast(
                    pc,
                    actionId);

            for (L1Object obj : L1World.getInstance().getClusterGrid().queryNearby(pc, 10)) {
                Random random = new Random();
                int[] stunTimeArray = { 2000, 2500, 3000, 3500, 4000 };
                int rnd = random.nextInt(stunTimeArray.length);
                int probability = random.nextInt(100) + 1;

                if (probability < 50) {
                    int _shockStunDuration = stunTimeArray[rnd];
                    if (obj instanceof L1PcInstance) {
                        L1PcInstance target = (L1PcInstance) obj;
                        L1PinkName.onAction(target, pc);
                        if ((pc.getClanid() > 0 && (pc.getClanid() == target.getClanid())) || target.isGm()) {
                        } else {
                            L1Character cha = (L1Character) obj;

                            if (!cha.hasSkillEffect(SHOCK_STUN) && !cha.hasSkillEffect(L1SkillId.EMPIRE) && !cha.hasSkillEffect(EARTH_BIND) && !cha.hasSkillEffect(ICE_LANCE)) {
                                L1EffectSpawn.getInstance().spawnEffect(81162, _shockStunDuration, target.getX(), target.getY(), target.getMapId());
                                SC_Paralysis.send(target, SC_Paralysis.TYPE_STUN, true);
                                target.setSkillEffect(SHOCK_STUN, _shockStunDuration);
                                SC_SkillSound.send(target, target.getId(), 15101); // 스턴
                                SC_SkillSound.broadcast(target, target.getId(), 15101);
                            }
                        }
                    } else if (obj instanceof L1MonsterInstance || obj instanceof L1SummonInstance || obj instanceof L1PetInstance) {
                        L1NpcInstance targetnpc = (L1NpcInstance) obj;
                        if (!targetnpc.trySetSkillEffect(SHOCK_STUN, _shockStunDuration)) {
                            throw new java.util.concurrent.RejectedExecutionException("NPC SHOCK_STUN admission exhausted");
                        }
                        L1EffectSpawn.getInstance().spawnEffect(81162, _shockStunDuration, targetnpc.getX(),
                                targetnpc.getY(), targetnpc.getMapId());
                        targetnpc.setParalyzed(true);
                        SC_SkillSound.broadcast(targetnpc, obj.getId(), 15101);
                    }
                }
            }
        } else {
            SC_SystemMessage.send(pc, "해당 기술은 군주만 시전이 가능합니다.");
        }
        System.currentTimeMillis();
        return;
    }
	
	public static void spawn(int x, int y, short MapId, int Heading, int npcId, int randomRange,
			int roomnumber) {
		try {// 타입이란부분에 월래2였는데 얼음여왕은 1을 죠 타입을따라가보면
			L1NpcInstance npc = NpcTable.getInstance().newNpcInstance(npcId);
			npc.setId(IdFactory.getInstance().nextId());
			npc.setMap(MapId);
			if (randomRange == 0) {
				npc.getLocation().set(x, y, MapId);
				npc.getLocation().forward(Heading);
			} else {
				int tryCount = 0;
				do {
					tryCount++;
					npc.setX(x + (int) (Math.random() * randomRange) - (int) (Math.random() * randomRange));
					npc.setY(y + (int) (Math.random() * randomRange) - (int) (Math.random() * randomRange));
					if (npc.getMap().isInMap(npc.getLocation()) && npc.getMap().isPassable(npc.getLocation())) {
						break;
					}
					Thread.sleep(1);
				} while (tryCount < 50);
				if (tryCount >= 50) {
					npc.getLocation().forward(Heading);
				}
			}
			if (npc instanceof L1DoorInstance) {
				if (npc.getNpcId() == 5147) {
					((L1DoorInstance) npc).setLeftEdgeLocation(32816);
					((L1DoorInstance) npc).setRightEdgeLocation(32821);
					((L1DoorInstance) npc).setDirection(1);
				} else if (npc.getNpcId() == 5148) {
					((L1DoorInstance) npc).setLeftEdgeLocation(32804);
					((L1DoorInstance) npc).setRightEdgeLocation(32809);
					((L1DoorInstance) npc).setDirection(1);
				} else if (npc.getNpcId() == 5149) {
					((L1DoorInstance) npc).setLeftEdgeLocation(32853);
					((L1DoorInstance) npc).setRightEdgeLocation(32858);
					((L1DoorInstance) npc).setDirection(1);
				} else if (npc.getNpcId() == 5150) {
					((L1DoorInstance) npc).setLeftEdgeLocation(32760);
					((L1DoorInstance) npc).setRightEdgeLocation(32764);
					((L1DoorInstance) npc).setDirection(0);
				} else if (npc.getNpcId() == 5151) {
					((L1DoorInstance) npc).setLeftEdgeLocation(32918);
					((L1DoorInstance) npc).setRightEdgeLocation(32923);
					((L1DoorInstance) npc).setDirection(1);
				}
			}
			npc.setHomeX(npc.getX());
			npc.setHomeY(npc.getY());
			npc.setHeading(Heading);

			L1World.getInstance().storeAndEnterWorld(npc);


			npc.getLight().turnOnOffLight();
			npc.startChat(L1NpcInstance.CHAT_TIMING_APPEARANCE); // 채팅 개시

		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	public static void 전사스킬(L1PcInstance pc, L1ItemInstance item, boolean ispassibe) {
		L1Skills skill = SkillsTable.getInstance().getTemplateByItem(item.getItemId());
		if (skill != null) {
			int skillLevel = skill.getSkillLevel();
			int id = skill.getId();
			int[] arr = new int[29];
			arr[skillLevel - 1] = id;
			int skillId = skill.getSkillId();
			int objid = pc.getId();
			//pc.sendPackets("arr:"+arr);
			SC_AddSkill.send(pc, arr);
			
			long s_skillSound = SC_SkillSound.pack(objid, 224);
			SC_SkillSound.sendPacked(pc, s_skillSound);
			SC_SkillSound.broadcastPacked(pc, s_skillSound);
			SkillsTable.getInstance().spellMastery(objid, skillId, skill.getName(), 0, 0);
		}
		pc.getInventory().removeItem(item, 1);
	}

	public static void 피씨방코인(L1PcInstance pc, int itemId, L1ItemInstance useItem, int day) {
        if (pc == null || useItem == null || useItem.getItemId() != itemId || day <= 0
                || pc.PC방_버프 || pc.getInventory().getItem(useItem.getId()) != useItem) return;
        final long now = System.currentTimeMillis();
        final Timestamp expiration = new Timestamp(now + 86400000L * day + 10000L);
        final String accountName = pc.getAccount().getName();
        try (l1j.server.server.model.L1InventoryTransaction tx =
                User.CheckAndSetPendingUseETCItem(pc,
                        CacheD.accountOrderKey("pcroom:", pc.getId()))) {
            if (!tx.debit(useItem, 1)) return;
            tx.requireTables("accounts");
            tx.sql(con -> {
                try (PreparedStatement ps = con.prepareStatement(
                        "UPDATE accounts SET BUFF_PCROOM_Time=? WHERE login=? "
                        + "AND (BUFF_PCROOM_Time IS NULL OR BUFF_PCROOM_Time<=?)")) {
                    ps.setTimestamp(1, expiration);
                    ps.setString(2, accountName);
                    ps.setTimestamp(3, new Timestamp(now));
                    if (ps.executeUpdate() != 1)
                        throw new SQLException("PC-room access active or account not found");
                }
            });
            tx.onFailure(() -> SC_SystemMessage.send(pc,
                    "PC방 이용권 저장에 실패했습니다. 아이템을 확인해 주세요."));
            CDB.RequestUseItem(pc, tx, () -> {
                pc.getAccount().setBuff_PC방(expiration);
                pc.setPC방_버프(true);
                SC_PacketBox.send(pc, SC_PacketBox.UNLIMITED_ICON1, 293, true);
                SC_ActionUI.send(pc, SC_ActionUI.PCBANG_SET, true);
                SC_PacketBox.send(pc, SC_PacketBox.GREEN_MESSAGE,
                        "PC방 이용 시간: " + day + "일 동안 PC방 혜택이 적용 됩니다.");
            });
        } catch (RuntimeException failure) {
            ITEM_USE2_LOG.log(java.util.logging.Level.WARNING,
                    "PC-room ticket prepare failed: " + pc.getId(), failure);
            SC_SystemMessage.send(pc, "PC방 이용권 처리를 시작하지 못했습니다.");
        }
    }

	public static void 강화버프(L1PcInstance pc, int itemId, L1ItemInstance useItem) {
		if (itemId >= 600198 && itemId <= 600217) {
			int buffId = itemId - 596123;
            // Account DB expiry may exceed the skill timer's int-millisecond range.
            final long durationMillis = 86400000L * Math.max(1, Config.TIME_N_BUFF);
            final int activeSeconds = (int) (Math.min(durationMillis,
                    (long) Integer.MAX_VALUE) / 1000L);

			if (pc.hasSkillEffect(buffId)) {
				SC_SystemMessage.send(pc, "이미 적용중인 강화 버프입니다.");
				return;
			}

            int activeBuffs = 0;
            for (int skillId = 4075; skillId <= 4094; skillId++) {
                if (pc.hasSkillEffect(skillId)) activeBuffs++;
            }

            if (activeBuffs >= Config.LIMIT_N_BUFF) {
				SC_SystemMessage.send(pc, "강화 버프는 최대 " + Config.LIMIT_N_BUFF + "종류까지 받을 수 있습니다.");
				return;
			}
			
			if (itemId >= 600209 && itemId <= 600212) {
				for (int skillId = 4086; skillId <= 4089; skillId++) {
					if (pc.hasSkillEffect(skillId)) {
						SC_SystemMessage.send(pc, "완력,민첩,지식,지혜는 한가지만 사용가능합니다.");
						return;
					}
				}
			}
            final int characterId=pc.getId(),accountId=pc.getAccount().getAccountId(),saveBuffId=buffId;
            final String characterName=pc.getName();
            final Timestamp expiration=new Timestamp(System.currentTimeMillis()+durationMillis);
            try(l1j.server.server.model.L1InventoryTransaction tx=
                    User.CheckAndSetPendingUseETCItem(pc,CacheD.accountOrderKey("nshop:", characterId))) {
                if(!tx.debit(useItem,1))return;
                tx.requireTables("character_tams");
                tx.sql(con->{
                    try(PreparedStatement ps=con.prepareStatement(
                            "INSERT INTO character_tams SET account_id=?,char_id=?,char_name=?,skill_id=?,expiration_time=?,reserve=? "
                            +"ON DUPLICATE KEY UPDATE account_id=?,char_name=?,expiration_time=?")) {
                        ps.setInt(1,accountId);ps.setInt(2,characterId);ps.setString(3,characterName);
                        ps.setInt(4,saveBuffId);ps.setTimestamp(5,expiration);ps.setInt(6,0);
                        ps.setInt(7,accountId);ps.setString(8,characterName);ps.setTimestamp(9,expiration);ps.executeUpdate();
                    }
                });
                CDB.RequestUseItem(pc, tx, ()->L1SkillUse.cast(pc,saveBuffId,pc.getId(),pc.getX(),pc.getY(),null,activeSeconds,L1SkillUse.TYPE_GMBUFF));
            } catch(RuntimeException failure) {
                SC_SystemMessage.send(pc,"강화 버프를 저장하지 못했습니다. 아이템을 확인해 주세요.");
            }
        } else if (itemId == 600218) {
            final int characterId=pc.getId();
            try(l1j.server.server.model.L1InventoryTransaction tx=
                    User.CheckAndSetPendingUseETCItem(pc,CacheD.accountOrderKey("nshop:", characterId))) {
                if(!tx.debit(useItem,1))return;
                tx.requireTables("character_tams");
                tx.sql(con->{
                    try(PreparedStatement ps=con.prepareStatement("DELETE FROM character_tams WHERE char_id=? AND skill_id BETWEEN 4075 AND 4094")) {
                        ps.setInt(1,characterId);ps.executeUpdate();
                    }
                });
                CDB.RequestUseItem(pc, tx, ()->{
                    for(int skill=4075;skill<=4094;skill++)if(pc.hasSkillEffect(skill))pc.removeSkillEffect(skill);
                    SC_SystemMessage.send(pc,"모든 N샵 버프가 초기화되었습니다.");
                });
            } catch(RuntimeException failure) {
                SC_SystemMessage.send(pc,"강화 버프 초기화를 저장하지 못했습니다.");
            }
		}
	}

}
