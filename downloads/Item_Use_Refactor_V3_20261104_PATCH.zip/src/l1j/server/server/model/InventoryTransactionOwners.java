package l1j.server.server.model;

import java.util.concurrent.atomic.AtomicIntegerFieldUpdater;

import l1j.server.server.model.Instance.L1PcInstance;
import l1j.server.server.model.network.core.CIOClient;

/** The one or two owners of a receipt, captured once at admission.
 * Fixed fields avoid maps, boxed session stamps and sorting on every item use.
 * Gate release is idempotent, including a callback which starts a new receipt.
 * No per-player buffer, thread, queue or JDBC connection is retained here.
 */
final class InventoryTransactionOwners {
    private static final AtomicIntegerFieldUpdater<InventoryTransactionOwners> RESERVED =
            AtomicIntegerFieldUpdater.newUpdater(InventoryTransactionOwners.class, "reserved");

    private final L1PcInstance primary;
    private final L1PcInstance first, second;
    private final CIOClient firstSession, secondSession;
    private final int firstStamp, secondStamp;
    private volatile int reserved;

    InventoryTransactionOwners(L1PcInstance primary, L1PcInstance other, boolean trade) {
        this.primary = primary;
        boolean ordered = other == null || primary.getId() <= other.getId();
        first = ordered ? primary : other;
        second = ordered ? other : primary;

        CIOClient firstConnection = admit(first, trade);
        int firstIdentity = first.getSessionStamp();
        CIOClient secondConnection = null;
        int secondIdentity = 0;
        try {
            if (second != null) {
                secondConnection = admit(second, trade);
                secondIdentity = second.getSessionStamp();
            }
        } catch (RuntimeException failure) {
            // Only the reservation acquired by this constructor is released.
            if (first.getSessionStamp() == firstIdentity) first.endItemTransfer();
            throw failure;
        }
        firstSession = firstConnection;
        secondSession = secondConnection;
        firstStamp = firstIdentity;
        secondStamp = secondIdentity;
        reserved = second == null ? 1 : 3;
    }

    private CIOClient admit(L1PcInstance pc, boolean trade) {
        CIOClient session = pc.getNetConnection();
        boolean connected = session != null && session.isConnected() && session.getActiveChar() == pc;
        boolean market = !trade && pc != primary && pc.isPrivateShop()
                && L1World.getInstance().findObject(pc.getId()) == pc;
        if ((!connected && !market)
                || (!trade && (pc.getTradeID() != 0 || pc.isTradeResolving()))
                || !pc.tryBeginItemTransfer())
            throw new IllegalStateException("Inventory owner unavailable or busy");
        return connected ? session : null;
    }

    int size() { return second == null ? 1 : 2; }

    L1PcInstance get(int index) {
        if (index == 0) return first;
        if (index == 1 && second != null) return second;
        throw new IndexOutOfBoundsException("Inventory owner index: " + index);
    }

    boolean contains(L1PcInstance pc) { return pc == first || (pc != null && pc == second); }

    int stamp(L1PcInstance pc) {
        if (pc == first) return firstStamp;
        if (pc != null && pc == second) return secondStamp;
        throw new IllegalArgumentException("Unreserved inventory owner");
    }

    private CIOClient session(L1PcInstance pc) {
        if (pc == first) return firstSession;
        if (pc != null && pc == second) return secondSession;
        throw new IllegalArgumentException("Unreserved inventory owner");
    }

    Object monitor(L1PcInstance pc) {
        CIOClient session = session(pc);
        return session == null ? pc.getInventory() : session;
    }

    boolean current(L1PcInstance pc) {
        if (pc.getSessionStamp() != stamp(pc)) return false;
        CIOClient session = session(pc);
        if (session == null) return pc != primary && pc.isPrivateShop()
                && L1World.getInstance().findObject(pc.getId()) == pc;
        return session.isConnected() && session.getActiveChar() == pc && pc.getNetConnection() == session;
    }

    void release() {
        int acquired = RESERVED.getAndSet(this, 0);
        if ((acquired & 1) != 0 && first.getSessionStamp() == firstStamp) first.endItemTransfer();
        if ((acquired & 2) != 0 && second.getSessionStamp() == secondStamp) second.endItemTransfer();
    }

    void quarantine() {
        if (firstSession != null && firstSession.isConnected()) firstSession.kick();
        if (secondSession != null && secondSession.isConnected()) secondSession.kick();
    }
}
