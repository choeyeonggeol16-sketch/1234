Read REPORT.md first. The immutable implementation baseline is 227c67b / CTransport ABI5.
This audit changes no engine/source/DLL/PSS files. Input EXEs are not redistributed.
Reproduction requires the original two EXEs, pefile/capstone, and the existing full L1 source + native Core root; place the research scripts there.
The source/ tree under research/network-audit is a hash-verified reading snapshot, not an alternate deployable server.
The 33 audit rows are not a restoration percentage or total function count.
