package l1j.server.IndunSystem.Ice.Demon;

import java.util.ArrayList;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import l1j.server.server.model.Instance.L1PcInstance;
import l1j.server.server.model.map.L1WorldMap;
import l1j.server.server.model.network.core.sc.packet.RChatPacket;

public class DemonSystem {
	
	private static DemonSystem _instance;
	private final ArrayList<Integer> _map = new ArrayList<Integer>();
	private final Map<Integer, Demon> _list = new ConcurrentHashMap<Integer, Demon>();

	public static DemonSystem getInstance() {
		if (_instance == null) {
			_instance = new DemonSystem();
		}
		return _instance;
	}

	public DemonSystem(){
		_map.add(2151);
	}

	public void startDemon(L1PcInstance pc){
		if(countDemon() >= 49){
			RChatPacket.sendDirect(pc, pc, "인스턴스 던전에 진입한 인원이 너무 많습니다");
			return;
		}
		int id = blankMapId();
		if(id != 2151)
			L1WorldMap.getInstance().cloneMap(2151, id);
		Demon demon = new Demon(id);
//		L1Teleport.teleport(pc, 32728, 32819, (short) id, 5, true);
		pc.start_teleport(32728, 32819, id, 5, 169, true, false);
		_list.put(id, demon);
		demon.Start();
	}

	public int blankMapId(){
		if(_list.size() == 0)
			return 2151;
		for(int i = 2151 ; i <= 2200; i++){
			Demon h = _list.get(i);
			if(h == null)
				return i;
		}  
		return 2200;
	}

	public Demon getDemon(int id){
		return _list.get(id);
	}

	public void removeDemon(int id){
		_list.remove(id);
	}

	public int countDemon(){
		return _list.size();
	}
}
