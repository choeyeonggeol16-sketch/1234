package l1j.server.MJDungeonTimer.Updator;

import java.util.Calendar;
import l1j.server.server.model.network.core.sc.packet.RSkillSound;
import java.util.concurrent.ArrayBlockingQueue;

import l1j.server.Config;
import l1j.server.MJDungeonTimer.DungeonTimeInformation;
import l1j.server.MJDungeonTimer.Loader.DungeonTimeInformationLoader;
import l1j.server.MJDungeonTimer.Loader.DungeonTimeLoadManager;
import l1j.server.server.ThreadPool;
import l1j.server.server.model.L1World;
import l1j.server.server.model.Instance.L1PcInstance;
import l1j.server.server.model.gametime.BaseTime;
import l1j.server.server.model.gametime.RealTimeClock;
import l1j.server.server.model.gametime.TimeListener;
import l1j.server.server.model.network.core.sc.packet.SC_PacketBox;

import l1j.server.server.model.network.core.sc.packet.RSystemMessage;

public class DungeonTimeUpdator implements TimeListener{
	private static DungeonTimeUpdator _instance;
	public static DungeonTimeUpdator getInstance(){
		if(_instance == null)
			_instance = new DungeonTimeUpdator();
		return _instance;
	}

	public static void release(){
		if(_instance != null){
			_instance.dispose();
			_instance = null;
		}
	}

	public static void reload(){
		DungeonTimeUpdator old = _instance;
		_instance = new DungeonTimeUpdator();
		if(old != null){
			old.dispose();
			old = null;
		}
	}
	
	public static boolean is_possible_update_character(L1PcInstance pc){
		return pc != null && pc.getNetConnection() != null;
	}

	private DungeonTimeConsumer _consumer;
	private DungeonTimeUpdator(){
	}
	
	public void run(){
		RealTimeClock.getInstance().addListener(this, Calendar.SECOND);
		_consumer = new DungeonTimeConsumer();
		ThreadPool.getInstance().execute(_consumer);
	}

	public void dispose(){
		RealTimeClock.getInstance().removeListener(this, Calendar.SECOND);
		if(_consumer != null){
			_consumer.offer(Boolean.FALSE);
			_consumer = null;
		}
	}

	public boolean is_running(){
		return _consumer != null;
	}
	
	@Override
	public void onMonthChanged(BaseTime time) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onDayChanged(BaseTime time) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onHourChanged(BaseTime time) {
	}

	@Override
	public void onMinuteChanged(BaseTime time) {
		// TODO Auto-generated method stub
		
	}

	public void do_initialize(Calendar cal){
		dispose();
		ThreadPool.getInstance().execute(new Runnable(){
			@Override
			public void run(){
				String message = "전체 던전 시간이 초기화되었습니다.";
				String message_en = "[NOTICE] All dungeon timers have been reset."; 
				try{
					L1World.getInstance()
					.getAllPlayerStream()
					.filter((L1PcInstance pc)->{
						return is_possible_update_character(pc);
					})
					.forEach((L1PcInstance pc)->{
						pc.initialize_dungeon_progress();
						SC_PacketBox.send(pc, SC_PacketBox.GREEN_MESSAGE, message);
						RSystemMessage.send(pc, message_en);
					});
				}catch(Exception e){
					e.printStackTrace();
				}finally{
					DungeonTimeLoadManager.getInstance().do_truncate(cal);
//					message.clear();
//					message_en.clear();
					DungeonTimeUpdator.this.run();
				}
			}
		});
	}
	
	@Override
	public void onSecondChanged(BaseTime time) {
		/** 던전초기화 시간 **/
		Calendar calendar = Calendar.getInstance();
		int nowDay = calendar.get(Calendar.DAY_OF_WEEK);
		// [던전초기화 시각 외부화] config/altsettings.properties 의 DungeonResetHour/DungeonResetMinute
		if(time.equals_time(Config.DungeonResetHour, Config.DungeonResetMinute, 0)){
			do_initialize(time.getCalendar());
			Config.네쥬던전초기화 = nowDay;
			final String message = "던전 초기화 시간으로, 더 이용하시기 위해서는 재입장 해주십시오.";
			ThreadPool.getInstance().execute(new Runnable(){
				@Override
				public void run(){
					for(int i=0; i<2; ++i){
						for(L1PcInstance pc : L1World.getInstance().getAllPlayers()){
							if(pc == null)
								continue;
							
							if(i == 0)
								SC_PacketBox.send(pc, SC_PacketBox.GREEN_MESSAGE, message);
							
							
							if(pc.getMapId() == 53 || pc.getMapId() == 54 ){
								//getback 베이스 마을로 귀환
								if(i == 0){
									pc.start_teleport(33430, 32823, 4, pc.getHeading(), 169, true, false);
									RSkillSound.send(pc, pc.getId(), 491);//
								}else{
									pc.do_simple_teleport(33436, 32812, 4);
									RSkillSound.send(pc, pc.getId(), 491);//
								}
							}
						}
					}
				//	message.clear();
					
				}
			});
		}else{
			if(_consumer != null){
				_consumer.offer(Boolean.TRUE);
			}
		}
	}
	
	static class DungeonTimeConsumer implements Runnable{
		private ArrayBlockingQueue<Boolean> _signal;
		DungeonTimeConsumer(){
			_signal = new ArrayBlockingQueue<Boolean>(2);
		}
		
		public void offer(Boolean b){
			_signal.offer(b);
		}
		
		@Override
		public void run() {
			try{
				boolean is_run = Boolean.TRUE;
				while(is_run){
					is_run = _signal.take();
					if(!is_run)
						return;
					
					do_update();
				}
			}catch(Exception e){
			//	e.printStackTrace();
			}
		}
		
		private void do_update(){
			try{
				DungeonTimeInformationLoader loader = DungeonTimeInformationLoader.getInstance();
				for(L1PcInstance pc : L1World.getInstance().getAllPlayers()){
					if(!is_possible_update_character(pc))
						continue;
					
					DungeonTimeInformation dtInfo = loader.from_map_id(pc.getMapId());
					if(dtInfo == null)
						continue;
					
					pc.dec_dungeon_progress(dtInfo);
				}
			}catch(Exception e){
				e.printStackTrace();
			}
		}
	}
}
