package l1j.server.BonusMaps;

import java.sql.ResultSet;
import java.util.HashMap;
import l1j.server.MJTemplate.MJSqlHelper.Executors.Selector;
import l1j.server.MJTemplate.MJSqlHelper.Handler.FullSelectorHandler;

public class BonusMapTable
{
  private static BonusMapTable _instance;
  private HashMap<Integer, BonusMapInfo> _bonusitem;
  
  public static BonusMapTable getInstance()
  {
    if (_instance == null) {
      _instance = new BonusMapTable();
    }
    return _instance;
  }
  
  public static void reload()
  {
    if (_instance != null) {
      _instance = new BonusMapTable();
    }
  }
  
  private BonusMapTable()
  {
    load();
  }
  
  private void load()
  {
    final HashMap<Integer, BonusMapInfo> bonus = new HashMap<Integer, BonusMapInfo>(256);
    Selector.exec("select * from 특정맵드랍", new FullSelectorHandler()
    {
      public void result(ResultSet rs)
        throws Exception
      {
        while (rs.next())
        {
          BonusMapInfo pInfo = BonusMapInfo.newInstance(rs);
          if (pInfo != null) {
            bonus.put(Integer.valueOf(pInfo.get_map_id()), pInfo);
          }
        }
      }
    });
    this._bonusitem = bonus;
  }
  
  public BonusMapInfo getBonusMapInfo(int MapId)
  {
    if (this._bonusitem.containsKey(Integer.valueOf(MapId))) {
      return (BonusMapInfo)this._bonusitem.get(Integer.valueOf(MapId));
    }
    return null;
  }
}
