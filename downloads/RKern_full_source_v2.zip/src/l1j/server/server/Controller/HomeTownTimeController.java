package l1j.server.server.Controller;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Calendar;
import java.util.logging.Level;
import java.util.logging.Logger;

import l1j.server.DatabaseFactory;
import l1j.server.server.datatables.TownTable;
import l1j.server.server.model.L1World;
import l1j.server.server.model.Instance.L1PcInstance;
import l1j.server.server.model.gametime.L1GameTime;
import l1j.server.server.model.gametime.L1GameTimeAdapter;
import l1j.server.server.model.gametime.L1GameTimeClock;
import l1j.server.server.model.network.core.sc.packet.SC_PacketBox;

public class HomeTownTimeController {
	private static final Logger _log = Logger.getLogger(HomeTownTimeController.class.getName());

	private static volatile HomeTownTimeController _instance;

	public static HomeTownTimeController getInstance() {
		if (_instance == null) {
			synchronized (HomeTownTimeController.class) {
				if (_instance == null) {
					_instance = new HomeTownTimeController();
				}
			}
		}
		return _instance;
	}

	private HomeTownTimeController() {
		startListener();
	}

	private static L1TownFixedProcListener _listener;

	private void startListener() {
		if (_listener == null) {
			synchronized (HomeTownTimeController.class) {
				if (_listener == null) {
					_listener = new L1TownFixedProcListener();
					L1GameTimeClock.getInstance().addListener(_listener);
				}
			}
		}
	}

	private class L1TownFixedProcListener extends L1GameTimeAdapter {
		@Override
		public void onDayChanged(L1GameTime time) {
			fixedProc(time);
		}
	}

	private void fixedProc(L1GameTime time) {
		Calendar cal = time.getCalendar();
		if (cal == null) return;
		int day = cal.get(Calendar.DAY_OF_MONTH);

		if (day == 25) {
			monthlyProc();
		} else {
			dailyProc();
		}
	}

	public void dailyProc() {
		_log.info("홈 타운 시스템：일시 처리 개시");
		TownTable.getInstance().updateTaxRate();
		TownTable.getInstance().updateSalesMoneyYesterday();
		TownTable.getInstance().load();
	}

	public void monthlyProc() {
		_log.info("홈 타운 시스템：월시 처리 개시");
		L1World.getInstance().setProcessingContributionTotal(true);

		for (int townId = 1; townId <= 10; townId++) {
			String leaderName = totalContribution(townId);
			if (leaderName != null) {
				
				for (L1PcInstance pc : L1World.getInstance().getAllPlayers()) {
					if (pc != null && pc.getHomeTownId() == townId) {
						pc.setContribution(0);
						SC_PacketBox.send(pc, SC_PacketBox.MSG_TOWN_LEADER, leaderName);
					}
				}
			}
		}
		TownTable.getInstance().load();

		for (L1PcInstance pc : L1World.getInstance().getAllPlayers()) {
			if (pc == null) continue;
			if (pc.getHomeTownId() == -1) {
				pc.setHomeTownId(0);
			}
			pc.setContribution(0);
			try {
				pc.save(); // DB 캐릭터 정보 저장
			} catch (Exception e) {
				_log.log(Level.SEVERE, "monthlyProc pc save error", e);
			}
		}
		clearHomeTownID();
		L1World.getInstance().setProcessingContributionTotal(false);
	}

	private static String totalContribution(int townId) {
		String leaderName = null;
		int leaderId = 0;
		double totalContribution = 0;
		double townFixTax = 0;
		double contributionUnit = 0;

		String sql1 = "SELECT objid, char_name FROM characters WHERE HomeTownID = ? AND Contribution > 0 ORDER BY Contribution DESC LIMIT 1";
		String sql2 = "SELECT SUM(Contribution) AS TotalContribution FROM characters WHERE HomeTownID = ?";
		String sql3 = "SELECT town_fix_tax FROM town WHERE town_id = ?";
		// [수정] Pay 계산을 먼저 수행한 뒤 Contribution을 0으로 초기화하도록 SQL 순서 및 로직 정정
		String sql4 = "UPDATE characters SET Pay = Contribution * ?, Contribution = 0 WHERE HomeTownID = ? AND Contribution > 0";
		String sql5 = "UPDATE town SET leader_id = ?, leader_name = ?, tax_rate = 0, tax_rate_reserved = 0, sales_money = 0, sales_money_yesterday = sales_money, town_tax = 0, town_fix_tax = 0 WHERE town_id = ?";

		try (Connection con = DatabaseFactory.getInstance().getConnection()) {
			
			// 1. 1위 군주/유저 조회
			try (PreparedStatement pstm1 = con.prepareStatement(sql1)) {
				pstm1.setInt(1, townId);
				try (ResultSet rs1 = pstm1.executeQuery()) {
					if (rs1.next()) {
						leaderId = rs1.getInt("objid");
						leaderName = rs1.getString("char_name");
					}
				}
			}

			// 2. 총 기여도 합산 조회
			try (PreparedStatement pstm2 = con.prepareStatement(sql2)) {
				pstm2.setInt(1, townId);
				try (ResultSet rs2 = pstm2.executeQuery()) {
					if (rs2.next()) {
						totalContribution = rs2.getDouble("TotalContribution");
					}
				}
			}

			// 3. 마을 고정 세금 조회
			try (PreparedStatement pstm3 = con.prepareStatement(sql3)) {
				pstm3.setInt(1, townId);
				try (ResultSet rs3 = pstm3.executeQuery()) {
					if (rs3.next()) {
						townFixTax = rs3.getDouble("town_fix_tax");
					}
				}
			}

			// 4. 기여도 단위 계산
			if (totalContribution != 0) {
				contributionUnit = Math.floor((townFixTax / totalContribution) * 100) / 100;
			}

			// 5. 보수(Pay) 정산 및 기여도 초기화
			try (PreparedStatement pstm4 = con.prepareStatement(sql4)) {
				pstm4.setDouble(1, contributionUnit);
				pstm4.setInt(2, townId);
				pstm4.execute();
			}

			// 6. 마을 정보 갱신
			try (PreparedStatement pstm5 = con.prepareStatement(sql5)) {
				pstm5.setInt(1, leaderId);
				pstm5.setString(2, leaderName);
				pstm5.setInt(3, townId);
				pstm5.execute();
			}

		} catch (SQLException e) {
			_log.log(Level.SEVERE, "totalContribution error for townId: " + townId, e);
		}

		return leaderName;
	}

	private static void clearHomeTownID() {
		String sql = "UPDATE characters SET HomeTownID = 0 WHERE HomeTownID = -1";
		try (Connection con = DatabaseFactory.getInstance().getConnection();
			 PreparedStatement pstm = con.prepareStatement(sql)) {
			pstm.execute();
		} catch (SQLException e) {
			_log.log(Level.SEVERE, "clearHomeTownID error", e);
		}
	}

	/**
	 * 보수를 취득해 클리어 한다
	 * 
	 * @return 보수
	 */
	public static int getPay(int objid) {
		int pay = 0;
		String sql1 = "SELECT Pay FROM characters WHERE objid = ?";
		String sql2 = "UPDATE characters SET Pay = 0 WHERE objid = ?";

		try (Connection con = DatabaseFactory.getInstance().getConnection()) {
			con.setAutoCommit(false); // 트랜잭션 안전성 보장

			try (PreparedStatement pstm1 = con.prepareStatement(sql1)) {
				pstm1.setInt(1, objid);
				try (ResultSet rs1 = pstm1.executeQuery()) {
					if (rs1.next()) {
						pay = rs1.getInt("Pay");
					}
				}
			}

			try (PreparedStatement pstm2 = con.prepareStatement(sql2)) {
				pstm2.setInt(1, objid);
				pstm2.execute();
			}

			con.commit();
		} catch (SQLException e) {
			_log.log(Level.SEVERE, "getPay error for objid: " + objid, e);
		}

		return pay;
	}
}