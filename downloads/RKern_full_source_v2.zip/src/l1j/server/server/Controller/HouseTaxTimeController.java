package l1j.server.server.Controller;

import java.util.Calendar;
import java.util.TimeZone;

import l1j.server.Config;
import l1j.server.server.ThreadPool;
import l1j.server.server.datatables.AuctionBoardTable;
import l1j.server.server.datatables.ClanTable;
import l1j.server.server.datatables.HouseTable;
import l1j.server.server.model.L1Clan;
import l1j.server.server.model.L1World;
import l1j.server.server.templates.L1AuctionBoard;
import l1j.server.server.templates.L1House;

public class HouseTaxTimeController implements Runnable {
	public static final int SLEEP_TIME = 60000; // 1분 (60초)

	private static volatile HouseTaxTimeController _instance;

	public static HouseTaxTimeController getInstance() {
		if (_instance == null) {
			synchronized (HouseTaxTimeController.class) {
				if (_instance == null) {
					_instance = new HouseTaxTimeController();
					// 서버 가동 시 1분 주기 스케줄러 자동 등록
					ThreadPool.getInstance().schedule(_instance, SLEEP_TIME);
				}
			}
		}
		return _instance;
	}

	private HouseTaxTimeController() {}

	@Override
	public void run() {
		try {
			checkTaxDeadline();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			// 1분마다 재귀 스케줄링 유지
			ThreadPool.getInstance().schedule(this, SLEEP_TIME);
		}
	}

	public Calendar getRealTime() {
		TimeZone tz = TimeZone.getTimeZone(Config.TIME_ZONE);
		return Calendar.getInstance(tz);
	}

	private void checkTaxDeadline() {
		Calendar now = getRealTime();
		for (L1House house : HouseTable.getInstance().getHouseTableList()) {
			if (!house.isOnSale()) { // 경매 중이 아닌 아지트만 세금 체납 체크
				if (house.getTaxDeadline() != null && house.getTaxDeadline().before(now)) {
					sellHouse(house);
				}
			}
		}
	}

	private void sellHouse(L1House house) {
        l1j.server.server.model.L1AuctionTransaction.foreclose(house);
    }
}