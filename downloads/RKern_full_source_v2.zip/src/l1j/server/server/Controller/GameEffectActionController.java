package l1j.server.server.Controller;

import l1j.server.server.ThreadPool;
import l1j.server.server.model.Instance.L1NpcInstance;
import l1j.server.server.model.network.core.sc.packet.RDoActionGFX;

public class GameEffectActionController implements Runnable {

	private L1NpcInstance _npc;
	private int _actId;
	private int _count;
	private int _delay;

	public GameEffectActionController(L1NpcInstance npc, int actId, int count, int delay) {
		_npc = npc;
		_actId = actId;
		_count = count;
		_delay = delay;
	}

	public void start() {
		ThreadPool.getInstance().execute(this);
	}
	
	@Override
	public void run() {
		try {
			while (_count > 0) {
				RDoActionGFX.broadcast(_npc, _actId);
				_count--;
				Thread.sleep(_delay);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
