package l1j.server.server.Controller;

import java.util.Calendar;
import java.util.TimeZone;

import l1j.server.Config;
import l1j.server.server.datatables.NpcChatTable;
import l1j.server.server.model.L1Object;
import l1j.server.server.model.L1World;
import l1j.server.server.model.Instance.L1NpcInstance;
import l1j.server.server.templates.L1NpcChat;

public class NpcChatTimeController implements Runnable {

    public static final int SLEEP_TIME = 60000;

    private static NpcChatTimeController _instance;

    public static NpcChatTimeController getInstance() {
        if (_instance == null) {
            _instance = new NpcChatTimeController();
        }

        return _instance;
    }

    @Override
    public void run() {
        try {
            checkNpcChatTime();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void checkNpcChatTime() {

        final Calendar now =
                Calendar.getInstance(
                        TimeZone.getTimeZone(Config.TIME_ZONE));

        final int nowTime =
                now.get(Calendar.HOUR_OF_DAY) * 100
                + now.get(Calendar.MINUTE);

        for (L1NpcChat npcChat
                : NpcChatTable.getInstance().getAllGameTime()) {

            if (npcChat == null) {
                continue;
            }

            if (npcChat.getGameTime() != nowTime) {
                continue;
            }

            final int npcId =
                    npcChat.getNpcId();


            for (L1Object obj
                    : L1World.getInstance().getObject()) {

                if (!(obj instanceof L1NpcInstance)) {
                    continue;
                }

                final L1NpcInstance npc =
                        (L1NpcInstance) obj;

                if (npc.getNpcTemplate().get_npcId() != npcId) {
                    continue;
                }

                npc.startChat(
                        L1NpcInstance.CHAT_TIMING_GAME_TIME);
            }
        }
    }
}