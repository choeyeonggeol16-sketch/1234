package l1j.server.server.Controller;
import l1j.server.server.model.network.core.sc.packet.ROwnCharStatus2;
import l1j.server.server.model.network.core.sc.packet.RSPMR;

import java.util.Iterator;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.logging.Level;
import java.util.logging.Logger;
import l1j.server.server.ThreadPool;
import l1j.server.server.datatables.ClanTable;
import l1j.server.server.model.L1Clan;
import l1j.server.server.model.L1Party;
import l1j.server.server.model.L1World;
import l1j.server.server.model.Instance.L1PcInstance;
import l1j.server.server.model.character.skill.L1SkillId;
import l1j.server.server.model.network.core.sc.packet.RInventoryIcon;
import l1j.server.server.model.network.core.sc.packet.RPledge;

import l1j.server.server.utils.eKind;

public final class AuraController implements Runnable {

    private static final Logger LOG = Logger.getLogger(AuraController.class.getName());
    private static final AuraController INSTANCE = new AuraController();

    private static final int TICK_MS = 2000;
    private static final int RANGE = 18;

    private final Set<Integer> trackedCrownIds = ConcurrentHashMap.newKeySet(512);

    private final AtomicBoolean started = new AtomicBoolean(false);
    private final AtomicBoolean running = new AtomicBoolean(false);
    private volatile boolean stopped = false;

    public static AuraController getInstance() {
        return INSTANCE;
    }

    private AuraController() {}

    public void start() {
        if (!started.compareAndSet(false, true)) return;
        stopped = false;
        ThreadPool.getInstance().execute(this);
    }

    public void stop() {
        stopped = true;
    }

    public void addMember(L1PcInstance pc) {
        if (pc == null) return;
        trackedCrownIds.add(pc.getId());
    }

    public void removeMember(L1PcInstance pc) {
        if (pc == null) return;
        trackedCrownIds.remove(pc.getId());
        safeEnd(pc);
    }

    public boolean getMember(L1PcInstance pc) {
        return pc != null && trackedCrownIds.contains(pc.getId());
    }

    @Override
    public void run() {
        if (stopped) return;

        if (!running.compareAndSet(false, true)) {
            reschedule();
            return;
        }

        try {
            tickAura();
            tickClanBuff();
        } catch (Throwable t) {
            LOG.log(Level.SEVERE, "AuraController tick error", t);
        } finally {
            running.set(false);
            reschedule();
        }
    }

    private void reschedule() {
        if (stopped) return;
        ThreadPool.getInstance().schedule(this, TICK_MS);
    }

    private void tickAura() {
        if (trackedCrownIds.isEmpty()) return;

        final L1World world = L1World.getInstance();

        for (Iterator<Integer> it = trackedCrownIds.iterator(); it.hasNext(); ) {
            final int crownId = it.next();

            final L1PcInstance crown = findPc(world, crownId);
            if (!isValidPc(crown)) {
                it.remove();
                continue;
            }

            final L1Party party = crown.getParty();
            if (party == null || party.getNumOfMembers() < 2) {
                if (crown.getPbavatar()) safeEnd(crown);
                continue;
            }

            final L1PcInstance[] members = party.getMembers();
            if (members == null || members.length == 0) {
                if (crown.getPbavatar()) safeEnd(crown);
                continue;
            }

            final int cx = crown.getX();
            final int cy = crown.getY();
            final int cmap = crown.getMapId();

            for (L1PcInstance m : members) {
                if (!isValidPc(m)) continue;

                final boolean shouldHaveAura = shouldHaveAura(crown, party, m, cx, cy, cmap);

                if (shouldHaveAura) {
                    ensureAuraOn(m);
                } else {
                    if (m.getPbavatar()) safeEnd(m);
                }
            }
        }
    }

    private static L1PcInstance findPc(L1World world, int objId) {
        try {
            return (L1PcInstance) world.findObject(objId);
        } catch (Throwable t) {
            return null;
        }
    }

    private static boolean shouldHaveAura(L1PcInstance crown, L1Party party, L1PcInstance m, int cx, int cy, int cmap) {
        if (m == null) return false;
        if (m.isDead()) return false;
        if (m.getParty() != party) return false;
        if (m.getMapId() != cmap) return false;

        final int dx = m.getX() - cx;
        if (dx > RANGE || dx < -RANGE) return false;

        final int dy = m.getY() - cy;
        if (dy > RANGE || dy < -RANGE) return false;

        // crown 본인도 포함해서 오라 주는 구조면 true 유지
        return true;
    }

    private void ensureAuraOn(L1PcInstance pc) {
        if (pc == null) return;

        // 이미 1st가 살아있으면 스탯/패킷 중복 적용 금지
        if (pc.hasSkillEffect(L1SkillId.BRAVE_AVATAR_1ST)) {
            if (!pc.getPbavatar()) pc.setPbavatar(true);
            return;
        }

        // 다른 단계 오라 제거
        if (pc.hasSkillEffect(L1SkillId.BRAVE_AVATAR_2ND)) pc.killSkillEffectTimer(L1SkillId.BRAVE_AVATAR_2ND);
        if (pc.hasSkillEffect(L1SkillId.BRAVE_AVATAR_3RD)) pc.killSkillEffectTimer(L1SkillId.BRAVE_AVATAR_3RD);

        pc.setSkillEffect(L1SkillId.BRAVE_AVATAR_1ST, -1);
        RInventoryIcon.iconNewUnLimit(pc, L1SkillId.아우라, 3432, true);

        pc.getResistance().addMr(10);
        pc.getResistance().addSpecialResistance(eKind.ALL, 2);

        pc.getAbility().addAddedStr((byte) 1);
        pc.getAbility().addAddedDex((byte) 1);
        pc.getAbility().addAddedInt((byte) 1);

        pc.resetBaseMr();
        pc.setPbavatar(true);

        RSPMR.send(pc);
        ROwnCharStatus2.send(pc);
    }

    public void brave_end(L1PcInstance pc) {
        safeEnd(pc);
    }

    public void allbrave_end(L1PcInstance pc) {
        if (pc == null) return;
        final L1Party party = pc.getParty();
        if (party == null) return;
        for (L1PcInstance m : party.getMembers()) {
            safeEnd(m);
        }
    }

    private void safeEnd(L1PcInstance pc) {
        if (pc == null) return;

        boolean changed = false;

        if (pc.hasSkillEffect(L1SkillId.BRAVE_AVATAR_1ST)) {
            pc.killSkillEffectTimer(L1SkillId.BRAVE_AVATAR_1ST);
            changed = true;
        }
        if (pc.hasSkillEffect(L1SkillId.BRAVE_AVATAR_2ND)) {
            pc.killSkillEffectTimer(L1SkillId.BRAVE_AVATAR_2ND);
            changed = true;
        }
        if (pc.hasSkillEffect(L1SkillId.BRAVE_AVATAR_3RD)) {
            pc.killSkillEffectTimer(L1SkillId.BRAVE_AVATAR_3RD);
            changed = true;
        }

        // 이미 꺼진 상태면 아무 것도 하지 않음
        if (!changed && !pc.getPbavatar()) return;

        pc.getResistance().addMr(-10);
        pc.getResistance().addSpecialResistance(eKind.ALL, -2);

        pc.getAbility().addAddedStr((byte) -1);
        pc.getAbility().addAddedDex((byte) -1);
        pc.getAbility().addAddedInt((byte) -1);

        pc.setPbavatar(false);

        RSPMR.send(pc);
        ROwnCharStatus2.send(pc);
        RInventoryIcon.icoEnd(pc, L1SkillId.아우라);
    }

    private void tickClanBuff() {
        try {
            for (L1Clan clan : L1World.getInstance().getAllClans()) {
                if (clan == null) continue;
                synchronized (clan) {
                if (l1j.server.server.storage.CacheD.getInstance().hasPendingOwnerApply(clan.getClanId())) continue;

                final int bless = clan.getBless();
                if (bless == 0) continue;

                final int[] time = clan.getBuffTime();
                if (time == null || bless - 1 < 0 || bless - 1 >= time.length) continue;

                clan.setBuffTime(bless - 1, time[bless - 1] - 1);

                if (clan.getBuffTime()[bless - 1] <= 0) {
                    for (L1PcInstance member : clan.getOnlineClanMember()) {
                        if (member == null) continue;
                        RPledge.sendBless(member, clan, bless);
                        member.removeSkillEffect(bless + 504);
                    }
                    clan.setBless(0);
                    ClanTable.getInstance().updateBless(clan.getClanId(), 0);
                }
                }
            }
        } catch (Throwable t) {
            LOG.log(Level.SEVERE, "Clanbuff tick error", t);
        }
    }

    private static boolean isValidPc(L1PcInstance pc) {
        if (pc == null) return false;
        try {
            if (pc.getNetConnection() == null || !pc.getNetConnection().isConnected()) return false;
        } catch (Throwable t) {
            return false;
        }
        return true;
    }
}
