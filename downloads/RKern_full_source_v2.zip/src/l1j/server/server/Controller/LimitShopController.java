package l1j.server.server.Controller;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;
import java.util.Collections;
import java.util.Map;
import java.util.TreeMap;
import java.util.logging.Level;
import java.util.logging.Logger;
import l1j.server.server.storage.cached.CTransaction;

import l1j.server.DatabaseFactory;
import l1j.server.server.model.L1World;
import l1j.server.server.model.Instance.L1PcInstance;
import l1j.server.server.utils.SQLUtil;

public class LimitShopController extends Thread {
	
	public class ShopLimitItem{
		public int _npcid;
		public int _itemid;
		public int _count;
		
		public ShopLimitItem(int npcid, int itemid, int count){
			_npcid = npcid;
			_itemid = itemid;
			_count = count;
			
		}
	}
	
	
	private volatile Map<Integer, Integer> limit_shop = Collections.emptyMap();
    private volatile boolean configurationReady;
    private static final Logger LOG = Logger.getLogger(LimitShopController.class.getName());
    private static volatile LimitShopController _instance;
    public static LimitShopController getInstance() {
        LimitShopController current = _instance;
        if (current != null) return current;
        synchronized (LimitShopController.class) {
            current = _instance;
            if (current == null) _instance = current = new LimitShopController();
        }
        return current;
    }
	
	public LimitShopController() {	
		Load();
	}
	
	public void reload(){
		Load();
	}
	
	public void Load(){
        final Map<Integer,Integer> loaded = new TreeMap<>();
		Connection con = null;
		PreparedStatement pstm = null;
		ResultSet rs = null;
		try {
			con = DatabaseFactory.getInstance().getConnection();
			pstm = con.prepareStatement("SELECT * FROM 상점계정1회제한");
			rs = pstm.executeQuery();
			while (rs.next()) {
				int npcId = rs.getInt("npc_id");
				int count = rs.getInt("count");
                if(npcId <= 0 || count < 0 || loaded.put(npcId,count) != null)
                    throw new SQLException("Invalid/duplicate account-shop quota configuration");
			}
            limit_shop = Collections.unmodifiableMap(loaded);
            configurationReady = true;
		} catch (SQLException e) {
            LOG.log(Level.SEVERE,"Account-shop quota configuration unavailable; retain previous configuration",e);
		} finally {
			SQLUtil.close(rs);
			SQLUtil.close(pstm);
			SQLUtil.close(con);
		}
	}
	
    public int getLimitShop(int npcId) {
        if(!configurationReady)throw new IllegalStateException("Account-shop quota configuration unavailable");
        return limit_shop.getOrDefault(npcId,-1);
    }

    /** Legacy admission is read-only. Only a prepared purchase may persist quota. */
    @Deprecated
    public boolean CheckLimitShop(L1PcInstance pc,int npcId,int itemId,int amount) {
        if(pc==null || amount<=0)return false;
        int limit=getLimitShop(npcId);
        if(limit<0)return true;
        long before=0;
        for(ShopLimitItem row:pc.getLimitShop())
            if(row._npcid==npcId && row._itemid==itemId)before+=row._count;
        return before>=0 && before+amount<=limit;
    }

    /** Immutable quota request. The worker obtains authoritative counts; no
     * live quota or inventory is changed while this plan is prepared.
     */
    public Quota preparePurchase(String account,int npcId,Map<Integer,Integer> quantities) {
        int limit=getLimitShop(npcId);
        if(limit<0)return null;
        if(account==null || account.isEmpty() || quantities==null || quantities.isEmpty())
            throw new IllegalArgumentException("Missing account-shop quota request");
        TreeMap<Integer,Integer> deltas=new TreeMap<>();
        for(Map.Entry<Integer,Integer> row:quantities.entrySet()) {
            if(row.getKey()==null || row.getKey()<=0 || row.getValue()==null
                    || row.getValue()<=0 || row.getValue()>limit)
                throw new IllegalArgumentException("Account-shop purchase quantity exceeds quota");
            deltas.put(row.getKey(),row.getValue());
        }
        return new Quota(account,npcId,limit,deltas);
    }

    public static final class Quota {
        private final String account;
        private final int npcId,limit;
        private final Map<Integer,Integer> deltas;
        private volatile int[] committedCounts;
        private Quota(String account,int npcId,int limit,TreeMap<Integer,Integer> quantities) {
            this.account=account;this.npcId=npcId;this.limit=limit;
            deltas=Collections.unmodifiableMap(new TreeMap<>(quantities));
        }
        /** Called only as a mutation of the purchase's existing receipt. */
        public void persist(Connection con)throws SQLException {
            CTransaction.requireTransactionalTables(con,"accounts");
            // The generic engine helper accepts ASCII identifiers only. The
            // existing Korean table name is a bound constant, never SQL input.
            try(PreparedStatement ps=con.prepareStatement("SELECT ENGINE FROM information_schema.TABLES "
                    +"WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME=?")) {
                ps.setString(1,"상점제한유저정보");
                try(ResultSet rs=ps.executeQuery()) {
                    if(!rs.next() || !"InnoDB".equalsIgnoreCase(rs.getString(1)))
                        throw new SQLException("Account-shop quota requires InnoDB table: 상점제한유저정보");
                }
            }
            // A pre-existing parent account row serializes the missing-quota
            // INSERT case even when the old schema has no unique quota index.
            try(PreparedStatement ps=con.prepareStatement("SELECT login FROM accounts WHERE login=? FOR UPDATE")) {
                ps.setString(1,account);
                try(ResultSet rs=ps.executeQuery()) {
                    if(!rs.next() || rs.next())throw new SQLException("Missing/ambiguous account quota owner");
                }
            }
            int[] results=new int[deltas.size()*2];int index=0;
            for(Map.Entry<Integer,Integer> row:deltas.entrySet()) {
                int itemId=row.getKey(),before=0;boolean exists;
                try(PreparedStatement ps=con.prepareStatement("SELECT `count` FROM `상점제한유저정보` "
                        +"WHERE account=? AND npc_id=? AND item_id=? FOR UPDATE")) {
                    ps.setString(1,account);ps.setInt(2,npcId);ps.setInt(3,itemId);
                    try(ResultSet rs=ps.executeQuery()) {
                        exists=rs.next();
                        if(exists) {
                            before=rs.getInt(1);
                            if(rs.wasNull() || before<0 || rs.next())
                                throw new SQLException("Invalid/duplicate account-shop quota rows");
                        }
                    }
                }
                long after=(long)before+row.getValue();
                if(after>limit)throw new SQLException("Account-shop purchase quota exhausted");
                String sql=exists ? "UPDATE `상점제한유저정보` SET `count`=? WHERE account=? AND npc_id=? AND item_id=? AND `count`=?"
                        : "INSERT INTO `상점제한유저정보` (`count`,account,npc_id,item_id) VALUES (?,?,?,?)";
                try(PreparedStatement ps=con.prepareStatement(sql)) {
                    ps.setInt(1,(int)after);ps.setString(2,account);ps.setInt(3,npcId);ps.setInt(4,itemId);
                    if(exists)ps.setInt(5,before);
                    if(ps.executeUpdate()!=1)throw new SQLException("Account-shop quota write not exact");
                }
                results[index++]=itemId;results[index++]=(int)after;
            }
            committedCounts=results;
        }
        /** Original CIO owner only, after receipt-confirmed purchase replay. */
        public void applyCommitted(L1PcInstance pc) {
            int[] values=committedCounts;
            if(values==null || !account.equals(pc.getAccountName()))
                throw new IllegalStateException("Committed account-shop quota result unavailable");
            for(int i=0;i<values.length;i+=2) {
                final int itemId=values[i];
                pc.getLimitShop().removeIf(row->row._npcid==npcId && row._itemid==itemId);
                pc.getLimitShop().add(LimitShopController.getInstance().new ShopLimitItem(npcId,itemId,values[i+1]));
            }
        }
    }

    public int[] readLimitSnapshot(String accountName) {
        int[] values = new int[12];
        int count = 0;
        try (Connection con = DatabaseFactory.getInstance().getConnection();
             PreparedStatement ps = con.prepareStatement(
                     "SELECT npc_id, item_id, count FROM 상점제한유저정보 WHERE account=?")) {
            ps.setString(1, accountName);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    if (count == values.length) {
                        int[] bigger = new int[values.length << 1];
                        System.arraycopy(values, 0, bigger, 0, count);
                        values = bigger;
                    }
                    values[count++] = rs.getInt(1);
                    values[count++] = rs.getInt(2);
                    values[count++] = rs.getInt(3);
                }
            }
        } catch (SQLException e) {
            throw new IllegalStateException("LimitShop DB read failed: " + accountName, e);
        }
        if (count == values.length) return values;
        int[] result = new int[count];
        System.arraycopy(values, 0, result, 0, count);
        return result;
    }

    public void applyLimitSnapshot(L1PcInstance pc, int[] values) {
        if (values == null) return;
        for (int i = 0; i + 2 < values.length; i += 3)
            pc.getLimitShop().add(new ShopLimitItem(values[i], values[i + 1], values[i + 2]));
    }

	public void LoadLimitpc(L1PcInstance pc){
		Connection con = null;
		PreparedStatement pstm = null;
		ResultSet rs = null;
		try {
			con = DatabaseFactory.getInstance().getConnection();
			pstm = con.prepareStatement("SELECT * FROM 상점제한유저정보 WHERE account=?");
			pstm.setString(1, pc.getAccountName());
			rs = pstm.executeQuery();
			boolean ck = false;
			while (rs.next()) {
				int npcId = rs.getInt("npc_id");
				int itemid = rs.getInt("item_id");
				int count = rs.getInt("count");
				
				pc.getLimitShop().add(new ShopLimitItem(npcId,itemid,count));
			}
			if(ck){
				deleteCharacterLimitShop(pc);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			SQLUtil.close(rs);
			SQLUtil.close(pstm);
			SQLUtil.close(con);
		}
	}
	
	public void deleteCharacterLimitShop(L1PcInstance pc) {
		Connection con = null;
		PreparedStatement pstm = null;
		try {
			pc.getLimitShop().clear();
			
			con = DatabaseFactory.getInstance().getConnection();
			pstm = con.prepareStatement("DELETE FROM 상점제한유저정보 WHERE account=?");
			pstm.setString(1, pc.getAccountName());
			pstm.execute();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			SQLUtil.close(pstm);
			SQLUtil.close(con);
		}
	}
	
	public void AlldeleteCharacterLimitShop() {
		Connection con = null;
		PreparedStatement pstm = null;
		try {
			con = DatabaseFactory.getInstance().getConnection();
			pstm = con.prepareStatement("DELETE FROM 상점제한유저정보");
			pstm.execute();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			SQLUtil.close(pstm);
			SQLUtil.close(con);
		}
	}
	
	
	
	
	
}
