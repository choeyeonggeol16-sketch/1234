package l1j.server.server.Controller;

import java.time.LocalTime;
import java.util.Iterator;

import l1j.server.MJTemplate.MJRnd;
import l1j.server.MJTemplate.Builder.MJLiftGateBuilder;
import l1j.server.MJTemplate.Interface.MJMonsterDeathHandler;
import l1j.server.MJTemplate.Interface.MJMonsterTransformHandler;
import l1j.server.MJTemplate.L1Instance.MJL1LiftGateInstance;
import l1j.server.server.ThreadPool;
import l1j.server.server.datatables.EventTimeTable;
import l1j.server.server.model.L1World;
import l1j.server.server.model.Instance.L1MonsterInstance;
import l1j.server.server.model.Instance.L1NpcInstance;
import l1j.server.server.model.Instance.L1PcInstance;
import l1j.server.server.model.network.core.sc.packet.SC_ActionUI;
import l1j.server.server.model.network.core.sc.packet.SC_PacketBox;
import l1j.server.server.utils.L1SpawnUtil;

public class EventThread implements Runnable {
	public static final long SLEEP_TIME = 60000L; // 1분

	private static volatile EventThread instance;

	public static EventThread getInstance() {
		if (instance == null) {
			synchronized (EventThread.class) {
				if (instance == null) {
					instance = new EventThread();
					// 서버 기동 시 1분 주기 스케줄러 자동 등록
					ThreadPool.getInstance().schedule(instance, SLEEP_TIME);
				}
			}
		}
		return instance;
	} 

	public static MJL1LiftGateInstance _leftBDoor;
	public static MJL1LiftGateInstance _rightBDoor;
	public static MJL1LiftGateInstance _centerBDoor;

	private EventThread() {
		if (_leftBDoor == null) {
			synchronized (EventThread.class) {
				if (_leftBDoor == null) {
					MJLiftGateBuilder builder = new MJLiftGateBuilder().setGfx(16115);			
					_leftBDoor = builder.build(32731, 32852, (short)15404, false, 3);
					_leftBDoor.down();
					_rightBDoor = builder.build(32731, 32878, (short)15404, false, 3);
					_rightBDoor.down();
					_centerBDoor = builder.build(16116, 32718, 32863, (short)15404, true, 5);
					_centerBDoor.down();
				}
			}
		}
	}
	
	private static void on(int id) {
		ThreadPool.getInstance().schedule(new BalogDoorController(id), 30000L);
	}
	
	public static class BalogDoorController implements Runnable {
		private final int _id;
		
		BalogDoorController(int ownerId) {
			_id = ownerId;
		}
		
		@Override
		public void run() {
			try {
				L1MonsterInstance m = (L1MonsterInstance) L1World.getInstance().findObject(_id);
				if (m == null || m.isDead()) {
					if (_leftBDoor != null) _leftBDoor.down();
					if (_rightBDoor != null) _rightBDoor.down();
					if (_centerBDoor != null) _centerBDoor.down();
					return;
				}
					
				if (MJRnd.isBoolean()) {
					_leftBDoor.takeClose(10000L);
					_rightBDoor.up();
					_centerBDoor.up();
				} else if (MJRnd.isBoolean()) {
					_leftBDoor.up();
					_rightBDoor.takeClose(10000L);
					_centerBDoor.up();
				} else {
					_leftBDoor.up();
					_rightBDoor.up();
					_centerBDoor.takeClose(10000L);
				}
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				ThreadPool.getInstance().schedule(this, 30000L);
			}
		}
	}
	
	private void start_event_boss() {
		try {
			Iterator<L1NpcInstance> npc_iter = EventTimeTable.getInstance().get_npc_iter();
			if (npc_iter == null) return;

			while (npc_iter.hasNext()) {
				L1NpcInstance npc = npc_iter.next();
				if (npc == null) {
					continue;
				}
				
				if (get_boss_spawn_time(npc.get_boss_hour(), npc.get_boss_minute())) {
					if (npc.get_boss_msg() != null) {
						SC_PacketBox.broadcastGreen(npc.get_boss_msg().toString());
					}
					
					// NPC가 생성 후 삭제되는 시간 1시간 (3600 * 1000ms)
					L1NpcInstance realNpc = L1SpawnUtil.Gmspawn(npc.getNpcId(), npc.getHomeX(), npc.getHomeY(), npc.getMapId(), npc.getHeading(), 3600 * 1000);
				
					if (npc.getNpcId() == 45752 && realNpc instanceof L1MonsterInstance) {
						if (_leftBDoor != null) _leftBDoor.up();
						if (_rightBDoor != null) _rightBDoor.up();
						
						L1MonsterInstance m = (L1MonsterInstance) realNpc;
						m.setTransformHandler(new MJMonsterTransformHandler() {
							@Override
							public void onTransFormNotify(L1MonsterInstance m) {
								if (_centerBDoor != null) _centerBDoor.up();
								on(m.getId());
							}
						});
						m.setDeathHandler(new MJMonsterDeathHandler() {
							@Override
							public boolean onDeathNotify(L1MonsterInstance m) {
								if (_leftBDoor != null) _leftBDoor.down();
								if (_rightBDoor != null) _rightBDoor.down();
								if (_centerBDoor != null) _centerBDoor.down();
								return false;
							}
						});
					}
				}
				
				if (get_boss_spawn_time((npc.get_boss_hour() + 1), npc.get_boss_minute())) {
					npc.set_boss_time(npc.get_boss_time() + 86400);
					
//					for (L1PcInstance pc : L1World.getInstance().getAllPlayers()) {
//						if (pc == null) {
//							continue;
//						} 
//						pc.sendPackets(new RActionUI(RActionUI.EVENT_SYSTEM, npc.getNpcId(), true));
//					}
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * 최신 LocalTime을 활용한 시간 검증 (Deprecated된 Date 클래스 대체)
	 * @param h 시간
	 * @param m 분
	 * @return 일치 여부
	 */
	private boolean get_boss_spawn_time(int h, int m) { 
		LocalTime now = LocalTime.now();
		return now.getHour() == h && now.getMinute() == m;
	}

	/**
	 * 컨트롤러가 1분마다 한번씩 호출됨.
	 */
	@Override
	public void run() {
		try {
			start_event_boss(); 
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			ThreadPool.getInstance().schedule(this, SLEEP_TIME);
		}
	}
}