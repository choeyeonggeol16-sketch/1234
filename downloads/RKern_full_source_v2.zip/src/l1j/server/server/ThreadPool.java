package l1j.server.server;

import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.RejectedExecutionHandler;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.ScheduledThreadPoolExecutor;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.logging.Logger;

import l1j.server.server.model.network.utill.PacketThreadFactory;
import l1j.server.server.utils.ThreadConfig;

public class ThreadPool {
	private static final Logger _log = Logger.getLogger(ThreadPool.class.getName());
	private static ThreadPool _instance;

	// 스레드풀 상수 도입
	private static final long ONE_HUNDRED_YEARS_MS = 3155695200000L;
	private static final long MIN_DELAY_MS = 0L;
	private static final long PURGE_INTERVAL_MS = 60000L;
	private static final int INSTANT_POOL_KEEP_ALIVE_MINUTES = 1;
	private static final int INSTANT_QUEUE_CAPACITY = 65536;

	private ScheduledThreadPoolExecutor _scheduler;
	private ThreadPoolExecutor _instantPool;
	private ScheduledThreadPoolExecutor _highPriorityScheduler;

	public static ThreadPool getInstance() {
		if (_instance == null) {
			synchronized (ThreadPool.class) {
				if (_instance == null) {
					_instance = new ThreadPool();
				}
			}
		}
		return _instance;
	}

	private ThreadPool() {
		_log.fine("ThreadPool: Initializing advanced thread pools.");
		
		ThreadConfig.load();

		int scheduledSize = ThreadConfig.SCHEDULED_THREAD_POOL_SIZE;
		int instantSize = ThreadConfig.INSTANT_THREAD_POOL_SIZE;
		int highPrioritySize = ThreadConfig.HIGH_PRIORITY_SCHEDULED_THREAD_POOL_SIZE;

		// 고우선순위 스케줄러 풀
		_highPriorityScheduler = new ScheduledThreadPoolExecutor(
			highPrioritySize, 
			new PacketThreadFactory("HighPriority Thread", Thread.MAX_PRIORITY), 
			new ThreadPoolExecutor.CallerRunsPolicy()
		);

		// 메인 스케줄러 풀 (취소된 작업 자동 정리 및 거부 정책 적용)
		_scheduler = new ScheduledThreadPoolExecutor(
			scheduledSize, 
			new PacketThreadFactory("ScheduledThread", Thread.NORM_PRIORITY), 
			new RejectedExecutionHandlerImpl()
		);
		_scheduler.setRemoveOnCancelPolicy(true);
		_scheduler.prestartAllCoreThreads();

		// 즉시 처리(인스턴트) 풀 (LinkedBlockingQueue 기반 튜닝)
		_instantPool = new ThreadPoolExecutor(
			instantSize, 
			Math.max(1, instantSize), 
			INSTANT_POOL_KEEP_ALIVE_MINUTES, 
			TimeUnit.MINUTES, 
			new LinkedBlockingQueue<>(INSTANT_QUEUE_CAPACITY), 
			new PacketThreadFactory("InstantThread", Thread.NORM_PRIORITY)
		);
		_instantPool.setRejectedExecutionHandler(new RejectedExecutionHandlerImpl());
		_instantPool.prestartAllCoreThreads();

		// 주기적인 메모리 청소(Purge) 태스크 등록 (60초 주기)
		scheduleAtFixedRate(ThreadPool::purge, PURGE_INTERVAL_MS, PURGE_INTERVAL_MS);
	}

	/**
	 * 취소된 태스크들을 메모리에서 즉시 해제합니다.
	 */
	public static void purge() {
		if (_instance != null) {
			try {
				if (_instance._scheduler != null) _instance._scheduler.purge();
				if (_instance._instantPool != null) _instance._instantPool.purge();
				if (_instance._highPriorityScheduler != null) _instance._highPriorityScheduler.purge();
			} catch (Exception e) {
				_log.log(Level.WARNING, "ThreadPool purge error", e);
			}
		}
	}

	public void execute(Runnable r) {
		if (r == null) return;
		try {
			_instantPool.execute(new RunnableWrapper(r));
		} catch (Exception e) {
			_log.warning("ThreadPool: Failed to execute task " + r.getClass().getSimpleName() + ": " + e.getMessage());
			if (_instantPool != null && !_instantPool.isShutdown()) {
				new RunnableWrapper(r).run();
			}
		}
	}

	public void execute(Thread t) {
		if (t != null) {
			t.start();
		}
	}

	public ScheduledFuture<?> schedule(Runnable r, long delay) {
		if (r == null) return null;
		try {
			return _scheduler.schedule(new RunnableWrapper(r), validateDelay(delay), TimeUnit.MILLISECONDS);
		} catch (Exception e) {
			_log.warning("ThreadPool: Failed to schedule task " + r.getClass().getSimpleName() + ": " + e.getMessage());
			return null;
		}
	}

	public ScheduledFuture<?> scheduleAtFixedRate(Runnable r, long initialDelay, long period) {
		if (r == null) return null;
		try {
			return _scheduler.scheduleAtFixedRate(new RunnableWrapper(r), validateDelay(initialDelay), validateDelay(period), TimeUnit.MILLISECONDS);
		} catch (Exception e) {
			_log.warning("ThreadPool: Failed to schedule recurring task " + r.getClass().getSimpleName() + ": " + e.getMessage());
			return null;
		}
	}

	public ScheduledFuture<?> scheduleAtFixedRateLong(Runnable r, long initialDelay, long period) {
		return scheduleAtFixedRate(r, initialDelay, period);
	}
	
	public ScheduledFuture<?> schedulePriorityTaskAtFixedRate(Runnable r, long initialDelay, long period) {
		if (r == null) return null;
		if (_highPriorityScheduler == null) {
			return scheduleAtFixedRate(r, initialDelay, period);
		}
		try {
			return _highPriorityScheduler.scheduleAtFixedRate(new RunnableWrapper(r), validateDelay(initialDelay), validateDelay(period), TimeUnit.MILLISECONDS);
		} catch (Exception e) {
			_log.warning("ThreadPool: Failed to schedule high priority task " + r.getClass().getSimpleName() + ": " + e.getMessage());
			return null;
		}
	}

	private long validateDelay(long delay) {
		if (delay < MIN_DELAY_MS) {
			return MIN_DELAY_MS;
		}
		if (delay > ONE_HUNDRED_YEARS_MS) {
			return ONE_HUNDRED_YEARS_MS;
		}
		return delay;
	}

	/**
	 * 작업 거부(Rejected) 발생 시 복구 실행하는 핸들러
	 */
	private static class RejectedExecutionHandlerImpl implements RejectedExecutionHandler {
		@Override
		public void rejectedExecution(Runnable runnable, ThreadPoolExecutor executor) {
			if (executor.isShutdown()) {
				return;
			}
			_log.warning("ThreadPool: Task rejected by executor, attempting recovery execution.");
			runnable.run();
		}
	}

	/**
	 * 태스크 실행 중 발생하는 예외를 안전하게 잡아주는 래퍼
	 */
	private static class RunnableWrapper implements Runnable {
		private final Runnable _wrappedRunnable;

		public RunnableWrapper(Runnable runnable) {
			_wrappedRunnable = runnable;
		}

		@Override
		public void run() {
			try {
				_wrappedRunnable.run();
			} catch (Throwable t) {
				final Thread currentThread = Thread.currentThread();
				final Thread.UncaughtExceptionHandler exceptionHandler = currentThread.getUncaughtExceptionHandler();
				if (exceptionHandler != null) {
					exceptionHandler.uncaughtException(currentThread, t);
				} else {
					_log.log(Level.SEVERE, "Uncaught exception in ThreadPool task", t);
				}
			}
		}
	}
	
	/**
	 * 서버 종료 시 모든 스레드 풀을 안전하게 종료합니다.
	 */
	public void shutdown() {
		if (_instance != null) {
			try {
			//	_log.info("ThreadPool: Shutting down all thread pools.");
				if (_instance._scheduler != null) {
					_instance._scheduler.shutdownNow();
				}
				if (_instance._instantPool != null) {
					_instance._instantPool.shutdownNow();
				}
				if (_instance._highPriorityScheduler != null) {
					_instance._highPriorityScheduler.shutdownNow();
				}
			} catch (Throwable t) {
				_log.log(Level.WARNING, "ThreadPool: Exception occurred during shutdown", t);
			}
		}
	}

}