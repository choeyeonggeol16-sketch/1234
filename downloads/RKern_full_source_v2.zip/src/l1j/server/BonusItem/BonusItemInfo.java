package l1j.server.BonusItem;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Random;
import l1j.server.MJTemplate.MJArrangeHelper.MJArrangeParsee;
import l1j.server.MJTemplate.MJArrangeHelper.MJArrangeParseeFactory;
import l1j.server.MJTemplate.MJArrangeHelper.MJArrangeParser;
import l1j.server.server.model.Instance.L1PcInstance;

public class BonusItemInfo
{
  private static int _is_loggin;
  private int _item_id;
  private String _item_name;
  private int _item_enchant;
  private int _bonus_item_id;
  private String _bonus_name;
  private int _bonus_min_item_count;
  private int _bonus_max_item_count;
  private int _min_probability;
  private int _max_probability;
  private String _mapids;
  
  static BonusItemInfo newInstance(ResultSet rs)
    throws SQLException
  {
    BonusItemInfo pInfo = newInstance();
    int checktype = rs.getString("is_loggin").equalsIgnoreCase("true") ? 1 : 0;
    pInfo._item_id = rs.getInt("item_id");
    pInfo._item_name = rs.getString("item_name");
    pInfo._item_enchant = rs.getInt("item_enchant");
    pInfo._bonus_item_id = rs.getInt("bonus_id");
    pInfo._bonus_name = rs.getString("bonus_name");
    pInfo._bonus_min_item_count = rs.getInt("bonus_min_count");
    pInfo._bonus_max_item_count = rs.getInt("bonus_max_count");
    pInfo._min_probability = rs.getInt("min_probability");
    pInfo._max_probability = rs.getInt("max_probability");
    pInfo.setItemCheckType(checktype);
    pInfo._mapids = rs.getString("mapids");
    return pInfo;
  }
  
  private static BonusItemInfo newInstance()
  {
    return new BonusItemInfo();
  }
  
  int get_item_id()
  {
    return this._item_id;
  }
  
  String get_item_name()
  {
    return this._item_name;
  }
  
  public int get_item_enchant()
  {
    return this._item_enchant;
  }
  
  public int get_bonus_id()
  {
    return this._bonus_item_id;
  }
  
  public String get_bonus_name()
  {
    return this._bonus_name;
  }
  
  public int get_bonus_min_count()
  {
    return this._bonus_min_item_count;
  }
  
  public int get_bonus_max_count()
  {
    return this._bonus_max_item_count;
  }
  
  public int get_min_probability()
  {
    return this._min_probability;
  }
  
  public int get_max_probability()
  {
    return this._max_probability;
  }
  
  public String get_mapids()
  {
    return this._mapids;
  }
  
  public static int getItemCheckType()
  {
    return _is_loggin;
  }
  
  public void setItemCheckType(int i)
  {
    _is_loggin = i;
  }
  
  void print() {}
  
  public int calc_probability(L1PcInstance pc)
  {
    Random random = new Random(System.nanoTime());
    int probability = 0;
    if (this._max_probability == this._min_probability) {
      probability = this._max_probability;
    } else {
      probability = random.nextInt(this._max_probability - this._min_probability) + this._min_probability;
    }
    return probability;
  }
  
  public int calc_count(L1PcInstance pc)
  {
    Random random = new Random(System.nanoTime());
    int count = 0;
    if (this._bonus_max_item_count == this._bonus_min_item_count) {
      count = this._bonus_max_item_count;
    } else {
      count = random.nextInt(this._bonus_max_item_count - this._bonus_min_item_count) + this._bonus_min_item_count;
    }
    return count;
  }
  
  public boolean isMap(L1PcInstance pc)
  {
    String[] bonusmap = (String[])MJArrangeParser.parsing(get_mapids(), ",", MJArrangeParseeFactory.createStringArrange()).result();
    for (String map : bonusmap)
    {
      int mapId = Integer.parseInt(map);
      if (pc.getMapId() == mapId) {
        return true;
      }
    }
    return false;
  }
}
