# RKern v5 vs Netty: isolated TCP transport benchmark

This is the benchmark, not a replacement game server. NPC, game rules, login, DB and production configuration are excluded. The 10 RKern transport/buffer/cipher source files in rkern-src are copied byte-for-byte; source-manifest.json records their experimental hashes.

## Reproduce on Linux with Java 21 and Python 3

The runner requires CPUs 0..3 and permits local TCP sockets. It pins each server to CPUs 0,1 and the common client to CPUs 2,3. Adapt the runner's affinity and environment collection to a different machine; record any changes. This archive does not reproduce a Windows IOCP measurement.

```sh
python3 fetch_dependencies.py
python3 build.py
python3 run.py --mode smoke --warmup 1 --seconds 1
python3 run.py --mode measure --rounds 3 --warmup 5 --seconds 5
python3 supplement/build.py
python3 supplement/run.py --mode smoke --warmup 1 --seconds 1
python3 supplement/run.py --mode measure --rounds 3 --warmup 5 --seconds 5
```

Netty 4.1.139.Final is pinned from Maven Central. JARs are downloaded over verified TLS and checked against the SHA-256 values captured for this experiment. No external EXE or player database is included.

## Test variants

- Main: RKern v5 API vs Netty NIO and native epoll, with Netty explicitly encoding the request's responses into a single pooled direct ByteBuf and flushing once per request.
- Supplement: Netty's per-packet pooled ByteBuf/write calls with one flush per request, vs the same unchanged RKern transport. A TX-heavy 4KiB response control reduces client request-encoding cost. For that control there is only one response, so the per-frame branch is inactive.

Both variants use the actual RKern Cryptor and ReadBuffer/WriteBuffer on both server implementations. The client uses an independent rolling-XOR request encoder and a separate cipher state to recover the server responses. The smoke runs validate every bulk response byte; measured runs validate headers, sequence, action values and a bulk payload tail, to reduce client overhead.

All runs use real loopback TCP, TCP_NODELAY, two server I/O workers, a 4096-byte initial receive allocation, the same JVM heap/direct-memory limits and the same common client. They measure a closed-loop workload with fixed connection count and in-flight window. Latency is request enqueue to the final matching reply and includes client queuing. It is not an open-loop latency test at identical offered packets/second.

Raw JSON includes per-run commands, CPU time, GC, RSS snapshots, direct allocation counters, request and response counts, and p50/p95/p99. Summary values are medians of three independent JVM runs, including the median of the per-run latency percentiles. Throughput counts logical application frames, not TCP segments or NIC packet rate.

The bidirectional 4KiB test reaches the client's two-CPU budget; do not infer maximum server throughput from it. Netty per-frame and combined-buffer results are separate implementations of the same wire protocol; neither is a universal rating of all Netty applications.
