from pathlib import Path
import hashlib,json,urllib.request
R=Path(__file__).resolve().parent
(R/'lib').mkdir(exist_ok=True)
for item in json.loads((R/'dependencies.json').read_text()):
 p=R/'lib'/item['name']
 if p.exists() and hashlib.sha256(p.read_bytes()).hexdigest()==item['sha256']:continue
 with urllib.request.urlopen(item['url'],timeout=60) as response:data=response.read()
 if hashlib.sha256(data).hexdigest()!=item['sha256']:raise RuntimeError('Hash mismatch: '+item['name'])
 p.write_bytes(data)
 print(item['name'])
# Supplement uses the exact same pinned public dependencies.
link=R/'supplement'/'lib'
if not link.exists():link.symlink_to('../lib',target_is_directory=True)
