package l1j.server.server.model.network.core;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.nio.channels.AsynchronousSocketChannel;
import java.nio.channels.CompletionHandler;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.Executor;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.VarHandle;
import java.util.concurrent.atomic.AtomicLongArray;

import l1j.server.server.Opcodes;
import l1j.server.server.model.character.CYieldLock;
import l1j.server.server.model.network.buffer.ReadBuffer;
import l1j.server.server.model.network.codec.Cryptor;
import l1j.server.server.model.network.safe.NetworkSafeLoadManager;
import l1j.server.server.model.network.thread.CIOThreadCallback;
import l1j.server.server.model.network.utill.ConnectionConfig;

import l1j.server.server.model.network.buffer.WriteBuffer;
import l1j.server.server.model.network.packet.CPacketHandler;
import l1j.server.server.model.network.packet.WritablePacket;

/**
 * Java NIO.2 transport with a per-socket 512-slot callback serializer.
 * WRITE completions and SEND starts follow the connection's ticket/FIFO
 * execution rule. READ framing retains its independent direct callback path;
 * creature actions execute on completion workers through their own
 * controller serializer; session/wheel ownership is still isolated.
 */
public final class CIOUserSocket implements AutoCloseable, Runnable {
    @FunctionalInterface
    public interface Closed {
        void onClosed(CIOUserSocket connection);
    }

    private final AsynchronousSocketChannel _channel;
    private final CIOBufferPool _pool;
    private final CYieldLock _stateLock = new CYieldLock();
    private static final Logger LOG = Logger.getLogger(CIOUserSocket.class.getName());
    // Diagnostics only; no new per-connection atomics or per-SEND allocation.
    public static final int REJECT_WIRE_BYTES = 1;
    public static final int REJECT_LOCAL_FRAMES = 2;
    public static final int REJECT_SERIALIZER = 3;
    public static final int REJECT_POOL = 4;
    public static final int REJECT_ENCODING = 5;
    private static final AtomicLongArray SEND_REJECTIONS = new AtomicLongArray(6);
    public static long sendRejections(int reason) {
        if (reason <= 0 || reason >= SEND_REJECTIONS.length())
            throw new IllegalArgumentException("invalid SEND rejection reason");
        return SEND_REJECTIONS.get(reason);
    }
    private static boolean rejectSend(int reason) {
        SEND_REJECTIONS.incrementAndGet(reason);
        return false;
    }
    private static final boolean DIRECT_UNROUTED = Boolean.parseBoolean(System.getProperty("cio.directUnrouted", "true"));
    private static final class DecodeState {
        final ReadBuffer buffer = new ReadBuffer();
        boolean active;
        DecodeState nested;
    }
    private static final ThreadLocal<DecodeState> DECODE = ThreadLocal.withInitial(DecodeState::new);
    private static DecodeState acquireDecodeState() {
        DecodeState state = DECODE.get();
        while (state.active) {
            if (state.nested == null) state.nested = new DecodeState();
            state = state.nested;
        }
        state.active = true;
        return state;
    }
    private volatile Cryptor _cryptor;
    private volatile boolean _handshakePlainPending;
    void initializeCipher(long seed) {
        final Cryptor cryptor = new Cryptor();
        cryptor.initKey(seed);
        _cryptor = cryptor;
        _handshakePlainPending = true;
    }
    void clearCipher() {
        _handshakePlainPending = false;
        _cryptor = null;
    }
    private Cryptor readCipher() { return _cryptor; }
    boolean encrypt(WriteBuffer buffer, int offset, int length) {
        if (_handshakePlainPending) {
            _handshakePlainPending = false;
            return true;
        }
        final Cryptor cipher = _cryptor;
        if (cipher == null) return true;
        try {
            cipher.encrypt(buffer, offset, length);
            return true;
        } catch (Exception error) {
            LOG.log(Level.SEVERE, "[CIOUserSocket] packet encryption failed", error);
            return false;
        }
    }
    boolean decrypt(ReadBuffer buffer, int offset, int length) {
        final Cryptor cipher = _cryptor;
        if (cipher == null) return true;
        try {
            cipher.decrypt(buffer, offset, length);
            return true;
        } catch (Exception error) {
            LOG.log(Level.WARNING, "[CIOUserSocket] packet decryption failed", error);
            return false;
        }
    }
    private volatile CIOClient _client;
    private final String _remoteAddress;
    private final int _affinityShard;
    private volatile int _closing;
    private volatile int _disconnecting;
    private volatile Runnable _onDrained;
    // The final packet is retained only until preceding accepted SENDs drain.
    // No extra worker, queue, or physical SEND lease is reserved for it.
    private WritablePacket<CIOClient> _deferredClosePacket;

    private final Closed _closedCallback;
    private CIOBufferPool.Lease[] _pending;
    private final int _maxQueuedFrames;
    // Volatile primitives avoid five standalone Atomic* objects per connection.
    // VarHandles preserve CAS/getAndAdd semantics when completion threads race.
    private volatile int _closed;
    private volatile int _closeNotified;

    private static final int SOCKET_SLOTS = 512;
    private static final int SOCKET_MASK = SOCKET_SLOTS - 1;
    private static final int SOCKET_REJECT_AT = SOCKET_SLOTS - 8;
    private static final long SOCKET_SEND_START = 1L;
    private static final long SOCKET_WRITE_COMPLETE = 2L;
    private static final long SOCKET_SEND_ENQUEUE = 3L;
    private static final long SOCKET_CANCELLED = 4L;
    private final long[] _socketCallbacks = new long[SOCKET_SLOTS];
    private final long[] _socketArguments = new long[SOCKET_SLOTS];
    private final CIOBufferPool.Lease[] _socketSendArguments = new CIOBufferPool.Lease[SOCKET_SLOTS];

    private volatile long _socketTicket;
    private long _socketHead;
    private volatile int _socketPending;
    private volatile int _socketDraining;
    // Optional SEND_START ticket coalescing: a reusable one-bit wake-up. The
    // serializer clears it only while owning the socket callback token.
    private volatile int _socketStartPending;
    private volatile Thread _socketOwner;
    // Java NIO.2 may complete synchronously inside the write() invocation.
    // Such a callback must not retire its pooled ByteBuffer until write() returns.
    private boolean _socketPosting;
    // Owner-thread-only: a completion observed inside write() is consumed by
    // the serializer loop after write() returns, without a second ring ticket.
    // Never consume it from the completion handler or recurse into the pump.
    private long _inlineWriteCompletion;
    // The current callback has already advanced _socketHead but is still
    // included in _socketPending until its finally block runs.
    private boolean _socketExecutingTicket;
    // A socket issues at most one outstanding WRITE. The mailbox rejects a
    // duplicate completion before its serializer ticket can run.
    private volatile long _writeEvent;
    // Diagnostic timestamps: one in-flight WRITE per socket, no event allocation.
    // Sampled only with -Dcio.writeProfile=true; no effect on SEND ownership.
    private volatile long _profileWritePostNs;
    private volatile long _profileWriteCallbackNs;
    private long _profileCompletionConsumedNs;
    private boolean _profileAwaitingNextPost;

    public static String writeProfileReport() { return CIOWriteProfile.snapshot(); }
    private static final int WRITE_DONE = 1;
    private static final int WRITE_FAILED = 2;
    private static final int GATHER_DONE = 3;
    private static final int GATHER_FAILED = 4;
    private volatile int _readKick;
    // At most one deferred READ pump task per socket; the socket itself is
    // the reusable Runnable, with no per-frame continuation allocation.
    private volatile int _readContinuationQueued;
    private volatile Executor _ioExecutor;
    // Zero disables fairness; a positive limit is a maximum number of complete
    // frames one READ pump may dispatch before yielding to other I/O sockets.
    private static final int READ_FRAME_BUDGET = Math.max(0,
            Math.min(256, Integer.getInteger("cio.readFrameBudget", 0)));
    static boolean readFairnessEnabled() { return READ_FRAME_BUDGET != 0; }
    // A/B switch: defer automatic SEND burst flushing until the current READ
    // buffer pass ends, but only if that buffer holds multiple complete frames.
    // Forced flushSendBurst(), close and READ-pressure boundaries stay intact.
    private static final boolean READ_PASS_BURST = Boolean.parseBoolean(
            System.getProperty("cio.readPassBurst", "true"));
    // Most window-1 game requests are below this size. Do not inspect the
    // packet header or enter a burst scope unless the READ holds enough data
    // for meaningful cross-request batching.
    private static final int READ_PASS_MIN_BUFFERED_BYTES = Math.max(20, Math.min(4096,
            Integer.getInteger("cio.readPassMinBufferedBytes", 64)));
    // READ completion is consumed only by the existing per-socket READ pump.
    // 0=empty, 1=failure, >=2=successful completion (transferred bytes + 2).
    // This keeps _readPending and zero-completion handling off foreign I/O threads.
    private volatile int _readEvent;
    private static final VarHandle CLOSED, CLOSE_NOTIFIED, READ_KICK, READ_ACTIVE,
            WRITE_EVENT, READ_EVENT, READ_CONTINUATION_QUEUED, SOCKET_TICKET, SOCKET_PENDING, SOCKET_DRAINING,
            SOCKET_START_PENDING,
            DISCONNECTING, CLOSING, ON_DRAINED;
    private static final VarHandle SOCKET_CALLBACK_SLOT = MethodHandles.arrayElementVarHandle(long[].class);
    private static final VarHandle SOCKET_ARGUMENT_SLOT = MethodHandles.arrayElementVarHandle(long[].class);
    static {
        try {
            final MethodHandles.Lookup lookup = MethodHandles.lookup();
            CLOSED = lookup.findVarHandle(CIOUserSocket.class, "_closed", int.class);
            CLOSE_NOTIFIED = lookup.findVarHandle(CIOUserSocket.class, "_closeNotified", int.class);
            SOCKET_TICKET = lookup.findVarHandle(CIOUserSocket.class, "_socketTicket", long.class);
            SOCKET_PENDING = lookup.findVarHandle(CIOUserSocket.class, "_socketPending", int.class);
            SOCKET_DRAINING = lookup.findVarHandle(CIOUserSocket.class, "_socketDraining", int.class);
            SOCKET_START_PENDING = lookup.findVarHandle(CIOUserSocket.class, "_socketStartPending", int.class);
            WRITE_EVENT = lookup.findVarHandle(CIOUserSocket.class, "_writeEvent", long.class);
            READ_KICK = lookup.findVarHandle(CIOUserSocket.class, "_readKick", int.class);
            READ_EVENT = lookup.findVarHandle(CIOUserSocket.class, "_readEvent", int.class);
            READ_CONTINUATION_QUEUED = lookup.findVarHandle(CIOUserSocket.class,
                    "_readContinuationQueued", int.class);
            READ_ACTIVE = lookup.findVarHandle(CIOUserSocket.class, "_readActive", int.class);
            DISCONNECTING = lookup.findVarHandle(CIOUserSocket.class, "_disconnecting", int.class);
            CLOSING = lookup.findVarHandle(CIOUserSocket.class, "_closing", int.class);
            ON_DRAINED = lookup.findVarHandle(CIOUserSocket.class, "_onDrained", Runnable.class);
        } catch (ReflectiveOperationException e) {
            throw new ExceptionInInitializerError(e);
        }
    }

    // One reusable flush list per CIO owner thread. This is not a packet queue:
    // leases remain owned by their connections, and no additional worker is used.
    private static final ThreadLocal<SendBurst> SEND_BURST = new ThreadLocal<>();
    private SendBurst _burstOwner;
    // Set under the socket state lock only when a burst first attaches.
    private int _burstWriteStartBytes = BURST_MAX_BYTES;
    // One producer-owned, not-yet-published packed SEND ticket per socket.
    // Reserved in FIFO order but never visible to the serializer until sealed.
    // No extra queue/worker; the existing SendBurst scope seals it in finally.
    // Experimental A/B gate: keep the verified low-load path as the default
    // until matched throughput/p99/CPU runs establish a global win.
    private static final boolean PRODUCER_BURST_TICKETS = Boolean.parseBoolean(
            System.getProperty("cio.producerBurstTickets", "false"));
    // Experimental: avoid a separate SEND_START ticket for foreign callers.
    // Retain the original ticket path unless a matched correctness/CPU trial
    // explicitly opts in; no new worker or packet queue is introduced.
    private static final boolean COALESCE_SEND_START = Boolean.parseBoolean(
            System.getProperty("cio.coalesceSendStart", "true"));
    // P5-A A/B: retire an uncontended WRITE completion under the existing
    // serializer token without reserving a redundant callback ring ticket.
    private static final boolean WRITE_COMPLETION_FAST_PATH = Boolean.parseBoolean(
            System.getProperty("cio.writeCompletionFastPath", "false"));
    // P5-B A/B, opt-in until matched TCP/Netty measurements. The common
    // same-owner inline completion avoids a redundant serializer ticket.
    private static final boolean INLINE_WRITE_COMPLETION = Boolean.parseBoolean(
            System.getProperty("cio.inlineWriteCompletion", "false"));
    // Experimental P6-A: one already-published first Action SEND may be
    // consumed by the existing SendBurst.flush() instead of entering the
    // serializer twice. Disabled until matched TCP performance checks pass.
    private static final boolean DEFER_OWNED_BURST_DRAIN = Boolean.parseBoolean(
            System.getProperty("cio.deferOwnedBurstDrain", "true"));
    // P6-B A/B: select the sole ready WRITE in acceptStagedSend's existing
    // admission lock. Never invoke the NIO.2 provider under that lock.
    // Keep the gather, queued, and already-pending SEND_START paths unchanged.
    private static final boolean FUSE_STAGED_WRITE_SELECTION = Boolean.parseBoolean(
            System.getProperty("cio.fuseStagedWriteSelection", "true"));
    private CIOBufferPool.Lease _producerLease;
    private long _producerTicket;
    // Only payload reservations, not WRITE_COMPLETE/SEND_START control tickets,
    // break producer-local packing. All payload reservations hold _stateLock.
    private int _payloadOrderEpoch;
    private int _producerOrderEpoch;
    private static final int BURST_MAX_BYTES = 8192;
    // READ-pass-only WRITE start threshold. Does not alter action/producer packing.
    private static final int READ_PASS_WRITE_START_BYTES = 32 * 1024;
    // Scatter/gather covers multiple independent 16K leases; this is not a lease size.
    private static final int GATHER_MAX_BYTES = 64 * 1024;
    private static final int BURST_INITIAL_SOCKETS = 32;
    private static final int BURST_MAX_SOCKETS = 256;

    private static final class SendBurst {
        // A burst never migrates between threads: the owning thread is fixed
        // when its ThreadLocal holder is first created.
        final Thread thread = Thread.currentThread();
        CIOUserSocket[] sockets = new CIOUserSocket[BURST_INITIAL_SOCKETS];
        int size;
        int depth;
        int readPassDepth;
        boolean flushing;

        boolean attach(CIOUserSocket socket) {
            if (flushing) return false;
            if (socket._burstOwner == this) return true;
            // Grow only when a large AOI burst actually needs more sockets.
            // The hard cap bounds how long a CIO owner can defer initial WRITEs.
            if (size == sockets.length) {
                if (size >= BURST_MAX_SOCKETS) return false;
                sockets = java.util.Arrays.copyOf(sockets,
                        Math.min(BURST_MAX_SOCKETS, sockets.length << 1));
            }
            sockets[size++] = socket;
            socket._burstOwner = this;

            return true;
        }

        void flush() {
            // Single-request dispatch ends with a second flush check. Avoid
            // the empty callback scope without changing ticket publication.
            if (flushing || size == 0) return;
            flushing = true;
            final int n = size;
            size = 0;
            try {
                for (int i = 0; i < n; i++) {
                    final CIOUserSocket socket = sockets[i];
                    sockets[i] = null;
                    final boolean publish;
                    socket._stateLock.lock(); try {
                        publish = socket.publishProducerLeaseLocked();
                        if (socket._burstOwner == this) {
                            socket._burstOwner = null;
                            socket._burstWriteStartBytes = BURST_MAX_BYTES;
                        }
                    } finally { socket._stateLock.unlock(); }
                    // The reserved FIFO ticket must be visible before WRITE is kicked.
                    if (publish) socket.drainSocketCallbacks();
                    // May have been posted by another producer; kickWrite is idempotent.
                    try { socket.kickWrite(); }
                    catch (Throwable failure) { socket.close(); }
                }
            } finally {
                flushing = false;
            }
        }
    }

    /** Scope only current direct opcode dispatch; leave external producers on immediate SEND. */
    public static void beginSendBurst() {
        SendBurst burst = SEND_BURST.get();
        if (burst == null) {
            burst = new SendBurst();
            SEND_BURST.set(burst);
        }
        ++burst.depth;
    }

    private static void beginReadPassSendBurst() {
        beginSendBurst();
        ++SEND_BURST.get().readPassDepth;
    }

    private static void endReadPassSendBurst() {
        final SendBurst burst = SEND_BURST.get();
        if (burst == null || burst.readPassDepth <= 0)
            throw new IllegalStateException("unbalanced READ-pass SEND burst");
        --burst.readPassDepth;
        endSendBurst();
    }

    public static void endSendBurst() {
        final SendBurst burst = SEND_BURST.get();
        if (burst == null || burst.depth <= 0)
            throw new IllegalStateException("unbalanced SEND burst");
        if (--burst.depth == 0) burst.flush();
    }

    /** Flush the current game command without discarding the owner-local burst scope. */
    public static void flushSendBurst() {
        final SendBurst burst = SEND_BURST.get();
        if (burst != null && burst.depth != 0) burst.flush();
    }

    /* Queue and active WRITE mutations use _stateLock, never a global pool lock. */
    private int _head;
    private int _tail;
    private int _queued;
    // Frames admitted to the 512-slot serializer but not yet attached to SEND.
    private int _stagedSends;
    // Byte-based connection-local backpressure, independent of the physical lease bound.
    // Counts all committed wire bytes including gather writes and packed frames.
    private static final int MAX_PENDING_WIRE_BYTES = Math.max(131072,
            Math.min(8 * 1024 * 1024, Integer.getInteger("cio.maxPendingWireBytes", 4 * 1024 * 1024)));
    // Flow-control stops inbound processing before a slow client accumulates
    // hundreds of 16K leases. The wire-byte and physical SEND lease caps are
    // preserved; logical frame pressure is READ backpressure, not a lease cap.
    private static final boolean SEND_READ_WATERMARK = Boolean.parseBoolean(
            System.getProperty("cio.sendReadWatermark", "true"));
    private static final int SEND_READ_HIGH_WATER_BYTES = Math.min(
            MAX_PENDING_WIRE_BYTES * 3 / 4,
            Math.max(64 * 1024, Integer.getInteger("cio.sendReadHighBytes", 256 * 1024)));
    private static final int SEND_READ_LOW_WATER_BYTES = SEND_READ_HIGH_WATER_BYTES / 2;
    private static final int SEND_READ_HIGH_WATER_FRAMES = Math.max(4, Math.min(256,
            Integer.getInteger("cio.sendReadHighFrames", READ_PASS_BURST ? 256 : 32)));
    private static final int SEND_READ_LOW_WATER_FRAMES = SEND_READ_HIGH_WATER_FRAMES / 2;
    private int _outstandingWireBytes;
    // Uncommitted direct producers own pooled leases too. Include their maximum
    // wire sizes in admission and READ watermark decisions until commit/abort.
    private int _reservedWireBytes;
    private int _outstandingFrames;
    private volatile boolean _sendReadPaused;

    /** Always invoked with this socket's state lock held. */
    private boolean canAdmitBytes(int count) {
        return count > 0 && count <= MAX_PENDING_WIRE_BYTES - _outstandingWireBytes - _reservedWireBytes;
    }

    /** Physical SEND leases under _stateLock, including every in-flight gather member. */
    private int physicalSendLeasesLocked() {
        return _queued + _reservedDirect + _stagedSends
                + (_writing == null ? 0 : _gatherCount > 0 ? _gatherCount : 1);
    }

    private boolean physicalSendFullLocked() {
        return physicalSendLeasesLocked() >= _maxQueuedFrames + 1;
    }

    // _maxQueuedFrames bounds physical SEND leases (all gather members plus
    // queued leases and reservations), not packets packed into those leases. The
    // logical packet count is separately tracked for READ backpressure.  Each
    // accepted frame consumes at least HEADER_BYTES + 1 wire bytes, so the
    // MAX_PENDING_WIRE_BYTES admission cap also strictly bounds that count.

    private void bytesAdmitted(int count) {
        bytesAdmittedBatch(count, 1);
    }

    /** Caller holds _stateLock. A validated batch publishes one watermark change. */
    private void bytesAdmittedBatch(int wireBytes, int frames) {
        _outstandingWireBytes += wireBytes;
        _outstandingFrames += frames;
        updateSendReadPauseLocked();
    }

    /** Under the state lock, accounting both published and uncommitted frames. */
    private boolean updateSendReadPauseLocked() {
        if (!SEND_READ_WATERMARK) return false;
        final int bytes = _outstandingWireBytes + _reservedWireBytes;
        final int frames = _outstandingFrames + _reservedDirect;
        if (!_sendReadPaused && (bytes >= SEND_READ_HIGH_WATER_BYTES
                || frames >= SEND_READ_HIGH_WATER_FRAMES)) {
            _sendReadPaused = true;
        } else if (_sendReadPaused && bytes <= SEND_READ_LOW_WATER_BYTES
                && frames <= SEND_READ_LOW_WATER_FRAMES) {
            _sendReadPaused = false;
            return _closed == 0 && _readActive != 0;
        }
        return false;
    }

    /** Under the state lock; caller kicks READ only after unlocking. */
    private boolean bytesReleased(int count, int frames) {
        _outstandingWireBytes -= count;
        _outstandingFrames -= frames;
        if (_outstandingWireBytes < 0 || _outstandingFrames < 0)
            throw new IllegalStateException("negative outstanding SEND accounting");
        return updateSendReadPauseLocked();
    }

    // Reserved producer slots for existing direct-frame serializers. A reservation
    // survives the serializer and is consumed atomically by commit or abort.
    private int _reservedDirect;
    private volatile CIOBufferPool.Lease _writing;
    // State-lock-owned first Action lease: only while a P6-A SEND_ENQUEUE is
    // published but has not yet been accepted by its FIFO serializer callback.
    // Do not store a lease after commit: it may be recycled by the pool.
    private CIOBufferPool.Lease _stagedBurstAction;
    // Per-connection fixed gather array: no byte-copy and no batch allocation.
    private static final int GATHER_MAX_FRAMES = 8;
    // Medium S-packets share the same ordered wire batch when space permits.
    private static final int PACK_MAX_FRAME_BYTES = 2048;
    private CIOBufferPool.Lease[] _gatherFrames;
    private ByteBuffer[] _gatherBuffers;
    private int _gatherCount;
    private int _zeroWriteCompletions;
    private int _zeroReadCompletions;

    /* READ lease is released only after the last completion callback, never during a pending read. */
    private volatile int _readActive;
    private CIOBufferPool.Lease _reading;
    private volatile boolean _readReleased;
    private volatile boolean _readPending;
    // Only the READ pump touches this; preserves buffered frames if an ACK races pause.
    private boolean _readYielded;
    // READ pump only. Do not add a ThreadLocal.get() to single-frame dispatch.
    private boolean _readPassBurstActive;

    // One reusable callback across all connections. A callback only publishes its
    // result; the socket READ pump owns the receive-buffer and READ state changes.
    private static final CompletionHandler<Integer, CIOUserSocket> READ_COMPLETION = new CompletionHandler<>() {
        @Override
        public void completed(Integer bytes, CIOUserSocket connection) {
            connection.publishReadCompletion(bytes == null ? -1 : bytes.intValue());
        }
        @Override
        public void failed(Throwable error, CIOUserSocket connection) {
            connection.publishReadCompletion(-1);
        }
    };

    private void publishReadCompletion(int bytes) {

        final int event = bytes < 0 || bytes > CIOBufferPool.LARGE_BYTES
                ? 1 : bytes + 2;
        if (!READ_EVENT.compareAndSet(this, 0, event)) {
            // An already-published completion cannot be overwritten by a
            // second callback; the first one must still release its READ lease.
            close();
            return;
        }
        kickRead();
    }

    private static final CompletionHandler<Integer, CIOUserSocket> WRITE_COMPLETION = new CompletionHandler<>() {
        @Override
        public void completed(Integer bytes, CIOUserSocket connection) {

            connection.publishWriteCompletion(WRITE_DONE, WRITE_FAILED,
                    bytes == null ? -1L : bytes.longValue());
        }
        @Override
        public void failed(Throwable error, CIOUserSocket connection) {
            connection.publishWriteCompletion(WRITE_DONE, WRITE_FAILED, -1L);
        }
    };

    private static final CompletionHandler<Long, CIOUserSocket> GATHER_COMPLETION = new CompletionHandler<>() {
        @Override
        public void completed(Long bytes, CIOUserSocket connection) {

            connection.publishWriteCompletion(GATHER_DONE, GATHER_FAILED,
                    bytes == null ? -1L : bytes.longValue());
        }
        @Override
        public void failed(Throwable error, CIOUserSocket connection) {
            connection.publishWriteCompletion(GATHER_DONE, GATHER_FAILED, -1L);
        }
    };

    /**
     * A WRITE's pending I/O keeps its lease attached to this socket. The NIO.2
     * completion thread only publishes the result; the existing WRITE pump is
     * the sole executor of completion, next-send and buffer-release transitions.
     * There is only one in-flight WRITE per connection, so a single completion
     * mailbox is sufficient. The existing bounded _pending ring continues to
     * retain queued outbound buffers without a redundant callback queue.
     */
    private void publishWriteCompletion(int okKind, int failKind, long transferred) {
        if (CIOWriteProfile.ENABLED) {
            final long now = System.nanoTime();
            final long posted = _profileWritePostNs;
            if (posted != 0L)
                CIOWriteProfile.record(CIOWriteProfile.POST_TO_COMPLETION, now - posted);
            _profileWriteCallbackNs = now;
        }
        final boolean ok = transferred >= 0L && transferred <= Integer.MAX_VALUE;
        final long event = (ok ? (transferred << 3) | okKind : failKind);
        if (!WRITE_EVENT.compareAndSet(this, 0L, event)) {
            // A second completion for one in-flight WRITE is a transport violation.
            // Never overwrite the first callback or release its lease twice.
            close();
            return;
        }
        // Most Linux NIO.2 completions run inside write() while this thread
        // already owns the serializer. Defer their retirement until the write
        // invocation returns, then consume in the existing nonrecursive loop.
        if (INLINE_WRITE_COMPLETION && deferOwnerInlineWriteCompletion(event)) return;
        // Uncontended completion already owns the only in-flight WRITE. Avoid
        // allocating a 512-slot callback ticket when no earlier SEND ticket
        // exists. Do not bypass reserved/unpublished tickets or an active
        // NIO.2 write() invocation (including its inline completion callback).
        if (WRITE_COMPLETION_FAST_PATH && tryDrainUncontendedWriteCompletion(event)) return;
        if (!serializeSocketCallback(SOCKET_WRITE_COMPLETE, event)) {
            // The completion remains in the mailbox. Close and let the current
            // drainer retire it once earlier callback tickets have finished.
            close();
        }
    }

    /**
     * Only the serializer owner may publish this local deferral. A ticket
     * reserved before this WRITE callback must still execute first. While
     * dispatching a ticket, _socketPending includes that one active ticket;
     * it has already been consumed and cannot be an earlier reservation.
     * Checking the pending reservation count first also sees unpublished
     * producer tickets whose ring slots are not yet visible.
     */
    private boolean deferOwnerInlineWriteCompletion(long event) {
        if (!_socketPosting || _socketOwner != Thread.currentThread()
                || _inlineWriteCompletion != 0L) return false;
        final int active = _socketExecutingTicket ? 1 : 0;
        if ((int) SOCKET_PENDING.getVolatile(this) != active
                || (long) SOCKET_TICKET.getVolatile(this) != _socketHead
                || (COALESCE_SEND_START
                    && (int) SOCKET_START_PENDING.getAcquire(this) != 0)) return false;
        _inlineWriteCompletion = event;
        return true;
    }

    /**
     * Claim the existing serializer token only when its FIFO is empty.
     * A concurrent producer's reservation is visible through _socketPending
     * before its ticket is published. Any contention takes the original
     * ticket path without changing WRITE ownership or lease lifetime.
     */
    private boolean tryDrainUncontendedWriteCompletion(long event) {
        if (!SOCKET_DRAINING.compareAndSet(this, 0, 1)) return false;
        if ((int) SOCKET_PENDING.getVolatile(this) != 0
                || (long) SOCKET_TICKET.getVolatile(this) != _socketHead
                || (COALESCE_SEND_START
                    && (int) SOCKET_START_PENDING.getAcquire(this) != 0)) {
            // We have not started a callback. The normal ticket publisher
            // below will wake the drainer after the token is released.
            SOCKET_DRAINING.setRelease(this, 0);
            return false;
        }
        _socketOwner = Thread.currentThread();
        try {
            if (WRITE_EVENT.compareAndSet(this, event, 0L))
                drainWriteCompletion(event);
        } catch (Throwable failure) {
            close();
        }
        // Keep ownership until all tickets reserved during this completion
        // have been observed. This is the same release/reacquire handshake
        // used by normal callback dispatch.
        drainSocketCallbacksAcquired();
        return true;
    }

    /** Runs only with the socket serializer's execution token. */
    private void drainWriteCompletion(long event) {
        if (CIOWriteProfile.ENABLED) {
            final long now = System.nanoTime();
            if (_profileWriteCallbackNs != 0L)
                CIOWriteProfile.record(CIOWriteProfile.COMPLETION_TO_SERIALIZER,
                        now - _profileWriteCallbackNs);
            _profileCompletionConsumedNs = now;
        }
        final int kind = (int) (event & 7L);
        if (kind == WRITE_FAILED) {
            final CIOBufferPool.Lease lease = _writing;
            if (lease != null) completeWrite(lease, false);
            else close();
            return;
        }
        if (kind == GATHER_FAILED) {
            completeGather(false);
            return;
        }
        if (kind == WRITE_DONE) {
            final CIOBufferPool.Lease lease = _writing;
            if (lease == null) { close(); return; }
            if (_closed != 0) { completeWrite(lease, false); return; }
            final ByteBuffer buffer = lease.buffer();
            if (buffer.hasRemaining()) {
                final long written = event >>> 3;

                if (written == 0L && ++_zeroWriteCompletions >= 8) {
                    completeWrite(lease, false);
                    return;
                }
                if (written != 0L) _zeroWriteCompletions = 0;
                lease._ioPending = false;
                if (CIOWriteProfile.ENABLED) _profileAwaitingNextPost = true;
                kickWrite();
            } else {
                _zeroWriteCompletions = 0;
                completeWrite(lease, true);
            }
            return;
        }
        if (kind == GATHER_DONE) {
            if (_closed != 0) { completeGather(false); return; }
            boolean remaining = false;
            for (int i = 0; i < _gatherCount; i++) {
                if (_gatherBuffers[i].hasRemaining()) {
                    remaining = true;
                    break;
                }
            }
            if (remaining) {
                final long written = event >>> 3;

                if (written == 0L && ++_zeroWriteCompletions >= 8) {
                    completeGather(false);
                    return;
                }
                if (written != 0L) _zeroWriteCompletions = 0;
                if (_writing == null) { close(); return; }
                _writing._ioPending = false;
                if (CIOWriteProfile.ENABLED) _profileAwaitingNextPost = true;
                kickWrite();
            } else {
                _zeroWriteCompletions = 0;
                completeGather(true);
            }
            return;
        }
        close();
    }

    public CIOUserSocket(AsynchronousSocketChannel channel, CIOBufferPool pool,
                         CIOThreadCallback scheduler, String remoteAddress,
                         int affinityShard, int maxQueuedFrames, Closed closedCallback) {
        if (channel == null || pool == null || scheduler == null
                || affinityShard < 0 || affinityShard >= scheduler.shardCount()
                || maxQueuedFrames < 1)
            throw new IllegalArgumentException("invalid game socket arguments");
        _channel = channel;
        _pool = pool;
        _remoteAddress = remoteAddress == null ? "Unknown" : remoteAddress;
        _affinityShard = affinityShard;
        _closedCallback = closedCallback;
        _maxQueuedFrames = maxQueuedFrames;
    }

    /** Bind the existing NIO.2 worker executor before the first READ is posted. */
    void bindIoExecutor(Executor executor) {
        if (executor == null || _ioExecutor != null || _readActive != 0)
            throw new IllegalStateException("READ executor already bound or started");
        _ioExecutor = executor;
    }

    void bindClient(CIOClient client) {
        if (client == null || client.getConnection() != this || _client != null || _closed != 0)
            throw new IllegalStateException("socket client already bound or closed");
        _client = client;
    }

    CIOClient client() { return _client; }

    public String getRemoteAddress() { return _remoteAddress; }
    public int affinityShard() { return _affinityShard; }

    public boolean isClientConnected() {
        return isOpen() && _closing == 0 && _disconnecting == 0;
    }

    public int getEstimateQueueSize() { return pendingSendFrames(); }
    public void read() { startRead(); }

    @SuppressWarnings({"rawtypes", "unchecked"})
    public void enqueuePacket(WritablePacket packet) {
        if (packet == null || !isClientConnected()) return;
        final CIOClient client = _client;
        if (client == null || !tryWritePacket(client, packet)) close();
    }

    /**
     * Graceful close: 0=open, 1=waiting to admit final, 3=encoding final,
     * 2=draining. A WRITE completion must never close before the final encoder
     * attaches its serializer ticket. This path is distinct from
     * close(), which remains the immediate error/cancellation path.
     */
    @SuppressWarnings({"rawtypes", "unchecked"})
    public void requestClientClose(WritablePacket packet) {
        if (_disconnecting != 0 || !isOpen()
                || !CLOSING.compareAndSet(this, 0, 1)) return;
        if (_client == null) {
            close();
            return;
        }
        // Wait for previously accepted SENDs before admitting the final packet.
        // Saturated local slots cannot cause an error-close that discards the
        // accepted prefix. The final packet is encoded exactly once.
        boolean publish;
        _stateLock.lock();
        try {
            // close() may win after the open-state CAS and before this lock.
            // Never reattach a final packet after forced-close cleanup.
            if (_closed != 0) return;
            _deferredClosePacket = packet;
            publish = publishProducerLeaseLocked();
        } finally { _stateLock.unlock(); }
        if (publish) drainSocketCallbacks();
        flushSendBurst();
        if (packet == null) CLOSING.setRelease(this, 2);
        kickWrite();
        onSendProgress();
    }

    public boolean sendAction(int objectId, int actionId) {
        if (!isClientConnected()) return false;
        if (tryWriteAction(objectId, actionId)) return true;
        close();
        return false;
    }

    public boolean beginClientDisconnect() {
        if (!DISCONNECTING.compareAndSet(this, 0, 1)) return false;
        _closing = 1;
        ON_DRAINED.setVolatile(this, null);
        return true;
    }

    public void finishClientDisconnect() { close(); }
    public int drainOnOwner() { return 0; }
    public void onSendDrainedOwner() { onSendProgress(); }
    public boolean hasDrainWorkOnOwner() { return getEstimateQueueSize() != 0; }
    public void requestDrain() { /* WRITE completion pump owns the drain. */ }

    public boolean whenWriteDrained(Runnable callback) {
        if (callback == null || _closed != 0) return false;
        ON_DRAINED.setVolatile(this, callback);
        if (_closed != 0) {
            ON_DRAINED.compareAndSet(this, callback, null);
            return false;
        }
        if (isWriteIdle()) onSendProgress();
        return true;
    }

    public void cancelWriteDrainCallback() {
        ON_DRAINED.setVolatile(this, null);
    }

    private void onSendProgress() {
        // Admission is blocked during close. An accepted encoder reservation
        // remains visible until it has attached its FIFO ticket.
        if (_closing == 0 && ON_DRAINED.getVolatile(this) == null) return;
        WritablePacket<CIOClient> finalPacket = null;
        Runnable callback = null;
        _stateLock.lock();
        try {
            if (!isWriteIdleLocked() || _closed != 0) return;
            if (_closing == 1 && _deferredClosePacket != null) {
                finalPacket = _deferredClosePacket;
                _deferredClosePacket = null;
                // Prevent another completion thread from encoding it twice.
                _closing = 3;
            } else if (_closing != 1 && _closing != 3) {
                callback = (Runnable) ON_DRAINED.getAndSet(this, null);
            }
        } finally { _stateLock.unlock(); }
        if (finalPacket != null) {
            final boolean accepted;
            try {
                accepted = tryWritePacketInternal(_client, finalPacket, true);
            } catch (Throwable failed) {
                close();
                return;
            }
            if (!accepted) {
                // At this point the earlier accepted prefix has drained.
                close();
                return;
            }
            CLOSING.setRelease(this, 2);
            kickWrite();
            onSendProgress();
            return;
        }
        if (callback != null) callback.run();
        // The callback may have admitted a new SEND. The earlier idle
        // snapshot is not a valid close decision: recheck after it returns.
        if (_closing == 2) {
            boolean closeNow;
            _stateLock.lock();
            try { closeNow = _closed == 0 && _closing == 2 && isWriteIdleLocked(); }
            finally { _stateLock.unlock(); }
            if (closeNow) close();
        }
    }

    /** Acquire a packet-writing slot; false/null means backpressure, not a silent successful SEND. */
    public CIOBufferPool.Lease beginOutboundFrame(int maxWireBytes) {
        return (_closed != 0) ? null : _pool.acquireSend(maxWireBytes);
    }

    /**
     * Direct-frame entry point compatible with CIOUserSocket's existing packet API.
     * Reserve one bounded queue position before exposing the writable buffer.
     * The reusable handle is owned by its pooled lease, not allocated per packet.
     */
    public CIOFrame beginDirectFrame(int maxWireBytes) {
        int slot = -1;
        boolean refused = false;
        boolean publishProducer = false;
        _stateLock.lock();
        try {
            if (_closed != 0 || _closing != 0) return null;
            if (maxWireBytes <= CIOBufferPool.HEADER_BYTES
                    || maxWireBytes > CIOBufferPool.MAX_WIRE_BYTES
                    || !canAdmitBytes(maxWireBytes)) {
                rejectSend(REJECT_WIRE_BYTES);
                refused = true;
            } else if (physicalSendFullLocked()) {
                rejectSend(REJECT_LOCAL_FRAMES);
                refused = true;
            } else {
                // A frame reserves FIFO BEFORE it is encoded, even when
                // the producer is also the current callback owner.
                for (;;) {
                    final int pending = (int) SOCKET_PENDING.getVolatile(this);
                    if (pending >= SOCKET_REJECT_AT) {
                        rejectSend(REJECT_SERIALIZER);
                        refused = true;
                        break;
                    }
                    if (SOCKET_PENDING.compareAndSet(this, pending, pending + 1)) break;
                }
                if (!refused) slot = (int) (long) SOCKET_TICKET.getAndAdd(this, 1L) & SOCKET_MASK;
                if (!refused) {
                    if (_producerLease != null) {
                        ++_payloadOrderEpoch;
                        publishProducer = publishProducerLeaseLocked();
                    }
                    ++_reservedDirect;
                    _reservedWireBytes += maxWireBytes;
                    updateSendReadPauseLocked();
                }
            }
        } finally { _stateLock.unlock(); }
        if (publishProducer) drainSocketCallbacks();
        if (refused) {
            // A packet that cannot be admitted must never look like a successful SEND.
            close();
            return null;
        }

        CIOBufferPool.Lease lease = null;
        try {
            lease = beginOutboundFrame(maxWireBytes);
            if (lease != null) {
                final CIOFrame frame = lease.beginDirectFrame(this);
                frame.setReservation(maxWireBytes, slot);
                return frame;
            }
            rejectSend(REJECT_POOL);
        } catch (Throwable failure) {
            rejectSend(REJECT_ENCODING);
            // Preserve the original failure, but release the ticket and lease.
            rollbackDirectBegin(maxWireBytes, slot, lease);
            close();
            throw failure;
        }
        rollbackDirectBegin(maxWireBytes, slot, lease);
        close();
        return null;
    }

    private void cancelReservedTicketLocked(int slot) {
        if (slot < 0) return;
        _socketSendArguments[slot] = null;
        SOCKET_ARGUMENT_SLOT.setRelease(_socketArguments, slot, 0L);
        SOCKET_CALLBACK_SLOT.setRelease(_socketCallbacks, slot, SOCKET_CANCELLED);
    }

    private void rollbackDirectBegin(int bytes, int slot,
            CIOBufferPool.Lease lease) {
        boolean resumeRead;
        _stateLock.lock();
        try {
            --_reservedDirect;
            _reservedWireBytes -= bytes;
            cancelReservedTicketLocked(slot);
            if (lease != null && lease.reserved()) abortOutboundFrame(lease);
            resumeRead = updateSendReadPauseLocked();
        } finally { _stateLock.unlock(); }
        if (slot >= 0) drainSocketCallbacks();
        if (resumeRead) kickRead();
        notifyClosedWhenReleased();
    }

    public boolean commitDirectFrame(CIOFrame frame) {
        if (frame == null) return false;
        final CIOBufferPool.Lease lease = frame.ioLease(this);
        final int reservedBytes = frame.reservedBytes();
        final int slot = frame.reservedTicket();
        boolean accepted = false;
        boolean direct = false;
        boolean resumeRead = false;
        _stateLock.lock();
        try {
            --_reservedDirect;
            _reservedWireBytes -= reservedBytes;
            try {
                // This reservation was acquired by beginDirectFrame().
                direct = false;
                accepted = stageOutboundFrameLocked(lease, direct, slot);
                if (accepted) frame.finishIO();
            } finally {
                if (!accepted) {
                    ++_reservedDirect;
                    _reservedWireBytes += reservedBytes;
                }
                resumeRead = updateSendReadPauseLocked();
            }
        } finally { _stateLock.unlock(); }
        if (accepted) finishStagedSend(lease, direct);
        if (resumeRead && _closed == 0) kickRead();
        if (!accepted) {
            // The caller's finally aborts the still-owned frame/ticket.
            close();
        }
        return accepted;
    }

    public void abortDirectFrame(CIOFrame frame) {
        if (frame == null) return;
        final CIOBufferPool.Lease lease = frame.ioLease(this);
        final int bytes = frame.reservedBytes();
        final int slot = frame.reservedTicket();
        boolean resumeRead;
        _stateLock.lock();
        try {
            --_reservedDirect;
            _reservedWireBytes -= bytes;
            frame.finishIO();
            cancelReservedTicketLocked(slot);
            abortOutboundFrame(lease);
            resumeRead = updateSendReadPauseLocked();
        } finally { _stateLock.unlock(); }
        if (slot >= 0) drainSocketCallbacks();
        if (resumeRead) kickRead();
        // Direct send failure is fatal for packet-stream consistency: never
        // silently lose an attack/HP update when callers ignore the boolean.
        if (_closed == 0) close();
        notifyClosedWhenReleased();
    }

    /**
     * Allocate the large pending ring only when a connection actually has a burst.
     * Called with the connection state lock held. The ring grows at most to the
     * original configured bound; no extra queue or per-frame nodes are created.
     */
    private boolean ensurePendingSlot() {
        final CIOBufferPool.Lease[] old = _pending;
        if (old == null) {
            _pending = new CIOBufferPool.Lease[Math.min(_maxQueuedFrames, 8)];
            return true;
        }
        if (_queued < old.length) return true;
        if (old.length >= _maxQueuedFrames) return false;
        final int capacity = (int) Math.min((long) _maxQueuedFrames, (long) old.length << 1);
        final CIOBufferPool.Lease[] next = new CIOBufferPool.Lease[capacity];
        final int first = Math.min(_queued, old.length - _head);
        System.arraycopy(old, _head, next, 0, first);
        if (_queued > first) System.arraycopy(old, 0, next, first, _queued - first);
        _pending = next;
        _head = 0;
        _tail = _queued;
        return true;
    }

    /** Successful commit means accepted for asynchronous SEND, not delivered to the peer. */
    public boolean commitOutboundFrame(CIOBufferPool.Lease lease) {
        final boolean admitted;
        final boolean direct = false;
        _stateLock.lock(); try {
            // Without an early reservation this legacy commit must never
            // bypass queued SEND tickets just because it runs on the owner.
            admitted = stageOutboundFrameLocked(lease, direct);
        } finally { _stateLock.unlock(); }
        if (admitted) finishStagedSend(lease, direct);
        return admitted;
    }

    private boolean stageOutboundFrameLocked(CIOBufferPool.Lease lease, boolean direct) {
        return stageOutboundFrameLocked(lease, direct, -1);
    }

    private boolean stageOutboundFrameLocked(CIOBufferPool.Lease lease, boolean direct,
            int reservedTicketSlot) {
        if (lease == null || !_pool.owns(lease) || !lease.reserved()) return false;
        final int length = lease.writer().position();
        if (length <= CIOBufferPool.HEADER_BYTES
                || length > lease._reservedWireBytes
                || length > CIOBufferPool.MAX_WIRE_BYTES
                || _closed != 0) return false;
        if (!canAdmitBytes(length)) return rejectSend(REJECT_WIRE_BYTES);
        if (physicalSendFullLocked())
            return rejectSend(REJECT_LOCAL_FRAMES);

        final int frames = lease._packedFrames ? lease._frameCount : 1;
        if (frames < 1) return rejectSend(REJECT_LOCAL_FRAMES);

        // Every staged SEND with no prior reservation takes a ticket unless
        // it is an inline completed action with no earlier work in the FIFO.
        int slot = reservedTicketSlot;
        if (!direct) {
            if (slot < 0) {
                for (;;) {
                    final int pending = (int) SOCKET_PENDING.getVolatile(this);
                    if (pending >= SOCKET_REJECT_AT) return rejectSend(REJECT_SERIALIZER);
                    if (SOCKET_PENDING.compareAndSet(this, pending, pending + 1)) break;
                }
                slot = (int) (long) SOCKET_TICKET.getAndAdd(this, 1L) & SOCKET_MASK;
                if (_producerLease != null) {
                    ++_payloadOrderEpoch;
                    publishProducerLeaseLocked();
                }
            }
            _socketSendArguments[slot] = lease;
            SOCKET_ARGUMENT_SLOT.setRelease(_socketArguments, slot, 0L);
        }
        ++_stagedSends;
        bytesAdmittedBatch(length, frames);
        final SendBurst burst = SEND_BURST.get();
        if (_burstOwner == null && burst != null && burst.depth != 0
                && _writing == null && _queued == 0) {
            final int startBytes = burst.readPassDepth != 0
                    ? READ_PASS_WRITE_START_BYTES : BURST_MAX_BYTES;
            if (_outstandingWireBytes <= startBytes && burst.attach(this))
                _burstWriteStartBytes = startBytes;
        }
        if (!direct) {
            if (CIOWriteProfile.ENABLED)
                SOCKET_ARGUMENT_SLOT.setRelease(_socketArguments, slot, System.nanoTime());
            SOCKET_CALLBACK_SLOT.setRelease(_socketCallbacks, slot, SOCKET_SEND_ENQUEUE);
        }
        return true;
    }

    private boolean isSocketSerializerOwner() {
        return _socketOwner == Thread.currentThread() && !_socketPosting;
    }

    /**
     * Inline only a fully encoded 8-byte action while executing the sole
     * serializer callback. _socketHead has already consumed that callback's
     * ticket. Foreign reservations or staged frames must never be bypassed.
     * Called with _stateLock held.
     */
    private boolean canInlineActionLocked() {
        return isSocketSerializerOwner()
                && (int) SOCKET_PENDING.getVolatile(this) == 1
                && (long) SOCKET_TICKET.getVolatile(this) == _socketHead
                && _reservedDirect == 0 && _stagedSends == 0;
    }

    // Evaluated only inside the existing action admission lock, after the
    // SEND_ENQUEUE slot has been release-published. The current producer's
    // live burst scope is responsible for the mandatory finally flush.
    private boolean canDeferOwnedBurstDrainLocked() {
        if (!DEFER_OWNED_BURST_DRAIN || !COALESCE_SEND_START
                || PRODUCER_BURST_TICKETS || _closed != 0 || _closing != 0
                || _sendReadPaused || _writing != null || _queued != 0
                || _stagedSends != 1 || _reservedDirect != 0
                || _producerLease != null
                || (int) SOCKET_START_PENDING.getVolatile(this) != 0
                || (int) SOCKET_DRAINING.getVolatile(this) != 0
                || (int) SOCKET_PENDING.getVolatile(this) != 1)
            return false;
        final SendBurst burst = _burstOwner;
        return burst != null && burst.thread == Thread.currentThread()
                && burst.depth != 0 && !burst.flushing;
    }

    /** Only this action admission path may defer an already-published SEND. */
    private void finishStagedSend(CIOBufferPool.Lease lease, boolean direct,
            boolean deferDrain) {
        if (deferDrain) return;
        finishStagedSend(lease, direct);
    }

    /** Direct SEND must run only after releasing the socket state lock. */
    private void finishStagedSend(CIOBufferPool.Lease lease, boolean direct) {
        if (!direct) {
            drainSocketCallbacks();
            return;
        }
        try {
            acceptStagedSend(lease);
        } catch (Throwable failure) {
            close();
        }
    }

    /** Consume SEND under the current socket serializer token. */
    private void acceptStagedSend(CIOBufferPool.Lease lease) {
        boolean start = false;
        boolean resumeRead = false;
        boolean success = false;
        CIOBufferPool.Lease selectedWrite = null;
        _stateLock.lock(); try {
            // The first published Action may have been packed by the same
            // burst before this callback acquired the state lock.
            if (_stagedBurstAction == lease) _stagedBurstAction = null;
            --_stagedSends;
            final int length = lease.writer().position();
            if (_closed == 0) {
                success = commitStagedOutboundFrameLocked(lease);
                if (success && _writing != null && !_writing._ioPending) {
                    start = _burstOwner == null
                            || _outstandingWireBytes >= _burstWriteStartBytes;
                    // For the common single-write case, avoid a second
                    // _stateLock acquisition in driveWriteOnce(). This
                    // callback already owns the FIFO serializer token. An
                    // outstanding coalesced SEND_START is left to its normal
                    // loop, and multi-lease gather remains on the old path.
                    if (start && FUSE_STAGED_WRITE_SELECTION
                            && !CIOWriteProfile.ENABLED
                            && isSocketSerializerOwner()
                            && _queued == 0 && _gatherCount == 0
                            && _stagedSends == 0 && _reservedDirect == 0
                            && _producerLease == null
                            && (int) SOCKET_PENDING.getVolatile(this) == 1) {
                        // The burst flush may have scheduled a coalesced
                        // start before this final SEND_ENQUEUE is consumed.
                        // With no other reserved FIFO ticket, absorb that
                        // wakeup here; otherwise its old outer-loop path
                        // must remain responsible for the next WRITE.
                        final int startPending = COALESCE_SEND_START
                                ? (int) SOCKET_START_PENDING.getAcquire(this) : 0;
                        if (startPending == 0 || DEFER_OWNED_BURST_DRAIN) {
                            if (startPending != 0)
                                SOCKET_START_PENDING.getAndSet(this, 0);
                            selectedWrite = _writing;
                            selectedWrite._ioPending = true;
                            start = false;
                        }
                    }
                }
            }
            if (!success) {
                resumeRead = bytesReleased(length,
                        lease._packedFrames ? lease._frameCount : 1);
                _pool.release(lease);
            }
        } finally { _stateLock.unlock(); }
        if (!success && _closed == 0) close();
        // The only selected lease was marked pending under _stateLock. The
        // NIO.2 provider call and its possible inline completion run outside
        // the lock, exactly as in driveWriteOnce() -> postWrite().
        if (selectedWrite != null) postWrite(selectedWrite);
        // P6-A: SendBurst.flush() may already have published SEND_START.
        // If we own this serializer, its outer loop will consume that bit
        // after the FIFO SEND_ENQUEUE callbacks. Posting here as well would
        // drive the same WRITE twice under the same owner. Do not suppress
        // kickWrite for any other caller or when no start is outstanding.
        if (start && _closed == 0
                && !(DEFER_OWNED_BURST_DRAIN && COALESCE_SEND_START
                     && isSocketSerializerOwner()
                     && (int) SOCKET_START_PENDING.getAcquire(this) != 0))
            kickWrite();
        if (resumeRead && _closed == 0) kickRead();
        notifyClosedWhenReleased();
    }

    /** Only the FIFO serializer owner may attach a staged SEND lease. */
    private boolean commitStagedOutboundFrameLocked(CIOBufferPool.Lease lease) {
        if (lease == null) return false;
        if (!_pool.owns(lease)) throw new IllegalArgumentException("foreign SEND lease");
        final WriteBuffer writer = lease.writer();
        final int length = writer.position();
        if (length <= CIOBufferPool.HEADER_BYTES
                || length > lease._reservedWireBytes
                || length > CIOBufferPool.MAX_WIRE_BYTES) return false;
        final int frameCount = lease._packedFrames ? lease._frameCount : 1;
        if (lease._packedFrames) {
            // Internal action-only leases were written under the admission lock:
            // each frame has a verified 8-byte header and 6-byte payload.
            // Mixed or externally encoded packets retain the full header walk.
            if (lease._actionOnly) {
                if (length != frameCount * 8) return false;
            } else {
                int pos = 0;
                final ByteBuffer packed = lease.buffer();
                for (int i = 0; i < frameCount; ++i) {
                    if (length - pos < CIOBufferPool.HEADER_BYTES) return false;
                    final int wireSize = Short.toUnsignedInt(packed.getShort(pos));
                    if (wireSize <= CIOBufferPool.HEADER_BYTES || wireSize > length - pos)
                        return false;
                    pos += wireSize;
                }
                if (pos != length) return false;
            }
        } else {
            writer.writeShort(0, (short) length);
        }
        writer.sealToPosition();
        lease._wireLength = length;
        lease._frameCount = frameCount;
        lease.publish();

        if (_closed != 0) {
            lease.unpublish();
            return false;
        }
        if (_writing != null && length <= PACK_MAX_FRAME_BYTES) {
            final CIOBufferPool.Lease tail = _queued != 0
                    ? _pending[_tail == 0 ? _pending.length - 1 : _tail - 1]
                    : (_burstOwner != null ? _writing : null);
            if (tail != null && !tail._ioPending && !tail._writePrepared
                    && tail.buffer().capacity() == CIOBufferPool.SMALL_SEND_BYTES
                    && tail._wireLength + length <= CIOBufferPool.SMALL_SEND_BYTES) {
                // Source packet is already serialized, but not yet encrypted.
                // Reuse the previously queued wire buffer without a new object.
                final ByteBuffer src = lease.buffer();
                final ByteBuffer dst = tail.buffer();
                final int offset = tail._wireLength;
                dst.limit(dst.capacity());
                // JDK absolute bulk put avoids per-byte bounds checks and
                // preserves both buffers' positions and limits.
                dst.put(offset, src, 0, length);
                tail._wireLength += length;
                tail._frameCount += frameCount;
                tail._packedFrames = true;
                tail._actionOnly &= lease._actionOnly;
                _pool.release(lease);
                return true;
            }
        }
        if (physicalSendFullLocked()) {
            lease.unpublish();
            return false;
        }
        if (_writing == null) {
            _writing = lease;
            _zeroWriteCompletions = 0;

        } else {
            if (!ensurePendingSlot()) {
                lease.unpublish();
                return false;
            }
            _pending[_tail] = lease;
            if (++_tail == _pending.length) _tail = 0;
            ++_queued;

        }
        return true;
    }

    /** Reserve FIFO position before serializing; encode does not hold the socket lock.
     * A true result means admitted to SEND, not delivered to the peer. */
    public boolean tryWritePacket(CIOClient client, WritablePacket<CIOClient> packet) {
        return tryWritePacketInternal(client, packet, false);
    }

    private boolean tryWritePacketInternal(CIOClient client,
            WritablePacket<CIOClient> packet, boolean finalPacket) {
        if (client == null || packet == null || !isOpen()
                || (!finalPacket && _closing != 0)) return false;
        final int learned = WriteBuffer.learnedPacketSize(packet.getClass());
        final boolean direct;
        final int slot;
        boolean publishProducer = false;
        _stateLock.lock();
        try {
            if (_closed != 0 || (!finalPacket && _closing != 0)) return false;
            if (!canAdmitBytes(Math.max(3, learned))) return rejectSend(REJECT_WIRE_BYTES);
            if (physicalSendFullLocked())
                return rejectSend(REJECT_LOCAL_FRAMES);
            // Packet bytes are encoded OUTSIDE the lock. Reserve a FIFO slot
            // before encoding, including when called by the serializer owner.
            direct = false;
            for (;;) {
                final int pending = (int) SOCKET_PENDING.getVolatile(this);
                if (pending >= SOCKET_REJECT_AT) return rejectSend(REJECT_SERIALIZER);
                if (SOCKET_PENDING.compareAndSet(this, pending, pending + 1)) break;
            }
            slot = (int) (long) SOCKET_TICKET.getAndAdd(this, 1L) & SOCKET_MASK;
            if (_producerLease != null) {
                ++_payloadOrderEpoch;
                publishProducer = publishProducerLeaseLocked();
            }
            ++_reservedDirect;
        } finally {
            _stateLock.unlock();
        }
        if (publishProducer) drainSocketCallbacks();

        CIOBufferPool.Lease encoded = null;
        boolean encodeFailed = false;
        int capacity = learned > CIOBufferPool.SMALL_SEND_BYTES
                ? CIOBufferPool.MAX_WIRE_BYTES : CIOBufferPool.SMALL_SEND_BYTES;
        for (int attempt = 0; attempt < 2; attempt++) {
            CIOBufferPool.Lease lease = null;
            boolean retryLarge = false;
            try {
                lease = beginOutboundFrame(capacity);
                if (lease == null) {
                    rejectSend(REJECT_POOL);
                    break;
                }
                final WriteBuffer writer = lease.beginPacket(packet.getClass());
                packet.writeData(client, writer);
                writer.notePacketSize();
                encoded = lease;
            } catch (WriteBuffer.RegisteredCapacityExceededException oversized) {
                retryLarge = capacity < CIOBufferPool.MAX_WIRE_BYTES;
                if (!retryLarge) encodeFailed = true;
            } catch (Throwable failure) {
                encodeFailed = true;
            } finally {
                if (lease != null && lease != encoded && lease.reserved())
                    abortOutboundFrame(lease);
            }
            if (encoded != null || !retryLarge) break;
            capacity = CIOBufferPool.MAX_WIRE_BYTES;
        }

        boolean accepted = false;
        _stateLock.lock();
        try {
            --_reservedDirect;
            try {
                if (encoded != null)
                    accepted = stageOutboundFrameLocked(encoded, direct, slot);
            } catch (Throwable failure) {
                encodeFailed = true;
            } finally {
                if (!accepted) {
                    try {
                        // Keep the encoder reservation until its lease is
                        // released. Close must never publish completion first.
                        if (encoded != null && encoded.reserved())
                            abortOutboundFrame(encoded);
                    } catch (Throwable failure) {
                        encodeFailed = true;
                    } finally {
                        if (slot >= 0) {
                            // Retire even failed encoders in original FIFO order.
                            SOCKET_ARGUMENT_SLOT.setRelease(_socketArguments, slot, 0L);
                            SOCKET_CALLBACK_SLOT.setRelease(_socketCallbacks, slot, SOCKET_CANCELLED);
                        }
                    }
                }
            }
        } finally {
            _stateLock.unlock();
        }
        if (accepted) {
            finishStagedSend(encoded, direct);
        } else {
            if (encodeFailed) rejectSend(REJECT_ENCODING);
            if (slot >= 0) drainSocketCallbacks();
            if (encodeFailed || encoded != null) close();
            if (_closed != 0) kickWrite();
            notifyClosedWhenReleased();
        }
        return accepted;
    }

    /**
     * Seal the producer's reserved FIFO ticket. Must hold _stateLock; drain the
     * serializer only after unlocking. A later foreign reservation is never
     * allowed to overtake this ticket, even if its encoder finished earlier.
     */
    private boolean publishProducerLeaseLocked() {
        final CIOBufferPool.Lease lease = _producerLease;
        if (lease == null) return false;
        final int slot = (int) _producerTicket & SOCKET_MASK;
        _producerLease = null;
        _socketSendArguments[slot] = lease;
        SOCKET_ARGUMENT_SLOT.setRelease(_socketArguments, slot,
                CIOWriteProfile.ENABLED ? System.nanoTime() : 0L);
        SOCKET_CALLBACK_SLOT.setRelease(_socketCallbacks, slot, SOCKET_SEND_ENQUEUE);
        return true;
    }

    /**
     * Append to the reserved ticket while no other payload producer has
     * reserved a later FIFO position. Control tickets (WRITE completion and
     * SEND wakeup) are not payload boundaries. The state lock orders this
     * append against every packet/direct/action payload reservation.
     */
    private boolean appendProducerActionLocked(int objectId, int actionId) {
        final CIOBufferPool.Lease lease = _producerLease;
        final SendBurst burst = _burstOwner;
        if (lease == null || burst == null || burst.thread != Thread.currentThread()
                || burst.depth == 0 || burst.flushing
                || _payloadOrderEpoch != _producerOrderEpoch)
            return false;
        final int offset = lease.writer().position();
        if (offset > CIOBufferPool.SMALL_SEND_BYTES - 8 || !canAdmitBytes(8))
            return false;
        putAction(lease.buffer(), offset, objectId, actionId);
        lease.writer().position(offset + 8);
        ++lease._frameCount;
        lease._packedFrames = true;
        bytesAdmitted(8);
        return true;
    }

    /**
     * Open one bounded packed SEND using the existing burst's producer thread.
     * The ticket is reserved before writing and its callback published at the
     * next foreign-ticket, full-buffer, close, or burst-end boundary.
     */
    private boolean beginProducerActionLocked(int objectId, int actionId) {
        if (_producerLease != null) return false;
        final SendBurst burst = _burstOwner;
        if (burst == null || burst.thread != Thread.currentThread()
                || burst.depth == 0 || burst.flushing
                || _outstandingWireBytes < BURST_MAX_BYTES
                || !canAdmitBytes(8)
                || physicalSendFullLocked())
            return false;
        // Do not reserve a ticket if no physical lease is available.
        final CIOBufferPool.Lease lease = _pool.acquireSend(CIOBufferPool.SMALL_SEND_BYTES);
        if (lease == null) return false;
        boolean reserved = false;
        for (;;) {
            final int pending = (int) SOCKET_PENDING.getVolatile(this);
            if (pending >= SOCKET_REJECT_AT) break;
            if (SOCKET_PENDING.compareAndSet(this, pending, pending + 1)) {
                reserved = true;
                break;
            }
        }
        if (!reserved) {
            _pool.release(lease);
            return false;
        }
        _producerTicket = (long) SOCKET_TICKET.getAndAdd(this, 1L);
        _producerOrderEpoch = _payloadOrderEpoch;
        _producerLease = lease;
        putAction(lease.buffer(), 0, objectId, actionId);
        lease.writer().position(8);
        lease._frameCount = 1;
        lease._actionOnly = true;
        ++_stagedSends;
        bytesAdmitted(8);
        return true;
    }

    /**
     * Reserve each action as a completed frame for the socket serializer.
     * Its callback coalesces into the last unsubmitted 16K batch when possible,
     * preserving FIFO order and the existing wire-frame cipher boundaries.
     */
    public boolean tryWriteAction(int objectId, int actionId) {
        if (_closing != 0) return false;
        boolean retriedDeferredSend = false;
        for (;;) {
            boolean drainDeferredSend = false;
            boolean accepted = false;
            boolean direct = false;
            boolean drainProducer = false;
            boolean packedProducer = false;
            boolean deferDrain = false;
            CIOBufferPool.Lease stagedLease = null;
            final long lockBefore = CIOWriteProfile.ENABLED ? System.nanoTime() : 0L;
            _stateLock.lock();
            final long lockAfter = CIOWriteProfile.ENABLED ? System.nanoTime() : 0L;
            try {
                if (_closed != 0 || _closing != 0) return false;
                if (!canAdmitBytes(8)) return rejectSend(REJECT_WIRE_BYTES);
                // When P6-A deferred only the first SEND, append to that
                // still-reserved lease under the admission lock instead of
                // draining the FIFO and reacquiring this lock on action #2.
                if (appendStagedBurstActionLocked(objectId, actionId)) return true;
                // The first unsubmitted burst lease already owns its physical slot.
                if (appendBurstActionLocked(objectId, actionId)) return true;
                // P6-A may leave the first already-published SEND staged until the
                // burst flush. Before renting another physical lease, let the
                // existing FIFO drainer attach that SEND so this action can use
                // the original writable tail. Never drain while holding the lock.
                if (!retriedDeferredSend && DEFER_OWNED_BURST_DRAIN
                        && _writing == null && _queued == 0
                        && _stagedSends == 1 && _reservedDirect == 0
                        && _producerLease == null
                        && (int) SOCKET_PENDING.getVolatile(this) == 1
                        && (int) SOCKET_DRAINING.getVolatile(this) == 0) {
                    final SendBurst burst = _burstOwner;
                    drainDeferredSend = burst != null
                            && burst.thread == Thread.currentThread()
                            && burst.depth != 0 && !burst.flushing;
                }
                if (!drainDeferredSend) {
                    // Fast single-frame/READ-pass workloads do not enter the producer
                    // packing path at all until there is a deferred lease or >8KiB
                    // pending in this owned burst.
                    if (PRODUCER_BURST_TICKETS && (_producerLease != null
                            || (_burstOwner != null && _outstandingWireBytes >= BURST_MAX_BYTES))) {
                        if (appendProducerActionLocked(objectId, actionId)) return true;
                        // A later foreign payload reservation (or full packed buffer)
                        // closes this FIFO position before any new action is admitted.
                        if (_producerLease != null && _burstOwner != null
                                && _burstOwner.thread == Thread.currentThread())
                            drainProducer = publishProducerLeaseLocked();
                        packedProducer = beginProducerActionLocked(objectId, actionId);
                    }
                    if (packedProducer) {
                        accepted = true;
                    } else if (physicalSendFullLocked()) {
                        rejectSend(REJECT_LOCAL_FRAMES);
                    } else {
                        final CIOBufferPool.Lease lease = _pool.acquireSend(CIOBufferPool.SMALL_SEND_BYTES);
                        if (lease == null) {
                            rejectSend(REJECT_POOL);
                        } else {
                            try {
                                final WriteBuffer writer = lease.writer();
                                putAction(lease.buffer(), 0, objectId, actionId);
                                writer.position(8);
                                lease._actionOnly = true;
                                direct = canInlineActionLocked();
                                accepted = stageOutboundFrameLocked(lease, direct);
                                if (accepted) {
                                    stagedLease = lease;
                                    if (!direct) {
                                        deferDrain = canDeferOwnedBurstDrainLocked();
                                        if (deferDrain) _stagedBurstAction = lease;
                                    }
                                }
                            } finally {
                                if (!accepted && lease.reserved()) _pool.release(lease);
                            }
                        }
                    }
                }
            } finally {
                final long lockEnd = CIOWriteProfile.ENABLED ? System.nanoTime() : 0L;
                _stateLock.unlock();
                if (CIOWriteProfile.ENABLED) {
                    CIOWriteProfile.record(CIOWriteProfile.SEND_LOCK_WAIT, lockAfter - lockBefore);
                    CIOWriteProfile.record(CIOWriteProfile.SEND_LOCK_HELD, lockEnd - lockAfter);
                }
            }
            if (drainDeferredSend) {
                // Published first SEND is still FIFO-ordered; this consumes it
                // without starting a WRITE while the owner burst is held.
                drainSocketCallbacks();
                retriedDeferredSend = true;
                continue;
            }
            if (drainProducer) drainSocketCallbacks();
            if (accepted && !packedProducer)
                finishStagedSend(stagedLease, direct, deferDrain);
            return accepted;
        }
    }

    /**
     * Append to the first still-staged P6-A Action without a second serializer
     * entry or a second state-lock acquisition. The lease is not published
     * (nor encrypted) until acceptStagedSend takes this same lock. Even if a
     * foreign drainer has removed the FIFO slot, it must wait for this lock
     * before touching the lease. A later ticket reservation disables append.
     */
    private boolean appendStagedBurstActionLocked(int objectId, int actionId) {
        final CIOBufferPool.Lease lease = _stagedBurstAction;
        if (lease == null || !DEFER_OWNED_BURST_DRAIN
                || _stagedSends != 1 || _writing != null || _queued != 0
                || _reservedDirect != 0 || _producerLease != null
                || (int) SOCKET_PENDING.getVolatile(this) != 1)
            return false;
        final SendBurst burst = _burstOwner;
        if (burst == null || burst.thread != Thread.currentThread()
                || burst.depth == 0 || burst.flushing)
            return false;
        // The single outstanding ticket is either not consumed yet (head+1),
        // or is being executed (head). No foreign reservation may precede it.
        final long ticket = (long) SOCKET_TICKET.getVolatile(this);
        final long head = _socketHead;
        if (ticket != head && ticket != head + 1L) return false;
        final int pos = lease.writer().position();
        if (pos > CIOBufferPool.SMALL_SEND_BYTES - 8
                || pos > lease._reservedWireBytes - 8
                || _outstandingWireBytes > BURST_MAX_BYTES - 8
                || !canAdmitBytes(8)) return false;
        putAction(lease.buffer(), pos, objectId, actionId);
        lease.writer().position(pos + 8);
        if (!lease._packedFrames) {
            lease._packedFrames = true;
            lease._frameCount = 2;
        } else {
            ++lease._frameCount;
        }
        bytesAdmitted(8);
        return true;
    }

    /**
     * The current SendBurst owns the unsubmitted first lease. No foreign
     * reservation, pending serializer callback, or I/O may precede an append.
     * Caller holds _stateLock. SEND admission remains FIFO at frame boundaries.
     */
    private CIOBufferPool.Lease writableBurstTailLocked() {
        // The connection already retains the burst. Avoid a ThreadLocal map
        // lookup on every 8-byte action; reject a foreign producer explicitly.
        final SendBurst burst = _burstOwner;
        if (burst == null || burst.thread != Thread.currentThread()
                || burst.depth == 0
                || _queued != 0 || _stagedSends != 0 || _reservedDirect != 0)
            return null;
        // The current callback still counts in SOCKET_PENDING until its
        // handler returns. It may append to its own unpublished burst, but
        // only when no other callback/ticket was admitted ahead of it.
        if ((int) SOCKET_PENDING.getVolatile(this) != 0
                && !canInlineActionLocked()) return null;
        final CIOBufferPool.Lease tail = _writing;
        if (tail == null || tail._ioPending || tail._writePrepared
                || tail.buffer().capacity() != CIOBufferPool.SMALL_SEND_BYTES)
            return null;
        return tail;
    }

    /**
     * Reuse a queued, not-yet-encrypted tail even when it is not burst-owned.
     * The active WRITE must already be in flight, so no kickWrite is required.
     * This avoids a temporary third lease for a small action appended behind
     * the currently in-flight WRITE. Called with _stateLock held.
     */
    private CIOBufferPool.Lease writableQueuedActionTailLocked() {
        if (_queued == 0 || _writing == null || !_writing._ioPending
                || _burstOwner != null || _stagedSends != 0 || _reservedDirect != 0
                || _socketPosting) return null;
        final int pending = (int) SOCKET_PENDING.getVolatile(this);
        if ((pending != 0 && !canInlineActionLocked())
                || (long) SOCKET_TICKET.getVolatile(this) != _socketHead)
            return null;
        final CIOBufferPool.Lease tail = _pending[_tail == 0
                ? _pending.length - 1 : _tail - 1];
        return tail != null && !tail._ioPending && !tail._writePrepared
                && tail.buffer().capacity() == CIOBufferPool.SMALL_SEND_BYTES
                ? tail : null;
    }

    /** Append one wire-complete action without a new lease or serializer ticket. */
    private boolean appendBurstActionLocked(int objectId, int actionId) {
        CIOBufferPool.Lease tail = writableBurstTailLocked();
        final boolean burstTail = tail != null;
        if (tail == null) tail = writableQueuedActionTailLocked();
        if (tail == null || !canAdmitBytes(8)
                || (burstTail && _outstandingWireBytes > BURST_MAX_BYTES - 8)
                || tail._wireLength > CIOBufferPool.SMALL_SEND_BYTES - 8)
            return false;
        final ByteBuffer bytes = tail.buffer();
        bytes.limit(bytes.capacity());
        putAction(bytes, tail._wireLength, objectId, actionId);
        tail._wireLength += 8;
        ++tail._frameCount;
        tail._packedFrames = true;
        bytesAdmitted(8);
        return true;
    }

    /**
     * Network-only action batch: no allocation, one lock and one watermark
     * update for N complete 8-byte frames. Only a writable burst-owned tail
     * permits the batch fast path; otherwise original single-frame FIFO is used.
     * Existing sendAction/tryWriteAction success and failure contracts remain.
     * The supplied arrays are borrowed for this call, never retained.
     */
    public boolean tryWriteActionBatch(int[] objectIds, int[] actionIds,
            int offset, int count) {
        if (objectIds == null || actionIds == null || offset < 0 || count < 0
                || offset > objectIds.length || count > objectIds.length - offset
                || offset > actionIds.length || count > actionIds.length - offset)
            throw new IllegalArgumentException("invalid action batch range");
        if (_closing != 0) return false;
        int done = 0;
        while (done < count) {
            // One lock per successful chunk: append to the owned tail or
            // encode/publish a private packed lease under that same lock.
            final int appended = tryWriteActionChunk(objectIds, actionIds,
                    offset + done, count - done);
            if (appended != 0) {
                done += appended;
            } else {
                // Only fall back to a single frame when a full chunk could
                // not be admitted under the current flow-control limits.
                if (!tryWriteAction(objectIds[offset + done], actionIds[offset + done])) {
                    // Previous frames in this batch cannot be rolled back after
                    // publication; never keep a partially accepted batch live.
                    if (done != 0 && _closed == 0) close();
                    return false;
                }
                ++done;
            }
        }
        return true;
    }

    /**
     * Encode an action chunk while holding the admission lock: unlike a generic
     * packet, no external encoder can delay publication after the chunk is
     * ordered. One lease, one serializer ticket, N logical encrypted frames.
     */
    private int tryWriteActionChunk(int[] objectIds, int[] actionIds,
            int offset, int requested) {
        CIOBufferPool.Lease lease = null;
        int frames = 0;
        boolean direct = false;
        boolean accepted = false;
        _stateLock.lock();
        try {
            if (_closed != 0 || _closing != 0) return 0;
            final int appended = appendBurstActionBatchLocked(objectIds, actionIds,
                    offset, requested);
            if (appended != 0) return appended;
            final int wireRoom = Math.min(
                    CIOBufferPool.SMALL_SEND_BYTES,
                    MAX_PENDING_WIRE_BYTES - _outstandingWireBytes - _reservedWireBytes);
            frames = Math.min(requested, wireRoom / 8);
            if (frames <= 0) return 0;
            if (physicalSendFullLocked())
                return 0;
            lease = _pool.acquireSend(CIOBufferPool.SMALL_SEND_BYTES);
            if (lease == null) return 0;
            final ByteBuffer bytes = lease.buffer();
            for (int i = 0, pos = 0; i < frames; ++i, pos += 8)
                putAction(bytes, pos, objectIds[offset + i], actionIds[offset + i]);
            lease.writer().position(frames * 8);
            lease._frameCount = frames;
            lease._packedFrames = frames > 1;
            lease._actionOnly = true;
            direct = canInlineActionLocked();
            accepted = stageOutboundFrameLocked(lease, direct);
        } finally {
            try {
                if (!accepted && lease != null && lease.reserved()) _pool.release(lease);
            } finally {
                _stateLock.unlock();
            }
        }
        if (accepted) finishStagedSend(lease, direct);
        return accepted ? frames : 0;
    }

    /** Batch admission and accounting are indivisible under _stateLock. */
    private int appendBurstActionBatchLocked(int[] objectIds, int[] actionIds,
            int offset, int count) {
        if (_closed != 0) return 0;
        final CIOBufferPool.Lease tail = writableBurstTailLocked();
        if (tail == null) return 0;
        final int freeBytes = Math.min(
                Math.min(BURST_MAX_BYTES - _outstandingWireBytes,
                        CIOBufferPool.SMALL_SEND_BYTES - tail._wireLength),
                MAX_PENDING_WIRE_BYTES - _outstandingWireBytes - _reservedWireBytes);
        final int frames = Math.min(count, freeBytes / 8);
        if (frames <= 0 || !canAdmitBytes(frames * 8)) return 0;

        final ByteBuffer bytes = tail.buffer();
        bytes.limit(bytes.capacity());
        int position = tail._wireLength;
        for (int i = 0; i < frames; ++i) {
            putAction(bytes, position, objectIds[offset + i], actionIds[offset + i]);
            position += 8;
        }
        tail._wireLength = position;
        tail._frameCount += frames;
        tail._packedFrames = true;
        bytesAdmittedBatch(frames * 8, frames);
        return frames;
    }

    private static void putAction(ByteBuffer out, int position, int objectId, int actionId) {
        out.putShort(position, (short) 8);
        out.put(position + 2, (byte) Opcodes.S_ACTION);
        out.putInt(position + 3, objectId);
        out.put(position + 7, (byte) actionId);
    }

    /**
     * The client cipher advances per game packet, not per transport write.
     * Each packed frame is encrypted individually in wire order.
     */
    private boolean preparePackedEncryption(CIOBufferPool.Lease lease) {
        final WriteBuffer writer = lease.writer();
        final ByteBuffer bytes = lease.buffer();
        final int length = lease.wireLength();
        if (lease._actionOnly) {
            if (length != lease._frameCount * 8) return false;
            for (int offset = 0; offset < length; offset += 8) {
                // Per-frame cipher initialization/advancement is unchanged.
                if (!encrypt(writer, offset + CIOBufferPool.HEADER_BYTES, 6)) return false;
            }
            return true;
        }
        int offset = 0;
        while (offset < length) {
            if (length - offset < CIOBufferPool.HEADER_BYTES) return false;
            final int frameLength = Short.toUnsignedInt(bytes.getShort(offset));
            if (frameLength <= CIOBufferPool.HEADER_BYTES
                    || frameLength > length - offset) return false;
            if (!encrypt(writer,
                    offset + CIOBufferPool.HEADER_BYTES,
                    frameLength - CIOBufferPool.HEADER_BYTES)) return false;
            offset += frameLength;
        }
        return true;
    }

    /** Only call this for a frame that was NOT committed. */
    public void abortOutboundFrame(CIOBufferPool.Lease lease) {
        if (lease == null) return;
        if (!_pool.owns(lease) || !lease.reserved())
            throw new IllegalStateException("abort after commit or foreign SEND lease");
        _pool.release(lease);
    }

    /** Exactly one pending read per socket. */
    public void startRead() {
        try {
            _stateLock.lock(); try {
                if ((_closed != 0) || !READ_ACTIVE.compareAndSet(this, 0, 1)) return;
                try {
                    _reading = _pool.acquireRecv();
                } catch (RuntimeException | Error failure) {
                    READ_ACTIVE.setVolatile(this, 0);
                    close();
                    throw failure;
                }
                if (_reading == null) {
                    READ_ACTIVE.setVolatile(this, 0);
                    close();
                    return;
                }
            } finally { _stateLock.unlock(); }
        } finally {
            // close() may reenter under the state lock on pool failure.
            if (_closed != 0) kickWrite();
        }
        kickRead();
    }

    /**
     * Only one thread may touch the compacting READ ByteBuffer at a time.
     * Synchronous completed() callbacks are trampolined without recursion.
     * Cross-thread SEND acknowledgements may race with the NIO completion.
     */
    private void kickRead() {
        if ((int) READ_KICK.getAndAdd(this, 1) != 0) return;
        int missed = 1;
        do {
            // The callback may be invoked inline, even before channel.read()
            // returns. Only this pump retires an outstanding READ operation.
            final int event = (int) READ_EVENT.getAndSet(this, 0);
            if (event != 0) {
                _readPending = false;
                if (event == 1 || _closed != 0) {
                    close();
                } else if (event == 2) {
                    if (++_zeroReadCompletions >= 8) close();
                } else {
                    _zeroReadCompletions = 0;
                }
            }
            if (_closed == 0 && _closing == 0 && !_readPending && !_sendReadPaused) {
                try {
                    if (!onRead()) {
                        close();
                    } else if (_closed == 0 && !_sendReadPaused && !_readYielded) {
                        postRead();
                    }
                } catch (Throwable failure) {
                    close();
                }
            }
            if (_readYielded && _closed == 0 && _closing == 0 && !_sendReadPaused
                    && READ_FRAME_BUDGET != 0 && _ioExecutor != null) {
                // The buffer was compacted at a complete frame boundary.
                // Release pump ownership BEFORE publishing its continuation.
                // Another kick may race and take ownership; READ_KICK still
                // serializes access to the READ lease in either case.
                READ_KICK.getAndSet(this, 0);
                scheduleReadContinuation();
                finishReadIfClosed();
                return;
            }
            missed = ((int) READ_KICK.getAndAdd(this, -missed) - missed);
        } while (missed != 0);
        finishReadIfClosed();
    }

    private void scheduleReadContinuation() {
        if (!READ_CONTINUATION_QUEUED.compareAndSet(this, 0, 1)) return;
        try {
            _ioExecutor.execute(this);
        } catch (RuntimeException refused) {
            READ_CONTINUATION_QUEUED.setVolatile(this, 0);
            // No suspended READ may be abandoned with a live session.
            close();
        }
    }

    /** A single reusable task per connection; runs on the same NIO.2 workers. */
    @Override
    public void run() {
        READ_CONTINUATION_QUEUED.setVolatile(this, 0);
        kickRead();
    }

    private void postRead() {
        if (_closed != 0 || _closing != 0) return;
        final ByteBuffer recv = _reading.buffer();
        if (!recv.hasRemaining()) {
            close();
            return;
        }
        // Set before the call: async I/O may invoke completed() synchronously.
        _readPending = true;
        try {

            _channel.read(recv, this, READ_COMPLETION);
        } catch (Throwable t) {
            _readPending = false;
            close();
        }
    }

    /** Release the READ lease on close only after the last completion. */
    private void finishReadIfClosed() {
        if ((_closed != 0) && !_readPending && _readKick == 0) {
            _stateLock.lock(); try {
                if (!_readPending && _readKick == 0) endRead();
            } finally { _stateLock.unlock(); }
        }
    }

    private boolean onRead() {
        _readYielded = false;
        ByteBuffer recv = _reading.buffer();
        if (recv.position() == 0) return true;
        // Avoid an extra ThreadLocal scope for a single completed request.
        // Every pass, including fairness yield or an exception, flushes in
        // finally before the READ pump can post another asynchronous read.
        boolean passBurst = false;
        if (READ_PASS_BURST && recv.position() >= READ_PASS_MIN_BUFFERED_BYTES) {
            final int first = Short.toUnsignedInt(recv.getShort(0));
            final int filled = recv.position();
            if (first >= CIOBufferPool.HEADER_BYTES
                    && first <= filled - CIOBufferPool.HEADER_BYTES) {
                final int second = Short.toUnsignedInt(recv.getShort(first));
                passBurst = second >= CIOBufferPool.HEADER_BYTES
                        && second <= filled - first;
            }
        }
        if (passBurst) {
            beginReadPassSendBurst();
            _readPassBurstActive = true;
        }
        try {
        recv.flip();
        // The READ pump owns framing and posts the next read only after the
        // current handler returns; fairness yields at complete frame boundaries.
        int frames = 0;
        while (recv.remaining() >= CIOBufferPool.HEADER_BYTES) {
            if (_closing != 0) break;
            // A READ already in flight may complete after SEND pressure rises.
            // Keep its frame encrypted/buffered until the low-water release.
            if (_sendReadPaused) {
                _readYielded = true;
                break;
            }
            final int start = recv.position();
            final int wireLength = Short.toUnsignedInt(recv.order(ByteOrder.LITTLE_ENDIAN).getShort(start));
            if (wireLength < CIOBufferPool.HEADER_BYTES
                    || wireLength > CIOBufferPool.MAX_WIRE_BYTES) return false;
            if (recv.remaining() < wireLength) break;
            final boolean accepted = onReadFrame(recv, start + CIOBufferPool.HEADER_BYTES,
                    wireLength - CIOBufferPool.HEADER_BYTES);
            if (!accepted || (_closed != 0)) return false;
            recv.position(start + wireLength);
            // requestClientClose() ends inbound dispatch, not the outbound
            // drain. Never decode the remaining coalesced requests or re-arm.
            if (_closing != 0) break;
            if (_sendReadPaused) {
                _readYielded = true;
                break;
            }
            if (_ioExecutor != null && READ_FRAME_BUDGET != 0
                    && ++frames >= READ_FRAME_BUDGET
                    && recv.remaining() >= CIOBufferPool.HEADER_BYTES) {
                final int nextLength = Short.toUnsignedInt(recv.getShort(recv.position()));
                if (nextLength >= CIOBufferPool.HEADER_BYTES
                        && nextLength <= recv.remaining()) {
                    _readYielded = true;
                    break;
                }
            }
        }
        // Graceful close leaves any later coalesced inbound frames unread.
        // Do not treat a full READ lease as a malformed large frame here:
        // the lease belongs to the socket until the final SEND drains.
        if (_closing != 0) return true;
        // Avoid compact's copy when all bytes were consumed, or when an
        // incomplete frame already begins at offset zero.
        if (!recv.hasRemaining()) {
            recv.clear();
        } else if (recv.position() == 0) {
            final int buffered = recv.limit();
            recv.clear();
            recv.position(buffered);
        } else {
            recv.compact();
        }
        if (!recv.hasRemaining()) {
            // A complete compact-buffer-sized frame can fill this lease exactly.
            // SEND-pressure backpressure can retain a complete frame.
            if (_readYielded) return true;
            if (recv.position() < CIOBufferPool.HEADER_BYTES) return false;
            final int wireLength = Short.toUnsignedInt(recv.getShort(0));
            if (wireLength <= recv.capacity()) return false;
            final CIOBufferPool.Lease large = _pool.acquireLargeRecv();
            if (large == null) return false;
            recv.flip();
            large.buffer().put(recv);
            final CIOBufferPool.Lease old = _reading;
            _reading = large;
            _pool.release(old);
        } else if (_reading.buffer().capacity() > CIOBufferPool.RECV_BYTES
                && recv.position() == 0) {
            final CIOBufferPool.Lease compact = _pool.acquireRecv();
            if (compact != null) {
                final CIOBufferPool.Lease old = _reading;
                _reading = compact;
                _pool.release(old);
            }
        }
        return true;
        } finally {
            if (passBurst) {
                _readPassBurstActive = false;
                endReadPassSendBurst();
            }
        }
    }

    private void endRead() {
        if (!READ_ACTIVE.compareAndSet(this, 1, 0)) return;
        releaseReadWhenIdle();
        notifyClosedWhenReleased();
    }

    private void releaseReadWhenIdle() {
        _stateLock.lock();
        try {
        if (_readReleased || (_readActive != 0)) return;
        final CIOBufferPool.Lease recv = _reading;
        _reading = null;
        if (recv != null) _pool.release(recv);
        _readReleased = true;
        } finally {
            _stateLock.unlock();
        }
    }

    private boolean onReadFrame(ByteBuffer wire, int bodyStart, int bodyLength) {
        if (_closing != 0) return _closed == 0 && _disconnecting == 0;
        if (!_client.isConnected()) return false;

        // Preserve the empty-packet flood handling (wire length == 2).
        if (bodyLength == 0) {
            if (_client.incrementEmptyPacketCount() <= ConnectionConfig.PACKET_LIMIT_PER_SEC) {
                return true;
            }
            _client.disconnect();
            return false;
        }
        _client.resetEmptyPacketCount();

        // Lineage decrypt consumes its 4-byte cipher prefix and requires 8 bytes.
        if (bodyLength < 8) {
            _client.disconnect();
            return false;
        }

        // Exactly one full decrypt per frame: it advances the rolling cipher
        // state, including filtered and unknown opcodes. Do not preview first.
        final DecodeState state = acquireDecodeState();
        try {
            final ReadBuffer decoded = state.buffer;
            boolean success = false;
            try {
                final boolean hasCipher = readCipher() != null;
                decoded.resetTrusted(wire, bodyStart, bodyLength);
                if (decrypt(decoded, 0, bodyLength)) {
                    decoded.limit(bodyLength - 4);
                    if (decoded.remaining() == 0) {
                        success = inboundHandlerConnected();
                    } else if (!_client.checkPacketRateLimit(System.currentTimeMillis())) {
                        final int opcode = decoded.readUnsignedByte();
                        if (DIRECT_UNROUTED && hasCipher
                                && !CPacketHandler.isFastOpcode(opcode)) {
                            // The unknown-opcode filter runs AFTER decrypt,
                            // so later packets retain the correct key state.
                            NetworkSafeLoadManager.isFilter(_client, opcode);
                            success = true;
                        } else if (NetworkSafeLoadManager.isFilter(_client, opcode)
                                != NetworkSafeLoadManager.RESULT_FILTER) {
                            if (CPacketHandler.isDirectOpcode(opcode)
                                    || (_client.isGameSessionReady()
                                    && !CPacketHandler.isSessionOpcode(opcode))) {
                                dispatchDecodedFrame(opcode, decoded);
                            } else {
                                synchronized (_client) {
                                    if (_client.isConnected()) {
                                        dispatchDecodedFrame(opcode, decoded);
                                    }
                                }
                            }
                            success = inboundHandlerConnected();
                        } else {
                            success = inboundHandlerConnected();
                        }
                    } else {
                        _client.disconnect();
                        return false;
                    }
                }
            } catch (Throwable error) {
                LOG.log(Level.WARNING, "[I/O OnRead] packet decode failed", error);
            } finally {
                decoded.clear();
            }
            if (!success) _client.disconnect();
            return success;
        } finally {
            state.buffer.clear();
            state.active = false;
        }
    }

    /** Graceful disconnect is an accepted handler outcome, not a decode error. */
    private boolean inboundHandlerConnected() {
        return _closed == 0 && _disconnecting == 0
                && (_closing != 0 || _client.isConnected());
    }

    private void dispatchDecodedFrame(int opcode, ReadBuffer decoded) {
        final CPacketHandler.PacketHandler handler = CPacketHandler.HANDLERS[opcode & 0xFF];
        // Only the current socket READ pump can set this flag. A full buffer
        // owns the SEND burst and its finally always flushes it.
        if (_readPassBurstActive) {
            if (handler != null) handler.execute(decoded, _client);
            // With large responses, READ pressure may stop the pass after a
            // single request. Submit its already accepted output immediately;
            // do not make that request wait for the outer frame-loop epilogue.
            if (_sendReadPaused) flushSendBurst();
            return;
        }
        // One ThreadLocal lookup per decoded single-frame handler instead of
        // begin/flush/end's three lookups. Keep nested scope boundaries and
        // the same flush-on-error contract; no SEND reorder or extra queue.
        SendBurst burst = SEND_BURST.get();
        if (burst == null) {
            burst = new SendBurst();
            SEND_BURST.set(burst);
        }
        ++burst.depth;
        try {
            if (handler != null) handler.execute(decoded, _client);
            burst.flush();
        } finally {
            if (--burst.depth == 0) burst.flush();
        }
    }

    private boolean serializeSocketCallback(long kind, long argument) {
        if (isSocketSerializerOwner()) {
            if (kind == SOCKET_SEND_START) driveWriteOnce();
            else if (kind == SOCKET_WRITE_COMPLETE
                    && WRITE_EVENT.compareAndSet(this, argument, 0L))
                drainWriteCompletion(argument);
            return true;
        }
        for (;;) {
            final int pending = (int) SOCKET_PENDING.getVolatile(this);
            if (pending >= SOCKET_REJECT_AT) return false;
            if (SOCKET_PENDING.compareAndSet(this, pending, pending + 1)) break;
        }
        final long ticket = (long) SOCKET_TICKET.getAndAdd(this, 1L);
        final int slot = (int) ticket & SOCKET_MASK;
        SOCKET_ARGUMENT_SLOT.setRelease(_socketArguments, slot, argument);
        SOCKET_CALLBACK_SLOT.setRelease(_socketCallbacks, slot, kind);
        drainSocketCallbacks();
        return true;
    }

    /** First contender becomes the inline drainer; other callers return. */
    private void drainSocketCallbacks() {
        if (!SOCKET_DRAINING.compareAndSet(this, 0, 1)) return;
        drainSocketCallbacksAcquired();
    }

    /** The caller already holds _socketDraining == 1. */
    private void drainSocketCallbacksAcquired() {
        for (;;) {
            _socketOwner = Thread.currentThread();
            for (;;) {
                // Deferred owner-inline completions precede any SEND ticket
                // reserved after their callback. Consume only after write()
                // returned; kickWrite may post another inline completion, so
                // drive this iteratively rather than recursively.
                if (INLINE_WRITE_COMPLETION && _inlineWriteCompletion != 0L) {
                    final long inline = _inlineWriteCompletion;
                    _inlineWriteCompletion = 0L;
                    try {
                        if (WRITE_EVENT.compareAndSet(this, inline, 0L))
                            drainWriteCompletion(inline);
                    } catch (Throwable failure) { close(); }
                    continue;
                }
                if ((int) SOCKET_PENDING.getVolatile(this) == 0) break;
                final int slot = (int) _socketHead & SOCKET_MASK;
                final long kind = (long) SOCKET_CALLBACK_SLOT.getAcquire(_socketCallbacks, slot);
                if (kind == 0L) {
                    break;
                }
                final long argument = (long) SOCKET_ARGUMENT_SLOT.getAcquire(_socketArguments, slot);
                final CIOBufferPool.Lease sendLease = kind == SOCKET_SEND_ENQUEUE
                        ? _socketSendArguments[slot] : null;
                _socketSendArguments[slot] = null;
                SOCKET_ARGUMENT_SLOT.setRelease(_socketArguments, slot, 0L);
                SOCKET_CALLBACK_SLOT.setRelease(_socketCallbacks, slot, 0L);
                ++_socketHead;
                if (INLINE_WRITE_COMPLETION) _socketExecutingTicket = true;
                try {
                    if (kind == SOCKET_WRITE_COMPLETE) {
                        if (WRITE_EVENT.compareAndSet(this, argument, 0L))
                            drainWriteCompletion(argument);
                    } else if (kind == SOCKET_SEND_START) {
                        driveWriteOnce();
                    } else if (kind == SOCKET_SEND_ENQUEUE && sendLease != null) {
                        if (CIOWriteProfile.ENABLED && argument != 0L)
                            CIOWriteProfile.record(CIOWriteProfile.SEND_TICKET,
                                    System.nanoTime() - argument);
                        acceptStagedSend(sendLease);
                    } else if (kind != SOCKET_CANCELLED) {
                        close();
                    }
                } catch (Throwable failure) {
                    close();
                } finally {
                    if (INLINE_WRITE_COMPLETION) _socketExecutingTicket = false;
                    SOCKET_PENDING.getAndAdd(this, -1);
                }
            }

            // A SEND_START notification is not a payload reservation. Every
            // attached SEND was already consumed in ticket order above; any
            // earlier unsealed ticket keeps later SENDs in that FIFO ring.
            if (COALESCE_SEND_START
                    && (int) SOCKET_START_PENDING.getAcquire(this) != 0
                    && (int) SOCKET_START_PENDING.getAndSet(this, 0) != 0) {
                try { driveWriteOnce(); }
                catch (Throwable failure) { close(); }
            }

            if (_closed != 0 && (int) SOCKET_PENDING.getVolatile(this) == 0) {
                final long stranded = (long) WRITE_EVENT.getAndSet(this, 0L);
                if (stranded != 0L) {
                    try { drainWriteCompletion(stranded); }
                    catch (Throwable ignored) { close(); }
                }
                try { driveWriteOnce(); }
                catch (Throwable ignored) { close(); }
            }
            
            // The coalesced SEND_START drive above can complete write()
            // inline after the inner loop has already exited. Keep the
            // current owner until the deferred completion is retired.
            if (INLINE_WRITE_COMPLETION && _inlineWriteCompletion != 0L)
                continue;

            final int nextSlot = (int) _socketHead & SOCKET_MASK;
            _socketOwner = null;
            SOCKET_DRAINING.setRelease(this, 0);
            
            // Release/reacquire handshake: a writer that posts just before
            // release sees the old owner, which must recheck this bit; a
            // writer arriving afterwards can itself acquire the token.
            final boolean startPending = COALESCE_SEND_START
                    && (int) SOCKET_START_PENDING.getAcquire(this) != 0;
            final boolean callbackReady = (int) SOCKET_PENDING.getVolatile(this) != 0
                    && (long) SOCKET_CALLBACK_SLOT.getAcquire(_socketCallbacks, nextSlot) != 0L;
            if ((!startPending && !callbackReady)
                    || !SOCKET_DRAINING.compareAndSet(this, 0, 1)) break;
        }
        notifyClosedWhenReleased();
    }

    /** SEND registration and next-WRITE selection, executed by the serializer. */
    private void kickWrite() {
        if (!COALESCE_SEND_START) {
            if (!serializeSocketCallback(SOCKET_SEND_START, 0L)) close();
            return;
        }
        // Match the former inline-owner behavior, including WRITE partials.
        if (isSocketSerializerOwner()) {
            driveWriteOnce();
            return;
        }
        SOCKET_START_PENDING.setRelease(this, 1);
        drainSocketCallbacks();
    }

    private void driveWriteOnce() {
        CIOBufferPool.Lease current = null;
        boolean gather = false;
        boolean cancelled = false;
        final long lockBefore = CIOWriteProfile.ENABLED ? System.nanoTime() : 0L;
        _stateLock.lock();
        final long lockAfter = CIOWriteProfile.ENABLED ? System.nanoTime() : 0L;
        try {
            if (_writing != null && !_writing._ioPending) {
                current = _writing;
                cancelled = (_closed != 0);
                if (!cancelled && _gatherCount == 0 && _queued != 0) {
                    if (_gatherFrames == null) {
                        _gatherFrames = new CIOBufferPool.Lease[GATHER_MAX_FRAMES];
                        _gatherBuffers = new ByteBuffer[GATHER_MAX_FRAMES];
                    }
                    int totalBytes = current.wireLength();
                    _gatherFrames[0] = current;
                    _gatherCount = 1;
                    while (_queued != 0 && _gatherCount < GATHER_MAX_FRAMES) {
                        final CIOBufferPool.Lease candidate = _pending[_head];
                        if (totalBytes + candidate.wireLength() > GATHER_MAX_BYTES)
                            break;
                        _pending[_head] = null;
                        if (++_head == _pending.length) _head = 0;
                        --_queued;
                        _gatherFrames[_gatherCount++] = candidate;
                        totalBytes += candidate.wireLength();
                    }
                    if (_gatherCount == 1) {
                        _gatherFrames[0] = null;
                        _gatherCount = 0;
                    }
                }
                gather = _gatherCount > 1;
                current._ioPending = true;
            }
        } finally {
            final long lockEnd = CIOWriteProfile.ENABLED ? System.nanoTime() : 0L;
            _stateLock.unlock();
            if (CIOWriteProfile.ENABLED) {
                CIOWriteProfile.record(CIOWriteProfile.DRIVE_LOCK_WAIT, lockAfter - lockBefore);
                CIOWriteProfile.record(CIOWriteProfile.DRIVE_LOCK_HELD, lockEnd - lockAfter);
            }
        }
        if (CIOWriteProfile.ENABLED && current == null)
            CIOWriteProfile.count(CIOWriteProfile.EMPTY_DRIVE);
        if (current != null) {
            if (cancelled) {
                if (gather) completeGather(false);
                else completeWrite(current, false);
            } else if (gather) postGather();
            else postWrite(current);
        }
    }

    /** Ordered packet encryption + async I/O scatter/gather WRITE, no coalescing copy. */
    private void postGather() {
        if (_closed != 0) {
            completeGather(false);
            return;
        }
        try {
            final long prepBefore = CIOWriteProfile.ENABLED ? System.nanoTime() : 0L;
            boolean preparedAny = false;
            for (int i = 0; i < _gatherCount; i++) {
                final CIOBufferPool.Lease lease = _gatherFrames[i];
                final ByteBuffer bytes = lease.buffer();
                if (!lease._writePrepared) {
                    preparedAny = true;
                    if (lease._packedFrames ? !preparePackedEncryption(lease)
                            : !encrypt(lease.writer(),
                                    CIOBufferPool.HEADER_BYTES,
                                    lease.wireLength() - CIOBufferPool.HEADER_BYTES)) {
                        completeGather(false);
                        return;
                    }
                    bytes.limit(lease.wireLength());
                    bytes.position(0);
                    lease._writePrepared = true;

                }
                _gatherBuffers[i] = bytes;
            }

            if (CIOWriteProfile.ENABLED) {
                final long now = System.nanoTime();
                if (preparedAny) CIOWriteProfile.record(CIOWriteProfile.GATHER_PREP,
                        now - prepBefore);
                if (_profileAwaitingNextPost) {
                    CIOWriteProfile.record(CIOWriteProfile.COMPLETION_TO_NEXT_POST,
                            now - _profileCompletionConsumedNs);
                    _profileAwaitingNextPost = false;
                }
                _profileWritePostNs = now;
            }
            _socketPosting = true;
            final long callBefore = CIOWriteProfile.ENABLED ? System.nanoTime() : 0L;
            try {
                _channel.write(_gatherBuffers, 0, _gatherCount, 0L,
                        TimeUnit.MILLISECONDS, this, GATHER_COMPLETION);
            } finally {
                _socketPosting = false;
                if (CIOWriteProfile.ENABLED)
                    CIOWriteProfile.record(CIOWriteProfile.GATHER_CALL,
                            System.nanoTime() - callBefore);
            }
        } catch (Throwable error) {
            // A provider may publish a completion before throwing. Let the
            // serializer consume the mailbox exactly once after write returns.
            if (INLINE_WRITE_COMPLETION && (long) WRITE_EVENT.getVolatile(this) != 0L) close();
            else completeGather(false);
        }
    }

    private void completeGather(boolean success) {

        CIOBufferPool.Lease next = null;
        boolean resumeInbound = false;
        final long lockBefore = CIOWriteProfile.ENABLED ? System.nanoTime() : 0L;
        _stateLock.lock();
        final long lockAfter = CIOWriteProfile.ENABLED ? System.nanoTime() : 0L;
        try {
            if (_gatherCount <= 1 || _writing != _gatherFrames[0]) {
                close();
                return;
            }
            int releasedBytes = 0;
            int releasedFrames = 0;
            for (int i = 0; i < _gatherCount; i++) {
                final CIOBufferPool.Lease frame = _gatherFrames[i];
                releasedBytes += frame.wireLength();
                releasedFrames += frame._frameCount;
                _pool.release(frame);
                _gatherFrames[i] = null;
                _gatherBuffers[i] = null;
            }
            // READ resumes once, after all gather frames have been retired.
            resumeInbound = bytesReleased(releasedBytes, releasedFrames);
            _gatherCount = 0;
            _writing = null;
            if (success && _closed == 0 && _queued != 0) {
                next = _pending[_head];
                _pending[_head] = null;
                if (++_head == _pending.length) _head = 0;
                --_queued;
                _writing = next;
                _zeroWriteCompletions = 0;
            }
        } finally {
            final long lockEnd = CIOWriteProfile.ENABLED ? System.nanoTime() : 0L;
            _stateLock.unlock();
            if (CIOWriteProfile.ENABLED) {
                CIOWriteProfile.record(CIOWriteProfile.GATHER_LOCK_WAIT, lockAfter - lockBefore);
                CIOWriteProfile.record(CIOWriteProfile.GATHER_LOCK_HELD, lockEnd - lockAfter);
            }
        }
        if (!success) close();
        else if (next != null) {
            if (CIOWriteProfile.ENABLED) _profileAwaitingNextPost = true;
            kickWrite();
        }
        if (resumeInbound && _closed == 0) kickRead();
        if (success && _closed == 0) notifySendSlotAvailable();
        notifyClosedWhenReleased();
    }

    private void notifySendSlotAvailable() {
        try { onSendProgress(); } catch (Throwable failure) { close(); }
    }

    private void postWrite(CIOBufferPool.Lease lease) {
        if (_closed != 0) {
            lease._ioPending = false;
            completeWrite(lease, false);
            return;
        }
        try {
            final long prepBefore = CIOWriteProfile.ENABLED ? System.nanoTime() : 0L;
            final ByteBuffer bytes = lease.buffer();
            final boolean preparing = !lease._writePrepared;
            if (preparing) {
                final WriteBuffer writer = lease.writer();
                if (lease._packedFrames ? !preparePackedEncryption(lease)
                        : !encrypt(writer,
                                CIOBufferPool.HEADER_BYTES,
                                lease.wireLength() - CIOBufferPool.HEADER_BYTES)) {
                    lease._ioPending = false;
                    completeWrite(lease, false);
                    return;
                }
                bytes.limit(lease.wireLength());
                bytes.position(0);
                lease._writePrepared = true;

            }

            if (CIOWriteProfile.ENABLED) {
                final long now = System.nanoTime();
                if (preparing)
                    CIOWriteProfile.record(CIOWriteProfile.WRITE_PREP, now - prepBefore);
                if (_profileAwaitingNextPost) {
                    CIOWriteProfile.record(CIOWriteProfile.COMPLETION_TO_NEXT_POST,
                            now - _profileCompletionConsumedNs);
                    _profileAwaitingNextPost = false;
                }
                _profileWritePostNs = now;
            }
            _socketPosting = true;
            final long callBefore = CIOWriteProfile.ENABLED ? System.nanoTime() : 0L;
            try {
                _channel.write(bytes, this, WRITE_COMPLETION);
            } finally {
                _socketPosting = false;
                if (CIOWriteProfile.ENABLED)
                    CIOWriteProfile.record(CIOWriteProfile.WRITE_CALL,
                            System.nanoTime() - callBefore);
            }
        } catch (Throwable error) {
            if (INLINE_WRITE_COMPLETION && (long) WRITE_EVENT.getVolatile(this) != 0L) close();
            else {
                lease._ioPending = false;
                completeWrite(lease, false);
            }
        }
    }

    private void completeWrite(CIOBufferPool.Lease lease, boolean success) {

        CIOBufferPool.Lease next = null;
        boolean resumeInbound;
        final long lockBefore = CIOWriteProfile.ENABLED ? System.nanoTime() : 0L;
        _stateLock.lock();
        final long lockAfter = CIOWriteProfile.ENABLED ? System.nanoTime() : 0L;
        try {
            if (_writing != lease) {
                close();
                return;
            }
            resumeInbound = bytesReleased(lease.wireLength(), lease._frameCount);
            _pool.release(lease);
            _writing = null;
            if (success && _closed == 0 && _queued != 0) {
                next = _pending[_head];
                _pending[_head] = null;
                if (++_head == _pending.length) _head = 0;
                --_queued;
                _writing = next;
                _zeroWriteCompletions = 0;
            }
        } finally {
            final long lockEnd = CIOWriteProfile.ENABLED ? System.nanoTime() : 0L;
            _stateLock.unlock();
            if (CIOWriteProfile.ENABLED) {
                CIOWriteProfile.record(CIOWriteProfile.COMPLETE_LOCK_WAIT, lockAfter - lockBefore);
                CIOWriteProfile.record(CIOWriteProfile.COMPLETE_LOCK_HELD, lockEnd - lockAfter);
            }
        }
        if (!success) {
            close();
        } else if (next != null) {
            if (CIOWriteProfile.ENABLED) _profileAwaitingNextPost = true;
            kickWrite();
        }
        if (resumeInbound && _closed == 0) kickRead();
        if (success && _closed == 0) notifySendSlotAvailable();
        notifyClosedWhenReleased();
    }

    /** No allocation; useful for admission diagnostics and slow-peer checks. */
    public int pendingSendBytes() {
        _stateLock.lock();
        try { return _outstandingWireBytes + _reservedWireBytes; }
        finally { _stateLock.unlock(); }
    }

    /** True when the connection's outbound backlog allows further socket reads. */
    public boolean isSendReadWritable() { return !_sendReadPaused; }

    /** Snapshot only; includes the active WRITE, queued frames and reserved producers. */
    public int pendingSendFrames() {
        _stateLock.lock();
        try { return physicalSendLeasesLocked(); }
        finally { _stateLock.unlock(); }
    }

    private boolean isWriteIdleLocked() {
        return _queued == 0 && _reservedDirect == 0 && _stagedSends == 0 && _writing == null;
    }

    public boolean isWriteIdle() {
        _stateLock.lock();
        try { return isWriteIdleLocked(); }
        finally { _stateLock.unlock(); }
    }

    public boolean isOpen() {
        return _closed == 0 && _channel.isOpen();
    }

    /** Transport close callback is emitted after every in-flight I/O lease is released. */
    public boolean isCloseComplete() {
        return (_closeNotified != 0);
    }

    private void notifyClosedWhenReleased() {
        if (_closed == 0 || !_readReleased || _socketDraining != 0 || _socketPending != 0
                || _writeEvent != 0L) return;
        _stateLock.lock(); try {
            if (_writing != null || _queued != 0 || _reservedDirect != 0 || _stagedSends != 0) return;
        } finally { _stateLock.unlock(); }
        if (!CLOSE_NOTIFIED.compareAndSet(this, 0, 1)) return;
        clearCipher();
        if (_closedCallback != null) {
            try {
                _closedCallback.onClosed(this);
            } catch (Throwable ignored) {
                // Never retain a closed socket when a lifecycle observer fails.
            }
        }
    }

    @Override
    public void close() {
        if (!CLOSED.compareAndSet(this, 0, 1)) return;
        ON_DRAINED.setVolatile(this, null);
        try { _channel.close(); } catch (IOException ignored) {}
        boolean drainProducer;
        _stateLock.lock(); try {
            _deferredClosePacket = null;
            drainProducer = publishProducerLeaseLocked();
            int releasedBytes = 0;
            int releasedFrames = 0;
            while (_queued != 0) {
                final CIOBufferPool.Lease lease = _pending[_head];
                _pending[_head] = null;
                if (++_head == _pending.length) _head = 0;
                --_queued;
                releasedBytes += lease.wireLength();
                releasedFrames += lease._frameCount;
                _pool.release(lease);
            }
            if (releasedFrames != 0) bytesReleased(releasedBytes, releasedFrames);
        } finally { _stateLock.unlock(); }
        if (drainProducer) drainSocketCallbacks();
        _stateLock.lock(); try {
            if (_readActive == 0) releaseReadWhenIdle();
        } finally { _stateLock.unlock(); }
        finishReadIfClosed();
        if (!_stateLock.isHeldByCurrentThread()) kickWrite();
        notifyClosedWhenReleased();
    }
}
