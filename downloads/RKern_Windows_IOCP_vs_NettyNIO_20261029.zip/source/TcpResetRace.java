package l1j.server.server.model.network.core;
import java.net.*;import java.util.*;import java.util.concurrent.*;import java.util.concurrent.atomic.*;
import l1j.server.server.model.network.thread.CIOThreadCallback;
/** Peer RST intentionally aborts delivery; verifies lifetime/retirement, not delivery of aborted frames. */
public final class TcpResetRace {
 static void check(boolean b,String m){if(!b)throw new AssertionError(m);}
 static void until(java.util.function.BooleanSupplier b)throws Exception{long end=System.nanoTime()+TimeUnit.SECONDS.toNanos(8);while(!b.getAsBoolean()&&System.nanoTime()<end)Thread.sleep(1);check(b.getAsBoolean(),"timeout");}
 public static void main(String[] args)throws Exception{
  var pool=new CIOBufferPool(64,1024,16,32);var current=new AtomicReference<CIOUserSocket>();var sent=new AtomicInteger();var closed=new AtomicInteger();var errors=new AtomicReference<Throwable>();var all=new ArrayList<CIOUserSocket>();byte[] body=new byte[4096];for(int i=0;i<body.length;i++)body[i]=(byte)(i*13);
  var server=new CIOServer(new InetSocketAddress("127.0.0.1",0),64,2,64,pool,(ch,p,cb)->{
   ch.setOption(StandardSocketOptions.SO_SNDBUF,1024);var s=new CIOUserSocket(ch,p,new CIOThreadCallback(),"reset",0,256,c->{closed.incrementAndGet();cb.onClosed(c);});var client=new CIOClient(s);s.bindClient(client);s.initializeCipher(NetworkRegression.SEED);
   client.handler=(op,b)->{try{for(int i=0;i<128;i++){var frame=s.beginDirectFrame(body.length+2);if(frame==null)break;boolean committed=false;try{frame.buffer().writeBytes(body);committed=s.commitDirectFrame(frame);}finally{if(!committed)s.abortDirectFrame(frame);}if(!committed)break;sent.incrementAndGet();}}catch(Throwable e){errors.compareAndSet(null,e);s.close();}};
   check(s.tryWriteAction(0x13572468,255),"greeting");current.set(s);return s;
  });
  try{for(int round=0;round<60;round++){
   sent.set(0);current.set(null);try(var peer=new Socket()){peer.setReceiveBufferSize(1024);peer.connect(server.localAddress());peer.setSoTimeout(8000);check(Arrays.equals(peer.getInputStream().readNBytes(8),ActionBatchRegression.plain(0x13572468,255)),"greeting bytes");until(()->current.get()!=null);all.add(current.get());peer.getOutputStream().write(new NetworkRegression.ClientEncoder().frame(1,4,round));until(()->sent.get()>=8||errors.get()!=null);check(errors.get()==null,"server encoding error");peer.setSoLinger(true,0);}
   until(()->server.liveConnections()==0);check(pool.usedRecvSlots()==0&&pool.usedSendSlots()==0,"RST leaked pool");
  }}finally{server.close();check(server.awaitTermination(10,TimeUnit.SECONDS),"group terminate");}
  for(var s:all)check(s.isCloseComplete()&&ProducerTicketRegression.field(s,"_socketPending")==0&&ProducerTicketRegression.field(s,"_socketDraining")==0,"stranded close/serializer");
  check(closed.get()==60&&errors.get()==null,"one close per connection");System.out.println("PASS TcpResetRace:60 RST during queued 4KiB SEND;60 closed;lease0;no stranded serializer");
 }
}
