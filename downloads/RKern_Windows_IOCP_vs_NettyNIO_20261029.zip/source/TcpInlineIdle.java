package l1j.server.server.model.network.core;
import java.net.*;import java.util.*;import java.util.concurrent.*;import java.util.concurrent.atomic.*;
import l1j.server.server.model.network.thread.CIOThreadCallback;
public final class TcpInlineIdle {
 public static void main(String[] a)throws Exception{
  var pool=new CIOBufferPool(8,64,4,4);var ref=new AtomicReference<CIOUserSocket>();
  var server=new CIOServer(new InetSocketAddress("127.0.0.1",0),8,2,8,pool,(ch,p,cb)->{var s=new CIOUserSocket(ch,p,new CIOThreadCallback(),"idle",0,256,cb);var c=new CIOClient(s);s.bindClient(c);s.initializeCipher(NetworkRegression.SEED);c.handler=(op,b)->{if(!s.tryWriteAction(41,41))throw new AssertionError("reply");};ref.set(s);if(!s.tryWriteAction(-1,255))throw new AssertionError("hello");return s;});
  boolean clean=false;
  try(var peer=new Socket()){peer.connect(server.localAddress());peer.setSoTimeout(5000);if(!Arrays.equals(peer.getInputStream().readNBytes(8),ActionBatchRegression.plain(-1,255)))throw new AssertionError("greeting");peer.getOutputStream().write(new NetworkRegression.ClientEncoder().frame(1,4,0));byte[] response=peer.getInputStream().readNBytes(8);if(!Arrays.equals(response,new NetworkRegression.ServerCipher().frame(ActionBatchRegression.body(41,41))))throw new AssertionError("full response cipher");
   Thread.sleep(200);var s=ref.get();clean=s.isWriteIdle()&&pool.usedSendSlots()==0;
   System.out.println("TCP_IDLE {\"response_valid\":true,\"idle\":"+s.isWriteIdle()+",\"send_used\":"+pool.usedSendSlots()+",\"inline\":"+ProducerTicketRegression.field(s,"_inlineWriteCompletion")+",\"event\":"+ProducerTicketRegression.field(s,"_writeEvent")+",\"pending\":"+ProducerTicketRegression.field(s,"_socketPending")+",\"draining\":"+ProducerTicketRegression.field(s,"_socketDraining")+"}");
  }finally{server.close();if(!server.awaitTermination(5,TimeUnit.SECONDS))throw new AssertionError("shutdown");}
  if(pool.usedSendSlots()!=0||pool.usedRecvSlots()!=0)throw new AssertionError("after-close residual");
  if(!clean)throw new AssertionError("completed TCP WRITE remains stranded until extra activity");
 }
}
