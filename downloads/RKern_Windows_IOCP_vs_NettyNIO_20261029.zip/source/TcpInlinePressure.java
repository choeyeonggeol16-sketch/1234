package l1j.server.server.model.network.core;
import java.net.*;import java.util.*;import java.util.concurrent.*;import java.util.concurrent.atomic.*;
import l1j.server.server.model.network.thread.CIOThreadCallback;
public final class TcpInlinePressure {
 public static void main(String[] a)throws Exception{
  var pool=new CIOBufferPool(8,64,4,4);var ref=new AtomicReference<CIOUserSocket>();var calls=new AtomicInteger();
  var server=new CIOServer(new InetSocketAddress("127.0.0.1",0),8,2,8,pool,(ch,p,cb)->{var s=new CIOUserSocket(ch,p,new CIOThreadCallback(),"idle",0,256,cb);var c=new CIOClient(s);s.bindClient(c);s.initializeCipher(NetworkRegression.SEED);c.handler=(op,b)->{calls.incrementAndGet();for(int i=0;i<256;i++)if(!s.tryWriteAction(i,i))throw new AssertionError("reply");};ref.set(s);if(!s.tryWriteAction(-1,255))throw new AssertionError("hello");return s;});
  boolean clean=false;
  try(var peer=new Socket()){peer.connect(server.localAddress());peer.setSoTimeout(5000);if(!Arrays.equals(peer.getInputStream().readNBytes(8),ActionBatchRegression.plain(-1,255)))throw new AssertionError("greeting");var enc=new NetworkRegression.ClientEncoder();var cipher=new NetworkRegression.ServerCipher();
   for(int round=0;round<2;round++){peer.getOutputStream().write(enc.frame(1,4,round));peer.setSoTimeout(800);var expected=new java.io.ByteArrayOutputStream();for(int i=0;i<256;i++)expected.writeBytes(cipher.frame(ActionBatchRegression.body(i,i)));boolean received;try{received=Arrays.equals(peer.getInputStream().readNBytes(2048),expected.toByteArray());}catch(java.net.SocketTimeoutException timeout){received=false;}
    var s=ref.get();System.out.println("PRESSURE round="+round+" fullResponse="+received+" handlers="+calls.get()+" readWritable="+s.isSendReadWritable()+" frames="+s.pendingSendFrames()+" inline="+ProducerTicketRegression.field(s,"_inlineWriteCompletion")+" event="+ProducerTicketRegression.field(s,"_writeEvent")+" tickets="+ProducerTicketRegression.field(s,"_socketPending")+" draining="+ProducerTicketRegression.field(s,"_socketDraining"));if(!received)break;
   }
   Thread.sleep(150);clean=calls.get()==2&&ref.get().isWriteIdle();

  }finally{server.close();if(!server.awaitTermination(5,TimeUnit.SECONDS))throw new AssertionError("shutdown");}
  if(pool.usedSendSlots()!=0||pool.usedRecvSlots()!=0)throw new AssertionError("after-close residual");
  if(!clean)throw new AssertionError("completed TCP WRITE remains stranded until extra activity");
 }
}
