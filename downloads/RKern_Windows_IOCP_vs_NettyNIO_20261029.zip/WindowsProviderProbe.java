import java.nio.channels.spi.AsynchronousChannelProvider;
import java.nio.channels.spi.SelectorProvider;
public class WindowsProviderProbe {
 public static void main(String[] a){
  System.out.printf("""
{"os":"%s","aio_provider":"%s","selector_provider":"%s","java":"%s","java_feature":%d}
""",System.getProperty("os.name"),AsynchronousChannelProvider.provider().getClass().getName(),SelectorProvider.provider().getClass().getName(),System.getProperty("java.version"),Runtime.version().feature());
 }
}
