import argparse,collections,csv,ctypes,datetime,json,os,platform,queue,shutil,statistics,subprocess,sys,threading,time,traceback,zipfile
from pathlib import Path

ROOT=Path(__file__).resolve().parent
p=argparse.ArgumentParser(description='Native Windows: RKern P7/P8 IOCP versus Netty NIO')
p.add_argument('--java',default='java');p.add_argument('--rounds',type=int,default=5)
p.add_argument('--warmup',type=int,default=5);p.add_argument('--seconds',type=int,default=5)
p.add_argument('--server-mask',type=lambda x:int(x,0),default=3)
p.add_argument('--client-mask',type=lambda x:int(x,0),default=12)
p.add_argument('--smoke-only',action='store_true')
A=p.parse_args()
if os.name!='nt':p.error('Windows CPython is required. WSL/Linux is not a Windows IOCP test.')
if sys.version_info<(3,10):p.error('Python 3.10+ is required.')
if not shutil.which(A.java):p.error('Java 21 is required on PATH; alternatively pass --java C:\\path\\to\\java.exe')
if (os.cpu_count()or 0)<4:p.error('At least four logical CPUs are required for the default 2+2 CPU budget.')
if A.server_mask&A.client_mask or any(m<=0 or m.bit_count()!=2 or m.bit_length()>min(64,os.cpu_count())for m in [A.server_mask,A.client_mask]):p.error('Use disjoint two-CPU masks within the current processor group.')
OUT=ROOT/('results_'+datetime.datetime.now().strftime('%Y%m%d_%H%M%S'));OUT.mkdir()
manifest={'platform':platform.platform(),'cpu_count':os.cpu_count(),'python':sys.version.split()[0],
 'server_mask':hex(A.server_mask),'client_mask':hex(A.client_mask),'warmup_s':A.warmup,'measurement_s':A.seconds,'rounds':A.rounds,
 'source_manifest':json.loads((ROOT/'SOURCE_MANIFEST.json').read_text()),'runs':[],'preflight':[],'failures':[]}
def save(): (OUT/'raw.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
def affinity(proc,mask):
 api=ctypes.WinDLL('kernel32',use_last_error=True);fn=api.SetProcessAffinityMask
 fn.argtypes=[ctypes.c_void_p,ctypes.c_size_t];fn.restype=ctypes.c_int
 if not fn(int(proc._handle),mask):raise ctypes.WinError(ctypes.get_last_error())
def java(jar=None):
 cp=str(ROOT/jar)+os.pathsep+str(ROOT/'lib'/'*')if jar else str(ROOT/'probe')
 return [A.java,'-ea','-Xms256m','-Xmx256m','-XX:MaxDirectMemorySize=512m','-XX:ActiveProcessorCount=2','-XX:+UseG1GC',
 '-Dfile.encoding=UTF-8','-Dcio.coalesceSendStart=true','-Dcio.deferOwnedBurstDrain=true','-Dcio.fuseStagedWriteSelection=true',
 '-Dcio.readCompletionFastPath=true','-Dcio.inlineWriteCompletion=false','-Dcio.writeCompletionFastPath=false',
 '-Dcio.writeProfile=false','-Dcio.readPassBurst=true','-Dcio.sendReadHighFrames=256','-Dcio.ioCompletionWorkers=2',
 '-Dcio.ioWorkers=8','-Dcio.sendPoolSlots=4368','-Dcio.producerBurstTickets=false','-Dcio.ioGroupMode=fixed',
 '-Dcio.readFrameBudget=0','-Dbench.readCompleteFlush=true','-cp',cp]
MAIN='l1j.server.server.model.network.core.NettyBench'
CASES=[('single',1,1,1,32,6,1),('response32',128,8,2,32,6,32),('many1024',1024,1,2,32,6,1),('bulk4k',64,4,2,32,4096,1),('window256',16,256,2,32,6,1)]
ENGINES=['P7','P8','NettyNIO']
def trial(case,engine,round_id,warm,seconds,exact=False):
 name,connections,window,ct,req,resp,replies=case;ident=f'{name}-{engine}-{round_id}';q=queue.Queue();procs=[];threads=[];files=[];row={'case':name,'engine':engine,'round':round_id,'exact':exact}
 def start(kind,cmd,mask):
  err=open(OUT/(ident+'-'+kind+'.err'),'w',encoding='utf-8');files.append(err)
  proc=subprocess.Popen(cmd,cwd=ROOT,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=err,text=True,encoding='utf-8',errors='replace',bufsize=1);procs.append(proc);affinity(proc,mask)
  def pump():
   with open(OUT/(ident+'-'+kind+'.log'),'w',encoding='utf-8')as f:
    for line in proc.stdout:f.write(line);f.flush();q.put((kind,line.rstrip()))
   q.put((kind,None))
  t=threading.Thread(target=pump,daemon=True);threads.append(t);t.start();return proc
 try:
  jar='rkern-p7-bench.jar'if engine=='P7'else'rkern-p8-bench.jar'
  server_cmd=java(jar)+[MAIN,'server','netty-nio'if engine=='NettyNIO'else'rkern','2',str(connections+max(256,connections//8)),str(req),str(resp),str(replies)]
  row['server_command']=server_cmd;server=start('server',server_cmd,A.server_mask);ready=None;deadline=time.monotonic()+40
  while ready is None:
   if time.monotonic()>deadline:raise RuntimeError('Server READY timeout')
   try:kind,line=q.get(timeout=1)
   except queue.Empty:continue
   if line is None:raise RuntimeError('Server exited before READY; inspect stderr')
   if line.startswith('READY '):ready=json.loads(line[6:])
  row['ready']=ready
  client_cmd=java('rkern-p8-bench.jar')+[MAIN,'client',str(ready['port']),str(connections),str(window),str(ct),str(warm),str(seconds),str(req),str(resp),str(replies),str(exact).lower()]
  row['client_command']=client_cmd;client=start('client',client_cmd,A.client_mask);deadline=time.monotonic()+warm+seconds+70
  while 'client'not in row or'server'not in row:
   if time.monotonic()>deadline:raise RuntimeError('Measurement/drain timeout')
   try:kind,line=q.get(timeout=1)
   except queue.Empty:
    if client.poll()is not None and client.returncode:raise RuntimeError('Client failed; inspect stderr')
    if server.poll()is not None:raise RuntimeError('Server stopped during measurement')
    continue
   if line is None:
    if kind=='client'and'client'not in row:raise RuntimeError('Client ended without metrics')
    continue
   if kind=='client':
    if line=='MEASURE_BEGIN':server.stdin.write('start\n');server.stdin.flush()
    elif line=='MEASURE_END':server.stdin.write('stop\n');server.stdin.flush()
    elif line.startswith('CLIENT '):row['client']=json.loads(line[7:])
   elif line.startswith('SERVER '):row['server']=json.loads(line[7:])
  if client.wait(timeout=10)!=0:raise RuntimeError('Client exit failure')
  if row['server']['failures']or row['server']['send_rejections']:raise RuntimeError('Server failure/SEND rejection')
  c=row['client']
  if not c['requests']or c['all_responses']!=c['all_requests']*replies:raise RuntimeError('Request/response conservation failure')
  if row['server']['cpu_s']<0:raise RuntimeError('Server process CPU metric unavailable on this JDK')
  row['cpu_us_per_request']=row['server']['cpu_s']*1e6/c['requests']
  row['allocation_B_per_request']=row['server']['heap_allocated_bytes']/c['requests']
  server.stdin.write('quit\n');server.stdin.flush()
  if server.wait(timeout=20)!=0:raise RuntimeError('Server shutdown failure')
  for t in threads:t.join(5)
  for f in files:f.flush()
  if engine!='NettyNIO'and'CLOSE_POOL recv=0 send=0'not in(OUT/(ident+'-server.err')).read_text(encoding='utf-8',errors='replace'):raise RuntimeError('Missing/nonzero RECV/SEND lease shutdown check')
  row['status']='PASS';return row
 finally:
  for proc in procs:
   if proc.poll()is None:
    proc.terminate()
    try:proc.wait(5)
    except subprocess.TimeoutExpired:proc.kill();proc.wait()
  for t in threads:t.join(5)
  for f in files:f.close()

try:
 probe=subprocess.run(java()+['WindowsProviderProbe'],capture_output=True,text=True,check=True)
 provider=json.loads(probe.stdout.strip());manifest['provider']=provider
 if provider['java_feature']!=21:raise RuntimeError('Use Java 21 for this comparison')
 if not provider['os'].lower().startswith('windows')or'WindowsAsynchronousChannelProvider'not in provider['aio_provider']:raise RuntimeError('Native Windows IOCP provider was not confirmed')
 print('Native provider:',provider,flush=True);save()
 for cls in ['TcpInlineIdle','TcpInlinePressure','TcpResetRace']:
  cmd=java('rkern-p8-regressions.jar')+['l1j.server.server.model.network.core.'+cls]
  x=subprocess.run(cmd,cwd=ROOT,capture_output=True,text=True,timeout=90);manifest['preflight'].append({'class':cls,'command':cmd,'returncode':x.returncode,'stdout':x.stdout,'stderr':x.stderr});save()
  if x.returncode:raise RuntimeError('Native TCP regression failed: '+cls)
 for e in ENGINES:
  print('Full-byte preflight:',e,flush=True);manifest['preflight'].append(trial(CASES[3],e,0,1,1,True));save()
 if not A.smoke_only:
  for k in range(A.rounds):
   order=ENGINES[k%3:]+ENGINES[:k%3]
   for case in CASES:
    for engine in order:
     x=trial(case,engine,k+1,A.warmup,A.seconds);manifest['runs'].append(x);save()
     print(f"{case[0]} {engine} round{k+1}: {x['client']['requests_per_s']:,.0f} req/s, p99 {x['client']['p99_us']/1000:.3f}ms, CPU {x['cpu_us_per_request']:.3f}us/req",flush=True)
except Exception:
 manifest['failures'].append(traceback.format_exc());print(manifest['failures'][-1],flush=True);save()
finally:
 summary=[]
 for case in CASES:
  for engine in ENGINES:
   rs=[x for x in manifest['runs']if x['case']==case[0]and x['engine']==engine]
   if not rs:continue
   vals=[x['client']['requests_per_s']for x in rs];summary.append({'case':case[0],'engine':engine,'n':len(rs),'rps':statistics.median(vals),'rps_min':min(vals),'rps_max':max(vals),'p99_ms':statistics.median(x['client']['p99_us']for x in rs)/1000,'CPU_us_per_request':statistics.median(x['cpu_us_per_request']for x in rs)})
 manifest['summary']=summary;save()
 (OUT/'summary.json').write_text(json.dumps(summary,indent=2),encoding='utf-8')
 with(OUT/'summary.csv').open('w',encoding='utf-8-sig',newline='')as f:
  w=csv.DictWriter(f,fieldnames=['case','engine','n','rps','rps_min','rps_max','p99_ms','CPU_us_per_request']);w.writeheader();w.writerows(summary)
 archive=OUT.with_suffix('.zip')
 with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED)as z:
  for f in OUT.rglob('*'):
   if f.is_file():z.write(f,str(f.relative_to(OUT)))
 print('RESULT ZIP:',archive,flush=True)
 if manifest['failures']:sys.exit(1)
