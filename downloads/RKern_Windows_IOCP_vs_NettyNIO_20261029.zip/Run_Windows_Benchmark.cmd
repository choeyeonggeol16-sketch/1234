@echo off
setlocal
cd /d "%~dp0"
where py.exe >nul 2>nul
if errorlevel 1 (
  python.exe windows_benchmark.py
) else (
  py.exe -3 windows_benchmark.py
)
echo.
echo Return the results_YYYYMMDD_HHMMSS.zip file for analysis.
pause
