XML helper SAXException 명시 참조 수정 — 2026-11-02

적용: ZIP의 src 폴더를 기존 프로젝트 src에 병합하고 build.xml을 덮어씁니다. 프로젝트 새로 고침(F5) 후 JDK 21로 Ant Build를 실행합니다. lib 폴더의 기존 Netty/JAXB 및 게임 라이브러리를 함께 사용합니다.

직접 수정한 두 메서드:
- src/l1j/server/server/GMCommandsConfig.java: private static Document loadXml(String file) throws Exception
- src/l1j/server/server/datatables/NpcActionTable.java: private List<L1NpcAction> loadAction(File file, String nodeName) throws Exception

두 파일에서 org.xml.sax.SAXException import 및 해당 예외가 나열된 throws 선언을 제거했습니다. 불필요해진 ParserConfigurationException과 IOException import도 제거했습니다. 기존 호출부는 이미 Exception을 처리합니다. XML 파싱 예외를 무시하거나 다른 타입으로 덮지 않으며, 원래 파싱 예외가 그대로 상위 처리부로 전달됩니다.

이전 숫자 래퍼 생성자 45곳 수정도 포함한 누적 패치입니다. Java 파일 28개와 Ant build.xml을 포함합니다. 한글 인코딩과 줄바꿈을 보존했습니다.

검증: 실제 서버 소스 970개 전체를 -Xlint:removal -Werror로 컴파일하고 JAR을 생성했습니다. 오류 0, warning 0. 실제 두 XML helper에서 정상 XML, 잘못된 XML, 존재하지 않는 파일을 확인했고 기존 파싱/입출력 예외 전파가 유지됐습니다.

주의할 검증 범위: 사용자 Eclipse의 실제 오류 문구/프로젝트 설정은 받지 못해 그 환경의 호환 오류를 재현한 것은 아닙니다. 이 패치는 소스의 명시적인 SAXException 타입 참조를 정리합니다. DOM 파싱은 여전히 JDK의 java.xml을 사용하므로 JDK/XML 모듈 또는 중복 API 설정 문제가 남아 있다면 별도로 해결해야 합니다. GUI/DB를 포함한 전체 서버 기동은 미검증입니다.
