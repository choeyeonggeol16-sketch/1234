import java.io.IOException;
import java.lang.reflect.*;
import java.nio.file.*;
import java.util.List;
import org.w3c.dom.Document;

/** Real server XML helpers: successful parsing and unchanged parser/I/O failures. */
public class XmlExceptionCheck {
    private static void check(boolean ok, String message) {
        if (!ok) throw new AssertionError(message);
    }
    private static Throwable failure(Method method, Object receiver, Object... args) throws Exception {
        try { method.invoke(receiver, args); throw new AssertionError("Invalid input was accepted"); }
        catch (InvocationTargetException expected) { return expected.getCause(); }
    }
    public static void main(String[] args) throws Exception {
        Path valid = Path.of("valid.xml"), invalid = Path.of("invalid.xml"), missing = Path.of("missing.xml");
        Files.writeString(valid, "<Root/>"); Files.writeString(invalid, "<Root>");
        Class<?> gm = Class.forName("l1j.server.server.GMCommandsConfig");
        Method load = gm.getDeclaredMethod("loadXml", String.class); load.setAccessible(true);
        Document doc = (Document) load.invoke(null, valid.toString());
        check(doc.getDocumentElement().getTagName().equals("Root"), "GM XML changed");
        check(failure(load, null, invalid.toString()).getClass().getName().equals("org.xml.sax.SAXParseException"), "GM parser cause was lost");
        check(failure(load, null, missing.toString()) instanceof IOException, "GM I/O cause was lost");

        Files.createDirectories(Path.of("data/xml/NpcActions"));
        Class<?> npc = Class.forName("l1j.server.server.datatables.NpcActionTable");
        Constructor<?> ctor = npc.getDeclaredConstructor(); ctor.setAccessible(true); Object table = ctor.newInstance();
        Method action = npc.getDeclaredMethod("loadAction", java.io.File.class, String.class); action.setAccessible(true);
        check(((List<?>) action.invoke(table, valid.toFile(), "NpcActionList")).isEmpty(), "Unexpected root handling changed");
        check(failure(action, table, invalid.toFile(), "NpcActionList").getClass().getName().equals("org.xml.sax.SAXParseException"), "NPC parser cause was lost");
        check(failure(action, table, missing.toFile(), "NpcActionList") instanceof IOException, "NPC I/O cause was lost");
        System.out.println("PASS actual GMCommandsConfig and NpcActionTable helpers: valid XML, malformed XML and missing-file failures preserved");
    }
}
