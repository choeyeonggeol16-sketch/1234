@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0PSS_UI_ReadOnly_Check.ps1" %*
pause
