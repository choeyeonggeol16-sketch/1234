from pathlib import Path
import subprocess,os,tempfile,sys
root=Path(__file__).resolve().parents[2];before=False
with tempfile.TemporaryDirectory(prefix='ad-startup-') as td:
 b=Path(td)
 def put(name,s):
  p=b/(name+'.java');p.parent.mkdir(parents=True,exist_ok=True);p.write_text(s);return p
 put('l1j/server/L1DatabaseFactory','package l1j.server;public class L1DatabaseFactory{public static L1DatabaseFactory getInstance(){return new L1DatabaseFactory();}public java.sql.Connection getConnection()throws java.sql.SQLException{throw new java.sql.SQLException("DB not used by startup test");}}')
 put('l1j/server/configure/Config','package l1j.server.configure;public class Config{public static int AD_REPORT_SERVER_PORT=0;}')
 put('l1j/server/server/utils/SQLUtil','package l1j.server.server.utils;public class SQLUtil{public static void close(AutoCloseable o){if(o!=null)try{o.close();}catch(Exception e){}}}')
 put('l1j/server/server/AdStartupTest','''package l1j.server.server;
import l1j.server.server.network.*;import java.net.*;import java.util.*;import java.util.concurrent.*;
public class AdStartupTest{
 public static void main(String[]a)throws Exception{
 NetworkConfig c=new NetworkConfig(new Properties());if(c.outboundBytes!=2097152||c.outboundPackets!=8192)throw new AssertionError("game defaults changed");
 try(TransportServer game=new TransportServer(c,s->new SessionApplication(){public byte[] encode(byte[]b){return b;}public byte[] decode(byte[]b){return b;}public void onPacket(byte[]b){}public void onClosed(CloseReason r){}})){
 game.start(new InetSocketAddress("127.0.0.1",0));
 try{AdCheckManager.init();AdCheckManager m=AdCheckManager.getInstance();java.lang.reflect.Field field=AdCheckManager.class.getDeclaredField("server");field.setAccessible(true);TransportServer ad=(TransportServer)field.get(m);
 try(Socket peer=new Socket()){peer.setSoTimeout(5000);peer.connect(ad.localAddress());peer.getOutputStream().write(new byte[]{5,0,0,0,'p','r','o','b','e'});if(peer.getInputStream().read()!=-1)throw new AssertionError("ad did not close");}
 if(!ad.awaitDrained(5000))throw new AssertionError("ad not retired");if(ad.snapshot().processed()!=1||ad.snapshot().handlerErrors()!=0)throw new AssertionError("ad packet failed "+ad.snapshot());
 java.lang.reflect.Field ips=AdCheckManager.class.getDeclaredField("_IpMap");ips.setAccessible(true);if(((Map<?,?>)ips.get(m)).size()!=1)throw new AssertionError("actual AdChecker was not exercised");
 if(game.localAddress().getPort()==0)throw new AssertionError();System.out.println("PASS game 2MiB defaults + actual AdCheckManager/AdChecker startup + real LE32 TCP request + session cleanup");
 }finally{AdCheckManager.closeNetwork();}
 }
 }}''')
 manager=Path('/workspace/netty-monster-validation/AdCheckManager.before.java') if before else root/'src/l1j/server/server/AdCheckManager.java'
 mp=b/'l1j/server/server/AdCheckManager.java';mp.write_bytes(manager.read_bytes())
 jars=sorted(Path(os.environ.get('NETTY_LIB_DIR',str(root/'lib'))).glob('*.jar'));cp=os.pathsep.join(map(str,jars))
 sources=[*b.rglob('*.java'),* (root/'src/l1j/server/server/network').glob('*.java'),root/'src/l1j/server/server/AdChecker.java']
 subprocess.run([os.environ.get('JAVAC','javac'),'--release','21','-encoding','MS949','-cp',cp,'-d',td,*map(str,sources)],check=True)
 r=subprocess.run(['java','-ea','-cp',td+os.pathsep+cp,'l1j.server.server.AdStartupTest'],text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=30)
 log=root/'test-results'/'monster-burst'/'ad-startup.log';log.parent.mkdir(parents=True,exist_ok=True);log.write_text(r.stdout);print(r.stdout);sys.exit(r.returncode)
