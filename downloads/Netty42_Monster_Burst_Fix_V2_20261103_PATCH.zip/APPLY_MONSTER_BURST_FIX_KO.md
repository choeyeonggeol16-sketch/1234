# V2 — 광고 서버 기동 오류 추가 수정

이전 수정에서 게임 세션 기본 송신 예산을 2MiB로 늘렸지만 AdCheckManager는 전체 예산을 1MiB로 고정하고 있었습니다. 그 결과 `globalOutboundBytes must be in 2097152..17179869184`로 초기화가 실패했습니다. 광고 서버에 별도 outboundPackets=512, outboundBytes=524288을 명시했습니다. 게임 서버의 8192개/2MiB 설정은 유지합니다.

**이전 수정본 적용 후 이 오류만 고치려면 `src/l1j/server/server/AdCheckManager.java`를 교체하고 재빌드하면 됩니다.** config/network.properties의 globalOutboundBytes를 바꾸는 것으로는 이 별도 코드 설정을 고칠 수 없습니다. 스택의 `Failed to Load ./config/log.properties File`은 이번 예외의 직접 원인이 아닙니다.

원본 AdCheckManager에서 동일 예외를 재현했고, 수정 후 실제 AdCheckManager/AdChecker와 Netty 코어를 컴파일하여 게임 리스너와 광고 리스너 기동, 실제 LE32 TCP 요청 처리, 연결 정리를 통과했습니다. DB 의존성은 대체했고 테스트 요청은 DB를 호출하지 않았습니다. 전체 게임/DB 기동 완료를 뜻하지는 않습니다.

추가 회귀: `NETTY_LIB_DIR=/path/to/lib python3 tests/monster_burst/test_ad_startup.py`

이번 V2 패치는 이전 4개 네트워크 파일과 AdCheckManager까지 총 5개를 포함합니다.

---

# 몬스터 대량 생성 시 Netty 송신 차단 수정

원본: Netty42_Mailbox_Progress_ReadResume_20261103_FULL_SRC.zip

## 확인한 원인과 수정

기존 송신 대기 한도는 세션당 512개/512KiB였다. I/O 루프가 다른 일을 하는 짧은 동안 표시·이동 패킷을 몰아 보내면, 정상적으로 읽는 클라이언트라도 OUTBOUND_OVERLOAD로 연결을 닫을 수 있었다. 원본은 이 원인을 콘솔에 남기지 않았다.

실제 Netty TCP 재현에서 64바이트 본문은 512개(33,792바이트)에서 차단됐다. 패킷 수만 늘린 중간 버전도 192바이트 본문은 2,702개(524,188바이트)에서 기존 바이트 한도에 걸렸다. 수정본은 기본값을 8,192개/2MiB로 조정했다. 메모리를 미리 2MiB 할당하지 않으며, 실제 대기 데이터만 예약한다. 전체 128MiB/262,144개 제한, 개별 제한과 느린 송신 종료 정책은 유지한다. 지속 부하가 네트워크 처리량을 초과하는 경우에는 여전히 제한으로 종료된다.

초과 시 어떤 제한(sessionPackets/sessionBytes/globalPackets/globalBytes)에 걸렸는지와 사용량을 서버 전체 10초에 한 번 기록한다. 시작 로그에도 적용된 한도를 표시해 옛 설정이 남았는지 확인할 수 있다. 기존 계정·클라이언트·프로토콜·월드 상태 코드는 변경하지 않았다.

## 적용

1. 서버를 종료하고 기존 소스·빌드 산출물을 백업한다.
2. 패치 ZIP의 src 아래 4개 파일을 동일한 경로에 교체하거나 전체 소스를 사용한다. JDK 21과 기존 Netty 4.2.19.Final 라이브러리로 프로젝트 전체를 재빌드한다. 이전 class/JAR가 실행 클래스패스에 남지 않게 한다.
3. **실제 설정 경로는 `config/network.properties`다.** 기존 파일이 있다면 다른 설정을 유지하면서 다음 두 키만 수정한다. 명시된 기존 값은 코드의 새 기본값보다 우선하므로 소스만 교체하면 이전 512개 설정이 계속 적용될 수 있다.

```properties
outboundPackets=8192
outboundBytes=2097152
```

4. 기존 설정 파일에 두 키가 없거나 설정 파일 자체가 없으면 새 기본값이 적용된다. 파일 전체를 위 두 줄로 덮어쓰지 않는다.
5. 시작 로그의 `outboundPackets=8192 outboundBytes=2097152`를 확인한다. 이후 대량 생성 상황의 콘솔과 입력 반응을 확인한다. `Outbound overload`가 있다면 limit/사용량이 추가 진단 근거다. 무조건 한도를 계속 높이는 방식으로 대응하지 않는다.

교체 파일:
- src/l1j/server/server/network/NetworkConfig.java
- src/l1j/server/server/network/NetworkMetrics.java
- src/l1j/server/server/network/NettySession.java
- src/l1j/server/server/network/TransportServer.java

## 검증

실제 첨부 소스의 네트워크 코어 9개를 JDK 21/Netty 4.2.19.Final로 컴파일해 Linux 로컬 TCP로 검사했다. 게임/DB를 대체하는 SessionApplication을 사용했으며, 상태형 테스트 codec으로 패킷 순서에 따른 인코딩을 확인했다. 실제 Lineage 암호화나 실제 몬스터 AI 부하를 테스트한 것은 아니다.

- 원본: 6,000개 순간 송신 테스트 실패, 512개에서 송신 거부 재현.
- 수정: 64바이트 본문 6,000개 전달, 전체 FIFO, 송신 이후 클라이언트 요청/에코 처리, 자원 반환 통과.
- 수정: 192바이트 본문 6,000개(총 wire 1,164,000바이트) 전달과 동일 검사 통과.
- 수정: 송신자 4개가 각각 1,500개를 동시에 제출. 송신자별 FIFO, 원본 배열을 변경해도 송신 내용 보존, 상태형 codec 순서 및 반환 통과.
- 바이트 상한/명시한 작은 패킷 상한/전역 패킷 상한의 거부 및 종료 후 자원 반환 통과.

재실행:

```sh
NETTY_LIB_DIR=/path/to/server/lib python3 tests/monster_burst/run.py
```

Java 21 javac와 java가 PATH에 필요하다. localhost TCP 연결 권한이 필요하다. 로그는 test-results/monster-burst 아래 생성된다.

전체 게임 서버 컴파일·기동, 운영 서버, 몬스터 수천 마리 AI·경로 탐색·DB·클라이언트 렌더링은 이 환경에서 재현하지 못했다. 따라서 사용자가 겪은 먹통의 유일한 원인이 이것이라고 확정하지 않는다. 이번 수정은 확인·재현한 Netty 송신 한도 결함을 해결한다. CPU 포화나 다른 대기 문제가 남으면 새 한도/초과 로그와 게임 스레드 덤프를 기준으로 구분해야 한다.
