#define CIONC_TEST
#include "../native/CIONcTransport.cpp"
#include <cassert>
#include <iostream>
#include <random>
#include <future>

static void check(bool ok, const char* message) { if (!ok) throw std::runtime_error(message); }
template<class Predicate> static void until(Predicate p) {
 const auto end = std::chrono::steady_clock::now() + std::chrono::seconds(5);
 while (!p()) { if (std::chrono::steady_clock::now() > end) throw std::runtime_error("completion deadline"); std::this_thread::yield(); }
}
struct Probe {
 std::mutex mutex;
 std::vector<std::uint64_t> ids;
 std::vector<unsigned char> received;
 std::atomic<int> closed{0}, sent{0};
 std::atomic<bool> echo{false}, pauseInCallback{false}, reject{false}, attemptStop{false};
 std::atomic<bool> blockReceive{false}, readEntered{false}, releaseRead{false};
};
static Probe* probe;
static int acceptCallback(void* server, std::uint64_t id, std::uint64_t) {
 { std::lock_guard<std::mutex> lock(probe->mutex); probe->ids.push_back(id); }
 if (probe->attemptStop.load()) check(!CIO_Server_Stop(server), "worker joined itself");
 return probe->reject ? 2 : 0;
}
static int receiveCallback(void* server, std::uint64_t id, const void* data, int length) {
 {
  std::lock_guard<std::mutex> lock(probe->mutex);
  const auto* p = static_cast<const unsigned char*>(data); probe->received.insert(probe->received.end(), p, p + length);
 }
 if (probe->pauseInCallback) CIO_Server_PauseReceive(server, id, 1);
 if (probe->blockReceive) { probe->readEntered=true; while(!probe->releaseRead.load())std::this_thread::yield(); }
 if (probe->echo) check(CIO_Server_Send(server, id, data, length), "reentrant receive/send failed");
 return 0;
}
static int sendCallback(void*, std::uint64_t, const void*, int length) { probe->sent.fetch_add(length); return 0; }
static int closeCallback(void*, std::uint64_t, int, int) { ++probe->closed; return 0; }

struct Fixture {
 Probe state; void* listener; Server* server;
 Fixture() {
  probe = &state; listener = CIO_Create_TcpServerListener();
  CIO_Set_FN_Server_OnAccept(listener, acceptCallback); CIO_Set_FN_Server_OnReceive(listener, receiveCallback);
  CIO_Set_FN_Server_OnSend(listener, sendCallback); CIO_Set_FN_Server_OnClose(listener, closeCallback);
  server = static_cast<Server*>(CIO_Create_TcpServer(listener)); CIO_Server_SetWorkerThreadCount(server, 4);
  check(CIO_Server_Start(server, "127.0.0.1", 0), "start failed");
 }
 std::pair<SOCKET,std::uint64_t> connect() {
  std::size_t count; { std::lock_guard<std::mutex> lock(state.mutex); count = state.ids.size(); }
  auto socket = fakewin::connect(server->listening);
  until([&]{std::lock_guard<std::mutex> lock(state.mutex);return state.ids.size() > count;});
  std::lock_guard<std::mutex> lock(state.mutex); return {socket,state.ids[count]};
 }
 ~Fixture() {
  fakewin::holdSend = false;
  check(CIO_Server_Stop(server), "stop failed"); check(CIO_Server_Wait(server, 0), "wait confused with running");
  CIO_Destroy_TcpServer(server); CIO_Destroy_TcpServerListener(listener);
 }
};
static void coreTests() {
 using namespace cionc;
 CIOBufferPool pool(1000); SendChain q;
 std::vector<unsigned char> payload(31000); for(std::size_t i=0;i<payload.size();++i)payload[i]=static_cast<unsigned char>(i*37);
 Span parts[]={{payload.data(),100},{payload.data()+100,9000},{payload.data()+9100,payload.size()-9100}};
 check(q.append(pool,parts,3),"copy gathering failed");
 std::vector<unsigned char> got; std::mt19937 random(27);
 while(q.head()) {
  auto* block=q.head(); auto remaining=block->used-block->offset; auto n=std::min<std::size_t>(remaining,1+random()%97);
  got.insert(got.end(),block->data.begin()+block->offset,block->data.begin()+block->offset+n);
  CIOBuffer* retired;check(q.complete(n,retired),"partial completion rejected");pool.recycle(retired);
 }
 check(got==payload&&q.size()==0,"partial sends reordered/lost bytes");
 Span one{payload.data(),100};check(q.append(pool,&one,1),"append failed");CIOBuffer* p;
 check(!q.complete(0,p)&&!q.complete(101,p)&&q.size()==100,"invalid completion changed queue");q.clear(pool);
 CIOBufferPool tiny(1);SendChain bounded;Span large{payload.data(),9000};
 check(!bounded.append(tiny,&large,1)&&!bounded.head()&&bounded.size()==0,"partial gather admission on OOM");
 IoState life;life.closing=true;check(!life.canClose(),"close bypassed accept callback");life.acceptDelivering=false;
 check(life.canClose(),"idle closing gate");life.readPosted=true;check(!life.canClose(),"close bypassed read");life.readPosted=false;
 life.writeDelivering=true;check(!life.canClose(),"close bypassed send callback");
 std::cout<<"PASS production 8192-byte pool/FIFO: gathering, randomized partial completion, invalid lengths, atomic allocation failure, lifetime gates\n";
}
static void engineTests() {
 {
  Fixture f;auto [socket,id]=f.connect();
  std::vector<unsigned char> input(17000);for(std::size_t i=0;i<input.size();++i)input[i]=static_cast<unsigned char>(i*19);
  fakewin::feed(socket,input);
  {std::lock_guard<std::mutex> lock(f.state.mutex);check(f.state.received.empty(),"accepted socket was not paused");}
  f.state.echo=true;fakewin::sendChunk=37;
  check(CIO_Server_PauseReceive(f.server,id,0),"resume failed");
  until([&]{return f.state.sent==static_cast<int>(input.size());});
  check(fakewin::wire(socket)==input,"echo/partial-send ordering mismatch");
  {std::lock_guard<std::mutex> lock(f.state.mutex);check(f.state.received==input,"receive data changed while borrowed");}
  char address[64];int capacity=64;unsigned short port;
  check(CIO_Server_GetRemoteAddress(f.server,id,address,&capacity,&port)&&std::string(address)=="127.0.0.1"&&port==23456,"address ABI");
  check(CIO_Server_Disconnect(f.server,id,1),"disconnect failed");until([&]{return f.state.closed==1;});
  until([&]{return !f.server->connections.load();});
  check(!CIO_Server_PauseReceive(f.server,id,0),"stale ID resolved after close");
 }
 std::cout<<"PASS actual native adapter: AcceptEx admission paused, 17000-byte receive/echo, synchronous success plus 37-byte completions, address lookup, stale ID rejection\n";
 {
  Fixture f;auto [socket,id]=f.connect();fakewin::holdSend=true;fakewin::sendChunk=8192;
  std::array<std::vector<unsigned char>,8> data;std::array<WSABUF,8> buffers;std::vector<unsigned char> expected;
  for(int i=0;i<8;++i){data[i].assign(7000,static_cast<unsigned char>(i+1));buffers[i]={7000,reinterpret_cast<char*>(data[i].data())};expected.insert(expected.end(),data[i].begin(),data[i].end());}
  check(CIO_Server_SendPackets(f.server,id,buffers.data(),8),"gathering ABI failed");
  for(auto& bytes:data)std::fill(bytes.begin(),bytes.end(),0);
  fakewin::holdSend=false;fakewin::flush(socket);until([&]{return f.state.sent==56000;});
  check(fakewin::wire(socket)==expected,"temporary gather source retained after return");
 }
 std::cout<<"PASS actual eight-WSABUF API, 56000-byte ordered send and immediate caller buffer reuse after native copy\n";
 {
  Fixture f;auto [socket,id]=f.connect();f.state.blockReceive=true;
  CIO_Server_PauseReceive(f.server,id,0);fakewin::feed(socket,{1,2,3});until([&]{return f.state.readEntered.load();});
  CIO_Server_Disconnect(f.server,id,1);check(f.state.closed==0,"terminal callback bypassed active receive callback");
  f.state.releaseRead=true;until([&]{return f.state.closed==1;});
 }
 std::cout<<"PASS remote disconnect while receive callback is active preserves its buffer and delays terminal delivery\n";
 {
  Fixture f;auto [socket,id]=f.connect();f.state.pauseInCallback=true;
  fakewin::feed(socket,std::vector<unsigned char>(9000,7));CIO_Server_PauseReceive(f.server,id,0);
  until([&]{std::lock_guard<std::mutex> lock(f.state.mutex);return f.state.received.size()==4096;});
  {auto* c=f.server->find(id);ObjectRef hold(c,false);std::lock_guard<std::mutex> lock(c->gate);check(!c->state.readPosted&&c->state.paused,"reentrant pause did not stop next receive");}
  f.state.pauseInCallback=false;CIO_Server_PauseReceive(f.server,id,0);
  until([&]{std::lock_guard<std::mutex> lock(f.state.mutex);return f.state.received.size()==9000;});
  fakewin::holdSend=true;const unsigned char data[]={1,2,3,4};check(CIO_Server_Send(f.server,id,data,4),"held send failed");
  CIO_Server_Disconnect(f.server,id,1);until([&]{return f.state.closed==1;});
 }
 std::cout<<"PASS callback-reentrant pause/resume; close with both a posted read and held write drains cancellations before one terminal callback\n";
 {
  Fixture f;auto [socket,id]=f.connect();fakewin::holdSend=false;fakewin::failSend=true;
  const unsigned char data[]={9,8,7};check(!CIO_Server_Send(f.server,id,data,3),"immediate WSASend failure accepted");
  until([&]{return f.state.closed==1;});
 }
 {
  Fixture f;auto [socket,id]=f.connect();fakewin::failRead=true;CIO_Server_PauseReceive(f.server,id,0);
  until([&]{return f.state.closed==1;});
 }
 {
  Fixture f;f.state.reject=true;auto connection=f.connect();until([&]{return f.state.closed==1;});
 }
 {
  Fixture f;f.state.attemptStop=true;auto connection=f.connect();
 }
 std::cout<<"PASS immediate submission failures balance I/O holds; rejected accept cleanup; completion worker cannot self-join\n";
 for(int cycle=0;cycle<10;++cycle) {
  Fixture f;std::vector<std::pair<SOCKET,std::uint64_t>> connections;
  for(int i=0;i<12;++i)connections.push_back(f.connect());
  for(auto [socket,id]:connections)CIO_Server_PauseReceive(f.server,id,0);
  std::vector<std::thread> closers;
  for(auto [socket,id]:connections)closers.emplace_back([&,id]{for(int k=0;k<5;++k)CIO_Server_Disconnect(f.server,id,1);});
  for(auto& t:closers)t.join();
  check(CIO_StopAccepting(f.server),"accept-stop failed");until([&]{return f.state.closed==12;});
  check(f.server->pendingAccepts==0,"accept operation hold leaked");
 }
 std::cout<<"PASS 120 connections/600 concurrent repeated closes; pending accepts cancelled and all workers drained over ten server lifetimes\n";
}
int main(){coreTests();engineTests();std::cout<<"PASS all native tests. Windows completion APIs are fixtures, not the Windows kernel.\n";}
