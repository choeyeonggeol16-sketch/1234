@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0PSS_Settings_Show_Test.ps1" %*
pause
