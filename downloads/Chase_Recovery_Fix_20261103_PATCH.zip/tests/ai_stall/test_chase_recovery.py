#!/usr/bin/env python3
"""Production target selection + chase action with deterministic actor/movement edges.

No live DB/client/scheduler. Only wall clock calls are replaced by Clock.now;
selection, cooldown, progress and action result logic are extracted unchanged.
--baseline-root runs common user scenarios against the previous public source.
"""
from pathlib import Path
import argparse, re, subprocess, tempfile

root = Path(__file__).resolve().parents[2]
p = argparse.ArgumentParser()
p.add_argument('--baseline-root', type=Path)
args = p.parse_args()
source = (args.baseline_root or root) / 'src/l1j/server/server/model/character/autohunt'

def method(text, name):
    m = re.search(r'(?m)^    (?:public|private|protected)[^\n;{]*\b' + name + r'\(', text)
    assert m, name
    b = text.index('{', m.start())
    depth, i = 1, b + 1
    while depth:
        if text[i] == '{': depth += 1
        elif text[i] == '}': depth -= 1
        i += 1
    return text[m.start():i]

processor = (source / 'AHProcessor.java').read_text()
names = ['onSeeCreature', 'onOutOfSight', 'seedKnownTargets', 'selectTarget',
         'checkTarget', 'tagertClear', 'isAttack', 'isAutoAttackPosition',
         'retargetWhenMoveBlocked', 'validateAutoCombatTarget', 'isDistance', 'getDistance']
if not args.baseline_root:
    names += ['retargetToAttackable', 'selectAlternativeTarget', 'isTemporarilyBlocked',
              'rememberBlockedTarget', 'abandonBlockedTarget']
proc_methods = '\n'.join(method(processor, n) for n in names)
executor = (source / 'AHExecutor.java').read_text()
executor_methods = '\n'.join(method(executor, n) for n in ['startAutoHunt', 'resetAuto'])
action = (source / 'ai/action/AHMoveToTargetAction.java').read_text()
action = action[action.index('public final class AHMoveToTargetAction'):]
state = (root / 'src/l1j/server/server/model/character/autohunt/AutoHuntChaseState.java').read_text()
state = state[state.index('public final class AutoHuntChaseState'):]

java = r'''
import java.util.*;
class ChaseRecoveryContract {
 static class Clock {static long now=100000;}
 static final class EActionCodes {static final int walk=0;}
 static class Location {
  final L1Object owner;Location(L1Object c){owner=c;}
  int getTileLineDistance(Location t){return Math.max(Math.abs(owner.x-t.owner.x),Math.abs(owner.y-t.owner.y));}
 }
 static class MapGrid {boolean safe;boolean isSafetyZone(Location l){return safe;}}
 static class L1Object {int id,x,y,map=1;int getId(){return id;}int getX(){return x;}int getY(){return y;}int getMapId(){return map;}}
 static class L1Character extends L1Object {
  boolean dead,invis;int hp=100;final MapGrid grid=new MapGrid();
  boolean isDead(){return dead;}int getCurrentHp(){return hp;}boolean isInvisble(){return invis;}
  Location getLocation(){return new Location(this);}MapGrid getMap(){return grid;}
 }
 static class L1MonsterInstance extends L1Character {int hidden;int getHiddenStatus(){return hidden;}}
 static class Targets {
  ArrayList<L1Character> list=new ArrayList<>();int copies;
  boolean isEmpty(){return list.isEmpty();}void clear(){list.clear();}
  ArrayList<L1Character> toTargetArrayList(){copies++;return new ArrayList<>(list);}
 }
 static class L1PcInstance extends L1Character {
  boolean active=true,dirty=true,stun,tu;int range=1,ignore,fail,action;long ignoreUntil,teleport,walk=150;
  int knownReads;L1Character target;final Targets candidates=new Targets();
  final ArrayList<L1Object> known=new ArrayList<>();final HashSet<Long> noLos=new HashSet<>();
  AutoHuntChaseState state;
  boolean getAutoHunt(){return active;}void setAutoHunt(boolean b){active=b;}
  Iterable<L1Object> getKnownObjects(){knownReads++;return known;}
  boolean canSeeObject(L1Object o){return o.map==map&&getLocation().getTileLineDistance(new Location(o))<=20;}
  boolean glanceCheck(int x,int y){return !noLos.contains(((long)x<<32)^(y&0xffffffffL));}
  void addAutoTargetList(L1Character m){if(!candidates.list.contains(m))candidates.list.add(m);}
  void removeAutoTargetList(L1Character m){candidates.list.remove(m);}
  Targets getAutoTargetList(){return candidates;}
  L1Character getAutoTarget(){return target;}void setAutoTarget(L1Character m){target=m;}
  boolean isAutoTargetDirty(){return dirty;}void setAutoTargetDirty(boolean b){dirty=b;}
  int getAutoIgnoreTarget(){return ignore;}void setAutoIgnoreTarget(int n){ignore=n;}
  long getAutoIgnoreTime(){return ignoreUntil;}void setAutoIgnoreTime(long n){ignoreUntil=n;}
  int getAttackRang(){return range;}long getCurrentSpriteInterval(int a){return walk;}
  void setAutoTeleportTime(long n){teleport=n;}
  int getAutoMoveFailCount(){return fail;}void setAutoMoveFailCount(int n){fail=n;}
  AutoHuntChaseState getAutoChaseState(){if(state==null)state=new AutoHuntChaseState();return state;}
  void resetAutoChaseState(){state=null;}
  boolean potion;int notices;
  int getCurrentSpriteId(){return 100;}void setAutoPotion(boolean b){potion=b;}
  void setAutoMapId(int n){}void setAutoPolyID(int n){}
  void setAutoMoveCount(int n){}void setAutoSkillDelay(int n){}
  void setAutoNearbyMobCount(int n){}void setAutoThreatScanTime(long n){}
  void resetAutoRoam(){}void setAutoTargetItem(Object n){}
 }
 static class L1World {
  static final L1World ONE=new L1World();static L1World getInstance(){return ONE;}
  final HashMap<Integer,L1Object> objects=new HashMap<>();int lookups;
  L1Object findObject(int id){lookups++;return objects.get(id);}
 }
 static class CommonUtil {static boolean isAutoNonActionSkill(L1PcInstance p){return p.stun;}}
 static class AHUseSkill {static AHUseSkill getInstance(){return new AHUseSkill();}
  boolean handleTurnUndeadChase(L1PcInstance p,L1Character t){return p.tu;}}
 static class AHSetMoving {
  static final byte RUNNING=0,AT_DISTANCE=1,INVALID=2,PATH_FAILED=3,DYNAMIC_BLOCKED=4;
  static byte outcome;static int dx,dy,calls,blocker;static L1Character movedTarget;
  static void reset(){outcome=RUNNING;dx=dy=calls=blocker=0;movedTarget=null;}
  static void clear(L1PcInstance p){}
  static int lastBlockerId(L1PcInstance p){return blocker;}
  static byte tick(L1PcInstance p,L1Character t,int r){calls++;movedTarget=t;p.x+=dx;p.y+=dy;return outcome;}
 }
 static class AHController {
  static final int ACTION_NONE=-1;
  static final byte RESULT_RUNNING=0,RESULT_DONE=1,RESULT_INVALID=2,RESULT_STOP=3;
  static void set(L1PcInstance p,int n){p.action=n;}
  static void attack(L1PcInstance p){p.action=2;}static void think(L1PcInstance p){p.action=1;}
 }
''' + state.replace('public final class', 'static final class', 1) + r'''
 static class AHProcessor {
  static final int TARGET_SCAN_RANGE=20;static final long TELEPORT_APPROACH_BUDGET_MS=1000;
  static final AHProcessor ONE=new AHProcessor();static AHProcessor getInstance(){return ONE;}
  boolean canUseTeleport(L1PcInstance p){return false;}
''' + proc_methods + '\n}\n' + action.replace('public final class', 'static final class', 1) + r'''
 static class Config {static final boolean AUTO_HUNT_DEFAULT_POTION=true;}
 static class SC_SystemMessage {static void send(L1PcInstance p,String text){p.notices++;}}
 static class CIOThreadCallback {
  interface Handle {boolean isCancelled();}
  static final CIOThreadCallback ONE=new CIOThreadCallback();static CIOThreadCallback getInstance(){return ONE;}
  boolean allow=true,cancelled;Runnable admission;
  Handle startAutoHunt(int id,long delay){if(admission!=null)admission.run();return allow?()->cancelled:null;}
  void clearPcState(L1PcInstance p){}
 }
 static class AHExecutor {
  void sendGuidancePackets(L1PcInstance p){p.notices++;}
''' + executor_methods + r'''
 }
 static final AHProcessor P=AHProcessor.getInstance();static int passed,failed;
 static void check(boolean c,String why){if(!c)throw new AssertionError(why);}
 static void test(String name,Runnable r){Clock.now=100000;AHSetMoving.reset();L1World.ONE.objects.clear();L1World.ONE.lookups=0;
  try{r.run();passed++;System.out.println("PASS "+name);}catch(Throwable e){failed++;System.out.println("FAIL "+name+": "+e);}}
 static L1PcInstance pc(){L1PcInstance p=new L1PcInstance();p.id=90;p.x=p.y=10;return p;}
 static L1MonsterInstance mon(int id,int x,int y){L1MonsterInstance m=new L1MonsterInstance();m.id=id;m.x=x;m.y=y;L1World.ONE.objects.put(id,m);return m;}
 static L1MonsterInstance rear(L1PcInstance p){L1MonsterInstance m=mon(1,10,16);p.target=m;P.onSeeCreature(p,m);return m;}
 public static void main(String[] args){
  test("known monsters present before hunt are selectable without a new sight event",()->{
   L1PcInstance p=pc();L1MonsterInstance a=mon(2,10,11),b=mon(1,10,16);p.known.add(b);p.known.add(a);
   P.seedKnownTargets(p);P.selectTarget(p);check(p.target==a,"front monster missing");
  });
  test("front attackable monster replaces rear chase before another old-target move",()->{
   L1PcInstance p=pc();rear(p);L1MonsterInstance front=mon(2,10,11);P.onSeeCreature(p,front);
   check(AHMoveToTargetAction.onTick(p)==0&&p.target==front,"rear target retained while front is in range");
   check(AHSetMoving.calls==0,"movement used captured rear target after retarget");
   check(AHMoveToTargetAction.onTick(p)==1,"front not handed to ATTACK");
  });
  test("dynamic block repairs missed AOI candidates from known objects",()->{
   L1PcInstance p=pc();rear(p);L1MonsterInstance front=mon(2,10,12);p.known.add(front);
   AHSetMoving.outcome=4;AHMoveToTargetAction.onTick(p);check(p.target==front,"already-known blocker absent from candidates");
  });
  test("direct visible monster blocker repairs missing known-list event",()->{
   L1PcInstance p=pc();rear(p);L1MonsterInstance front=mon(2,10,12);AHSetMoving.blocker=front.id;
   AHSetMoving.outcome=4;AHMoveToTargetAction.onTick(p);check(p.target==front,"direct blocker not considered");
  });
  test("blocked rear/front pair cannot ping-pong on every retry",()->{
   L1PcInstance p=pc();L1MonsterInstance back=rear(p),front=mon(2,10,12);P.onSeeCreature(p,front);
   AHSetMoving.outcome=4;AHMoveToTargetAction.onTick(p);check(p.target==front,"first block did not prefer front");
   for(int n=0;n<4;n++){Clock.now+=350;AHMoveToTargetAction.onTick(p);check(p.target==front,"blocked target selected again before expiry");}
  });
  test("permanent single body blockage releases chase and returns to THINK",()->{
   L1PcInstance p=pc();rear(p);AHSetMoving.outcome=4;AHMoveToTargetAction.onTick(p);byte result=0;
   for(int n=0;n<16&&result==0;n++){Clock.now+=250;result=AHMoveToTargetAction.onTick(p);}
   check(result==2&&p.target==null,"permanent RUNNING pins action");AHMoveToTargetAction.onEnd(p,result);check(p.action==1,"THINK not resumed");
  });
  test("RUNNING without physical movement also expires and cannot refresh idle time",()->{
   L1PcInstance p=pc();rear(p);p.teleport=123;byte result=0;
   for(int n=0;n<15&&result==0;n++){Clock.now+=250;result=AHMoveToTargetAction.onTick(p);}
   check(result==2&&p.target==null,"nonmoving RUNNING never releases target");check(p.teleport==123,"standing tick refreshes idle timer");
  });
  test("two-tile oscillation is not navigation progress",()->{
   L1PcInstance p=pc();rear(p);byte result=0;
   for(int n=0;n<20&&result==0;n++){Clock.now+=250;p.x=10+(n&1);result=AHMoveToTargetAction.onTick(p);}
   check(result==2&&p.target==null,"short loop kept chase alive forever");
  });
  test("real detour steps keep chase alive and refresh idle timer",()->{
   L1PcInstance p=pc();L1MonsterInstance m=rear(p);
   for(int n=0;n<18;n++){Clock.now+=700;p.x=10+n;p.y=10+n/8;m.x=p.x;m.y=p.y+6;AHSetMoving.dx=1;
    check(AHMoveToTargetAction.onTick(p)==0&&p.target==m,"valid detour abandoned");check(p.teleport==Clock.now,"moved tick not recorded");}
  });
  test("slow sprite gets its own no-progress budget",()->{
   L1PcInstance p=pc();L1MonsterInstance m=rear(p);p.walk=1000;AHSetMoving.outcome=4;AHMoveToTargetAction.onTick(p);
   Clock.now+=7000;check(AHMoveToTargetAction.onTick(p)==0&&p.target==m,"slow actor expired before eight walk intervals");
   Clock.now+=1100;check(AHMoveToTargetAction.onTick(p)==2&&p.target==null,"slow actor never expires");
  });
  test("control and turn-undead waits preserve combat intent",()->{
   for(boolean tu:new boolean[]{false,true}){L1PcInstance p=pc();L1MonsterInstance m=rear(p);p.stun=!tu;p.tu=tu;
    for(int n=0;n<8;n++){Clock.now+=2000;check(AHMoveToTargetAction.onTick(p)==0&&p.target==m,"intentional wait mistaken for blocked chase");}
    check(AHSetMoving.calls==0,"intentional wait moved actor");p.stun=p.tu=false;check(AHMoveToTargetAction.onTick(p)==0&&p.target==m,"first resumed tick abandoned target");AHSetMoving.reset();}
  });
  test("static failure limit releases current target, not immediately reacquiring it",()->{
   L1PcInstance p=pc();rear(p);AHSetMoving.outcome=3;byte r=0;
   for(int n=0;n<31;n++){Clock.now+=20;r=AHMoveToTargetAction.onTick(p);}
   check(r==2&&p.target==null,"31 path failures left current live target");P.selectTarget(p);check(p.target==null,"failed target immediately reacquired");
  });
  test("clean candidates are revisited when existing monster becomes usable",()->{
   L1PcInstance p=pc();L1MonsterInstance m=mon(1,10,12);P.onSeeCreature(p,m);m.hidden=1;P.selectTarget(p);
   check(p.target==null&&!p.dirty,"hidden target chosen");m.hidden=0;Clock.now+=350;P.selectTarget(p);
   check(p.target==m,"no new sight event leaves stationary hunter blind");
  });
  test("invalid candidates and LOS remain enforced",()->{
   L1PcInstance p=pc();L1MonsterInstance hidden=mon(1,10,11),dead=mon(2,9,11),invis=mon(3,11,11),safe=mon(4,10,9),other=mon(5,9,10),valid=mon(6,10,12);
   for(L1MonsterInstance m:new L1MonsterInstance[]{hidden,dead,invis,safe,other,valid})P.onSeeCreature(p,m);
   hidden.hidden=1;dead.dead=true;invis.invis=true;safe.grid.safe=true;other.map=2;P.selectTarget(p);check(p.target==valid,"invalid monster selected");
   p.noLos.add(((long)valid.x<<32)^(valid.y&0xffffffffL));check(!P.isAutoAttackPosition(p,valid),"LOS bypass");
  });
  test("already attackable current target retains attack handoff",()->{
   L1PcInstance p=pc();L1MonsterInstance m=mon(1,10,11);p.target=m;P.onSeeCreature(p,m);
   check(AHMoveToTargetAction.onTick(p)==1&&AHSetMoving.calls==0&&p.target==m,"ready attack displaced");
  });
  if(args.length==0){
   test("real start seeds known monsters before the first admitted wheel",()->{
    L1PcInstance p=pc();p.active=false;L1MonsterInstance m=mon(1,10,11);p.known.add(m);
    CIOThreadCallback.ONE.allow=true;CIOThreadCallback.ONE.cancelled=false;
    CIOThreadCallback.ONE.admission=()->{check(p.active,"wheel sees inactive actor");P.selectTarget(p);check(p.target==m,"first wheel cannot see pre-existing monster");};
    new AHExecutor().startAutoHunt(p);check(p.target==m&&p.potion,"start state lost");CIOThreadCallback.ONE.admission=null;
   });
   test("real reset drops candidates, suppression and progress on restart",()->{
    L1PcInstance p=pc();rear(p);p.fail=30;p.ignore=12;p.ignoreUntil=Clock.now+9999;
    AutoHuntChaseState old=p.getAutoChaseState();old.defer(1,12,Clock.now+9999);
    new AHExecutor().resetAuto(p);
    check(p.target==null&&p.candidates.isEmpty()&&p.dirty&&p.fail==0&&p.ignore==0&&p.ignoreUntil==0,"stale hunt state survives reset");
    check(p.state==null&&p.getAutoChaseState()!=old,"lazy state retained after reset");
   });
   test("null and cancelled timer admissions clear real seeded candidates",()->{
    for(boolean cancelled:new boolean[]{false,true}){
     L1PcInstance p=pc();p.known.add(mon(1,10,11));CIOThreadCallback.ONE.allow=cancelled;CIOThreadCallback.ONE.cancelled=cancelled;
     new AHExecutor().startAutoHunt(p);check(!p.active&&p.candidates.isEmpty()&&p.state==null,"failed startup leaves active or retained state");
    }CIOThreadCallback.ONE.allow=true;CIOThreadCallback.ONE.cancelled=false;
   });
   test("blocked cooldown expires without AOI churn",()->{
    L1PcInstance p=pc();L1MonsterInstance m=rear(p);P.abandonBlockedTarget(p);P.selectTarget(p);check(p.target==null,"deferred target selected");
    Clock.now+=2100;P.selectTarget(p);check(p.target==m,"expired target never reconsidered");
   });
   test("approaching monster cancels cooldown when actually attackable",()->{
    L1PcInstance p=pc();L1MonsterInstance m=rear(p);P.abandonBlockedTarget(p);m.y=11;P.selectTarget(p);check(p.target==m,"in-range monster stayed deferred");
   });
   test("proactive review does not consume independent blocked recovery budget",()->{
    L1PcInstance p=pc();rear(p);L1MonsterInstance m=mon(2,10,12);P.onSeeCreature(p,m);
    check(!P.retargetToAttackable(p),"distant target selected proactively");check(P.retargetWhenMoveBlocked(p)&&p.target==m,"proactive gate starved blocked recovery");
   });
   test("candidate copies and known reconciliation are rate limited",()->{
    L1PcInstance p=pc();rear(p);for(int n=0;n<300;n++){Clock.now+=1;P.retargetToAttackable(p);P.retargetWhenMoveBlocked(p);}
    check(p.knownReads==1&&p.candidates.copies==2,"per-wheel retained/known scan");check(L1World.ONE.lookups==1,"per-wheel world lookup");
   });
   test("bounded state and actor/map isolation",()->{
    AutoHuntChaseState a=new AutoHuntChaseState(),b=new AutoHuntChaseState();a.defer(1,7,Clock.now+2000);
    check(a.isDeferred(1,7,Clock.now)&&!a.isDeferred(2,7,Clock.now)&&!b.isDeferred(1,7,Clock.now),"cross actor/map suppression");
    for(int n=0;n<10000;n++)a.defer(1,n,Clock.now+2000);
    check(!a.isDeferred(1,1,Clock.now)&&a.isDeferred(1,9999,Clock.now),"unbounded target retention");
    int arrays=0;for(var f:AutoHuntChaseState.class.getDeclaredFields())if(f.getType().isArray()){f.setAccessible(true);try{check(java.lang.reflect.Array.getLength(f.get(a))==8,"grown state array");arrays++;}catch(IllegalAccessException e){throw new RuntimeException(e);}}
    check(arrays==3,"unexpected actor-reference storage");
   });
   test("target/map change and backwards clock restart progress observation",()->{
    AutoHuntChaseState a=new AutoHuntChaseState();check(a.observe(1,7,10,10,10000,3000),"first observation");
    check(!a.observe(1,7,10,10,14000,3000),"standing timeout");check(a.observe(1,8,10,10,14000,3000),"new target inherits stale timeout");
    check(a.observe(2,8,10,10,18000,3000),"new map inherits stale timeout");check(a.observe(2,8,10,10,9000,3000),"backwards clock loses chase");
   });
  }
  System.out.println("RESULT passed="+passed+" failed="+failed);if(failed!=0)throw new AssertionError("chase recovery failures="+failed);
 }
}
'''
if args.baseline_root:
    # Baseline lacks the new public recovery entry points. They are referenced
    # only by extra tests excluded in baseline mode; these stubs never execute.
    missing = '''public void abandonBlockedTarget(L1PcInstance p){throw new AssertionError("baseline lacks API");}
      public boolean retargetToAttackable(L1PcInstance p){throw new AssertionError("baseline lacks API");}'''
    java = java.replace('boolean canUseTeleport(L1PcInstance p){return false;}',
                        'boolean canUseTeleport(L1PcInstance p){return false;}\n' + missing)
java = java.replace('System.currentTimeMillis()', 'Clock.now')
with tempfile.TemporaryDirectory() as td:
    f = Path(td) / 'ChaseRecoveryContract.java'
    f.write_text(java)
    subprocess.run(['java', '-m', 'jdk.compiler/com.sun.tools.javac.Main', '-source', '21',
                    '-target', '21', '-encoding', 'UTF-8', '-d', td, str(f)], check=True, timeout=60)
    subprocess.run(['java', '-ea', '-cp', td, 'ChaseRecoveryContract'] + (['baseline'] if args.baseline_root else []),
                   check=True, timeout=30)
