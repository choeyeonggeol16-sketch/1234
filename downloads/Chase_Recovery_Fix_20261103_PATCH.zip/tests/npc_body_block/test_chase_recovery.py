#!/usr/bin/env python3
"""Real NPC onTick dispatch + BFS + slot claim + physical reserved-step commit.

Reuses the existing deterministic 40x40 map/occupancy fixture. Normal macro-path
results are injected to exercise DYNAMIC_BLOCKED and PATH_FAILED recovery;
fallback routing and commits are production methods. No live server is run.
"""
from pathlib import Path
import argparse, subprocess, tempfile

root = Path(__file__).resolve().parents[2]
p = argparse.ArgumentParser()
p.add_argument('--baseline-root', type=Path)
args = p.parse_args()
fixture = root / 'tests/npc_body_block/test_persistent_passing.py'
ns = {'__file__': str(fixture)}
exec(fixture.read_text().split('with tempfile.TemporaryDirectory()')[0], ns)
java = ns['java']
action = (args.baseline_root or root) / 'src/l1j/server/server/model/npc/ai/action'

def method(text, signature):
    a = text.index(signature)
    b = text.index('{', a)
    depth, i = 1, b + 1
    while depth:
        if text[i] == '{': depth += 1
        elif text[i] == '}': depth -= 1
        i += 1
    return text[a:i]

chase = (action / 'CMoveToTargetAction.java').read_text()
resume = ns['extract'](action / 'CMoveAroundAction.java', 'tryResumeBlockedAttack')
tick = method(chase, '    static byte onTick(')
ring = method(chase, '    private static boolean isMeleeAttackRingFull(')
java = java.replace('int get_ranged(){return 1;}', 'int ranged=1;int get_ranged(){return ranged;}')
java = java.replace('L1Map getMap(){return new L1Map();}', '''Location getLocation(){return new Location(this);}
  L1Map getMap(){return new L1Map();}''')
java = java.replace(' static class Template {', ''' static class Location {
  final L1Object c;Location(L1Object c){this.c=c;}
  int getTileLineDistance(Location t){return Math.max(Math.abs(c.x-t.c.x),Math.abs(c.y-t.c.y));}
 }
 static class Template {''')
java = java.replace('L1Character target;byte action=6;int generation=1,moves,sleep,_moveSide;', '''L1Character target;byte action=6;int generation=1,moves,sleep,_moveSide;
  boolean root,immovable;int thinks,wakes,_pathFindFailCount;final Template template=new Template();
  boolean isMovable(){return !immovable;}boolean 발묶임상태(){return root;}''')
java = java.replace('Template getNpcTemplate(){return new Template();}', 'Template getNpcTemplate(){return template;}')
java = java.replace('_desireBlockedAttackTargetId,_pathFindFailCount;', '_desireBlockedAttackTargetId;')
java = java.replace('static final WorldCollisionHash ONE=', '''static final int MOVE_NPC=2,MOVE_PC=3,MOVE_RESERVED=4;
  int testStep(short map,int x,int y,int id){
   if(bodies.getOrDefault(key(x,y),0)!=0&&bodies.get(key(x,y))!=id)return MOVE_NPC;
   if(claims.getOrDefault(key(x,y),0)!=0&&claims.get(key(x,y))!=id)return MOVE_RESERVED;
   return 0;}
  static final WorldCollisionHash ONE=''')
java = java.replace('static byte currentAction(L1NpcInstance c){return c.action;}', '''static byte currentAction(L1NpcInstance c){return c.action;}
  static byte pendingAction(L1NpcInstance c){return 2;}
  static boolean tryMoveToTargetTeleport(L1NpcInstance c,L1Character t){return false;}''')
java = java.replace('RESULT_RUNNING=0,RESULT_DONE=1,RESULT_INVALID=2;}', '''RESULT_RUNNING=0,RESULT_DONE=1,RESULT_INVALID=2;
   static void think(L1NpcInstance c){c.thinks++;c.action=0;}
   static void rethinkNow(L1NpcInstance c){c.wakes++;c.action=0;}
 }''')
java = java.replace('static class CDesirePQ {static void releaseBlockedAttack', '''static class CDesirePQ {
  static final byte BLOCKED_ATTACK_LANE=1;static boolean other;static L1Character blocked;
  static boolean hasOtherAttack(L1MonsterInstance m,int id){return other;}
  static L1Character blockedAttackTarget(L1MonsterInstance m){return blocked;}
  static byte blockedAttackMode(L1MonsterInstance m){return 1;}
  static void blockAttackForMoveAround(L1MonsterInstance m,L1Character t,int x,int y){blocked=t;}
  static void blockAttackForMoveAroundRing(L1MonsterInstance m,L1Character t){blocked=t;}
  static void releaseBlockedAttack''')
java = java.replace('static final byte RUNNING=0,AT_DISTANCE=1,INVALID=2,DYNAMIC_BLOCKED=4;', '''static final byte RUNNING=0,AT_DISTANCE=1,INVALID=2,PATH_FAILED=3,DYNAMIC_BLOCKED=4;
  static byte normalResult=DYNAMIC_BLOCKED;static int normalCalls;
  static byte tick(L1NpcInstance c,L1Character t,int distance){normalCalls++;return normalResult;}
  static byte tickRelative(L1NpcInstance c,L1Character t,int distance){return tick(c,t,distance);}
  static void clear(L1NpcInstance c){}''')
java = java.replace('static boolean validTarget(L1MonsterInstance m,L1Character t)',
                    'static boolean validTarget(L1NpcInstance m,L1Character t)')
java = java.replace(' static boolean validTarget(', ''' static final int PATH_FAIL_LIMIT=30,TARGET_CLEAR_DISTANCE=40;
 static final byte RESULT_PATH_FAILED=5;
 static void discardObsoleteAttackSlot(L1MonsterInstance m,L1Character t){}
 static boolean isGuard(L1NpcInstance m){return false;}
 static boolean isPetFamily(L1NpcInstance m){return false;}
 static boolean tryPetFamilyRetargetWhenBlocked(L1NpcInstance m,L1Character t){return false;}
 static class CAttackAction {static boolean tryCombatAbility(L1NpcInstance m,L1Character t){return false;}}
 static class CMoveToTargetActionBase {static int computeDistance(L1NpcInstance m,L1Character t){return m.template.ranged;}}
 static class CMoveToTargetWaitAction {static void set(L1NpcInstance m,L1Character t,int d,byte a){}}
''' + tick + ring + '\n static boolean validTarget(', 1)
# Add real wander recovery method; its straight-step lane probe is deterministic.
java = java.replace('static final int BLOCKED_RING_RECHECK_RADIUS=12;', '''static boolean validDirectionTarget(L1MonsterInstance m,L1Character t){return t!=null&&!t.dead&&t.map==m.map;}
  static boolean isBlockedAttackLaneOpen(L1MonsterInstance m){int h=m.targetDirection(m.target.x,m.target.y);return COLLISION.canEnter((short)1,m.x+DX[h],m.y+DY[h],m.id);}
''' + resume + '\n static final int BLOCKED_RING_RECHECK_RADIUS=12;')
# The fixture originally had fixed map IDs. Keep them configurable for guards.
java = java.replace('int id,x,y;int getId()', 'int id,x,y,map=1;int getId()')
java = java.replace('int getMapId(){return 1;}', 'int getMapId(){return map;}')
start = java.index(' public static void main(String[] args)')
java = java[:start] + r'''
 static int passed,failed;
 static void test(String name,Runnable r){CDesirePQ.other=false;CDesirePQ.blocked=null;SetMoving.normalCalls=0;
  try{r.run();passed++;System.out.println("PASS "+name);}catch(Throwable t){failed++;System.out.println("FAIL "+name+": "+t);}}
 static byte chase(L1MonsterInstance m){return onTick(m,m.target,false,(byte)6);}
 static void leaderAlive(){check(COLLISION.bodies.getOrDefault(key(20,22),0)==1,"leader was removed or walked through");}
 static void finish(L1MonsterInstance m){L1Character t=m.target;int ticks=0;
  while(!m.isAttackPosition(t,m.template.ranged)&&ticks++<25){check(chase(m)==0,"recovery stopped before attack range");leaderAlive();}
  check(m.isAttackPosition(t,m.template.ranged)&&ticks<25,"rear never reached attack range");check(chase(m)==1,"ATTACK handoff missing");}
 public static void main(String[] args){
  test("rear melee macro PATH_FAILED still detours while leader stays alive",()->{
   L1MonsterInstance m=scene();SetMoving.normalResult=3;
   check(chase(m)==0&&m.moves==1&&m._desireResumeAttackPos!=0,"macro failure never invoked body-aware route");leaderAlive();finish(m);
  });
  test("rear ranged dynamic blockage uses sideways-first detour",()->{
   L1MonsterInstance m=scene();m.template.ranged=2;SetMoving.normalResult=4;
   check(chase(m)==0&&m.moves==1&&m._desireResumeAttackPos!=0,"ranged block never invoked body-aware route");leaderAlive();finish(m);
   check(!m.isAttackPosition(m.target,1),"ranged actor unnecessarily forced to melee range");
  });
  test("rear ranged macro failure also detours",()->{
   L1MonsterInstance m=scene();m.template.ranged=2;SetMoving.normalResult=3;
   check(chase(m)==0&&m.moves==1,"ranged macro failure stuck");finish(m);
  });
  test("rear melee dynamic collision continues with its real target",()->{
   L1MonsterInstance m=scene();SetMoving.normalResult=4;L1Character target=m.target;
   check(chase(m)==0&&m.moves==1&&m.target==target,"melee chase did not begin");finish(m);
  });
  test("ranged MOVE_AROUND can reopen an alternate route past an occupied first step",()->{
   L1MonsterInstance m=scene();m.template.ranged=2;CDesirePQ.blocked=m.target;
   check(CMoveAroundAction.tryResumeBlockedAttack(m)&&m._desireResumeAttackPos!=0,"straight-step gate hides valid side route");
  });
  test("sealed one-wide choke keeps target but cannot pass through leader",()->{
   L1MonsterInstance m=scene();SetMoving.normalResult=3;
   for(int y=0;y<40;y++){MAP.walls.add(key(19,y));MAP.walls.add(key(21,y));}
   m._pathFindFailCount=30;L1Character target=m.target;
   check(chase(m)==0&&m.moves==0&&m.target==target&&m._pathFindFailCount==0,"temporary adjacent body treated as static target failure");
   check(m.thinks==1&&CDesirePQ.blocked==target,"blocked target did not yield to MOVE_AROUND policy");leaderAlive();
  });
  test("full attack ring cannot create a false route",()->{
   L1MonsterInstance m=scene();SetMoving.normalResult=4;
   for(int h=0;h<8;h++)COLLISION.bodies.put(key(20+DX[h],20+DY[h]),100+h);
   check(chase(m)==0&&m.moves==0&&m.thinks==1,"full ring bypassed");
  });
  test("static no-path retains the existing 31-failure retirement limit",()->{
   L1MonsterInstance m=scene();SetMoving.normalResult=3;COLLISION.bodies.remove(key(20,22));
   for(int h=0;h<8;h++)MAP.walls.add(key(m.x+DX[h],m.y+DY[h]));
   for(int n=0;n<30;n++)check(chase(m)==0,"static failure retired too early");
   check(chase(m)==5&&m.moves==0,"genuine static failure never retired");
  });
  test("dead/map-changed/replaced targets never enter fallback movement",()->{
   L1MonsterInstance m=scene();SetMoving.normalResult=3;m.dead=true;check(chase(m)==2&&m.moves==0,"dead mover moved");
   m=scene();m.target.map=2;check(chase(m)==2&&m.moves==0,"cross-map movement");
   m=scene();L1Character old=m.target;m.target=new L1Character();check(onTick(m,old,false,(byte)6)==2&&m.moves==0,"stale target moved");
  });
  test("control-effect waits preserve target and never spend fallback work",()->{
   L1MonsterInstance m=scene();SetMoving.normalResult=3;m.root=true;
   check(chase(m)==0&&m.moves==0&&SetMoving.normalCalls==0,"root treated as navigation failure");
  });
  System.out.println("RESULT passed="+passed+" failed="+failed);if(failed!=0)throw new AssertionError("NPC recovery failures="+failed);
 }
}
'''
with tempfile.TemporaryDirectory() as td:
    f = Path(td) / 'PersistentPassingContract.java'
    f.write_text(java)
    subprocess.run(['java', '-m', 'jdk.compiler/com.sun.tools.javac.Main', '-source', '21',
                    '-target', '21', '-encoding', 'UTF-8', '-d', td, str(f)], check=True, timeout=60)
    subprocess.run(['java', '-ea', '-cp', td, 'PersistentPassingContract'], check=True, timeout=30)
