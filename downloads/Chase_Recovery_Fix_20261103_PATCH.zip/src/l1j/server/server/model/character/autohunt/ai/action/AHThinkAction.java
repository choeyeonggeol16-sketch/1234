package l1j.server.server.model.character.autohunt.ai.action;

import java.util.List;

import l1j.server.Config;
import l1j.server.server.model.L1Object;
import l1j.server.server.model.L1World;
import l1j.server.server.model.Instance.L1MonsterInstance;
import l1j.server.server.model.Instance.L1PcInstance;
import l1j.server.server.model.character.autohunt.AHProcessor;
import l1j.server.server.model.character.autohunt.AHReturnManager;

/**
 * Auto-hunt decision state.
 *
 * 사냥터 우선순위는 여기 한 군데서만 결정한다.
 *
 * 1. 현재 교전중인 target
 * 2. 가까운 위협 몬스터
 * 3. 바닥 아이템
 * 4. 그 외 몬스터
 * 4. no-target teleport
 * 5. random move
 *
 * Action은 판단하지 않고 실행만 한다.
 */
public final class AHThinkAction {

    static final byte RESULT_SELECTED =
            AHController.RESULT_DONE;

    static final byte RESULT_EXECUTE_SELECTED = 4;

    private AHThinkAction() {
    }

    public static byte onTick(final L1PcInstance pc) {
        if (pc == null) {
            return AHController.RESULT_INVALID;
        }

        if (pc.getMapId() == 4) {
            return selectTownAction(pc);
        }

        return selectHuntAction(pc);
    }

    private static byte selectHuntAction(
            final L1PcInstance pc) {

        final AHProcessor processor =
                AHProcessor.getInstance();

        processor.checkTarget(pc);

        if (pc.getAutoTarget() != null) {
            processor.switchToAttack(pc);
            return RESULT_SELECTED;
        }

        final boolean hasItem = processor.toPickupItem(
                pc,
                AHProcessor.PICKUP_RANGE);

        final boolean closeThreat =
                hasNearbyCombatThreat(pc);

        if (closeThreat) {
            pc.setAutoTargetDirty(true);
            processor.selectTarget(pc);
            if (pc.getAutoTarget() != null) {
                processor.switchToAttack(pc);
                return RESULT_SELECTED;
            }
        }

        if (hasItem) {
            AHController.getItem(pc);
            return RESULT_SELECTED;
        }

        if (!closeThreat) {
            processor.selectTarget(pc);
            if (pc.getAutoTarget() != null) {
                processor.switchToAttack(pc);
                return RESULT_SELECTED;
            }
        }

        if (processor.noTargetTeleport(pc)) {
            return AHController.RESULT_STOP;
        }

        AHController.set(
                pc,
                AHController.ACTION_MOVE);

        return RESULT_EXECUTE_SELECTED;
    }

    static boolean hasNearbyCombatThreat(final L1PcInstance pc) {
        if (pc.getAutoTargetList().isEmpty()) {
            return false;
        }

        final int x = pc.getX();
        final int y = pc.getY();
        final int mapId = pc.getMapId();
        final int ignoreId = pc.getAutoIgnoreTarget();
        final long now = System.currentTimeMillis();
        final long ignoreUntil = pc.getAutoIgnoreTime();

        final List<L1Object> nearby = L1World.getInstance().getClusterGrid().queryNearbyReusable(pc, 3);

        for (int i = 0, count = nearby.size(); i < count; i++) {
            final L1Object obj = nearby.get(i);
            if (!(obj instanceof L1MonsterInstance)) {
                continue;
            }
            final L1MonsterInstance mon = (L1MonsterInstance) obj;
            if (mon.getMapId() != mapId
                    || mon.isDead()
                    || mon.getCurrentHp() <= 0
                    || mon.getHiddenStatus() >= 1
                    || AHProcessor.getInstance().isTemporarilyBlocked(pc, mon, now)
                    || (mon.getId() == ignoreId && now < ignoreUntil)) {
                continue;
            }

            if (Math.max(Math.abs(mon.getX() - x),
                    Math.abs(mon.getY() - y)) > 4) {
                continue;
            }

            if (pc.canSeeObject(mon) && pc.glanceCheck(mon.getX(), mon.getY())) {
                return true;
            }
        }

        return false;
    }

    private static byte selectTownAction(
            final L1PcInstance pc) {

        final AHProcessor processor =
                AHProcessor.getInstance();

        if (processor.isNeedSupplies(pc)) {
            AHController.set(
                    pc,
                    AHController.ACTION_MOVE_SHOP);

            return RESULT_EXECUTE_SELECTED;
        }

        final int hpPercent =
                pc.getCurrentHp() * 100
                / pc.getMaxHp();

        final int mpPercent =
                pc.getCurrentMp() * 100
                / pc.getMaxMp();

        final boolean needRegen;

        if (pc.isWizard() || pc.isElf()) {
            needRegen =
                    mpPercent
                    < Config.AUTO_HUNT_WIZ_ELF_MP;
        } else {
            needRegen =
                    hpPercent
                    < Config.AUTO_HUNT_OTHER_HP;
        }

        if (needRegen) {
            AHController.set(
                    pc,
                    AHController.ACTION_REGEN);

            return RESULT_EXECUTE_SELECTED;
        }

        AHReturnManager
                .getInstance()
                .returnToHuntingGround(pc);

        return AHController.RESULT_STOP;
    }
}
