package l1j.server.server.model.character.autohunt;
import l1j.server.server.model.network.core.sc.packet.SC_PacketBox;
import l1j.server.server.model.network.core.sc.packet.SC_SystemMessage;

import l1j.server.server.model.network.core.sc.packet.SC_CharVisualUpdate;
import l1j.server.Config;
import l1j.server.MJDungeonTimer.DungeonTimeInformation;
import l1j.server.MJDungeonTimer.Loader.DungeonTimeInformationLoader;
import l1j.server.MJDungeonTimer.Progress.DungeonTimeProgress;
import l1j.server.MJExpAmpSystem.MJExpAmplifierLoader;
import l1j.server.server.Controller.EventNpcSpawnCotroller;
import l1j.server.server.datatables.EventNpcSpawnTable;
import l1j.server.server.model.Getback;
import l1j.server.server.model.L1World;
import l1j.server.server.model.Instance.L1PcInstance;
import l1j.server.server.model.character.autohunt.ai.action.AHController;
import l1j.server.server.model.network.core.sc.packet.SC_RemoveObject;
import l1j.server.server.model.network.core.sc.packet.SC_WorldPutObject;
import l1j.server.server.model.network.thread.CIOThreadCallback;
import l1j.server.server.packets.Protocol.Packet.SC_MapID;
import l1j.server.server.templates.L1EventNpcSpawn;

import l1j.server.server.model.network.core.sc.packet.SC_Weather;
public class AHExecutor {

    private static final AHExecutor instance = new AHExecutor();

    public static AHExecutor getInstance() {
        return instance;
    }

    public void execute(L1PcInstance pc) {
        if (pc == null || pc.getNetConnection() == null) {
            return;
        }

        try {
            if (!Config.USE_AUTO_HUNT) {
                SC_SystemMessage.send(pc, "현재 자동사냥 시스템 점검 중입니다.");
                return;
            }

            if (!isAllowedMap(pc.getMapId())) {
                SC_SystemMessage.send(pc, "이 지역에서는 자동사냥을 시작할 수 없습니다.");
                return;
            }

            if (!hasHuntTicket(pc)) {
                SC_SystemMessage.send(pc, "자동사냥 사용권이 필요합니다.");
                return;
            }

            if (!check_auto_dungeon(pc, pc.getMapId())) {
                SC_SystemMessage.send(pc, "던전 이용시간이 종료되었습니다.");
                return;
            }

            L1EventNpcSpawn event_map_check =
                    EventNpcSpawnTable.getInstance()
                            .getEventMapCheck(pc.getMapId());

            if (event_map_check != null) {
                if (!EventNpcSpawnCotroller.isSpawn(event_map_check)) {
                    SC_SystemMessage.send(pc, "사냥시간이 이용시간이 종료되었습니다.");
                    return;
                }
            }

            if (pc.isInParty()) {
                SC_SystemMessage.send(pc, "파티 중에는 자동사냥을 할 수 없습니다.");
                return;
            }

            startAutoHunt(pc);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static boolean check_auto_dungeon(
            L1PcInstance pc,
            int targetMapId) {

        DungeonTimeInformation dtInfo =
                DungeonTimeInformationLoader.getInstance()
                        .from_map_id(targetMapId);

        if (dtInfo != null) {
            DungeonTimeProgress<?> progress =
                    pc.get_progress(dtInfo);

            if (progress != null
                    && progress.get_remain_seconds() <= 0) {

                return false;
            }
        }

        return true;
    }

    public void startAutoHunt(L1PcInstance pc) {
        if (pc == null) return;
        resetAuto(pc);

        pc.setAutoPotion(Config.AUTO_HUNT_DEFAULT_POTION);
        pc.setAutoMapId(pc.getMapId());
        pc.setAutoPolyID(pc.getCurrentSpriteId());
        // The first wheel tick may start as soon as the owner admits it.
        pc.setAutoHunt(true);
        // Existing known monsters do not emit another InSight just because
        // auto-hunt starts. Seed before the first owner wheel can run.
        AHProcessor.getInstance().seedKnownTargets(pc);
        final CIOThreadCallback.Handle handle = CIOThreadCallback.getInstance()
                .startAutoHunt(pc.getId(), 20L);
        if (handle == null || handle.isCancelled()) {
            // Never report a running auto-hunt whose recurring wheel task
            // was rejected at admission. No extra thread or retry queue.
            pc.setAutoHunt(false);
            resetAuto(pc);
            SC_SystemMessage.send(pc, "자동사냥 타이머를 등록하지 못했습니다. 다시 시도해 주세요.");
            return;
        }
        sendGuidancePackets(pc);
    }

    public void LogoutAutoHunt(L1PcInstance pc) {
        if (pc == null) {
            return;
        }

        pc.setAutoHunt(false);

        CIOThreadCallback.getInstance()
                .stopAutoHunt(pc);

        resetAuto(pc);
    }

    private boolean isAllowedMap(int mapId) {
        if (Config.AUTO_HUNT_MAP_LIST == null) {
            return true;
        }

        for (int id : Config.AUTO_HUNT_MAP_LIST) {
            if (id == mapId) {
                return true;
            }
        }

        return false;
    }

    private boolean hasHuntTicket(L1PcInstance pc) {
        if (Config.AUTO_HUNT_TICKETS == null) {
            return true;
        }

        for (int id : Config.AUTO_HUNT_TICKETS) {
            if (pc.getInventory().hasItemDirect(id)) {
                return true;
            }
        }

        return false;
    }

    public void resetAuto(L1PcInstance pc) {
        AHController.set(
                pc,
                AHController.ACTION_NONE);

        pc.setAutoMoveCount(0);
        pc.setAutoSkillDelay(0);
        pc.setAutoTarget(null);
        pc.getAutoTargetList().clear();
        pc.setAutoTargetDirty(true);
        pc.setAutoMoveFailCount(0);
        pc.setAutoIgnoreTarget(0);
        pc.setAutoIgnoreTime(0L);
        pc.resetAutoChaseState();
        pc.setAutoNearbyMobCount(0);
        pc.setAutoThreatScanTime(0);
        pc.resetAutoRoam();
        CIOThreadCallback.getInstance()
                .clearPcState(pc);

        pc.setAutoTargetItem(null);
    }

    public void endAutoHunt(L1PcInstance pc) {
        if (pc == null) {
            return;
        }

        pc.setAutoHunt(false);

        CIOThreadCallback.getInstance()
                .stopAutoHunt(pc);

        resetAuto(pc);
        toCharacterRefresh(pc);
    }

    public void toCharacterRefresh(L1PcInstance pc) {
        if (pc == null
                || pc.getNetConnection() == null
                || !pc.getNetConnection().isConnected()) {

            return;
        }

        pc.broadcastRemoveAllKnownObjects();
        pc.removeAllKnownObjects();

        // 신형 direct WorldPut
        SC_WorldPutObject.put(
                pc.getNetConnection(),
                pc);

        pc.onWorldMove(
                pc.getMapId(),
                pc.getX(),
                pc.getY());

        SC_CharVisualUpdate.sendPacked(pc, SC_CharVisualUpdate.pack(pc));
    }

    public void sendautomsg(
            L1PcInstance pc,
            String s) {

        SC_PacketBox.send(pc, SC_PacketBox.GREEN_MESSAGE, s);

        SC_SystemMessage.send(pc, s);

        endAutoHunt(pc);
    }

    private void sendGuidancePackets(L1PcInstance pc) {
        SC_PacketBox.send(pc, SC_PacketBox.GREEN_MESSAGE, "자동사냥이 시작되었습니다.");

        SC_SystemMessage.send(pc, "자동사냥이 시작되었습니다.");
    }

    public void restart(L1PcInstance pc) {
        if (pc == null) {
            return;
        }

        if (pc.getAutoDeadTime()
                < Config.AUTO_HUNT_RESTART_DELAY) {

            pc.setAutoDeadTime(
                    pc.getAutoDeadTime() + 1);

            return;
        }

        if (!pc.isDead()) {
            return;
        }

        int[] loc =
                Getback.GetBack_Restart(pc);

        if (loc == null) {
            loc =
                    Getback.GetBack_Location(
                            pc,
                            true);
        }

        resetCharacterState(pc);
        performRestartTeleport(pc, loc);
        finalizeRestart(pc);
    }

    private void resetCharacterState(L1PcInstance pc) {
        pc.removeAllKnownObjects();
        SC_RemoveObject.broadcast(pc);

        pc.setCurrentHp(pc.getLevel());
        pc.set_food(39);
        pc.setDead(false);
        pc.setAutoDead(true);
        pc.setStatus(0);
    }

    private void performRestartTeleport(
            L1PcInstance pc,
            int[] loc) {

        L1World.getInstance().relocateVisibleObject(
                pc, loc[0], loc[1], loc[2]);

        pc.sendPackets(
                SC_MapID.create(
                        pc.getMap().getBaseMapId(),
                        pc.getMap().isUnderwater()));

        MJExpAmplifierLoader.getInstance()
                .set(pc);

        SC_WorldPutObject.broadcastPc(pc);
        SC_WorldPutObject.put(
                pc.getNetConnection(),
                pc);

        SC_CharVisualUpdate.sendPacked(pc, SC_CharVisualUpdate.pack(pc));

        SC_Weather.send(pc, L1World.getInstance()
                                .getWeather());
    }

    private void finalizeRestart(L1PcInstance pc) {
        pc.setAutoDeadTime(0);

        AHController.set(
                pc,
                AHController.ACTION_NONE);

        sendautomsg(
                pc,
                "캐릭터가 사망하여 자동사냥이 종료되었습니다.");
    }
}
