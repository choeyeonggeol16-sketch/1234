package l1j.server.server.model.character.autohunt.ai.action;

import l1j.server.server.model.L1Character;
import l1j.server.server.model.Instance.L1PcInstance;
import l1j.server.server.model.character.autohunt.AHProcessor;
import l1j.server.server.model.character.autohunt.AHUseSkill;
import l1j.server.server.model.character.autohunt.AutoHuntChaseState;
import l1j.server.server.model.character.autohunt.ai.AHSetMoving;
import l1j.server.MJ3SEx.EActionCodes;
import l1j.server.server.utils.CommonUtil;

/**
 * PC AutoHunt combat chase.
 *
 * NPC MoveToTargetAction의 역할만 PC 쪽으로 옮긴다.
 *
 * - mover  : L1PcInstance
 * - target : autoTarget (일반 사냥에서는 Monster/NPC)
 * - target 선택 정책은 THINK/AHProcessor가 담당
 * - 실제 이동은 AHSetMoving이 담당
 * - ATTACK은 여기서 수행하지 않고 공격 위치 도달 시 ACTION_ATTACK으로 넘긴다.
 */
public final class AHMoveToTargetAction {

    /*
     * NPC dPAttack과 같은 연속 static PathFind failure 한계.
     * body collision은 이 카운터를 올리지 않는다.
     */
    private static final int PATH_FAIL_LIMIT = 30;

    private AHMoveToTargetAction() {
    }

    public static byte onTick(
            final L1PcInstance pc) {

        if (pc == null) {
            return AHController.RESULT_INVALID;
        }

        final L1Character target =
                pc.getAutoTarget();

        if (target == null) {
            return AHController.RESULT_INVALID;
        }

        if (!AHProcessor.getInstance()
                .validateAutoCombatTarget(
                        pc,
                        target)) {

            AHSetMoving.clear(pc);
            pc.setAutoMoveFailCount(0);
            return AHController.RESULT_INVALID;
        }

        final AutoHuntChaseState progress = pc.getAutoChaseState();

        /*
         * 턴 언데드는 평타 사거리보다 우선한다.
         *
         * 10칸 + LOS + MP/스킬 조건을 만족하면 현재 위치를 유지하며
         * TURN_UNDEAD를 시도한다. skill delay 중에도 이동하지 않는다.
         */
        if (AHUseSkill.getInstance()
                .handleTurnUndeadChase(
                        pc,
                        target)) {

            AHSetMoving.clear(pc);
            progress.clearProgress();
            pc.setAutoMoveFailCount(0);
            return AHController.RESULT_RUNNING;
        }

        /*
         * 이미 실제 공격 위치라면 이동은 끝.
         * 다음 action은 ATTACK.
         */
        if (AHProcessor.getInstance().isAutoAttackPosition(pc, target)) {
            AHSetMoving.clear(pc);
            progress.clearProgress();
            pc.setAutoMoveFailCount(0);
            return AHController.RESULT_DONE;
        }

        // Legitimate cast/control-effect waits are not navigation failures.
        if (CommonUtil.isAutoNonActionSkill(pc)) {
            progress.clearProgress();
            return AHController.RESULT_RUNNING;
        }

        if (AHProcessor.getInstance().retargetToAttackable(pc)) {
            AHSetMoving.clear(pc);
            pc.setAutoMoveFailCount(0);
            return AHController.RESULT_RUNNING;
        }

        final long now = System.currentTimeMillis();
        final long walk = Math.max(1L, pc.getCurrentSpriteInterval(EActionCodes.walk));
        final long timeout = Math.max(3_000L, Math.min(3_750L, walk) * 8L);
        if (!progress.observe(pc.getMapId(), target.getId(), pc.getX(), pc.getY(), now, timeout)) {
            final boolean changed = AHProcessor.getInstance().retargetWhenMoveBlocked(pc);
            if (!changed) AHProcessor.getInstance().abandonBlockedTarget(pc);
            AHSetMoving.clear(pc);
            pc.setAutoMoveFailCount(0);
            return changed ? AHController.RESULT_RUNNING : AHController.RESULT_INVALID;
        }

        final int attackRange =
                Math.max(
                        1,
                        pc.getAttackRang());

        final int currentDistance =
                pc.getLocation()
                        .getTileLineDistance(
                                target.getLocation());

        /*
         * NPC MoveToTargetAction과 동일한 이유:
         *
         * raw range 안인데 LOS가 안 나오는 경우 range 그대로 넘기면
         * SetMoving이 AT_DISTANCE로 멈춘다.
         * 실제 공격 위치가 아니면 최소 한 칸 더 접근하도록 한다.
         */
        final int desiredDistance =
                currentDistance <= attackRange
                        ? Math.max(
                                1,
                                currentDistance - 1)
                        : attackRange;

        final int oldX = pc.getX();
        final int oldY = pc.getY();
        final byte move =
                AHSetMoving.tick(
                        pc,
                        target,
                        desiredDistance);
        if (pc.getX() != oldX || pc.getY() != oldY) pc.setAutoTeleportTime(now);

        switch (move) {
        case AHSetMoving.RUNNING:
            pc.setAutoMoveFailCount(0);
            return AHController.RESULT_RUNNING;

        case AHSetMoving.AT_DISTANCE:
            /*
             * SetMoving distance boundary에 도달했더라도
             * sprite footprint / LOS 최종 판정은 다시 한다.
             */
            if (AHProcessor.getInstance().isAutoAttackPosition(pc, target)) {
                AHSetMoving.clear(pc);
                progress.clearProgress();
                pc.setAutoMoveFailCount(0);
                return AHController.RESULT_DONE;
            }

            return AHController.RESULT_RUNNING;

        case AHSetMoving.DYNAMIC_BLOCKED:
            /*
             * 실제 body/choke에 막혔으면 현재 target을 고집하지 않는다.
             * retained AOI 후보에서 즉시 다른 공격 대상을 우선 찾는다.
             */
            pc.setAutoMoveFailCount(0);

            if (AHProcessor.getInstance()
                    .retargetWhenMoveBlocked(pc)) {

                AHSetMoving.clear(pc);
            }

            return AHController.RESULT_RUNNING;

        case AHSetMoving.PATH_FAILED: {
            if (AHProcessor.getInstance()
                    .retargetWhenMoveBlocked(pc)) {

                pc.setAutoMoveFailCount(0);
                AHSetMoving.clear(pc);
                return AHController.RESULT_RUNNING;
            }

            final int failCount =
                    pc.getAutoMoveFailCount() + 1;

            pc.setAutoMoveFailCount(failCount);

            if (failCount <= PATH_FAIL_LIMIT) {
                return AHController.RESULT_RUNNING;
            }

            pc.setAutoMoveFailCount(0);
            AHSetMoving.clear(pc);
            AHProcessor.getInstance().abandonBlockedTarget(pc);
            return AHController.RESULT_INVALID;
        }

        case AHSetMoving.INVALID:
        default:
            AHSetMoving.clear(pc);
            pc.setAutoMoveFailCount(0);
            return AHController.RESULT_INVALID;
        }
    }

    public static void onEnd(
            final L1PcInstance pc,
            final byte result) {

        if (pc == null) {
            return;
        }

        switch (result) {
        case AHController.RESULT_DONE:
            /*
             * 현재 target을 그대로 들고 ATTACK으로 hand-off.
             */
            AHController.attack(pc);
            return;

        case AHController.RESULT_INVALID:
            AHSetMoving.clear(pc);
            AHController.think(pc);
            return;

        case AHController.RESULT_RUNNING:
        case AHController.RESULT_STOP:
        default:
            return;
        }
    }

    public static void clear(
            final L1PcInstance pc) {

        if (pc == null) {
            return;
        }

        AHSetMoving.clear(pc);
        pc.setAutoMoveFailCount(0);
        pc.getAutoChaseState().clearProgress();
    }

}
