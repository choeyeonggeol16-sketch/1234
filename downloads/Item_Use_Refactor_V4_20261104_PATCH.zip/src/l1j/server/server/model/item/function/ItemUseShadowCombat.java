package l1j.server.server.model.item.function;

import l1j.server.server.model.network.core.sc.packet.SC_Paralysis;
import l1j.server.server.model.network.core.sc.packet.SC_EffectLocation;
import l1j.server.server.model.network.core.sc.packet.SC_SkillSound;
import static l1j.server.server.model.character.skill.L1SkillId.COUNTER_MAGIC;
import static l1j.server.server.model.character.skill.L1SkillId.EARTH_BIND;
import static l1j.server.server.model.character.skill.L1SkillId.SHOCK_STUN;
import static l1j.server.server.model.character.skill.L1SkillId.STATUS_FREEZE;
import java.util.Random;
import java.util.concurrent.ThreadLocalRandom;
import l1j.server.Config;
import l1j.server.server.ActionCodes;
import l1j.server.server.model.L1EffectSpawn;
import l1j.server.server.model.L1Location;
import l1j.server.server.model.L1Object;
import l1j.server.server.model.L1World;
import l1j.server.server.model.Instance.L1EffectInstance;
import l1j.server.server.model.Instance.L1ItemInstance;
import l1j.server.server.model.Instance.L1NpcInstance;
import l1j.server.server.model.Instance.L1PcInstance;
import l1j.server.server.model.character.skill.L1SkillId;
import l1j.server.server.model.item.teleport.L1Teleport;
import l1j.server.server.model.poison.L1DamagePoison;
import l1j.server.server.model.network.core.sc.packet.SC_AttackPacket;
import l1j.server.server.model.network.core.sc.packet.SC_DoActionGFX;
import l1j.server.server.model.network.core.sc.packet.SC_PacketBox;
import l1j.server.server.model.network.core.sc.packet.SC_ServerMessage;
import l1j.server.server.model.network.core.sc.packet.SC_SystemMessage;
import l1j.server.server.utils.MJCommons;
import l1j.server.server.utils.eKind;
import static l1j.server.server.model.item.function.ItemUseCreature.*;

/**
 * Legacy combat effects grouped by responsibility. 
 */
final class ItemUseShadowCombat {
    private static final Random _random = ItemUseCreature._random;
    
    private ItemUseShadowCombat() {
    }
    
    public static void 쉐도우(L1PcInstance pc, int targetId, L1ItemInstance item) {
        SC_AttackPacket.send(pc.getNetConnection(), pc, 0, ActionCodes.ACTION_Wand);
        SC_AttackPacket.broadcast(pc, 0, ActionCodes.ACTION_Wand);
        L1Object target = L1World.getInstance().findObject(targetId);
        if ((pc.getType() == 4 && pc.getLevel() >= 80) || pc.isGm()) {
            if (target != null) {
                if (target instanceof L1PcInstance) {
                    L1PcInstance member = (L1PcInstance)target;
                    if (pc.getId() == member.getId()) {
                        SC_SystemMessage.send(pc, "\\aH자기 자신에게는 사용할 수 없습니다");
                        return;
                    }
                    int diffLocX = Math.abs(pc.getX() - member.getX());
                    int diffLocY = Math.abs(pc.getY() - member.getY());
                    if (diffLocX > 5 || diffLocY > 5) {
                        SC_PacketBox.send(pc, SC_PacketBox.GREEN_MESSAGE, "\\fY거리가 멀어서 사용할 수 없습니다.");
                        SC_SystemMessage.send(pc, "\\fY거리가 멀어서 사용할 수 없습니다.");
                        return;
                    }
                    if (pc.hasSkillEffect(L1SkillId.쉐도우대기)) {
                        int n = pc.getSkillEffectTimeSec(L1SkillId.쉐도우대기);
                        SC_SystemMessage.send(pc, String.format("\\fY쉐도우스탭 대기시간 : %d초 후에 사용가능합니다.", n));
                        return;
                    }
                    if (MJCommons.isNonAction(pc) || pc.hasSkillEffect(L1SkillId.STATUS_FREEZE)) {
                        return;
                    }
                    if (pc.getSafetyZone() && (!(pc.getMapId() == 9 || pc.getMapId() == 1 || pc.getMapId() == 2))) {
                        SC_SystemMessage.send(pc, "세이프티존에서는 사용할 수 없습니다.");
                        return;
                    }
                    if (pc.isInvisble()) {
                        SC_SystemMessage.send(pc, "쉐도우 스텝은 투명상태로 시전이 불가능합니다.");
                        return;
                    }
                    if (pc.getCurrentMp() < 15) {
                        SC_ServerMessage.send(pc, 278);
                        return;
                    }
                    int tx = member.getX();
                    int ty = member.getY();
                    if (!pc.glanceCheck(tx, ty) || !member.glanceCheck(pc.getX(), pc.getY())) {
                        SC_PacketBox.send(pc, SC_PacketBox.GREEN_MESSAGE, "\\fY타겟과의 사이에 장애물로 인해 사용할 수 없습니다.");
                        SC_SystemMessage.send(pc, "\\fY타겟과의 사이에 장애물로 인해 사용할 수 없습니다.");
                        return;
                    }
                    int 랜덤 = _random.nextInt(100) + 1;
                    int 렙차 = pc.getLevel() - member.getLevel();
                    int 기본확률 = Config.쉐도우기본;
                    int 양렙차 = 기본확률 + (렙차 * Config.쉐도우양);
                    int 음렙차 = 기본확률 + (렙차 * Config.쉐도우음);
                    pc.start_teleport(member.getX(), member.getY(), member.getMapId(), pc.getHeading(), 169, false, false);
                    pc.setSkillEffect(L1SkillId.쉐도우대기, Config.쉐도우대기 * 1000);
                    pc.setCurrentMp(pc.getCurrentMp() - 15);
                    SC_EffectLocation.send(pc, pc.getX(), pc.getY(), 2235);
                    SC_EffectLocation.broadcast(pc, pc.getX(), pc.getY(), 2235);
                    if (렙차 >= 0) {
                        if (랜덤 <= 양렙차) {
                            if (양렙차 > 100) {
                                양렙차 = 100;
                            }
                            int 요정 = (int)((double)Config.쉐도우제약 * Config.리버레이션절감);
                            if (member.hasSkillEffect(L1SkillId.리버레이션)) {
                                member.setSkillEffect(STATUS_FREEZE, 요정);
                                L1EffectSpawn.getInstance().spawnEffect(771162, 요정, member.getX(), member.getY(), member.getMapId());
                            } else {
                                member.setSkillEffect(STATUS_FREEZE, Config.쉐도우제약);
                                L1EffectSpawn.getInstance().spawnEffect(771162, Config.쉐도우제약, member.getX(), member.getY(), member.getMapId());
                            }
                            SC_Paralysis.send(member, SC_Paralysis.TYPE_BIND, true);
                        } else {
                            pc.sendPackets("마법 사용: 실패(성공하지 못함)");
                        }
                        if (pc.isGm()) {
                            pc.sendPackets("쉐도우스텝: 확률[" + 랜덤 + "]   렙차[+" + 렙차 + "*" + Config.쉐도우양 + "+" + 기본확률 + "] = 확률범위[1~" + 양렙차 + "]");
                        }
                    } else {
                        if (랜덤 <= 음렙차) {
                            if (음렙차 < 30) {
                                음렙차 = 30;
                            }
                            int 요정 = (int)((double)Config.쉐도우제약 * Config.리버레이션절감);
                            if (member.hasSkillEffect(L1SkillId.리버레이션)) {
                                member.setSkillEffect(STATUS_FREEZE, 요정);
                                L1EffectSpawn.getInstance().spawnEffect(771162, 요정, member.getX(), member.getY(), member.getMapId());
                            } else {
                                member.setSkillEffect(STATUS_FREEZE, Config.쉐도우제약);
                                L1EffectSpawn.getInstance().spawnEffect(771162, Config.쉐도우제약, member.getX(), member.getY(), member.getMapId());
                            }
                            SC_Paralysis.send(member, SC_Paralysis.TYPE_BIND, true);
                        } else {
                            pc.sendPackets("마법 사용: 실패(성공하지 못함)");
                        }
                        if (pc.isGm()) {
                            pc.sendPackets("쉐도우스텝: 확률[" + 랜덤 + "]   렙차[-" + 렙차 + "*" + Config.쉐도우음 + "+" + 기본확률 + "] = 확률범위[1~" + 음렙차 + "]");
                        }
                    }
                }
                if (target instanceof L1NpcInstance) {
                    L1NpcInstance member1 = (L1NpcInstance)target;
                    int diffLocX1 = Math.abs(pc.getX() - member1.getX());
                    int diffLocY1 = Math.abs(pc.getY() - member1.getY());
                    if (diffLocX1 > 5 || diffLocY1 > 5) {
                        SC_PacketBox.send(pc, SC_PacketBox.GREEN_MESSAGE, "\\fY거리가 멀어서 사용할 수 없습니다.");
                        SC_SystemMessage.send(pc, "\\fY거리가 멀어서 사용할 수 없습니다.");
                        return;
                    }
                    if (pc.getInventory().getTypeEquipped(1, 1) >= 1 || pc.getInventory().getTypeEquipped(1, 3) >= 1 || pc.getInventory().getTypeEquipped(1, 2) >= 1 || pc.getInventory().getTypeEquipped(1, 4) >= 1 || pc.getInventory().getTypeEquipped(1, 5) >= 1 || pc.getInventory().getTypeEquipped(1, 6) >= 1 || pc.getInventory().getTypeEquipped(1, 7) >= 1 || pc.getInventory().getTypeEquipped(1, 8) >= 1 || pc.getInventory().getTypeEquipped(1, 10) >= 1 || pc.getInventory().getTypeEquipped(1, 13) >= 1 || pc.getInventory().getTypeEquipped(1, 14) >= 1 || pc.getInventory().getTypeEquipped(1, 17) >= 1 || pc.getInventory().getTypeEquipped(1, 15) >= 1 || pc.getInventory().getTypeEquipped(1, 18) >= 1 || pc.getInventory().getTypeEquipped(1, 16) >= 1) {
                        SC_SystemMessage.send(pc, "사용조건(다크엘프): 이도류, 크로우 중 착용");
                        return;
                    }
                    if (pc.getInventory().getTypeEquipped(1, 1) >= 1 || pc.getInventory().getTypeEquipped(1, 3) >= 1 || pc.getInventory().getTypeEquipped(1, 2) >= 1 || pc.getInventory().getTypeEquipped(1, 4) >= 1 || pc.getInventory().getTypeEquipped(1, 5) >= 1 || pc.getInventory().getTypeEquipped(1, 6) >= 1 || pc.getInventory().getTypeEquipped(1, 7) >= 1 || pc.getInventory().getTypeEquipped(1, 8) >= 1 || pc.getInventory().getTypeEquipped(1, 10) >= 1 || pc.getInventory().getTypeEquipped(1, 13) >= 1 || pc.getInventory().getTypeEquipped(1, 14) >= 1 || pc.getInventory().getTypeEquipped(1, 17) >= 1 || pc.getInventory().getTypeEquipped(1, 15) >= 1 || pc.getInventory().getTypeEquipped(1, 18) >= 1 || pc.getInventory().getTypeEquipped(1, 16) >= 1) {
                        SC_SystemMessage.send(pc, "사용조건(다크엘프): 이도류, 크로우 중 착용");
                        return;
                    }
                    if (pc.hasSkillEffect(L1SkillId.쉐도우대기)) {
                        int n = pc.getSkillEffectTimeSec(L1SkillId.쉐도우대기);
                        SC_SystemMessage.send(pc, String.format("\\fY쉐도우스탭 대기시간 : %d초 후에 사용가능합니다.", n));
                        return;
                    }
                    if (MJCommons.isNonAction(pc) || pc.hasSkillEffect(L1SkillId.STATUS_FREEZE)) {
                        return;
                    }
                    if (pc.isInvisble()) {
                        SC_SystemMessage.send(pc, "쉐도우 스텝은 투명상태로 시전이 불가능합니다.");
                        return;
                    }
                    if (pc.getCurrentMp() < 15) {
                        SC_ServerMessage.send(pc, 278);
                        return;
                    }
                    int tx1 = member1.getX();
                    int ty1 = member1.getY();
                    if (!pc.glanceCheck(tx1, ty1) || !member1.glanceCheck(pc.getX(), pc.getY())) {
                        SC_PacketBox.send(pc, SC_PacketBox.GREEN_MESSAGE, "\\fY타겟과의 사이에 장애물로 인해 사용할 수 없습니다.");
                        SC_SystemMessage.send(pc, "\\fY타겟과의 사이에 장애물로 인해 사용할 수 없습니다.");
                        return;
                    }
                    pc.start_teleport(member1.getX(), member1.getY(), member1.getMapId(), pc.getHeading(), 169, false, false);
                    SC_EffectLocation.send(pc, pc.getX(), pc.getY(), 2235);
                    SC_EffectLocation.broadcast(pc, pc.getX(), pc.getY(), 2235);
                    SC_SkillSound.send(member1, member1.getId(), 12531);
                    SC_SkillSound.broadcast(member1, member1.getId(), 12531);
                    pc.setCurrentMp(pc.getCurrentMp() - 15);
                    pc.setSkillEffect(L1SkillId.쉐도우대기, Config.쉐도우대기 * 1000);
                    int qq = Config.쉐도우몬스터;
                    int 랜덤1 = _random.nextInt(100) + 1;
                    if (랜덤1 <= qq) {
                        member1.setSkillEffect(STATUS_FREEZE, Config.쉐도우제약);
                        SC_Paralysis.send(member1, SC_Paralysis.TYPE_BIND, true);
                        @SuppressWarnings("unused")
                        L1EffectInstance eff12 = L1EffectSpawn.getInstance().spawnEffect(771162, Config.쉐도우제약, member1.getX(), member1.getY(), member1.getMapId());
                    } else {
                    }
                    if (pc.isGm()) {
                        pc.sendPackets("제약: 확률[" + 랜덤1 + "]  확률범위[1~" + Config.쉐도우몬스터 + "]");
                    }
                }
            } else {
                SC_SystemMessage.send(pc, "타겟이 올바르지않습니다.");
            }
        } else {
            pc.sendPackets("\\aH조건에 맞지 않아 사용할 수 없는 스킬입니다.");
            pc.sendPackets("\\aH조건:다크엘프      레벨: 80 이상");
        }
    }
    
    public static void 데몰리션(L1PcInstance pc, int targetId, L1ItemInstance item) {
        SC_AttackPacket.send(pc.getNetConnection(), pc, 0, ActionCodes.ACTION_Wand);
        SC_AttackPacket.broadcast(pc, 0, ActionCodes.ACTION_Wand);
        L1Object target = L1World.getInstance().findObject(targetId);
        Random random = ThreadLocalRandom.current();
        int rnd = random.nextInt(100) + 1;
        if ((pc.getType() == 7 && pc.getLevel() >= 85) || pc.isGm()) {
            if (target != null) {
                if (target instanceof L1PcInstance) {
                    L1PcInstance member = (L1PcInstance)target;
                    int diffLocX = Math.abs(pc.getX() - member.getX());
                    int diffLocY = Math.abs(pc.getY() - member.getY());
                    if (diffLocX > 6 || diffLocY > 6) {
                        SC_PacketBox.send(pc, SC_PacketBox.GREEN_MESSAGE, "\\fY거리가 멀어서 사용할 수 없습니다.");
                        SC_SystemMessage.send(pc, "\\fY거리가 멀어서 사용할 수 없습니다.");
                        return;
                    }
                    if (pc.hasSkillEffect(L1SkillId.데몰리션대기)) {
                        int n = pc.getSkillEffectTimeSec(L1SkillId.데몰리션대기);
                        SC_SystemMessage.send(pc, String.format("\\fY데몰리션 대기시간 : %d초 후에 사용가능합니다.", n));
                        return;
                    }
                    if (pc.isSkillDelay()) {
                        SC_SystemMessage.send(pc, "\\f3스킬 딜레이중이므로 사용할 수 없습니다");
                        return;
                    }
                    if (pc.getSafetyZone() && (!(pc.getMapId() == 9 || pc.getMapId() == 1 || pc.getMapId() == 2))) {
                        SC_SystemMessage.send(pc, "세이프티존에서는 사용할 수 없습니다.");
                        return;
                    }
                    if (MJCommons.isNonAction(pc)) {
                        return;
                    }
                    if (pc.isInvisble()) {
                        SC_SystemMessage.send(pc, "데몰리션은 투명상태로 시전이 불가능합니다.");
                        return;
                    }
                    if (pc.getInventory().getTypeEquipped(1, 6) < 1) {
                        SC_SystemMessage.send(pc, "한손 둔기 착용 시에만 사용가능합니다.");
                        return;
                    }
                    if (!pc.getInventory().checkItem(41246, 100)) {
                        SC_SystemMessage.send(pc, "마법 재료가 부족합니다.");
                        return;
                    }
                    if (pc.getCurrentMp() < Config.데몰리션엠피) {
                        SC_ServerMessage.send(pc, 278);
                        return;
                    }
                    if (pc.getId() == member.getId()) {
                        SC_SystemMessage.send(pc, "\\aH자기 자신에게는 사용할 수 없습니다");
                        return;
                    }
                    int tx = member.getX();
                    int ty = member.getY();
                    if (!pc.glanceCheck(tx, ty) || !member.glanceCheck(pc.getX(), pc.getY())) {
                        SC_PacketBox.send(pc, SC_PacketBox.GREEN_MESSAGE, "\\fY타겟과의 사이에 장애물로 인해 사용할 수 없습니다.");
                        SC_SystemMessage.send(pc, "\\fY타겟과의 사이에 장애물로 인해 사용할 수 없습니다.");
                        return;
                    }
                    int attackLevel = 0;
                    int defenseLevel = 0;
                    int probability = 0;
                    attackLevel = pc.getLevel();
                    defenseLevel = member.getLevel();
                    int shockStunPoint = pc.getResistance().getSpecialPierce(eKind.FEAR) + pc.getResistance().getSpecialPierce(eKind.ALL);
                    final int 데몰리션시간 = ItemUseDurationChoices.demolition(random);
                    if (shockStunPoint > 0) {
                        attackLevel += Math.round(((double)shockStunPoint * (double)Config.STUNHIT_TO_LEVEL11));
                    }
                    probability = (int)+Config.데페기본확률 + ((attackLevel - defenseLevel) * 2);
                    probability += pc.getImpactUp();
                    int resistance = (member.getResistance().getSpecialResistance(eKind.FEAR) + member.getResistance().getSpecialResistance(eKind.ALL)) / Config.내성배율;
                    if (resistance > 0) {
                        probability -= resistance;
                    }
                    if (probability < 15) {
                        probability = 15;
                    }
                    if (probability > 100) {
                        probability = 100;
                    }
                    if (pc.isGm()) {
                        SC_SystemMessage.send(pc, "데몰리션 제약확률: " + rnd + "    \\aH범위 [1~" + probability + "]");
                    }
                    int actionId = ActionCodes.ACTION_SkillBuff;
                    SC_DoActionGFX.send(pc.getNetConnection(), pc.getId(), actionId);
                    SC_DoActionGFX.broadcast(pc, actionId);
                    pc.setSkillEffect(L1SkillId.데몰리션대기, Config.데몰리션대기 * 1000);
                    pc.setCurrentMp(pc.getCurrentMp() - Config.데몰리션엠피);
                    pc.getInventory().consumeItem(41246, 100);
                    if (rnd <= probability) {
                        member.setSkillEffect(L1SkillId.쉐도우제약, 데몰리션시간);
                        SC_Paralysis.send(member, SC_Paralysis.TYPE_BIND, true);
                        SC_SkillSound.send(member, member.getId(), 14449);
                        SC_SkillSound.broadcast(member, member.getId(), 14449);
                        int 요정 = (int)((double)데몰리션시간 * Config.리버레이션절감);
                        if (member.hasSkillEffect(L1SkillId.리버레이션)) {
                            L1DamagePoison.doInfection(pc, member, 800, pc.getLevel() * 2 / Config.데몰리션대미지, true, 요정);
                            L1EffectSpawn.getInstance().spawnEffect(9418, 요정, member.getX(), member.getY(), member.getMapId());
                            L1EffectSpawn.getInstance().spawnEffect(881162, 요정, member.getX(), member.getY(), member.getMapId());
                            member.setSkillEffect(STATUS_FREEZE, 요정);
                        } else {
                            L1DamagePoison.doInfection(pc, member, 800, pc.getLevel() * 2 / Config.데몰리션대미지, true, 데몰리션시간);
                            L1EffectSpawn.getInstance().spawnEffect(9418, 데몰리션시간, member.getX(), member.getY(), member.getMapId());
                            L1EffectSpawn.getInstance().spawnEffect(881162, 데몰리션시간, member.getX(), member.getY(), member.getMapId());
                            member.setSkillEffect(STATUS_FREEZE, 데몰리션시간);
                        }
                    } else {
                        SC_SkillSound.send(member, member.getId(), 17233);
                        SC_SkillSound.broadcast(member, member.getId(), 17233);
                        SC_SkillSound.send(member, member.getId(), 14448);
                        SC_SkillSound.broadcast(member, member.getId(), 14448);
                        pc.sendPackets("마법 사용: 실패(성공하지 못함)");
                    }
                } else {
                    SC_SystemMessage.send(pc, "\\aHPC에게만 가능합니다.");
                }
            } else {
                SC_SystemMessage.send(pc, "타겟이 올바르지않습니다.");
            }
        } else {
            pc.sendPackets("\\aH조건에 맞지 않아 사용할 수 없는 스킬입니다.");
            pc.sendPackets("\\aH조건:전사      레벨: 85 이상");
        }
    }
}
