package l1j.server.server.model.item.function;

import l1j.server.server.model.network.core.sc.packet.SC_SkillSound;
import l1j.server.server.model.network.core.sc.packet.SC_HpUpdate;
import l1j.server.Config;
import l1j.server.server.datatables.SkillsTable;
import l1j.server.server.model.Instance.L1ItemInstance;
import l1j.server.server.model.Instance.L1PcInstance;
import l1j.server.server.model.character.skill.L1SkillId;
import l1j.server.server.model.network.core.sc.packet.SC_InventoryIcon;
import l1j.server.server.model.network.core.sc.packet.SC_SystemMessage;
import l1j.server.server.model.network.core.sc.packet.SC_SkillBrave;

/**
 * Original conditions, debit callbacks and effect order preserved. 
 */
final class ItemUsePassiveLearning {
    
    private ItemUsePassiveLearning() {
    }
    
    static void use(L1PcInstance pc, L1ItemInstance l1iteminstance, int itemId) {
        switch (itemId) {
        case 70701:
            if (pc.hasSkillEffect(L1SkillId.램페이지)) {
                pc.sendPackets("이미 습득한 패시브입니다.");
                return;
            }
            if (pc.getType() == 5 && pc.getLevel() >= 1) {
                ItemUseDurableSkills.useDurablePassive(pc, l1iteminstance, L1SkillId.램페이지, 0, ()->{
                    pc.램페이지(true);
                    pc.setSkillEffect(L1SkillId.램페이지, -1);
                    SC_SkillSound.send(pc, pc.getId(), 224);
                    SC_SkillSound.broadcast(pc, pc.getId(), 224);
                });
            } else {
                pc.sendPackets("현재 [램페이지] 패시브를 배울 수 없는 상태입니다");
            }
            break;
        
        case 70702:
            if (pc.hasSkillEffect(L1SkillId.래스트)) {
                pc.sendPackets("이미 습득한 패시브입니다.");
                return;
            }
            if (pc.getType() == 6 && pc.getLevel() >= 1) {
                ItemUseDurableSkills.useDurablePassive(pc, l1iteminstance, L1SkillId.래스트, 0, ()->{
                    pc.래스트(true);
                    pc.setSkillEffect(L1SkillId.래스트, -1);
                    SC_SkillSound.send(pc, pc.getId(), 224);
                    SC_SkillSound.broadcast(pc, pc.getId(), 224);
                });
            } else {
                pc.sendPackets("현재 [본브레이크:래스트] 패시브를 배울 수 없는 상태입니다");
            }
            break;
        
        case 80805:
            if (pc.hasSkillEffect(L1SkillId.에테리얼)) {
                pc.sendPackets("이미 습득한 패시브입니다.");
                return;
            }
            if (pc.getType() == 3) {
                ItemUseDurableSkills.useDurablePassive(pc, l1iteminstance, L1SkillId.에테리얼, 0, ()->{
                    pc.에테리얼(true);
                    pc.setSkillEffect(L1SkillId.에테리얼, -1);
                    SC_SkillSound.send(pc, pc.getId(), 224);
                    SC_SkillSound.broadcast(pc, pc.getId(), 224);
                });
            } else {
                pc.sendPackets("현재 [에테리얼 서클] 패시브를 배울 수 없는 상태입니다");
            }
            break;
        
        case 80804:
            if (pc.hasSkillEffect(L1SkillId.에볼루션)) {
                pc.sendPackets("이미 습득한 패시브입니다.");
                return;
            }
            if (pc.getType() == 3 && pc.getLevel() >= 1) {
                ItemUseDurableSkills.useDurablePassive(pc, l1iteminstance, L1SkillId.에볼루션, 0, ()->{
                    pc.setSkillEffect(L1SkillId.에볼루션, -1);
                    SC_SkillSound.send(pc, pc.getId(), 224);
                    SC_SkillSound.broadcast(pc, pc.getId(), 224);
                    if (pc.hasSkillEffect(L1SkillId.HOLY_WALK)) {
                        pc.removeSkillEffect(L1SkillId.HOLY_WALK);
                        pc.setSkillEffect(L1SkillId.STATUS_ELFBRAVE, 300 * 1000);
                        SC_SkillBrave.send(pc, pc.getId(), 3, 300 * 1000);
                        SC_SkillBrave.broadcast(pc, pc.getId(), 3, 0);
                        SC_InventoryIcon.icoNew(pc, L1SkillId.에볼루션, 3907, 300, true);
                        pc.setBraveSpeed(1);
                    }
                    SC_SystemMessage.send(pc, "\\aH홀리워크 사용 시 이동 및 공격속도가 증가됩니다.");
                });
            } else {
                pc.sendPackets("현재 [홀리워크:에볼루션] 패시브를 배울 수 없는 상태입니다");
            }
            break;
        
        case 70716:
            if (pc.hasSkillEffect(L1SkillId.네메시스)) {
                pc.sendPackets("이미 습득한 스킬입니다.");
                return;
            }
            if (!SkillsTable.getInstance().spellCheck(pc.getId(), 77)) {
                pc.sendPackets("디스인티그레이트를 습득한 후 네메시스를 습득할 수 있습니다.");
                return;
            }
            if (pc.getType() == 3 && pc.getLevel() >= 1) {
                ItemUseDurableSkills.useDurablePassive(pc, l1iteminstance, L1SkillId.네메시스, 0, ()->{
                    pc.네메시스(true);
                    pc.setSkillEffect(L1SkillId.네메시스, -1);
                    SC_SkillSound.send(pc, pc.getId(), 224);
                    SC_SkillSound.broadcast(pc, pc.getId(), 224);
                });
            } else {
                pc.sendPackets("현재 [디스인티그레이트:네메시스]를 배울 수 없는 조건입니다");
            }
            break;
        
        case 70704:
            if (pc.hasSkillEffect(L1SkillId.맥시멈)) {
                pc.sendPackets("이미 습득한 패시브입니다.");
                return;
            }
            if (pc.getType() == 4 && pc.getLevel() >= 1) {
                ItemUseDurableSkills.useDurablePassive(pc, l1iteminstance, L1SkillId.맥시멈, 0, ()->{
                    pc.setSkillEffect(L1SkillId.맥시멈, -1);
                    SC_SkillSound.send(pc, pc.getId(), 224);
                    SC_SkillSound.broadcast(pc, pc.getId(), 224);
                    if (pc.hasSkillEffect(L1SkillId.MOVING_ACCELERATION)) {
                        pc.removeSkillEffect(L1SkillId.MOVING_ACCELERATION);
                        pc.setSkillEffect(L1SkillId.STATUS_ELFBRAVE, 960 * 1000);
                        SC_SkillBrave.send(pc, pc.getId(), 3, 960 * 1000);
                        SC_SkillBrave.broadcast(pc, pc.getId(), 3, 0);
                        SC_InventoryIcon.icoNew(pc, L1SkillId.맥시멈, 3902, 960, true);
                        pc.setBraveSpeed(1);
                    }
                    SC_SystemMessage.send(pc, "\\aH무빙악셀레이션 사용 시 공격속도가 증가됩니다.");
                });
            } else {
                pc.sendPackets("현재 [무빙 악셀레이션:맥시멈] 패시브를 배울 수 없는 상태입니다");
            }
            break;
        
        case 70705:
            if (pc.hasSkillEffect(L1SkillId.아머데스티니)) {
                pc.sendPackets("이미 습득한 패시브입니다.");
                return;
            }
            if (pc.getType() == 4 && pc.getLevel() >= 1) {
                ItemUseDurableSkills.useDurablePassive(pc, l1iteminstance, L1SkillId.아머데스티니, 0, ()->{
                    pc.setSkillEffect(L1SkillId.아머데스티니, -1);
                    SC_SkillSound.send(pc, pc.getId(), 224);
                    SC_SkillSound.broadcast(pc, pc.getId(), 224);
                    SC_SystemMessage.send(pc, "\\aH[쉐도우 아머:데스티니]를 습득하였습니다.");
                    SC_SystemMessage.send(pc, "\\aH쉐도우 아머를 사용 시 데스티니의 효과가 지속됩니다.");
                });
            } else {
                pc.sendPackets("현재 [쉐도우 아머:데스티니] 패시브를 배울 수 없는 상태입니다");
            }
            break;
        
        case 210122:
            if (pc.hasSkillEffect(L1SkillId.기간틱)) {
                pc.sendPackets("이미 습득한 패시브입니다.");
                return;
            }
            if (pc.getType() == 7) {
                ItemUseDurableSkills.useDurablePassive(pc, l1iteminstance, L1SkillId.기간틱, 0, ()->{
                    SC_HpUpdate.send(pc, pc.getCurrentHp(), pc.getMaxHp());
                    pc.기간틱(true);
                    pc.setSkillEffect(L1SkillId.기간틱, -1);
                    SC_SkillSound.send(pc, pc.getId(), 224);
                    SC_SkillSound.broadcast(pc, pc.getId(), 224);
                    SC_SystemMessage.send(pc, "\\aH[기간틱] 패시브를 습득하였습니다.");
                });
            } else {
                pc.sendPackets("현재 [기간틱] 패시브를 배울 수 없는 조건입니다");
            }
            break;
        
        case 50512:
            if (pc.hasSkillEffect(L1SkillId.엠파이어오버로드)) {
                pc.sendPackets("이미 습득한 패시브입니다.");
                return;
            }
            if (pc.getType() == 0 && pc.getLevel() >= 1) {
                ItemUseDurableSkills.useDurablePassive(pc, l1iteminstance, L1SkillId.엠파이어오버로드, 0, ()->{
                    pc.엠파이어오버로드(true);
                    pc.setSkillEffect(L1SkillId.엠파이어오버로드, -1);
                    SC_SkillSound.send(pc, pc.getId(), 224);
                    SC_SkillSound.broadcast(pc, pc.getId(), 224);
                });
            } else {
                pc.sendPackets("현재 [엠파이어:오버로드] 패시브를 배울 수 없는 상태입니다");
            }
            break;
        
        case 40228:
            if (pc.hasSkillEffect(L1SkillId.샤이닝아머)) {
                pc.sendPackets("이미 습득한 패시브입니다.");
                return;
            }
            if (pc.getType() == 0 && pc.getLevel() >= 1) {
                ItemUseDurableSkills.useDurablePassive(pc, l1iteminstance, L1SkillId.샤이닝아머, 0, ()->{
                    pc.샤이닝아머(true);
                    pc.setSkillEffect(L1SkillId.샤이닝아머, -1);
                    SC_SkillSound.send(pc, pc.getId(), 224);
                    SC_SkillSound.broadcast(pc, pc.getId(), 224);
                });
            } else {
                pc.sendPackets("현재 [샤이닝 아머] 패시브를 배울 수 없는 상태입니다");
            }
            break;
        
        case 40231:
            if (pc.hasSkillEffect(L1SkillId.마제스티)) {
                pc.sendPackets("이미 습득한 패시브입니다.");
                return;
            }
            if (pc.getType() == 0 && pc.getLevel() >= 1) {
                ItemUseDurableSkills.useDurablePassive(pc, l1iteminstance, L1SkillId.마제스티, 0, ()->{
                    pc.마제스티(true);
                    pc.setSkillEffect(L1SkillId.마제스티, -1);
                    SC_SkillSound.send(pc, pc.getId(), 224);
                    SC_SkillSound.broadcast(pc, pc.getId(), 224);
                });
            } else {
                pc.sendPackets("현재 [마제스티] 패시브를 배울 수 없는 상태입니다");
            }
            break;
        
        case 70712:
            if (pc.hasSkillEffect(L1SkillId.포스스턴)) {
                pc.sendPackets("이미 습득한 패시브입니다.");
                return;
            }
            if (pc.getType() == 1 && pc.getLevel() >= 1) {
                ItemUseDurableSkills.useDurablePassive(pc, l1iteminstance, L1SkillId.포스스턴, 0, ()->{
                    pc.포스스턴(true);
                    pc.setSkillEffect(L1SkillId.포스스턴, -1);
                    SC_SkillSound.send(pc, pc.getId(), 224);
                    SC_SkillSound.broadcast(pc, pc.getId(), 224);
                });
            } else {
                pc.sendPackets("현재 [포스 스턴] 패시브를 배울 수 없는 상태입니다");
            }
            break;
        
        case 70713:
            if (pc.hasSkillEffect(L1SkillId.레이징포스)) {
                pc.sendPackets("이미 습득한 패시브입니다.");
                return;
            }
            if (pc.getType() == 1 && pc.getLevel() >= 1) {
                ItemUseDurableSkills.useDurablePassive(pc, l1iteminstance, L1SkillId.레이징포스, 0, ()->{
                    pc.sendPackets("\\aH[레이징 포스] 패시브를 습득하였습니다.");
                    pc.sendPackets("\\aH80레벨부터 4레벨마다 PVP 대미지 감소 +1 추가");
                    pc.setSkillEffect(L1SkillId.레이징포스, -1);
                    SC_InventoryIcon.iconNewUnLimit(pc, L1SkillId.레이징포스, 6082, true);
                    SC_SkillSound.send(pc, pc.getId(), 224);
                    SC_SkillSound.broadcast(pc, pc.getId(), 224);
                });
            } else {
                pc.sendPackets("현재 [레이징 포스] 패시브를 배울 수 없는 상태입니다");
            }
            break;
        
        case 70717:
            if (pc.hasSkillEffect(L1SkillId.세인트)) {
                pc.sendPackets("이미 습득한 스킬입니다.");
                return;
            }
            if (!SkillsTable.getInstance().spellCheck(pc.getId(), 68)) {
                pc.sendPackets("이뮨 투 함을 습득한 후 세인트를 습득할 수 있습니다.");
                return;
            }
            if (pc.getType() == 3 && pc.getLevel() >= 80) {
                ItemUseDurableSkills.useDurablePassive(pc, l1iteminstance, L1SkillId.세인트, 0, ()->{
                    pc.setSkillEffect(L1SkillId.세인트, -1);
                    SC_SkillSound.send(pc, pc.getId(), 224);
                    SC_SkillSound.broadcast(pc, pc.getId(), 224);
                    SC_SystemMessage.send(pc, "\\aH[이뮨 투함:세인트]를 습득하였습니다.");
                    SC_SystemMessage.send(pc, "\\aH이뮨 투 함을 사용 시 세인트의 효과가 지속됩니다.");
                });
            } else {
                pc.sendPackets("현재 [이뮨투함:세인트]를 배울 수 없는 조건입니다");
            }
            break;
        
        case 70718:
            if (pc.hasSkillEffect(L1SkillId.가드피어)) {
                pc.sendPackets("이미 습득한 스킬입니다.");
                return;
            }
            if (pc.hasSkillEffect(L1SkillId.가드피어호러)) {
                pc.sendPackets("상위 단계 디스트로이 패시브가 적용 중입니다.");
                return;
            }
            if (pc.getType() == 5) {
                ItemUseDurableSkills.useDurablePassive(pc, l1iteminstance, L1SkillId.가드피어, 0, ()->{
                    pc.가드피어(true);
                    pc.setSkillEffect(L1SkillId.가드피어, -1);
                    SC_SkillSound.send(pc, pc.getId(), 224);
                    SC_SkillSound.broadcast(pc, pc.getId(), 224);
                    SC_SystemMessage.send(pc, "\\aH[디스트로이:피어]를 습득하였습니다.");
                    SC_SystemMessage.send(pc, "\\aH가드 브레이크를 사용 시 디스트로이:피어 효과가 지속됩니다.");
                });
            } else {
                pc.sendPackets("현재 [디스트로이:피어]를 배울 수 없는 조건입니다");
            }
            break;
        
        case 70719:
            if (pc.hasSkillEffect(L1SkillId.가드피어호러)) {
                pc.sendPackets("이미 습득한 스킬입니다.");
                return;
            }
            if (!pc.hasSkillEffect(L1SkillId.가드피어)) {
                pc.sendPackets("디스트로이:피어를 습득한 후에 배울 수 있습니다.");
                return;
            }
            if (pc.getType() == 5) {
                ItemUseDurableSkills.useDurablePassive(pc, l1iteminstance, L1SkillId.가드피어호러, L1SkillId.가드피어, ()->{
                    if (pc.hasSkillEffect(L1SkillId.가드피어)) {
                        SC_InventoryIcon.icoEnd(pc, L1SkillId.가드피어);
                        pc.removeSkillEffect(L1SkillId.가드피어);
                    }
                    pc.가드피어호러(true);
                    pc.setSkillEffect(L1SkillId.가드피어호러, -1);
                    SC_SkillSound.send(pc, pc.getId(), 224);
                    SC_SkillSound.broadcast(pc, pc.getId(), 224);
                    SC_SystemMessage.send(pc, "\\aH[디스트로이:호러]를 습득하였습니다.");
                    SC_SystemMessage.send(pc, "\\aH가드 브레이크를 사용 시 디스트로이:호러 효과가 지속됩니다.");
                });
            } else {
                pc.sendPackets("현재 [디스트로이:호러]를 배울 수 없는 조건입니다");
            }
            break;
        
        case 10889:
            if (pc.hasSkillEffect(L1SkillId.카배마스터)) {
                pc.sendPackets("이미 습득한 패시브입니다.");
                return;
            }
            if (pc.getType() == 1 && pc.getLevel() >= 86) {
                ItemUseDurableSkills.useDurablePassive(pc, l1iteminstance, L1SkillId.카배마스터, 0, ()->{
                    pc.setSkillEffect(L1SkillId.카배마스터, -1);
                    SC_SkillSound.send(pc, pc.getId(), 224);
                    SC_SkillSound.broadcast(pc, pc.getId(), 224);
                    SC_SystemMessage.send(pc, "\\aH[카운터 배리어:마스터]를 습득하였습니다.");
                    SC_SystemMessage.send(pc, "\\aH카운터 배리어 발동 시 HP의 일정량을 회복 합니다.");
                });
            } else {
                pc.sendPackets("현재 [카운터 배리어:마스터]를 배울 수 없는 조건입니다");
            }
            break;
        
        case 10888:
            if (pc.hasSkillEffect(L1SkillId.게일샷)) {
                pc.sendPackets("이미 습득한 패시브입니다.");
                return;
            }
            if (SkillsTable.getInstance().spellCheck(pc.getId(), 174) && pc.getLevel() >= 85) {
                ItemUseDurableSkills.useDurablePassive(pc, l1iteminstance, L1SkillId.게일샷, 0, ()->{
                    SC_InventoryIcon.iconNewUnLimit(pc, L1SkillId.게일샷, 6913, true);
                    pc.setSkillEffect(L1SkillId.게일샷, -1);
                    SC_SkillSound.send(pc, pc.getId(), 224);
                    SC_SkillSound.broadcast(pc, pc.getId(), 224);
                    SC_SystemMessage.send(pc, "\\aH[스트라이커 게일:샷]을 습득하였습니다.");
                    SC_SystemMessage.send(pc, "\\aH스트라이커 게일 사용 시 기존 효과 및 게일 적중 확률 증가, 홀드효과, 치유 회복 효과 감소가 추가됩니다.");
                });
            } else {
                pc.sendPackets("현재 [스트라이커 게일:샷]을 배울 수 없는 조건입니다");
            }
            break;
        
        case 70732:
            if (pc.hasSkillEffect(L1SkillId.비욘드)) {
                pc.sendPackets("이미 습득한 스킬입니다.");
                return;
            }
            if (pc.getType() == 3 && pc.getLevel() >= 85) {
                ItemUseDurableSkills.useDurablePassive(pc, l1iteminstance, L1SkillId.비욘드, 0, ()->{
                    pc.비욘드(true);
                    pc.setSkillEffect(L1SkillId.비욘드, -1);
                    SC_SkillSound.send(pc, pc.getId(), 224);
                    SC_SkillSound.broadcast(pc, pc.getId(), 224);
                    SC_SystemMessage.send(pc, "\\aH[메디테이션:비욘드]를 습득하였습니다.");
                });
            } else {
                pc.sendPackets("현재 [메디테이션:비욘드]를 배울 수 없는 조건입니다");
            }
            break;
        
        case 40271:
            if (pc.hasSkillEffect(L1SkillId.버닝)) {
                pc.sendPackets("이미 습득한 스킬입니다.");
                return;
            }
            if (pc.getType() == 4) {
                ItemUseDurableSkills.useDurablePassive(pc, l1iteminstance, L1SkillId.버닝, 0, ()->{
                    pc.버닝(true);
                    pc.setSkillEffect(L1SkillId.버닝, -1);
                    SC_SkillSound.send(pc, pc.getId(), 224);
                    SC_SkillSound.broadcast(pc, pc.getId(), 224);
                    SC_SystemMessage.send(pc, "\\aH[버닝 스피릿츠]를 습득하였습니다.");
                });
            } else {
                pc.sendPackets("현재 [버닝 스피릿츠]를 배울 수 없는 조건입니다");
            }
            break;
        
        case 40279:
            if (pc.hasSkillEffect(L1SkillId.이베이젼)) {
                pc.sendPackets("이미 습득한 스킬입니다.");
                return;
            }
            if (pc.getType() == 4) {
                ItemUseDurableSkills.useDurablePassive(pc, l1iteminstance, L1SkillId.이베이젼, 0, ()->{
                    pc.이베이젼(true);
                    pc.setSkillEffect(L1SkillId.이베이젼, -1);
                    SC_SkillSound.send(pc, pc.getId(), 224);
                    SC_SkillSound.broadcast(pc, pc.getId(), 224);
                    SC_SystemMessage.send(pc, "\\aH[드레스 이베이젼]을 습득하였습니다.");
                });
            } else {
                pc.sendPackets("현재 [드레스 이베이젼]을 배울 수 없는 조건입니다");
            }
            break;
        
        case 210008:
            if (pc.hasSkillEffect(L1SkillId.일루션리치)) {
                pc.sendPackets("이미 습득한 패시브입니다.");
                return;
            }
            if (pc.getType() == 6) {
                ItemUseDurableSkills.useDurablePassive(pc, l1iteminstance, L1SkillId.일루션리치, 0, ()->{
                    pc.일루션리치(true);
                    pc.setSkillEffect(L1SkillId.일루션리치, -1);
                    SC_SkillSound.send(pc, pc.getId(), 224);
                    SC_SkillSound.broadcast(pc, pc.getId(), 224);
                    SC_SystemMessage.send(pc, "\\aH[일루션:리치]를 습득하였습니다.");
                });
            } else {
                pc.sendPackets("현재 [일루션:리치]를 배울 수 없는 조건입니다");
            }
            break;
        
        case 210013:
            if (pc.hasSkillEffect(L1SkillId.일루션골렘)) {
                pc.sendPackets("이미 습득한 패시브입니다.");
                return;
            }
            if (pc.getType() == 6) {
                ItemUseDurableSkills.useDurablePassive(pc, l1iteminstance, L1SkillId.일루션골렘, 0, ()->{
                    pc.일루션골렘(true);
                    pc.setSkillEffect(L1SkillId.일루션골렘, -1);
                    SC_SkillSound.send(pc, pc.getId(), 224);
                    SC_SkillSound.broadcast(pc, pc.getId(), 224);
                    SC_SystemMessage.send(pc, "\\aH[일루션:골렘]을 습득하였습니다.");
                });
            } else {
                pc.sendPackets("현재 [일루션:골렘]을 배울 수 없는 조건입니다");
            }
            break;
        
        case 41147:
            if (pc.hasSkillEffect(L1SkillId.솔리드캐리지)) {
                pc.sendPackets("이미 습득한 패시브입니다.");
                return;
            }
            if (pc.getType() == 1) {
                ItemUseDurableSkills.useDurablePassive(pc, l1iteminstance, L1SkillId.솔리드캐리지, 0, ()->{
                    pc.솔리드캐리지(true);
                    pc.setSkillEffect(L1SkillId.솔리드캐리지, -1);
                    SC_SkillSound.send(pc, pc.getId(), 224);
                    SC_SkillSound.broadcast(pc, pc.getId(), 224);
                    SC_SystemMessage.send(pc, "\\aH[솔리드 캐리지]를 습득하였습니다.");
                });
            } else {
                pc.sendPackets("현재 [솔리드 캐리지]을 배울 수 없는 조건입니다");
            }
            break;
        
        case 70720:
            if (pc.hasSkillEffect(L1SkillId.리덕션베테랑)) {
                pc.sendPackets("이미 습득한 패시브입니다.");
                return;
            }
            if (!SkillsTable.getInstance().spellCheck(pc.getId(), 88)) {
                pc.sendPackets("리덕션 아머를 배운 후 습득가능합니다.");
                return;
            }
            if (pc.getType() == 1) {
                ItemUseDurableSkills.useDurablePassive(pc, l1iteminstance, L1SkillId.리덕션베테랑, 0, ()->{
                    if (pc.hasSkillEffect(L1SkillId.REDUCTION_ARMOR)) {
                        pc.removeSkillEffect(L1SkillId.REDUCTION_ARMOR);
                    }
                    pc.setSkillEffect(L1SkillId.리덕션베테랑, -1);
                    SC_SkillSound.send(pc, pc.getId(), 224);
                    SC_SkillSound.broadcast(pc, pc.getId(), 224);
                    SC_SystemMessage.send(pc, "\\aH[리덕션아머:베테랑]을 습득하였습니다.");
                    SC_SystemMessage.send(pc, "\\aH리덕션 아머 사용 시 공포내성 +3 효과가 적용됩니다.");
                });
            } else {
                pc.sendPackets("현재 [리덕션아머:베테랑]을 배울 수 없는 조건입니다");
            }
            break;
        
        case 40224:
            if (pc.hasSkillEffect(L1SkillId.어드밴스)) {
                pc.sendPackets("이미 습득한 패시브입니다.");
                return;
            }
            if (pc.getType() == 3) {
                ItemUseDurableSkills.useDurablePassive(pc, l1iteminstance, L1SkillId.어드밴스, 0, ()->{
                    if (pc.hasSkillEffect(L1SkillId.ADVANCE_SPIRIT)) {
                        pc.removeSkillEffect(L1SkillId.ADVANCE_SPIRIT);
                    }
                    pc.어드밴스(true);
                    pc.setSkillEffect(L1SkillId.어드밴스, -1);
                    SC_SkillSound.send(pc, pc.getId(), 224);
                    SC_SkillSound.broadcast(pc, pc.getId(), 224);
                    SC_SystemMessage.send(pc, "\\aH[어드밴스 스피릿]이 적용되었습니다.");
                });
            } else {
                pc.sendPackets("현재 [어드밴스 스피릿]을 배울 수 없는 조건입니다");
            }
            break;
        
        case 4100100:
            if (pc.hasSkillEffect(L1SkillId.프라이드)) {
                pc.sendPackets("이미 습득한 패시브입니다.");
                return;
            }
            if (pc.getType() == 1) {
                ItemUseDurableSkills.useDurablePassive(pc, l1iteminstance, L1SkillId.프라이드, 0, ()->{
                    SC_HpUpdate.send(pc, pc.getCurrentHp(), pc.getMaxHp());
                    pc.프라이드(true);
                    pc.setSkillEffect(L1SkillId.프라이드, -1);
                    SC_SkillSound.send(pc, pc.getId(), 224);
                    SC_SkillSound.broadcast(pc, pc.getId(), 224);
                    SC_SystemMessage.send(pc, "\\aH[프라이드]를 습득하였습니다.");
                });
            } else {
                pc.sendPackets("현재 [프라이드]을 배울 수 없는 조건입니다");
            }
            break;
        
        }
    }
}
