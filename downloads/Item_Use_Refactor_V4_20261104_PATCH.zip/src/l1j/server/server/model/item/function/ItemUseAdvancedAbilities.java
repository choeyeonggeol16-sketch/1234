package l1j.server.server.model.item.function;

import l1j.server.server.model.Instance.L1ItemInstance;
import l1j.server.server.model.Instance.L1PcInstance;

/** Routes learning and active items without changing item eligibility. */
final class ItemUseAdvancedAbilities {
    private ItemUseAdvancedAbilities() {}

    static void use(L1PcInstance pc, L1ItemInstance l1iteminstance, int itemId) {
        switch (itemId) {
            case 70701, 70702, 80805, 80804, 70716, 70704, 70705, 210122, 50512, 40228, 40231, 70712, 70713, 70717, 70718, 70719, 10889, 10888, 70732, 40271, 40279, 210008, 210013, 41147, 70720, 40224, 4100100 -> ItemUsePassiveLearning.use(pc, l1iteminstance, itemId);
            case 90905, 80889, 70707, 70734, 70709, 70711, 70715, 70722, 44002, 70730, 220013, 70731, 707778, 707780, 707782, 70741 -> ItemUseSkillLearning.use(pc, l1iteminstance, itemId);
            case 70706, 70708, 70733, 70710, 70714, 44001, 70735, 880800, 70740 -> ItemUseActiveSkills.use(pc, l1iteminstance, itemId);
        }
    }
}
