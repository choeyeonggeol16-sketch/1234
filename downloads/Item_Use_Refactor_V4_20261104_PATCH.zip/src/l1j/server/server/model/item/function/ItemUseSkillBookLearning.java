package l1j.server.server.model.item.function;

import l1j.server.server.datatables.SkillsTable;
import l1j.server.server.model.Instance.L1ItemInstance;
import l1j.server.server.model.Instance.L1PcInstance;
import l1j.server.server.model.network.core.sc.packet.SC_AddSkill;
import l1j.server.server.model.network.core.sc.packet.SC_ServerMessage;
import l1j.server.server.model.network.core.sc.packet.SC_SkillSound;
import l1j.server.server.model.network.core.sc.packet.SC_SystemMessage;
import l1j.server.server.templates.L1Skills;

/** One learning flow; book families supply only their existing differences. */
final class ItemUseSkillBookLearning {
    enum Kind {
        DARK_ELF(97, 241, "흑정령의 수정 (", 231, 29, true),
        ELF(129, 179, "정령의 수정 (", 224, -1, false),
        KNIGHT(87, 96, "기술서 (", 224, -1, false),
        PRINCE(113, 123, "마법서 (", 224, -1, false),
        DRAGON_KNIGHT(181, 199, "용기사의 서판(", 224, -1, false),
        ILLUSIONIST(201, 224, "기억의 수정(", 224, 28, false);

        final int first, last, sound, level29Slot;
        final String prefix;
        final boolean skipMissing;

        Kind(int first, int last, String prefix, int sound, int level29Slot, boolean skipMissing) {
            this.first=first; this.last=last; this.prefix=prefix; this.sound=sound;
            this.level29Slot=level29Slot; this.skipMissing=skipMissing;
        }
    }

    private ItemUseSkillBookLearning() {}

    static void learn(L1PcInstance pc, L1ItemInstance item, Kind kind) {
        String skillName = "";
        int skillId = 0;
        int[] levels = new int[30];
        SkillsTable table = SkillsTable.getInstance();
        for (int id=kind.first; id<=kind.last; id++) {
            L1Skills skill = table.getTemplate(id);
            if (skill == null && kind.skipMissing) {
                System.out.println(String.format("누락된 스킬 아이디 : %d", id));
                continue;
            }
            if (!matches(item.getItem().getName(), kind.prefix, String.valueOf(skill.getName()))) continue;
            if (kind == Kind.ELF && !pc.isGm() && skill.getAttr()!=0 && pc.getElfAttr()!=skill.getAttr()) {
                int attr = pc.getElfAttr();
                if (attr==0 || attr==1 || attr==2 || attr==4 || attr==8) {
                    SC_ServerMessage.send(pc, 79);
                    return;
                }
            }
            int level = skill.getSkillLevel();
            skillName = skill.getName();
            skillId = skill.getSkillId();
            if (level>=1 && level<=28) levels[level-1] = skill.getId();
            else if (level==29 && kind.level29Slot>=0) levels[kind.level29Slot] = skill.getId();
        }
        if (pc.isSkillMastery(skillId)) {
            SC_SystemMessage.send(pc, "이미 배운 마법입니다.");
            return;
        }
        SC_AddSkill.send(pc, levels);
        long sound = SC_SkillSound.pack(pc.getId(), kind.sound);
        SC_SkillSound.sendPacked(pc, sound);
        SC_SkillSound.broadcastPacked(pc, sound);
        table.spellMastery(pc.getId(), skillId, skillName, 0, 0);
        pc.getInventory().removeItem(item, 1);
    }

    /** Equivalent to equalsIgnoreCase(prefix + name + ")"), without building it. */
    static boolean matches(String book, String prefix, String name) {
        int prefixLength=prefix.length(), nameLength=name.length();
        return book.length()==prefixLength+nameLength+1
            && book.charAt(book.length()-1)==')'
            && book.regionMatches(true, 0, prefix, 0, prefixLength)
            && book.regionMatches(true, prefixLength, name, 0, nameLength);
    }
}
