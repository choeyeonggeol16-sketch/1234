package l1j.server.server.model.item.function;

import l1j.server.server.model.network.core.sc.packet.SC_SkillSound;
import l1j.server.Config;
import l1j.server.server.model.Instance.L1ItemInstance;
import l1j.server.server.model.Instance.L1PcInstance;
import l1j.server.server.model.character.skill.L1SkillId;
import l1j.server.server.model.network.core.sc.packet.SC_SystemMessage;
import l1j.server.server.utils.MJCommons;

/**
 * Original conditions, debit callbacks and effect order preserved. 
 */
final class ItemUseSkillLearning {
    
    private ItemUseSkillLearning() {
    }
    
    static void use(L1PcInstance pc, L1ItemInstance l1iteminstance, int itemId) {
        switch (itemId) {
        case 90905:
            if (pc.getInventory().checkItem(90088)) {
                pc.sendPackets("이미 스킬이 있으므로 획득할 수 없습니다.");
                return;
            }
            if (pc.getType() == 3) {
                ItemUseDurable.UseDurableExchange(pc, l1iteminstance, 90088, ()->{
                    SC_SkillSound.send(pc, pc.getId(), 224);
                    SC_SkillSound.broadcast(pc, pc.getId(), 224);
                });
            } else {
                pc.sendPackets("현재 [비전 텔레포트]를 배울 수 없는 상태입니다");
            }
            break;
        
        case 80889:
            if (pc.getInventory().checkItem(80888)) {
                pc.sendPackets("이미 이터니티 스킬이 있으므로 획득할 수 없습니다.");
                return;
            }
            if (pc.getType() == 3 && pc.getLevel() >= 1) {
                ItemUseDurable.UseDurableExchange(pc, l1iteminstance, 80888, ()->{
                    SC_SkillSound.send(pc, pc.getId(), 224);
                    SC_SkillSound.broadcast(pc, pc.getId(), 224);
                    pc.sendPackets("\\f3이터니티를 습득하였습니다.");
                    pc.sendPackets("\\f3[첫번째 공격은 카운터 매직 무시. 확률적 적중 시 홀드 및 2차 데미지]");
                });
            } else {
                pc.sendPackets("현재 [이터니티]를 배울 수 없는 상태입니다");
            }
            break;
        
        case 70707:
            if (pc.getType() == 7 && pc.getLevel() >= 1) {
                if (pc.getInventory().checkItem(70706)) {
                    pc.sendPackets("이미 버서크 스킬이 있으므로 획득할 수 없습니다.");
                    return;
                }
                ItemUseDurable.UseDurableExchange(pc, l1iteminstance, 70706, ()->{
                    pc.sendPackets("\\aH전사의 인장 (버서크)를 획득하였습니다.");
                });
            } else {
                pc.sendPackets("조건이 맞지 않아 버서크를 획득 할 수 없습니다.");
            }
            break;
        
        case 70734:
            if (pc.getInventory().checkItem(70733)) {
                pc.sendPackets("이미 매스 이뮨 투 함 스킬이 있으므로 획득할 수 없습니다.");
                return;
            }
            if (pc.getType() == 3 && pc.getLevel() >= 1) {
                ItemUseDurable.UseDurableExchange(pc, l1iteminstance, 70733, ()->{
                    SC_SkillSound.send(pc, pc.getId(), 224);
                    SC_SkillSound.broadcast(pc, pc.getId(), 224);
                    pc.sendPackets("\\aH마법서 (매스 이뮨 투 함)을 획득하였습니다.");
                });
            } else {
                pc.sendPackets("조건이 맞지 않아 매스 이뮨 투 함을 획득 할 수 없습니다.");
            }
            break;
        
        case 70709:
            if (pc.getType() == 0 && pc.getLevel() >= 85) {
                if (pc.getInventory().checkItem(70708)) {
                    pc.sendPackets("이미 프라임 스킬이 있으므로 획득할 수 없습니다.");
                    return;
                }
                ItemUseDurable.UseDurableExchange(pc, l1iteminstance, 70708, ()->{
                    SC_SkillSound.send(pc, pc.getId(), 224);
                    SC_SkillSound.broadcast(pc, pc.getId(), 224);
                    pc.sendPackets("\\aH마법서 (프라임)을 획득하였습니다.");
                });
            } else {
                pc.sendPackets("조건이 맞지 않아 프라임을 획득 할 수 없습니다.");
            }
            break;
        
        case 70711:
            if (pc.getType() == 5 && pc.getLevel() >= 1) {
                if (pc.getInventory().checkItem(70710)) {
                    pc.sendPackets("이미 할파스 스킬이 있으므로 획득할 수 없습니다.");
                    return;
                }
                ItemUseDurable.UseDurableExchange(pc, l1iteminstance, 70710, ()->{
                    SC_SkillSound.send(pc, pc.getId(), 224);
                    SC_SkillSound.broadcast(pc, pc.getId(), 224);
                    pc.sendPackets("\\aH[할파스]를 획득하였습니다.");
                });
            } else {
                pc.sendPackets("조건이 맞지 않아 할파스를 획득 할 수 없습니다.");
            }
            break;
        
        case 70715:
            if (pc.getType() == 6 && pc.getLevel() >= 85) {
                if (pc.getInventory().checkItem(70714)) {
                    pc.sendPackets("이미 포텐셜 스킬이 있으므로 획득할 수 없습니다.");
                    return;
                }
                ItemUseDurable.UseDurableExchange(pc, l1iteminstance, 70714, ()->{
                    pc.sendPackets("\\aH[포텐셜]을 획득하였습니다.");
                });
            } else {
                pc.sendPackets("조건이 맞지 않아 포텐셜을 획득 할 수 없습니다.");
            }
            break;
        
        case 70722:
            if (pc.getInventory().checkItem(70721)) {
                pc.sendPackets("이미 습득한 스킬입니다.");
                return;
            }
            if (pc.getType() == 0 && pc.getLevel() >= Config.어드밴스레벨) {
                ItemUseDurable.UseDurableExchange(pc, l1iteminstance, 70721, ()->{
                    SC_SkillSound.send(pc, pc.getId(), 224);
                    SC_SkillSound.broadcast(pc, pc.getId(), 224);
                    SC_SystemMessage.send(pc, "\\aH[콜 클랜 어드밴스]를 습득하였습니다.");
                });
            } else {
                pc.sendPackets("현재 [콜 클랜 어드밴스]를 배울 수 없는 조건입니다");
            }
            break;
        
        case 44002:
            if (pc.getInventory().checkItem(44001)) {
                pc.sendPackets("이미 습득한 스킬입니다.");
                return;
            }
            if (pc.getType() == 2 && pc.getLevel() >= 85) {
                ItemUseDurable.UseDurableExchange(pc, l1iteminstance, 44001, ()->{
                    SC_SkillSound.send(pc, pc.getId(), 224);
                    SC_SkillSound.broadcast(pc, pc.getId(), 224);
                    SC_SystemMessage.send(pc, "\\aH[버닝 샷]을 습득하였습니다.");
                });
            } else {
                pc.sendPackets("현재 [버닝 샷]을 배울 수 없는 조건입니다");
            }
            break;
        
        case 70730:
            if (pc.getInventory().checkItem(70735)) {
                pc.sendPackets("이미 리버레이션 스킬이 있으므로 획득할 수 없습니다.");
                return;
            }
            if (pc.getType() == 2 && pc.getLevel() >= 85) {
                ItemUseDurable.UseDurableExchange(pc, l1iteminstance, 70735, ()->{
                    SC_SkillSound.send(pc, pc.getId(), 224);
                    SC_SkillSound.broadcast(pc, pc.getId(), 224);
                    SC_SystemMessage.send(pc, "\\aH[리버레이션]을 습득하였습니다.");
                });
            } else {
                pc.sendPackets("현재 [리버레이션]을 배울 수 없는 조건입니다");
            }
            break;
        
        case 220013:
            if (pc.getInventory().checkItem(220012)) {
                pc.sendPackets("이미 습득한 스킬입니다.");
                return;
            }
            if (pc.getType() == 2 && pc.getLevel() >= 85) {
                ItemUseDurable.UseDurableExchange(pc, l1iteminstance, 220012, ()->{
                    SC_SkillSound.send(pc, pc.getId(), 224);
                    SC_SkillSound.broadcast(pc, pc.getId(), 224);
                    SC_SystemMessage.send(pc, "\\aH[매직실드]를 습득하였습니다.");
                });
            } else {
                pc.sendPackets("현재 [매직실드]를 배울 수 없는 조건입니다");
            }
            break;
        
        case 70731:
            if (pc.getInventory().checkItem(70888)) {
                pc.sendPackets("이미 습득한 스킬입니다.");
                return;
            }
            if (pc.getType() == 2 && pc.getLevel() >= 85) {
                ItemUseDurable.UseDurableExchange(pc, l1iteminstance, 70888, ()->{
                    SC_SkillSound.send(pc, pc.getId(), 224);
                    SC_SkillSound.broadcast(pc, pc.getId(), 224);
                    SC_SystemMessage.send(pc, "\\aH[엘븐 스트라이크]를 습득하였습니다.");
                });
            } else {
                pc.sendPackets("현재 [엘븐 스트라이크]를 배울 수 없는 조건입니다");
            }
            break;
        
        case 707778:
            if (pc.getInventory().checkItem(707777)) {
                pc.sendPackets("이미 습득한 스킬입니다.");
                return;
            }
            if (pc.getType() == 4 && pc.getLevel() >= 80) {
                ItemUseDurable.UseDurableExchange(pc, l1iteminstance, 707777, ()->{
                    SC_SkillSound.send(pc, pc.getId(), 224);
                    SC_SkillSound.broadcast(pc, pc.getId(), 224);
                    SC_SystemMessage.send(pc, "\\aH[쉐도우 스텝]을 습득하였습니다.");
                });
            } else {
                pc.sendPackets("현재 [쉐도우 스텝]을 배울 수 없는 조건입니다");
            }
            break;
        
        case 707780:
            if (pc.getInventory().checkItem(707779)) {
                pc.sendPackets("이미 습득한 스킬입니다.");
                return;
            }
            if (pc.getType() == 4 && pc.getLevel() >= 80) {
                ItemUseDurable.UseDurableExchange(pc, l1iteminstance, 707779, ()->{
                    SC_SkillSound.send(pc, pc.getId(), 224);
                    SC_SkillSound.broadcast(pc, pc.getId(), 224);
                    SC_SystemMessage.send(pc, "\\aH[어벤저]를 습득하였습니다.");
                });
            } else {
                pc.sendPackets("현재 [어벤저]를 배울 수 없는 조건입니다");
            }
            break;
        
        case 707782:
            if (pc.getInventory().checkItem(707781)) {
                pc.sendPackets("이미 습득한 스킬입니다.");
                return;
            }
            if (pc.getType() == 7 && pc.getLevel() >= 85) {
                ItemUseDurable.UseDurableExchange(pc, l1iteminstance, 707781, ()->{
                    SC_SkillSound.send(pc, pc.getId(), 224);
                    SC_SkillSound.broadcast(pc, pc.getId(), 224);
                    SC_SystemMessage.send(pc, "\\aH[데몰리션]을 습득하였습니다.");
                });
            } else {
                pc.sendPackets("현재 [데몰리션]을 배울 수 없는 조건입니다");
            }
            break;
        
        case 70741:
            if (pc.getInventory().checkItem(70740)) {
                pc.sendPackets("이미 습득한 스킬입니다.");
                return;
            }
            if (pc.getLevel() >= Config.이뮨투함블레이드레벨) {
                if (MJCommons.isNonAction(pc)) {
                    return;
                }
                ItemUseDurable.UseDurableExchange(pc, l1iteminstance, 70740, ()->{
                    SC_SkillSound.send(pc, pc.getId(), 224);
                    SC_SkillSound.broadcast(pc, pc.getId(), 224);
                    SC_SystemMessage.send(pc, "\\aH[이뮨 투 함 블레이드]를 습득하였습니다.");
                });
            } else {
                pc.sendPackets("현재 [이뮨 투 함 블레이드]를 배울 수 없는 조건입니다");
            }
            break;
        
        }
    }
}
