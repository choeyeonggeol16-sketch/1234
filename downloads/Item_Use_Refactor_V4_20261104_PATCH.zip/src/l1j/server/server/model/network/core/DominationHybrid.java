package l1j.server.server.model.network.core;

import java.nio.charset.StandardCharsets;
import java.security.SecureRandom;
import java.util.logging.Level;
import java.util.logging.Logger;

import l1j.server.Config;
import l1j.server.server.Account;
import l1j.server.server.Controller.LoginController;
import l1j.server.server.ThreadPool;
import l1j.server.server.model.Instance.L1PcInstance;
import l1j.server.server.model.L1World;
import l1j.server.server.model.map.L1Map;
import l1j.server.server.model.map.L1WorldMap;
import l1j.server.server.model.network.core.cs.packet.CS_EnterWorld;
import l1j.server.server.model.network.utill.ConnectionState;
import l1j.server.server.packets.Protocol.Proto;
import l1j.server.server.packets.Protocol.ProtoMsg;
import l1j.server.server.packets.Protocol.ProtoWriter;
import l1j.server.server.storage.CacheD;

/**
 * GM-only trial of the original hybrid reconnect wire flow on one physical server.
 * A single bounded pending handoff avoids a new executor, queue, or persistent user state.
 * Standard tower NPC / scroll entry paths are intentionally untouched.
 */
public final class DominationHybrid {
    private static final Logger LOG = Logger.getLogger(DominationHybrid.class.getName());
    private static final SecureRandom RANDOM = new SecureRandom();
    private static final long TTL_NS = 90_000_000_000L;
    private static final int RESERVED_TOWER = 112;
    private static final int KIND_TOWER = 7;
    private static final int[] X = {0, 32728, 32721, 32724, 32597, 32592, 32602,
            32604, 32593, 32602, 32732, 32639};
    private static final int[] Y = {0, 32800, 32803, 32802, 32863, 32866, 32865,
            32866, 32866, 32866, 32802, 32797};

    private static final class Pending {
        final CIOClient oldClient;
        final Account account;
        final String character;
        final String ip;
        final int characterId, mapId, x, y;
        final String token;
        final long createdNs;
        CIOClient newClient;
        boolean oldClosed;
        boolean finishing;
        Pending(L1PcInstance pc, CIOClient client, String nonce, int floor) {
            oldClient = client;
            account = client.getAccount();
            character = pc.getName();
            characterId = pc.getId();
            ip = client.getIp();
            token = nonce;
            mapId = 12851 + floor;
            x = X[floor];
            y = Y[floor];
            createdNs = System.nanoTime();
        }
    }

    // Only one GM handoff is enabled at a time, not one record per player.
    private static Pending pending;

    // At most one GM trial can be traced; normal sockets pay no per-socket memory.
    private static volatile CIOClient traceClient;
    private static volatile long traceUntilNs;
    private static int traceReceived;
    private static int traceLastOpcode = -1;
    private static final int TRACE_RECEIVE_LIMIT = 40;
    private static final int OUTBOUND_HISTORY = 96;
    private static final String[] outbound = new String[OUTBOUND_HISTORY];
    private static int outboundSerial;
    private static int outboundLastDump = -1;

    /** Retain only the last 96 admitted S->C frames for the current GM trial. */
    public static void traceOutbound(CIOClient client, String type, int id) {
        if (!tracing(client)) return;
        synchronized (DominationHybrid.class) {
            if (!tracing(client)) return;
            final int serial = ++outboundSerial;
            outbound[serial % OUTBOUND_HISTORY] = "#" + serial + " " + type
                    + (id >= 0 ? " id=" + id + " (0x" + Integer.toHexString(id) + ')' : "");
        }
    }

    private static void dumpOutbound(CIOClient client) {
        if (!tracing(client)) return;
        synchronized (DominationHybrid.class) {
            final int last = outboundSerial;
            if (outboundLastDump == last) return;
            outboundLastDump = last;
            LOG.warning("[INTER-DIAG] S->C admitted frame history (not delivery ACK), total=" + last);
            for (int s = Math.max(1, last - 31); s <= last; s++) {
                String event = outbound[s % OUTBOUND_HISTORY];
                if (event != null) LOG.warning("[INTER-DIAG] S->C " + event);
            }
        }
    }

    public static boolean tracing(CIOClient client) {
        return client != null && traceClient == client
                && System.nanoTime() - traceUntilNs < 0L;
    }

    public static void traceInbound(CIOClient client, int opcode, int remaining) {
        if (!tracing(client)) return;
        synchronized (DominationHybrid.class) {
            if (!tracing(client) || traceReceived >= TRACE_RECEIVE_LIMIT) return;
            traceLastOpcode = opcode;
            ++traceReceived;
            LOG.info("[INTER-DIAG] recv #" + traceReceived
                    + " opcode=0x" + Integer.toHexString(opcode & 255)
                    + " bytesAfterOpcode=" + remaining
                    + " state=" + client.getConnectionState()
                    + " gameReady=" + client.isGameSessionReady());
        }
    }

    public static void traceExtended(CIOClient client, int msgId, int len, boolean known) {
        if (!tracing(client)) return;
        LOG.info("[INTER-DIAG] protobuf C->S msgId=0x"
                + Integer.toHexString(msgId) + " len=" + len + " handler=" + known);
    }

    public static void traceReadFailure(CIOClient client, Throwable error) {
        if (!tracing(client)) return;
        LOG.warning("[INTER-DIAG] read.failed detail="
                + (error == null ? "unknown" : error.toString())
                + " cause=" + (error == null ? "unknown" : String.valueOf(error.getCause())));
        dumpOutbound(client);
    }

    public static void traceTransport(CIOClient client, String reason) {
        if (!tracing(client)) return;
        LOG.warning("[INTER-DIAG] transport=" + reason
                + " lastOpcode=0x" + Integer.toHexString(traceLastOpcode & 255)
                + " frames=" + traceReceived + " state=" + client.getConnectionState()
                + " gameReady=" + client.isGameSessionReady());
    }

    private DominationHybrid() { }

    public static void gmCommand(L1PcInstance gm, String param) {
        if (gm == null || gm.getNetConnection() == null || gm.getAccount() == null
                || !gm.getAccount().isGameMaster()) return;
        final String[] args = param == null ? new String[0] : param.trim().split("\\s+");
        if (args.length != 3 || !"지배".equals(args[0])) {
            gm.sendPackets("[INTER-TEST] .인터서버 지배 <1~11> <서버 IPv4>");
            return;
        }
        final int floor;
        try { floor = Integer.parseInt(args[1]); }
        catch (NumberFormatException e) { gm.sendPackets("[INTER-TEST] 층 번호는 1~11."); return; }
        if (floor < 1 || floor > 11 || gm.isDead() || gm.isLogoutStarted()
                || gm.isPrivateShop() || gm.isAutoClanjoin() || gm.getTradeID() != 0
                || !gm.getNetConnection().isGameSessionReady()) {
            gm.sendPackets("[INTER-TEST] 입장 불가: 층/캐릭터 상태 확인.");
            return;
        }
        final String serverIP = args[2];
        final int ip32 = parseIpv4(serverIP);
        if (ip32 == -1 || Config.GAME_SERVER_PORT < 1 || Config.GAME_SERVER_PORT > 65535) {
            gm.sendPackets("[INTER-TEST] 유효한 서버 IPv4와 포트를 입력하세요.");
            return;
        }
        final L1Map map = L1WorldMap.getInstance().getMap((short) (12851 + floor));
        if (map == null || !map.isInMap(X[floor], Y[floor])
                || !map.isPassable(X[floor], Y[floor])) {
            gm.sendPackets("[INTER-TEST] 해당 지배의 탑 이동 타일이 유효하지 않음.");
            return;
        }
        final Pending p;
        synchronized (DominationHybrid.class) {
            if (pending != null && !isExpired(pending)) {
                gm.sendPackets("[INTER-TEST] 다른 재접속 테스트 진행 중. 90초 후 재시도.");
                return;
            }
            byte[] random = new byte[16];
            RANDOM.nextBytes(random);
            char[] hex = new char[32];
            final char[] digits = "0123456789abcdef".toCharArray();
            for (int i = 0; i < random.length; i++) {
                hex[i * 2] = digits[(random[i] >>> 4) & 15];
                hex[i * 2 + 1] = digits[random[i] & 15];
            }
            p = new Pending(gm, gm.getNetConnection(), new String(hex), floor);
            pending = p;
        }
        // Wire fields reproduced from the other pack, without copying its
        // unauthenticated account|character|position pseudo-token.
        final ProtoWriter writer = Proto.begin(gm.getNetConnection(),
                ProtoMsg.SC_CONNECT_HIBREEDSERVER_NOTI_PACKET, 256);
        if (writer == null) { clear(p); gm.sendPackets("[INTER-TEST] 전송 프레임 할당 실패."); return; }
        boolean sent = false;
        try {
            writer.uint32(1, ip32).int32(2, Config.GAME_SERVER_PORT)
                    .uint32(3, RESERVED_TOWER)
                    .bytes(4, p.token.getBytes(StandardCharsets.US_ASCII))
                    .int32(5, KIND_TOWER).string(6, serverIP).bool(7, false);
            sent = Proto.commit(writer);
        } catch (Throwable e) {
            LOG.log(Level.WARNING, "[INTER-TEST] 113 build/send failed", e);
        } finally {
            Proto.abort(writer);
        }
        if (!sent) { clear(p); gm.sendPackets("[INTER-TEST] 113 전송 실패."); return; }
        LOG.info("[INTER-TEST] 113 sent kind=7 reserved=112 floor=" + floor
                + " dest=" + serverIP + ':' + Config.GAME_SERVER_PORT
                + " char=" + p.character + " (GM only)");
    }

    /** C->S protobuf message 115: fields 1=reserved, 2=one-time token. */
    public static void onHybridAuth(CIOClient arriving, long reserved, String token) {
        if (arriving == null || !arriving.isConnected() || arriving.getAccount() != null
                || arriving.getActiveChar() != null || reserved != RESERVED_TOWER
                || token == null || token.length() != 32) return;
        CIOClient retire = null;
        synchronized (DominationHybrid.class) {
            Pending p = pending;
            if (p == null || isExpired(p) || p.newClient != null || p.finishing
                    || !p.token.equals(token) || !p.ip.equals(arriving.getIp())) return;
            p.newClient = arriving;
            traceClient = arriving;
            traceUntilNs = System.nanoTime() + 90_000_000_000L;
            traceReceived = 0;
            traceLastOpcode = -1;
            outboundSerial = 0;
            outboundLastDump = -1;
            for (int i = 0; i < OUTBOUND_HISTORY; i++) outbound[i] = null;
            LOG.info("[INTER-TEST] 115 verified; oldClosed=" + p.oldClosed);
            if (p.oldClosed) finishOffOwner(p);
            else retire = p.oldClient;
        }
        // The original client may leave its old TCP session open while
        // connecting to the destination. Retire it only after a valid 115.
        if (retire != null) retire.close();
    }

    /** Called only AFTER old logout + LoginController removal + socket cleanup. */
    public static void onClientClosed(CIOClient closed) {
        synchronized (DominationHybrid.class) {
            Pending p = pending;
            if (p == null) {
                if (traceClient == closed) {
                    traceTransport(closed, "new-client-cleanup-after-world-enter");
                    traceClient = null;
                }
                return;
            }
            if (p.newClient == closed) {
                traceTransport(closed, "new-client-cleanup");
                if (traceClient == closed) traceClient = null;
                pending = null;
                return;
            }
            if (p.oldClient != closed) return;
            p.oldClosed = true;
            if (p.newClient != null) finishOffOwner(p);
        }
    }

    private static void finishOffOwner(Pending p) {
        if (p.finishing || p.newClient == null || !p.oldClosed) return;
        p.finishing = true;
        // Persistence barriers must not run on CIO completion workers or CacheD workers.
        try {
            ThreadPool.getInstance().execute(() -> {
                try {
                    if (isExpired(p) || !p.newClient.isConnected()) { fail(p); return; }
                    final CacheD cache = CacheD.getInstance();
                    if (!cache.flushCharacter(p.character, 10_000L)
                            || !cache.flushItemsByCharacter(p.characterId, 10_000L)
                            || !cache.flushDbOwner(p.characterId, 10_000L)
                            || !cache.flushAccount(p.account.getName(), 10_000L)
                            || !cache.flushDbOwner(CacheD.accountOrderKey(p.account.getName()), 10_000L)) {
                        LOG.warning("[INTER-TEST] persistence barrier failed: " + p.character);
                        fail(p); return;
                    }
                    // Complete on the new socket's existing CIO session executor.
                    if (!l1j.server.server.model.network.thread.CIOThreadCallback.getInstance()
                            .completeSession(p.newClient, () -> attach(p))) {
                        fail(p);
                    }
                } catch (Throwable e) {
                    LOG.log(Level.WARNING, "[INTER-TEST] handoff barrier failed", e);
                    fail(p);
                }
            });
        } catch (RuntimeException ex) {
            LOG.log(Level.WARNING, "[INTER-TEST] existing thread pool rejected handoff", ex);
            fail(p);
        }
    }

    private static void attach(Pending p) {
        final CIOClient next = p.newClient;
        try {
            if (isExpired(p) || !next.isConnected() || next.getAccount() != null
                    || LoginController.getInstance().getClientByAccount(p.account.getName()) != null
                    || L1World.getInstance().getPlayer(p.character) != null) {
                fail(p); return;
            }
            LoginController.getInstance().login(next, p.account);
            next.setAccount(p.account);
            next.setConnectionState(ConnectionState.AUTHENTICATED);
            final ProtoWriter writer = Proto.begin(next,
                    ProtoMsg.SC_HIBREED_AUTH_ACK_PACKET, 32);
            if (writer == null) { fail(p); return; }
            boolean sent = false;
            try {
                writer.int32(1, 1); // Result_sucess in the source pack.
                sent = Proto.commit(writer);
            } finally {
                Proto.abort(writer);
            }
            if (!sent) { fail(p); return; }
            LOG.info("[INTER-TEST] 116 acknowledged; entering tower: " + p.character);
            CS_EnterWorld.doEnterWorld(p.character, next);
        } catch (Throwable e) {
            LOG.log(Level.WARNING, "[INTER-TEST] new session admission failed", e);
            fail(p);
        }
    }

    /** Override normal logout get-back only for this authenticated, one-shot arrival. */
    public static void applyLoginDestination(CIOClient client, L1PcInstance pc) {
        synchronized (DominationHybrid.class) {
            final Pending p = pending;
            if (p == null || !p.finishing || p.newClient != client || isExpired(p)
                    || pc.getId() != p.characterId || !pc.getName().equals(p.character)) return;
            pc.setX(p.x);
            pc.setY(p.y);
            pc.setMap((short) p.mapId);
            LOG.info("[INTER-TEST] tower destination applied map=" + p.mapId);
        }
    }

    public static void onEnterComplete(CIOClient client, L1PcInstance pc) {
        boolean resync = false;
        synchronized (DominationHybrid.class) {
            Pending p = pending;
            if (p != null && p.finishing && p.newClient == client
                    && pc != null && pc.getId() == p.characterId) {
                pending = null;
                resync = true;
                LOG.info("[INTER-TEST] entered same-server tower map=" + pc.getMapId());
                LOG.info("[INTER-DIAG] world entered, tracing inbound and close on GM socket only");
            }
        }
        // The source pack performs a same-position start_teleport after its hybrid
        // EnterWorld. This produces the existing portal/teleport synchronization
        // sequence, without another socket, player object or execution thread.
        // Do not change ordinary login or scroll/NPC teleport paths.
        if (resync && client.isConnected() && client.isGameSessionReady()
                && !pc.isLogoutStarted() && !pc.get_teleport()) {
            LOG.info("[INTER-TEST] begin same-position hybrid world resync map=" + pc.getMapId());
            pc.start_teleport(pc.getX(), pc.getY(), pc.getMapId(), pc.getHeading(),
                    18339, false, false);
        }
    }

    private static void fail(Pending p) {
        final CIOClient next;
        synchronized (DominationHybrid.class) {
            if (pending != p) return;
            pending = null;
            next = p.newClient;
        }
        if (next != null) next.close();
    }

    private static void clear(Pending p) {
        synchronized (DominationHybrid.class) {
            if (pending == p) pending = null;
        }
    }

    private static boolean isExpired(Pending p) {
        return System.nanoTime() - p.createdNs > TTL_NS;
    }

    private static int parseIpv4(String addr) {
        if (addr == null) return -1;
        String[] parts = addr.split("\\.", -1);
        if (parts.length != 4) return -1;
        int result = 0;
        for (String part : parts) {
            if (part.isEmpty() || part.length() > 3) return -1;
            int v = 0;
            for (int i = 0; i < part.length(); i++) {
                char c = part.charAt(i);
                if (c < '0' || c > '9') return -1;
                v = 10 * v + (c - '0');
            }
            if (v > 255) return -1;
            result = (result << 8) | v;
        }
        return result;
    }
}
