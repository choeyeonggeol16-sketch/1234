#!/usr/bin/env python3
"""Compile real slot manager, packet handler and inventory equipment methods.
Game item/stat/packet dependencies are doubles; no DB or game client is simulated.
Pass --baseline-dir DIRECTORY to run the same cases against the pre-fix files.
"""
from pathlib import Path
import argparse, re, shutil, subprocess, tempfile
root = Path(__file__).resolve().parents[2]
parser = argparse.ArgumentParser()
parser.add_argument('--baseline-dir', type=Path)
args = parser.parse_args()
def source(relative):
    p = args.baseline_dir / Path(relative).name if args.baseline_dir else root / 'src/l1j/server/server' / relative
    return p.read_text(encoding='utf-8')
def method(s, signature):
    start = s.index(signature)
    brace = s.index('{', start)
    depth = 1
    end = brace + 1
    while depth:
        if s[end] == '{': depth += 1
        elif s[end] == '}': depth -= 1
        end += 1
    return s[start:end]
inv = source('model/L1PcInventory.java')
base = source('model/L1Inventory.java')
slot = source('model/character/slot/SlotChangeManager.java')
packet = source('model/network/core/cs/packet/CS_Craft.java')
pc = (root/'src/l1j/server/server/model/Instance/L1PcInstance.java').read_text()
slot = re.sub(r'(?m)^(package|import) [^\n]+\n', '', slot).replace('public final class SlotChangeManager', 'static final class SlotChangeManager')
flags = inv[inv.index('public static final int COL_SAVE_ALL'):inv.index('\n\t@Override', inv.index('public static final int COL_SAVE_ALL'))]
masks = inv[inv.index('private static final int MASK_STATUS'):inv.index('\n\t@Override', inv.index('private static final int MASK_STATUS'))]
helpers = ''
if 'public final boolean tryBeginEquipmentChange()' in inv:
    helpers = 'private volatile Thread equipmentChangeOwner; private int equipmentChangeDepth;\n' + '\n'.join(method(inv, sig) for sig in [
        'public final boolean tryBeginEquipmentChange()', 'public final void endEquipmentChange()', 'final boolean isEquipmentChangeOwner()'])
java = r'''
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.*;
public class EquipmentContract {
 static int passed, failed;
 static void check(boolean ok,String message){if(!ok)throw new AssertionError(message);}
 static void run(String name,Runnable action){try{action.run();passed++;System.out.println("PASS "+name);}catch(Throwable e){failed++;System.out.println("FAIL "+name+": "+e);}}
 static class CacheD {static final ThreadLocal<Boolean> replay=ThreadLocal.withInitial(()->false);static boolean isItemTransferReplaying(){return replay.get();}}
 static class L1Item {int type2=2,type=0,type1=0; int getItemId(){return 200;}int getType(){return type;}int getType2(){return type2;}int getType1(){return type1;}boolean isTwohandedWeapon(){return false;}int getWeight(){return 0;}}
 static class L1ItemInstance {
  final int id;final L1Item definition=new L1Item();boolean equipped;int lastWeight;L1PcInstance _cha;
  L1ItemInstance(int id,boolean e){this.id=id;equipped=e;}int getId(){return id;}int getItemId(){return definition.getItemId();}L1Item getItem(){return definition;}
  boolean isEquipped(){return equipped;}void setEquipped(boolean e){equipped=e;}int getWeight(){return 0;}int getLastWeight(){return lastWeight;}void setLastWeight(int n){lastWeight=n;}
 }
 static class EquipmentSlot {
  final L1PcInstance pc;int stats=1;Runnable hook;
  EquipmentSlot(L1PcInstance pc){this.pc=pc;}void set(L1ItemInstance i){stats++;if(hook!=null)hook.run();}void remove(L1ItemInstance i){stats--;if(hook!=null)hook.run();}int getWeaponCount(){return 1;}
 }
 static class L1PcInstance {
  private volatile int itemTransferBusy;
  private static final AtomicIntegerFieldUpdater<L1PcInstance> ITEM_TRANSFER_BUSY=AtomicIntegerFieldUpdater.newUpdater(L1PcInstance.class,"itemTransferBusy");
  final L1PcInventory inventory=new L1PcInventory(this);
  final SlotChangeManager _slotChange=new SlotChangeManager(this);
  final EquipmentSlot equipment=new EquipmentSlot(this);
  int packets,messages,notifications,tradeID;boolean tradeResolving;boolean ackAfterState=true;
  L1PcInventory getInventory(){return inventory;}EquipmentSlot getEquipSlot(){return equipment;}
  int getCurrentSpriteId(){return 0;}int getId(){return 1;}int getTradeID(){return tradeID;}boolean isTradeResolving(){return tradeResolving;}
  int getCurrentHp(){return 100;}int getCurrentMp(){return 100;}void setCurrentHp(int n){}void setCurrentMp(int n){}
  boolean isInvisble(){return false;}
  void delInvis(){}void beginInvisTimer(){}boolean hasSkillEffect(int n){return false;}void removeSkillEffect(int n){}void remove_elf_second_brave(){}
  void sendPackets(Object packet){packets++;ackAfterState &= !inventory.items.get(0).equipped&&inventory.items.get(1).equipped;}
''' + '\n'.join(method(pc, signature) for signature in [
 'public boolean tryBeginItemTransfer()', 'public void endItemTransfer()', 'public boolean isItemTransferBusy()',
 'public int getSlotNumber()', 'public void setSlotNumber(int i)', 'public void addSlotItem(int slotNum, int itemobjid, boolean flag)',
 'public List<Integer> getSlotItems(int slotNum)', 'public void getChangeSlot(int slotNum)']) + r'''
 }
 static class L1Inventory {
  final List<L1ItemInstance> items=new ArrayList<>();
  List<L1ItemInstance> getItems(){return items;}
''' + method(base, 'protected final boolean rejectPendingItemTransfer()') + r'''
 }
 static class L1PcInventory extends L1Inventory {
  final L1PcInstance _owner;final Map<Integer,Integer> _equippedCountMap=new HashMap<>();long timeVisible,timeVisibleDelay=3000;
  L1PcInventory(L1PcInstance pc){_owner=pc;_equippedCountMap.put(200,1);}L1PcInstance getOwner(){return _owner;}
  int getArrowItemId(){return 0;}void setArrow(int n){}L1ItemInstance findItemId(int id){return null;}
  void toSlotPacket(L1PcInstance pc,L1ItemInstance item,boolean flag){pc.notifications++;}
''' + helpers + flags + masks + '\n'.join(method(inv,sig) for sig in [
 'public void setEquipped(L1ItemInstance item, boolean equipped)',
 'public void setEquipped(L1ItemInstance item, boolean equipped, boolean loaded, boolean changeWeapon, boolean shieldWeapon)',
 'public void updateItem(L1ItemInstance item, int column)']) + r'''
 }
 static class L1PolyMorph {static boolean isEquipableWeapon(int s,int t){return true;}static boolean isEquipableArmor(int s,int t){return true;}}
 static class L1SkillId {static final int INFERNO=1,COUNTER_BARRIER=2;}
 static class SC_SlotChange {static final int SLOT_CHANGE=1;static Object create(int t,int s){return s;}static void sendCreate(L1PcInstance pc,int t,int s){pc.sendPackets(s);}}
 static class SC_SystemMessage {static void send(L1PcInstance pc,String text){pc.messages++;}}
 static class SC_ItemStatus {static void send(L1PcInstance pc,L1ItemInstance i){pc.notifications++;}}
 static class SC_ItemName extends SC_ItemStatus {}
 static class SC_ItemColor extends SC_ItemStatus {}
 static class SC_Weight {static void send(L1PcInstance pc){pc.notifications++;}}
 static class SC_SkillSound {static void send(Object... args){}}
 static class SC_PacketBox {static final int UNLIMITED_ICON1=1,공격가능거리=2,ITEM_ENCHANT_UPDATE=3;static void send(Object... args){}}
 static class SC_CharVisualUpdate {static long pack(L1PcInstance pc){return 0;}static void sendPacked(L1PcInstance pc,long n){}static void broadcastFastPacked(L1PcInstance pc,long n){}}
''' + slot + method(packet,'private static void handleEquipSwap(L1PcInstance pc, int equipType, int slot)') + r'''
 static L1PcInstance player(){L1PcInstance pc=new L1PcInstance();pc.inventory.items.add(new L1ItemInstance(1,true));pc.inventory.items.add(new L1ItemInstance(2,false));pc.addSlotItem(0,1,false);pc.addSlotItem(1,2,false);return pc;}
 static void unchanged(L1PcInstance pc){check(pc.inventory.items.get(0).equipped&&!pc.inventory.items.get(1).equipped,"equipment partially changed");check(pc.equipment.stats==1&&pc.inventory._equippedCountMap.get(200)==1,"equipment stats/cache changed");check(pc.getSlotNumber()==0&&pc.packets==0&&pc.notifications==0,"slot or notifications changed");check(pc.isItemTransferBusy(),"pending transfer gate was released");}
 static void join(Thread t){try{t.join(3000);}catch(InterruptedException e){throw new RuntimeException(e);}check(!t.isAlive(),"thread hung");}
 public static void main(String[] args){
  run("pending packet refuses before equipment/slot/ack mutation",()->{L1PcInstance p=player();p.tryBeginItemTransfer();handleEquipSwap(p,16,1);unchanged(p);check(p.messages==1,"busy feedback missing");});
  run("pending direct slot call preserves whole preset",()->{L1PcInstance p=player();p.tryBeginItemTransfer();p.getChangeSlot(1);unchanged(p);});
  run("pending direct equip/unequip refuses before stats",()->{L1PcInstance p=player();p.tryBeginItemTransfer();p.inventory.setEquipped(p.inventory.items.get(0),false);p.inventory.setEquipped(p.inventory.items.get(1),true);unchanged(p);});
  run("pending snapshot preserves saved preset",()->{L1PcInstance p=player();p.tryBeginItemTransfer();handleEquipSwap(p,8,1);unchanged(p);check(p.getSlotItems(1).equals(List.of(2)),"preset overwritten while busy");});
  run("retry after transfer completion swaps and acknowledges final state",()->{L1PcInstance p=player();p.tryBeginItemTransfer();handleEquipSwap(p,16,1);p.endItemTransfer();handleEquipSwap(p,16,1);check(!p.inventory.items.get(0).equipped&&p.inventory.items.get(1).equipped,"retry did not swap");check(p.equipment.stats==1&&p.inventory._equippedCountMap.get(200)==1,"stat/cache mismatch");check(p.getSlotNumber()==1&&p.packets==1&&p.ackAfterState&&!p.isItemTransferBusy(),"ack/state/gate mismatch");});
  run("no-op preset and invalid requests release/avoid reservation",()->{L1PcInstance p=player();handleEquipSwap(p,0,1);handleEquipSwap(p,16,3);check(p.packets==0&&!p.isItemTransferBusy(),"invalid request touched gate");p.addSlotItem(1,0,true);handleEquipSwap(p,16,1);check(p.getSlotNumber()==1&&p.packets==1&&!p.isItemTransferBusy(),"no-op selection not recorded");check(p.inventory.items.get(0).equipped&&!p.inventory.items.get(1).equipped,"no-op changed equipment");});
  run("snapshot after completion works",()->{L1PcInstance p=player();handleEquipSwap(p,8,1);check(p.getSlotItems(1).equals(List.of(1))&&!p.isItemTransferBusy(),"snapshot failed");});
  run("trade state blocks slot changes",()->{L1PcInstance p=player();p.tradeID=2;handleEquipSwap(p,16,1);check(p.packets==0&&p.inventory.items.get(0).equipped,"trade slot changed");p.tradeID=0;p.tradeResolving=true;handleEquipSwap(p,16,1);check(p.packets==0&&!p.isItemTransferBusy(),"resolving slot changed");});
  run("1000 repeated pending requests leave inventory and IO handler intact",()->{L1PcInstance p=player();p.tryBeginItemTransfer();for(int i=0;i<1000;i++)handleEquipSwap(p,16,1);unchanged(p);});
  run("committed replay retains its transfer reservation",()->{L1PcInstance p=player();p.tryBeginItemTransfer();CacheD.replay.set(true);try{p.inventory.setEquipped(p.inventory.items.get(0),false);check(!p.inventory.items.get(0).equipped&&p.isItemTransferBusy(),"replay blocked or gate released");}finally{CacheD.replay.remove();}boolean refused=false;try{p.inventory.updateItem(p.inventory.items.get(0),8);}catch(IllegalStateException e){refused=true;}check(refused,"ordinary mutation bypassed transfer guard");});
  run("loaded equipment supported, pending load refused",()->{L1PcInstance p=player();p.inventory.setEquipped(p.inventory.items.get(1),true,true,false,false);check(p.equipment.stats==2&&!p.isItemTransferBusy(),"load failed");p=player();p.tryBeginItemTransfer();p.inventory.setEquipped(p.inventory.items.get(1),true,true,false,false);unchanged(p);});
  run("exception releases nested reservations and sends no success ack",()->{L1PcInstance p=player();p.equipment.hook=()->{throw new IllegalArgumentException("injected equipment effect failure");};boolean thrown=false;try{handleEquipSwap(p,16,1);}catch(IllegalArgumentException e){thrown=true;}check(thrown&&!p.isItemTransferBusy()&&p.packets==0,"exception swallowed, gate leaked or false ack");p.equipment.hook=null;handleEquipSwap(p,16,1);check(p.inventory.items.get(1).equipped&&!p.isItemTransferBusy(),"subsequent request blocked");});
''' + (r'''
  run("nested reservation excludes concurrent transfer and mutation",()->{L1PcInstance p=player();check(p.inventory.tryBeginEquipmentChange(),"reserve");try{check(p.inventory.tryBeginEquipmentChange(),"nest");try{AtomicReference<Throwable> failure=new AtomicReference<>();Thread t=new Thread(()->{try{check(!p.tryBeginItemTransfer(),"concurrent transfer admitted");check(!p.inventory.tryBeginEquipmentChange(),"concurrent equipment admitted");boolean refused=false;try{p.inventory.updateItem(p.inventory.items.get(0),8);}catch(IllegalStateException e){refused=true;}check(refused,"other thread used owner's permit");p.inventory.setEquipped(p.inventory.items.get(0),false);check(p.inventory.items.get(0).equipped,"other thread unequipped");}catch(Throwable e){failure.set(e);}});t.start();join(t);if(failure.get()!=null)throw new AssertionError(failure.get());}finally{p.inventory.endEquipmentChange();}check(p.isItemTransferBusy(),"inner release opened gate");p.inventory.setEquipped(p.inventory.items.get(0),false);check(!p.inventory.items.get(0).equipped,"owner cannot change equipment");}finally{p.inventory.endEquipmentChange();}check(p.tryBeginItemTransfer(),"gate not reusable");});
  run("transfer cannot begin between first unequip and last equip",()->{L1PcInstance p=player();AtomicInteger attempts=new AtomicInteger();p.equipment.hook=()->{AtomicReference<Throwable> failure=new AtomicReference<>();Thread t=new Thread(()->{try{check(!p.tryBeginItemTransfer(),"mid-swap transfer admitted");attempts.incrementAndGet();}catch(Throwable e){failure.set(e);}});t.start();join(t);if(failure.get()!=null)throw new AssertionError(failure.get());};handleEquipSwap(p,16,1);check(attempts.get()==2&&p.packets==1&&!p.isItemTransferBusy(),"swap not fully protected");});
''' if helpers else '') + r'''
  System.out.println("RESULT passed="+passed+" failed="+failed);
  if(failed!=0)throw new AssertionError("Equipment regressions failed: "+failed);
 }
}
'''
# Keep production CacheD calls and Korean method/constant identifiers intact.
java = java.replace('l1j.server.server.storage.CacheD', 'CacheD')
compiler = shutil.which('javac') or '/workspace/java-toolchain/bin/javac'
with tempfile.TemporaryDirectory() as td:
    p = Path(td)/'EquipmentContract.java'
    p.write_text(java,encoding='utf-8')
    subprocess.run([compiler,'--release','21','-encoding','UTF-8','-d',td,str(p)],check=True)
    subprocess.run(['java','-ea','-cp',td,'EquipmentContract'],check=True,timeout=30)
