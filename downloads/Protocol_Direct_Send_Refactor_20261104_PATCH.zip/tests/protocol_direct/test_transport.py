#!/usr/bin/env python3
"""Actual Proto/ProtoWriter/WriteBuffer, deterministic test-only lease contract."""
from pathlib import Path
import argparse, json, os, subprocess, tempfile
root = Path(__file__).resolve().parents[2]
here = Path(__file__).resolve().parent
p = argparse.ArgumentParser()
p.add_argument('--classes', type=Path, default=Path('/workspace/builds/protocol-direct/classes'))
a = p.parse_args()
deps = Path(os.environ.get('ITEM_DEPS_DIR', '/workspace/dependencies/item-processing'))
cp = os.pathsep.join([str(a.classes), *map(str, deps.glob('*.jar'))])
production = ['packets/Protocol/Proto.java', 'packets/Protocol/ProtoWriter.java',
              'packets/Protocol/ProtoPacket.java', 'packets/Protocol/ProtoPacketWriter.java',
              'model/network/buffer/WriteBuffer.java']
with tempfile.TemporaryDirectory() as td:
    manifest = Path(td) / 'schemas.txt'
    manifest.write_text('\n'.join(json.loads((here/'packet_fields.json').read_text()))+'\n')
    sources = [*map(str, (here/'transport').rglob('*.java')),
               *[str(root/'src/l1j/server/server'/s) for s in production],
               str(here/'ProtocolTransportAudit.java')]
    subprocess.run(['java', '-m', 'jdk.compiler/com.sun.tools.javac.Main', '--enable-preview',
                    '-source', '21', '-target', '21', '-encoding', 'UTF-8', '-cp', cp,
                    '-d', td, *sources], check=True, timeout=60)
    subprocess.run(['java', '--enable-preview', '-ea', '-cp', td+os.pathsep+cp,
                    'l1j.server.server.packets.Protocol.ProtocolTransportAudit', str(manifest)],
                   check=True, timeout=90, cwd=td)
