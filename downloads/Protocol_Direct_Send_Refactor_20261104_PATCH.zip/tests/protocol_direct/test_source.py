#!/usr/bin/env python3
"""Keep independent baseline fingerprints for the original serialization oracles."""
from pathlib import Path
import hashlib, json, subprocess
here = Path(__file__).resolve().parent
root = here.parents[1]
expected = json.loads((here/'original_schema_sha256.json').read_text())
result = subprocess.run(['java', str(here/'ProtocolSourceCatalog.java'), str(root)],
                        check=True, capture_output=True, text=True, timeout=60)
seen = {}
for schema in json.loads(result.stdout):
    for method in schema['methods']:
        key = schema['name']+'.'+method['name']
        if key in expected:
            seen[key] = hashlib.sha256(method['body'].encode()).hexdigest()
if seen != expected:
    raise SystemExit('Original schema oracle changed: '+str([k for k,v in expected.items() if seen.get(k) != v]))
print(f'PASS preserved original AST bodies: {len(seen)} serializers/message IDs (63 schemas)')
