import java.util.*;
import l1j.server.server.model.Instance.L1ItemInstance;
import l1j.server.server.model.network.core.CIOClient;
import l1j.server.server.packets.Protocol.*;
import l1j.server.server.packets.Protocol.Packet.*;
import l1j.server.server.packets.Protocol.Packet.Inventory.ItemInfo;
import l1j.server.MJCompanion.Basic.ClassInfo.MJCompanionClassInfo;
import l1j.server.MJCompanion.Instance.MJCompanionInstanceCache;

/** Actual old/new item projection and protobuf bodies, deterministic game inputs. */
public final class ProtocolInventoryAudit {
    static int checks;
    static void same(byte[] a, byte[] b, String label) {
        if (!Arrays.equals(a, b)) throw new AssertionError(label + " expected=" + a.length + " actual=" + b.length);
        checks++;
    }
    public static void main(String[] args) {
        CIOClient client = new CIOClient();
        int[] ids = {40001, 41297, 41296, 41301, 41304, 41303, 600230, 820018,
            49092, 49093, 49094, 49095, 875640331, 875640341, 875640446, 875640448,
            875640330, 875640342, 875640445, 875640449};
        for (int n = 0; n < 640; n++) {
            L1ItemInstance item = new L1ItemInstance();
            item.template.id = ids[n % ids.length];
            item.template.type = n % 4;
            item.template.use = n % 2 == 0 ? -1 : 128;
            item.template.name = n % 2 == 0 ? Integer.MIN_VALUE : Integer.MAX_VALUE;
            item.template.safe = n % 3 - 1;
            item.template.tradable = n % 2 == 0;
            item.template.cantDelete = n % 3 == 0;
            item.template.timed = n % 4 == 0;
            item.id = n % 3 == 0 ? -1 : n;
            item.icon = 1234;
            item.bless = n % 3 == 0 ? 129 : n % 3;
            item.attr = n;
            item.enchant = n % 2 == 0 ? -1 : 10;
            item.count = n % 3 == 0 ? Integer.MAX_VALUE : n;
            item.weight = n;
            item.identified = n % 3 != 0;
            item.name = new String[] {"한글 물약", "", "\uD83D\uDE00", "\uD800"}[n % 4];
            item.status = n % 5 == 0 ? null : new byte[n % 2 == 0 ? 127 : 128];
            item.status2 = n % 5 == 0 ? null : new byte[n % 2 == 0 ? 16383 : 16384];
            MJCompanionClassInfo.fixture = null;
            MJCompanionInstanceCache.fixture = null;
            if (n % 3 != 0) {
                MJCompanionClassInfo info = new MJCompanionClassInfo();
                info.type = n;
                info.name = "$펫";
                MJCompanionClassInfo.fixture = info;
                if (n % 3 == 2) {
                    MJCompanionInstanceCache cache = new MJCompanionInstanceCache();
                    cache.dead = n % 2 == 0;
                    cache.oblivion = n % 4 == 0;
                    cache.summoned = n % 8 == 0;
                    cache.level = n;
                    cache.name = n % 4 == 0 ? null : "펫 이름";
                    cache.elixirs = n;
                    MJCompanionInstanceCache.fixture = cache;
                }
            }
            byte[] warehouse = SC_WarehouseItemListNoti.WarehouseItemInfo.newInstance()
                .set_index(item.id).set_item_info(ItemInfo.newInstance(item).set_extra_description(null)).encodeBody();
            same(warehouse, ItemInfo.encodeWarehouseBody(item), "warehouse item " + n);
            SC_WarehouseItemListNoti warehousePacket = SC_WarehouseItemListNoti.newInstance()
                .set_checker(-1).set_count(1).set_warehouse_type(SC_WarehouseItemListNoti.eWarehouseType.TRADE_RETRIEVE)
                .set_price(128).set_warehouse_size(640).add_encoded_item(warehouse).set_serial_last(n % 2 == 0);
            SC_WarehouseItemListNoti.sendEncodedChunk(client, -1, 128, 640,
                SC_WarehouseItemListNoti.eWarehouseType.TRADE_RETRIEVE, new byte[][] {warehouse}, 1, n % 2 == 0);
            same(warehousePacket.encode(), client.socket.lastBytes, "warehouse chunk " + n);
            byte[] body = ItemInfo.newInstance(item).encodeBody();
            same(body, ItemInfo.encodeItemBody(item), "item body " + n);
            SC_AddInventoryNoti old = new SC_AddInventoryNoti().set_on_start(false)
                .set_owner_oid(-1).add_item_info(ItemInfo.newInstance(item));
            if (!ItemInfo.sendAddedItem(client, item, false, -1)) throw new AssertionError("item send refused");
            same(old.encode(), client.socket.lastBytes, "live item " + n);
            SC_AddInventoryNoti.sendEncodedItem(client, body, false, -1);
            same(old.encode(), client.socket.lastBytes, "encoded item " + n);
            MJCompanionInstanceCache cache = MJCompanionInstanceCache.fixture;
            if (cache != null) {
                SC_UpdateInventoryNoti update = new SC_UpdateInventoryNoti().add_item_info(ItemInfo.newInstance(item.id, cache));
                SC_UpdateInventoryNoti.sendCompanion(client, item.id, cache);
                same(update.encode(), client.socket.lastBytes, "companion update " + n);
            }
        }
        byte[][] bodies = {new byte[0], null, new byte[127], new byte[128], null, new byte[16384]};
        for (int from = 0; from <= bodies.length; from++) for (int to = from; to <= bodies.length; to++) {
            SC_AddInventoryNoti old = new SC_AddInventoryNoti().set_on_start(true).set_owner_oid(128);
            for (int i = from; i < to; i++) if (bodies[i] != null) old.add_encoded_item(bodies[i]);
            SC_AddInventoryNoti.sendEncoded(client, bodies, from, to, true, 128);
            same(old.encode(), client.socket.lastBytes, "login range " + from + ":" + to);
        }
        if (client.socket.active != 0) throw new AssertionError("inventory lease leak");
        System.out.println("PASS inventory projection / live sends / companion / login / warehouse: " + checks + " byte comparisons");
    }
}
