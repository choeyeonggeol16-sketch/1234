package l1j.server.server.model.Instance;
import l1j.server.server.templates.L1Item;
public final class L1ItemInstance {
    public final L1Item template = new L1Item();
    public int id, icon, bless, attr, enchant, count, weight;
    public boolean identified;
    public String name;
    public byte[] status, status2;
    public L1Item getItem() { return template; }
    public int getId() { return id; }
    public int getItemId() { return template.id; }
    public int get_gfxid() { return icon; }
    public int getBless() { return bless; }
    public int getAttrEnchantLevel() { return attr; }
    public int getEnchantLevel() { return enchant; }
    public int getCount() { return count; }
    public int getWeight() { return weight; }
    public boolean isIdentified() { return identified; }
    public String getViewName() { return name; }
    public byte[] getStatusBytes() { return status; }
    public byte[] getStatusBytes2() { return status2; }
    public static int attrEnchantToElementalType(int v) { return v / 10; }
    public static int pureAttrEnchantLevel(int v) { return v % 10; }
}
