package l1j.server.server.templates;
public final class L1Item {
    public int type, id, use, name, safe;
    public boolean tradable, cantDelete, timed;
    public int getType2() { return type; }
    public int getItemId() { return id; }
    public int getUseType() { return use; }
    public int getItemDescId() { return name; }
    public int get_safeenchant() { return safe; }
    public boolean isTradable() { return tradable; }
    public boolean isCantDelete() { return cantDelete; }
    public boolean isEndedTimeMessage() { return timed; }
}
