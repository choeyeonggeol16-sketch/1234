package l1j.server.MJCompanion.Basic.ClassInfo;
public final class MJCompanionClassInfo {
    public static MJCompanionClassInfo fixture;
    public int type;
    public String name;
    public static MJCompanionClassInfo from_item_id(int item) { return fixture; }
    public int get_class_id() { return type; }
    public String get_class_npc_name_id() { return name; }
}
