package l1j.server.MJCompanion.Instance;
public final class MJCompanionInstanceCache {
    public static MJCompanionInstanceCache fixture;
    public boolean dead, oblivion, summoned;
    public int level, elixirs;
    public String name;
    public static MJCompanionInstanceCache get(int object) { return fixture; }
    public boolean get_is_dead() { return dead; }
    public boolean get_is_oblivion() { return oblivion; }
    public boolean get_is_summoned() { return summoned; }
    public int get_level() { return level; }
    public int get_elixir_use_count() { return elixirs; }
    public String get_name() { return name; }
}
