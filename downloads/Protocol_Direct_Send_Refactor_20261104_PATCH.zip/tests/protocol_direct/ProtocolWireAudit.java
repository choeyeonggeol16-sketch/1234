import java.lang.reflect.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;
import sun.misc.Unsafe;

/** Actual original packet encode() versus primitive-field encodeFields(). */
public class ProtocolWireAudit {
    static Unsafe unsafe;
    static int round;
    static final Random random=new Random(0x70726f746fL);
    static Object value(Type generic,int depth)throws Exception {
        Class<?> t=generic instanceof Class<?> c?c:(Class<?>)((ParameterizedType)generic).getRawType();
        if(t==boolean.class||t==Boolean.class)return round%3==0?false:random.nextBoolean();
        if(t==byte.class||t==Byte.class)return (byte)random.nextInt();
        if(t==short.class||t==Short.class)return (short)random.nextInt();
        if(t==char.class||t==Character.class)return (char)(32+random.nextInt(90));
        if(t==int.class||t==Integer.class)return switch(round%8){case 0->0;case 1->-1;case 2->Integer.MIN_VALUE;case 3->Integer.MAX_VALUE;case 4->127;case 5->128;default->random.nextInt();};
        if(t==long.class||t==Long.class)return switch(round%6){case 0->0L;case 1->-1L;case 2->Long.MIN_VALUE;case 3->Long.MAX_VALUE;default->random.nextLong();};
        if(t==float.class||t==Float.class)return Float.intBitsToFloat(random.nextInt());
        if(t==double.class||t==Double.class)return Double.longBitsToDouble(random.nextLong());
        if(t==String.class)return new String[]{"","ASCII","한글 물약","\uD83D\uDE00","\uD800","a\u0000b"}[round%6];
        if(t.isEnum()){Object[] constants=t.getEnumConstants();return constants[round%constants.length];}
        if(t.isArray()){
            int n=round%4; if(t.getComponentType()==byte.class)n=new int[]{0,1,127,128}[round%4];
            Object a=Array.newInstance(t.getComponentType(),n);
            for(int i=0;i<n;i++)Array.set(a,i,value(t.getComponentType(),depth+1));return a;
        }
        if(Collection.class.isAssignableFrom(t)) {
            Collection<Object> out=LinkedList.class.isAssignableFrom(t)?new LinkedList<>():new ArrayList<>();
            if(depth<3&&generic instanceof ParameterizedType p)for(int i=0;i<round%3;i++)out.add(value(p.getActualTypeArguments()[0],depth+1));
            return out;
        }
        if(t.getName().equals("l1j.server.server.model.Instance.L1PcInstance")) {
            Object pc=unsafe.allocateInstance(t);
            Class<?> parent=Class.forName("l1j.server.server.model.L1Character");
            Field resistance=parent.getDeclaredField("resistance");resistance.setAccessible(true);
            Object stats=Class.forName("l1j.server.server.model.Resistance").getConstructor().newInstance();
            for(String arrayName:List.of("_specialResist","_specialPierce")) {
                Field array=stats.getClass().getDeclaredField(arrayName);array.setAccessible(true);
                int[] values=(int[])array.get(stats);
                for(int i=1;i<values.length;i++)values[i]=new int[]{-128,-1,0,127}[Math.floorMod(round+i,4)];
            }
            resistance.set(pc,stats);return pc;
        }
        if(!t.getName().startsWith("l1j.server.server.packets.Protocol.Packet.")||depth>4)return null;
        Object out=unsafe.allocateInstance(t);fill(out,depth+1);return out;
    }
    static void fill(Object out,int depth)throws Exception {
        for(Field f:out.getClass().getDeclaredFields()) {
            if(Modifier.isStatic(f.getModifiers()))continue;f.setAccessible(true);
            Object v=value(f.getGenericType(),depth);
            if(!f.getType().isPrimitive()&&Number.class.isAssignableFrom(f.getType())&&round%4==0)v=null;
            if(f.getName().equals("_mode"))v=round%4+1;
            f.set(out,v);
        }
    }
    static Object zero(Class<?> t) {
        if(t==boolean.class)return false;if(t==long.class)return 0L;if(t==double.class)return 0d;
        if(t==float.class)return 0f;if(t==short.class)return (short)0;if(t==byte.class)return (byte)0;
        if(t==char.class)return (char)0;return 0;
    }
    public static void main(String[] args)throws Exception {
        Field u=Unsafe.class.getDeclaredField("theUnsafe");u.setAccessible(true);unsafe=(Unsafe)u.get(null);
        int passed=0,covered=0;List<String> skipped=new ArrayList<>();
        for(String line:Files.readAllLines(Path.of(args[0]),StandardCharsets.UTF_8)) {
            String[] row=line.split("\\|");String name=row[0];String[] names=row.length>1&&!row[1].isEmpty()?row[1].split(","):new String[0];
            Set<String> nullable=row.length>2&&!row[2].isEmpty()?new LinkedHashSet<>(List.of(row[2].split(","))):Set.of();
            Class<?> type=Class.forName("l1j.server.server.packets.Protocol.Packet."+name);
            Method direct=Arrays.stream(type.getDeclaredMethods()).filter(m->m.getName().equals("encodeFields")).findFirst().orElseThrow();
            int valid=0;String invalid="";
            for(round=0;round<32;round++) {
                Object packet=unsafe.allocateInstance(type);fill(packet,0);
                Object[] params=new Object[direct.getParameterCount()];int at=nullable.isEmpty()?0:1;long mask=0;int bit=0;
                for(String fieldName:names) {
                    Field f=type.getDeclaredField(fieldName);f.setAccessible(true);Object v=f.get(packet);
                    if(nullable.contains(fieldName)){if(v!=null)mask|=1L<<bit;bit++;}
                    if(v==null&&direct.getParameterTypes()[at].isPrimitive())v=zero(direct.getParameterTypes()[at]);
                    params[at++]=v;
                }
                if(!nullable.isEmpty())params[0]=mask;
                byte[] expected;
                try {expected=(byte[])type.getMethod("encode").invoke(packet);}
                catch(InvocationTargetException oldFailure){invalid=oldFailure.getCause().getClass().getSimpleName();continue;}
                byte[] actual=(byte[])direct.invoke(null,params);
                if(!Arrays.equals(expected,actual))throw new AssertionError(name+" round="+round+" mismatch bytes old="+expected.length+" new="+actual.length);
                valid++;passed++;
            }
            if(valid>0)covered++;else skipped.add(name+":"+invalid);
        }
        System.out.println("PASS actual packet bytes: "+passed+" fixtures across "+covered+" packet types");
        System.out.println("Game-state-dependent types without a valid fixture: "+skipped);
        if(covered<50)throw new AssertionError("insufficient actual wire coverage");
    }
}
