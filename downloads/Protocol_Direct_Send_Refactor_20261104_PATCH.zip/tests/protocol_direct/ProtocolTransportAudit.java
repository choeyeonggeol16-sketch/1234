package l1j.server.server.packets.Protocol;

import java.lang.management.ManagementFactory;
import java.lang.reflect.*;
import java.nio.file.*;
import java.util.*;
import java.util.concurrent.*;
import com.sun.management.ThreadMXBean;
import l1j.server.server.model.network.core.*;
import l1j.server.server.packets.Protocol.Packet.SC_SpellBuffNoti;

/** Real transport adapter and serializers, fake FIFO admission/lease ownership. */
public final class ProtocolTransportAudit {
    private static int checks;
    private static volatile Object escaped;
    static void check(boolean condition, String message) {
        if (!condition) throw new AssertionError(message);
        checks++;
    }
    static void fail(Runnable action, String message) {
        try { action.run(); } catch (RuntimeException expected) { checks++; return; }
        throw new AssertionError("expected failure: " + message);
    }
    static void payload(ProtoWriter w, int n) {
        w.int32(1, -1).uint32(2, -1).sint32(3, Integer.MIN_VALUE)
            .uint64(4, Long.MIN_VALUE).fixed64(5, -1).string(6, "한글\uD83D\uDE00\uD800")
            .msg(7).bytes(1, new byte[n]).msg(2).bool(1, false).end().end();
    }
    static void lifecycle() throws Exception {
        CIOClient client = new CIOClient();
        check(Proto.begin((CIOClient) null, 1, 1024) == null, "null connection");
        client.connected = false;
        check(Proto.begin(client, 1, 1024) == null, "disconnected client");
        client.connected = true;
        client.socket.refuse = true;
        check(Proto.begin(client, 1, 1024) == null, "admission refused");
        check(client.socket.active == 0, "refusal owns no lease");
        client.socket.refuse = false;
        for (int n : new int[] {0, 1, 127, 128, 16383, 16384}) {
            ProtoWriter array = new ProtoWriter();
            payload(array, n);
            byte[] expected = array.finishWithTrailer(0x1234);
            ProtoWriter direct = Proto.begin(client, 0x1234, 65535);
            try { payload(direct, n); check(Proto.commit(direct), "commit"); }
            finally { Proto.abort(direct); }
            check(Arrays.equals(expected, client.socket.lastBytes), "wire at length boundary " + n);
            check(direct.directFrame == null && direct.directConnection == null, "TL transport refs cleared");
        }
        byte[] cached = client.socket.lastBytes.clone();
        check(Proto.sendRaw(client, cached), "cached direct");
        check(Arrays.equals(cached, client.socket.lastBytes), "cached unchanged");
        check(!Proto.sendRaw(client, new byte[65534]), "oversize cache refused before lease");
        check(!Proto.sendRaw(client, null), "null cache refused");
        int aborts = client.socket.aborts;
        client.socket.forcedCapacity = 3;
        fail(() -> Proto.begin(client, 1, 1024), "header overflow");
        check(client.socket.active == 0 && client.socket.aborts == ++aborts, "failed begin released once");
        client.socket.forcedCapacity = 0;
        ProtoWriter owned = Proto.begin(client, 1, 1024);
        fail(() -> owned.reset(), "reset while owning lease");
        Proto.abort(owned);
        check(client.socket.active == 0 && client.socket.aborts == ++aborts, "reset guard retains ownership for abort");
        ProtoWriter unclosed = Proto.begin(client, 1, 1024);
        unclosed.msg(1);
        fail(() -> Proto.commit(unclosed), "unclosed nested message");
        Proto.abort(unclosed);
        check(client.socket.active == 0 && client.socket.aborts == ++aborts, "finish failure released once");
        client.socket.rejectCommit = true;
        ProtoWriter refused = Proto.begin(client, 1, 1024);
        check(!Proto.commit(refused), "commit refused");
        Proto.abort(refused);
        check(client.socket.active == 0 && client.socket.aborts == ++aborts, "rejected commit released once");
        client.socket.rejectCommit = false;
        client.socket.throwCommit = true;
        ProtoWriter failed = Proto.begin(client, 1, 1024);
        fail(() -> Proto.commit(failed), "commit exception");
        Proto.abort(failed);
        check(client.socket.active == 0 && client.socket.aborts == ++aborts, "throwing commit released once");
        fail(() -> Proto.sendRaw(client, cached), "cached commit exception");
        check(client.socket.active == 0 && client.socket.aborts == ++aborts, "cached exception released once");
        client.socket.throwCommit = false;
        ProtoWriter outer = Proto.begin(client, 1, 1024);
        outer.int32(1, 73);
        ProtoWriter inner = Proto.begin(client, 2, 1024);
        check(inner != outer, "reentrant writers distinct");
        check(outer.directFrame.ticket < inner.directFrame.ticket, "FIFO tickets reserved before reentrant encoding");
        inner.int32(1, 96);
        Proto.commit(inner);
        outer.int32(2, 74);
        Proto.commit(outer);
        ProtoWriter expectedOuter = new ProtoWriter();
        expectedOuter.int32(1, 73).int32(2, 74);
        check(Arrays.equals(expectedOuter.finishWithTrailer(1), client.socket.lastBytes), "outer survives reentry");
        ProtoWriter reusedOuter = Proto.begin(client, 1, 1024);
        ProtoWriter reusedInner = Proto.begin(client, 2, 1024);
        check(reusedOuter == outer && reusedInner == inner, "bounded reentry chain reused");
        Proto.abort(reusedInner);
        Proto.abort(reusedOuter);
        Set<ProtoWriter> threads = ConcurrentHashMap.newKeySet();
        List<Thread> workers = new ArrayList<>();
        for (int i = 0; i < 8; i++) {
            Thread worker = new Thread(() -> {
                CIOClient c = new CIOClient();
                ProtoWriter w = Proto.begin(c, 3, 1024);
                threads.add(w);
                Proto.abort(w);
            });
            workers.add(worker); worker.start();
        }
        for (Thread worker : workers) worker.join();
        check(threads.size() == 8, "thread-confined writer state");
        check(client.socket.active == 0, "no live lease at end");
        System.out.println("PASS direct-frame lifecycle: " + checks + " checks");
    }
    static boolean simple(Class<?> t) {
        return t.isPrimitive() || t.isEnum() || t == String.class || t == byte[].class
            || t == int[].class || t == String[].class || Collection.class.isAssignableFrom(t);
    }
    static Object argument(Class<?> t, int round) {
        if (t == int.class) return new int[] {0, -1, 127, 128, 25, 35, 45, Integer.MAX_VALUE}[round % 8];
        if (t == long.class) return round % 2 == 0 ? Long.MIN_VALUE : Long.MAX_VALUE;
        if (t == boolean.class) return round % 2 == 0;
        if (t == String.class) return new String[] {"", "한글", "\uD800", "x"}[round % 4];
        if (t == byte[].class) return new byte[round % 2 == 0 ? 0 : 128];
        if (t == int[].class) return new int[] {1, 2, 3};
        if (t == String[].class) return new String[] {"한글", "b", ""};
        if (t.isEnum()) return t.getEnumConstants()[round % t.getEnumConstants().length];
        if (LinkedList.class.isAssignableFrom(t)) return new LinkedList<>();
        if (Collection.class.isAssignableFrom(t)) return new ArrayList<>();
        throw new AssertionError(t);
    }
    static void bridges(Path names) throws Exception {
        CIOClient client = new CIOClient();
        int fixtures = 0, paths = 0;
        for (String name : Files.readAllLines(names)) {
            if (name.equals("SC_MapID")) continue; // Actual map registry needs server configuration.
            Class<?> type = Class.forName("l1j.server.server.packets.Protocol.Packet." + name);
            List<Executable> originals = new ArrayList<>(List.of(type.getDeclaredConstructors()));
            for (Method m : type.getDeclaredMethods())
                if (Modifier.isStatic(m.getModifiers()) && m.getReturnType() == type) originals.add(m);
            for (Executable original : originals) {
                if (original.getName().equals("newDummyInstance")) continue; // Random class selection.
                if (name.equals("SC_TamWindow") && Arrays.asList(original.getParameterTypes()).contains(String.class)) continue; // DB-backed account lookup.
                Class<?>[] params = original.getParameterTypes();
                if (!Arrays.stream(params).allMatch(ProtocolTransportAudit::simple)) continue;
                String methodName = original instanceof Constructor ? "sendConstructed"
                    : "send" + Character.toUpperCase(original.getName().charAt(0)) + original.getName().substring(1);
                Class<?>[] signature = new Class<?>[params.length + 1];
                signature[0] = CIOClient.class;
                System.arraycopy(params, 0, signature, 1, params.length);
                Method direct;
                try { direct = type.getMethod(methodName, signature); }
                catch (NoSuchMethodException excluded) { continue; }
                original.setAccessible(true);
                int valid = 0;
                for (int round = 0; round < 16; round++) {
                    Object[] args = new Object[params.length];
                    for (int i = 0; i < args.length; i++) args[i] = argument(params[i], round + i);
                    byte[] expected;
                    try {
                        ProtoPacket packet = (ProtoPacket)(original instanceof Constructor<?> c
                            ? c.newInstance(args) : ((Method)original).invoke(null, args));
                        if (packet == null) continue;
                        expected = packet.encode();
                    } catch (InvocationTargetException | NullPointerException invalidFixture) { continue; }
                    Object[] sendArgs = new Object[args.length + 1];
                    sendArgs[0] = client;
                    System.arraycopy(args, 0, sendArgs, 1, args.length);
                    if (!Boolean.TRUE.equals(direct.invoke(null, sendArgs))) throw new AssertionError("bridge refused " + original);
                    if (!Arrays.equals(expected, client.socket.lastBytes)) throw new AssertionError("bridge bytes differ " + original + " round " + round);
                    valid++; fixtures++;
                }
                if (valid > 0) paths++;
            }
        }
        check(paths >= 40, "constructor/factory coverage");
        System.out.println("PASS actual constructor/factory bridges: " + fixtures + " fixtures across " + paths + " overloads");
    }
    static void legacy(CIOClient client, int duration) {
        SC_SpellBuffNoti packet = SC_SpellBuffNoti.newInstance();
        packet.set_noti_type(SC_SpellBuffNoti.eNotiType.RESTAT);
        packet.set_spell_id(171);
        packet.set_duration(duration);
        escaped = packet; // Simulate an escaping packet at the polymorphic queue boundary.
        client.sendPacket(packet);
    }
    static void direct(CIOClient client, int duration) {
        SC_SpellBuffNoti.sendFields(client, SC_SpellBuffNoti.eNotiType.RESTAT, 171, duration,
            null, 0, 0, 0, 0, 0, 0, false, 0, 0, 0, 7);
    }
    static void passives() {
        CIOClient client = new CIOClient();
        for (int count = 0; count < 80; count++) {
            ArrayList<l1j.server.MJPassiveSkill.MJPassiveInfo> domain = new ArrayList<>();
            l1j.server.server.packets.Protocol.Packet.SC_AllSpellPassiveNoti old =
                new l1j.server.server.packets.Protocol.Packet.SC_AllSpellPassiveNoti();
            for (int i = 0; i < count; i++) {
                int id = i % 3 == 0 ? l1j.server.MJPassiveSkill.MJPassiveID.ARMOR_GUARD.toInt()
                    : new int[] {0, -1, 127, 128, Integer.MAX_VALUE}[i % 5];
                domain.add(l1j.server.MJPassiveSkill.MJPassiveInfo.newInstance().setPassiveId(id));
                if (id == l1j.server.MJPassiveSkill.MJPassiveID.ARMOR_GUARD.toInt()) old.add(id, 10);
                else old.add(id);
            }
            l1j.server.server.packets.Protocol.Packet.SC_AllSpellPassiveNoti.sendPassives(client, domain);
            check(Arrays.equals(old.encode(), client.socket.lastBytes), "passive rows " + count);
        }
        System.out.println("PASS actual passive domain direct bytes: 80 fixtures");
    }
    static void allocation() {
        ThreadMXBean bean = (ThreadMXBean)ManagementFactory.getThreadMXBean();
        if (!bean.isThreadAllocatedMemorySupported()) throw new AssertionError("allocation counters unavailable");
        bean.setThreadAllocatedMemoryEnabled(true);
        CIOClient client = new CIOClient();
        client.socket.capture = false;
        for (int i = 0; i < 60000; i++) { legacy(client, i); direct(client, i); }
        int n = 200000;
        long thread = Thread.currentThread().threadId();
        long before = bean.getThreadAllocatedBytes(thread);
        for (int i = 0; i < n; i++) legacy(client, i);
        long oldBytes = bean.getThreadAllocatedBytes(thread) - before;
        before = bean.getThreadAllocatedBytes(thread);
        for (int i = 0; i < n; i++) direct(client, i);
        long directBytes = bean.getThreadAllocatedBytes(thread) - before;
        check(directBytes < n, "steady primitive send should allocate <1 byte/send");
        check(oldBytes > directBytes, "escaping packet allocation removed");
        System.out.printf(Locale.ROOT,
            "PASS escaping buff fixture allocation: legacy %.2f B/send, direct %.2f B/send (%d sends; mock FIFO, real serializers)%n",
            (double)oldBytes/n, (double)directBytes/n, n);
    }
    public static void main(String[] args) throws Exception {
        lifecycle(); bridges(Path.of(args[0])); passives(); allocation();
    }
}
