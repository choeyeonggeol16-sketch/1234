#!/usr/bin/env python3
"""Real inventory/protobuf sources, controlled item and companion inputs."""
from pathlib import Path
import argparse, os, subprocess, tempfile
root = Path(__file__).resolve().parents[2]
here = Path(__file__).resolve().parent
p = argparse.ArgumentParser()
p.add_argument('--classes', type=Path, default=Path('/workspace/builds/protocol-direct/classes'))
a = p.parse_args()
deps = Path(os.environ.get('ITEM_DEPS_DIR', '/workspace/dependencies/item-processing'))
cp = os.pathsep.join([str(a.classes), *map(str, deps.glob('*.jar'))])
production = ['packets/Protocol/Proto.java', 'packets/Protocol/ProtoWriter.java',
              'packets/Protocol/ProtoPacket.java', 'packets/Protocol/ProtoPacketWriter.java',
              'model/network/buffer/WriteBuffer.java', 'packets/Protocol/Packet/Inventory/ItemInfo.java',
              'packets/Protocol/Packet/SC_AddInventoryNoti.java', 'packets/Protocol/Packet/SC_UpdateInventoryNoti.java']
with tempfile.TemporaryDirectory() as td:
    sources = [*map(str, (here/'transport').rglob('*.java')),
               *map(str, (here/'inventory').rglob('*.java')),
               *[str(root/'src/l1j/server/server'/s) for s in production],
               str(here/'ProtocolInventoryAudit.java')]
    subprocess.run(['java', '-m', 'jdk.compiler/com.sun.tools.javac.Main', '--enable-preview',
                    '-source', '21', '-target', '21', '-encoding', 'UTF-8', '-cp', cp,
                    '-d', td, *sources], check=True, timeout=60)
    subprocess.run(['java', '--enable-preview', '-ea', '-cp', td+os.pathsep+cp,
                    'ProtocolInventoryAudit'], check=True, timeout=60, cwd=td)
