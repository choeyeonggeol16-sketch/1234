package l1j.server.server.model.item.function;
import l1j.server.server.model.item.function.ItemUseCreature;

import l1j.server.server.model.item.function.CItemUse;
import l1j.server.server.model.network.core.sc.packet.SC_Paralysis;
import l1j.server.server.model.network.core.sc.packet.SC_OwnCharStatus2;
import l1j.server.server.model.network.core.sc.packet.SC_OwnCharAttrDef;
import l1j.server.server.model.network.core.sc.packet.SC_SPMR;
import l1j.server.server.model.network.core.sc.packet.SC_ItemStatus;
import l1j.server.server.model.network.core.sc.packet.SC_MpUpdate;
import l1j.server.server.model.network.core.sc.packet.SC_SkillSound;
import l1j.server.server.model.network.core.sc.packet.SC_HpUpdate;
import static l1j.server.server.model.character.skill.L1SkillId.STATUS_CURSE_BARLOG;
import static l1j.server.server.model.character.skill.L1SkillId.STATUS_CURSE_YAHEE;
import static l1j.server.server.model.character.skill.L1SkillId.STATUS_FREEZE;
import static l1j.server.server.model.character.skill.L1SkillId.STATUS_HOLY_MITHRIL_POWDER;
import static l1j.server.server.model.character.skill.L1SkillId.STATUS_HOLY_WATER;
import static l1j.server.server.model.character.skill.L1SkillId.STATUS_HOLY_WATER_OF_EVA;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Logger;
import l1j.server.Config;
import l1j.server.MJINNSystem.MJINNHelper;
import l1j.server.MJINNSystem.MJINNRoom;
import l1j.server.MJWarSystem.MJCastleWarBusiness;
import l1j.server.Stadium.StadiumManager;
import l1j.server.server.datatables.ClanTable;
import l1j.server.server.datatables.ItemTable;
import l1j.server.server.datatables.SkillsTable;
import l1j.server.server.model.Getback;
import l1j.server.server.model.L1CastleLocation;
import l1j.server.server.model.L1Clan;
import l1j.server.server.model.L1EffectSpawn;
import l1j.server.server.model.L1HouseLocation;
import l1j.server.server.model.L1Inventory;
import l1j.server.server.model.L1Location;
import l1j.server.server.model.L1NeigeItemBox;
import l1j.server.server.model.L1Object;
import l1j.server.server.model.L1Party;
import l1j.server.server.model.L1Quest;
import l1j.server.server.model.L1TownLocation;
import l1j.server.server.model.L1World;
import l1j.server.server.model.Instance.L1EffectInstance;
import l1j.server.server.model.Instance.L1ItemInstance;
import l1j.server.server.model.Instance.L1MonsterInstance;
import l1j.server.server.model.Instance.L1NpcInstance;
import l1j.server.server.model.Instance.L1PcInstance;
import l1j.server.server.model.character.auto.AutoSystemHandler;
import l1j.server.server.model.character.autohunt.AHExecutor;
import l1j.server.server.model.character.skill.L1SkillId;
import l1j.server.server.model.character.skill.L1SkillUse;
import l1j.server.server.model.item.function.IceBuffItem;
import l1j.server.server.model.network.core.CIOClient;
import l1j.server.server.model.rank.business.RankBusiness;
import l1j.server.server.packets.Protocol.Proto;
import l1j.server.server.packets.Protocol.Packet.SC_SpellBuffNoti;
import l1j.server.server.packets.Protocol.Packet.SC_SpellBuffNoti.eDurationShowType;
import l1j.server.server.packets.Protocol.Packet.SC_SpellBuffNoti.eNotiType;
import l1j.server.server.model.network.core.sc.packet.SC_AuctionSystemBoard;
import l1j.server.server.model.network.core.sc.packet.SC_Board;
import l1j.server.server.model.network.core.sc.packet.SC_Boarditem;
import l1j.server.server.model.network.core.sc.packet.SC_ChatPacket;
import l1j.server.server.model.network.core.sc.packet.SC_InventoryIcon;
import l1j.server.server.model.network.core.sc.packet.SC_NPCTalkReturn;
import l1j.server.server.model.network.core.sc.packet.SC_OwnCharStatus;
import l1j.server.server.model.network.core.sc.packet.SC_PacketBox;
import l1j.server.server.model.network.core.sc.packet.SC_ServerMessage;
import l1j.server.server.model.network.core.sc.packet.SC_SystemMessage;
import l1j.server.server.templates.L1ItemBookMark;
import l1j.server.server.utils.CommonUtil;
import l1j.server.server.utils.L1SpawnUtil;
import l1j.server.server.utils.MJCommons;
import l1j.server.server.utils.eKind;
import l1j.server.server.model.network.core.sc.packet.SC_SkillBrave;
import l1j.server.server.model.network.core.sc.packet.SC_Sound;

final class ItemUseAdvancedAbilities {
    private ItemUseAdvancedAbilities() {}

    static void use(L1PcInstance pc, L1ItemInstance l1iteminstance, int itemId) {
        switch (itemId) {
		case 70701:
			if (pc.hasSkillEffect(L1SkillId.램페이지)) {
				pc.sendPackets("이미 습득한 패시브입니다.");
				return;
			}

			if (pc.getType() == 5 && pc.getLevel() >= 1) {
				ItemUseDurableSkills.useDurablePassive(pc, l1iteminstance, L1SkillId.램페이지, 0, () -> {
				pc.램페이지(true);
				pc.setSkillEffect(L1SkillId.램페이지, -1);
				SC_SkillSound.send(pc, pc.getId(), 224);
				SC_SkillSound.broadcast(pc, pc.getId(), 224);

			
				});
			} else {
				pc.sendPackets("현재 [램페이지] 패시브를 배울 수 없는 상태입니다");

			}
			break;
		case 70702:
			if (pc.hasSkillEffect(L1SkillId.래스트)) {
				pc.sendPackets("이미 습득한 패시브입니다.");
				return;
			}

			if (pc.getType() == 6 && pc.getLevel() >= 1) {
				ItemUseDurableSkills.useDurablePassive(pc, l1iteminstance, L1SkillId.래스트, 0, () -> {
				pc.래스트(true);
				pc.setSkillEffect(L1SkillId.래스트, -1);
				SC_SkillSound.send(pc, pc.getId(), 224);
				SC_SkillSound.broadcast(pc, pc.getId(), 224);

			
				});
			} else {
				pc.sendPackets("현재 [본브레이크:래스트] 패시브를 배울 수 없는 상태입니다");

			}

			break;
		case 90905:
			if (pc.getInventory().checkItem(90088)) {
				pc.sendPackets("이미 스킬이 있으므로 획득할 수 없습니다.");
				return;
			}

			if (pc.getType() == 3) {
				ItemUseDurable.UseDurableExchange(pc, l1iteminstance, 90088, () -> {
					SC_SkillSound.send(pc, pc.getId(), 224);
					SC_SkillSound.broadcast(pc, pc.getId(), 224);
				});


			} else {
				pc.sendPackets("현재 [비전 텔레포트]를 배울 수 없는 상태입니다");

			}
			break;

		case 80889:

			if (pc.getInventory().checkItem(80888)) {
				pc.sendPackets("이미 이터니티 스킬이 있으므로 획득할 수 없습니다.");
				return;
			}

			if (pc.getType() == 3 && pc.getLevel() >= 1 ) {
				ItemUseDurable.UseDurableExchange(pc, l1iteminstance, 80888, () -> {
					SC_SkillSound.send(pc, pc.getId(), 224);
					SC_SkillSound.broadcast(pc, pc.getId(), 224);
					pc.sendPackets("\\f3이터니티를 습득하였습니다.");
					pc.sendPackets("\\f3[첫번째 공격은 카운터 매직 무시. 확률적 적중 시 홀드 및 2차 데미지]");
				});
			} else {
				pc.sendPackets("현재 [이터니티]를 배울 수 없는 상태입니다");

			}
			break;
		case 80805:
			if (pc.hasSkillEffect(L1SkillId.에테리얼)) {
				pc.sendPackets("이미 습득한 패시브입니다.");
				return;
			}

			if (pc.getType() == 3) {
				ItemUseDurableSkills.useDurablePassive(pc, l1iteminstance, L1SkillId.에테리얼, 0, () -> {

				pc.에테리얼(true);
				pc.setSkillEffect(L1SkillId.에테리얼, -1);
				SC_SkillSound.send(pc, pc.getId(), 224);
				SC_SkillSound.broadcast(pc, pc.getId(), 224);

			
				});
			} else {
				pc.sendPackets("현재 [에테리얼 서클] 패시브를 배울 수 없는 상태입니다");

			}
			break;

		case 80804:
			if (pc.hasSkillEffect(L1SkillId.에볼루션)) {
				pc.sendPackets("이미 습득한 패시브입니다.");
				return;
			}

			if (pc.getType() == 3 && pc.getLevel() >= 1) {
				ItemUseDurableSkills.useDurablePassive(pc, l1iteminstance, L1SkillId.에볼루션, 0, () -> {
				// pc.맥시멈(true);
				pc.setSkillEffect(L1SkillId.에볼루션, -1);
				SC_SkillSound.send(pc, pc.getId(), 224);
				SC_SkillSound.broadcast(pc, pc.getId(), 224);

				if (pc.hasSkillEffect(L1SkillId.HOLY_WALK)) {
					pc.removeSkillEffect(L1SkillId.HOLY_WALK);
					pc.setSkillEffect(L1SkillId.STATUS_ELFBRAVE, 300 * 1000);
					SC_SkillBrave.send(pc, pc.getId(), 3, 300 * 1000);
					SC_SkillBrave.broadcast(pc, pc.getId(), 3, 0);
					SC_InventoryIcon.icoNew(pc, L1SkillId.에볼루션, 3907, 300, true);
					pc.setBraveSpeed(1);

				}
				SC_SystemMessage.send(pc, "\\aH홀리워크 사용 시 이동 및 공격속도가 증가됩니다.");
			
				});
			} else {
				pc.sendPackets("현재 [홀리워크:에볼루션] 패시브를 배울 수 없는 상태입니다");

			}
			break;
		case 70716: 

			if (pc.hasSkillEffect(L1SkillId.네메시스)) {
				pc.sendPackets("이미 습득한 스킬입니다.");
				return;
			}
			if (!SkillsTable.getInstance().spellCheck(pc.getId(), 77)) {
				pc.sendPackets("디스인티그레이트를 습득한 후 네메시스를 습득할 수 있습니다.");
				return;
			}
			if (pc.getType() == 3 && pc.getLevel() >= 1) {
				ItemUseDurableSkills.useDurablePassive(pc, l1iteminstance, L1SkillId.네메시스, 0, () -> {
				pc.네메시스(true);
				pc.setSkillEffect(L1SkillId.네메시스, -1);
				SC_SkillSound.send(pc, pc.getId(), 224);
				SC_SkillSound.broadcast(pc, pc.getId(), 224);

			
				});
			} else {
				pc.sendPackets("현재 [디스인티그레이트:네메시스]를 배울 수 없는 조건입니다");

			}
			break;
		case 70704:
			if (pc.hasSkillEffect(L1SkillId.맥시멈)) {
				pc.sendPackets("이미 습득한 패시브입니다.");
				return;
			}

			if (pc.getType() == 4 && pc.getLevel() >= 1) {
				ItemUseDurableSkills.useDurablePassive(pc, l1iteminstance, L1SkillId.맥시멈, 0, () -> {
				// pc.맥시멈(true);
				pc.setSkillEffect(L1SkillId.맥시멈, -1);
				SC_SkillSound.send(pc, pc.getId(), 224);
				SC_SkillSound.broadcast(pc, pc.getId(), 224);

				if (pc.hasSkillEffect(L1SkillId.MOVING_ACCELERATION)) {
					pc.removeSkillEffect(L1SkillId.MOVING_ACCELERATION);
					pc.setSkillEffect(L1SkillId.STATUS_ELFBRAVE, 960 * 1000);
					SC_SkillBrave.send(pc, pc.getId(), 3, 960 * 1000);
					SC_SkillBrave.broadcast(pc, pc.getId(), 3, 0);
					SC_InventoryIcon.icoNew(pc, L1SkillId.맥시멈, 3902, 960, true);
					pc.setBraveSpeed(1);

				}
				SC_SystemMessage.send(pc, "\\aH무빙악셀레이션 사용 시 공격속도가 증가됩니다.");
			
				});
			} else {
				pc.sendPackets("현재 [무빙 악셀레이션:맥시멈] 패시브를 배울 수 없는 상태입니다");

			}
			break;

		case 70705:
			if (pc.hasSkillEffect(L1SkillId.아머데스티니)) {
				pc.sendPackets("이미 습득한 패시브입니다.");
				return;
			}

			if (pc.getType() == 4 && pc.getLevel() >= 1) {
				ItemUseDurableSkills.useDurablePassive(pc, l1iteminstance, L1SkillId.아머데스티니, 0, () -> {
				// pc.래스트(true);
				pc.setSkillEffect(L1SkillId.아머데스티니, -1);
				SC_SkillSound.send(pc, pc.getId(), 224);
				SC_SkillSound.broadcast(pc, pc.getId(), 224);

				SC_SystemMessage.send(pc, "\\aH[쉐도우 아머:데스티니]를 습득하였습니다.");
				SC_SystemMessage.send(pc, "\\aH쉐도우 아머를 사용 시 데스티니의 효과가 지속됩니다.");


			
				});
			} else {
				pc.sendPackets("현재 [쉐도우 아머:데스티니] 패시브를 배울 수 없는 상태입니다");

			}
			break;
		case 70706:

			if (pc.getType() == 7 && pc.getLevel() >= 1) {

				if (pc.getCurrentHp() <= 100) {
					pc.sendPackets("HP가 부족합니다.");
					return;
				}
				if (!pc.getInventory().checkItem(41246, 100)) {
					pc.sendPackets("결정체가 부족합니다.");
					return;
				}
				if (MJCommons.isNonAction(pc)) {
					return;
				}
				//				if (pc.hasSkillEffect(L1SkillId.SHOCK_STUN) || pc.hasSkillEffect(L1SkillId.EMPIRE)
				//						|| pc.hasSkillEffect(L1SkillId.EARTH_BIND) || pc.hasSkillEffect(L1SkillId.BONE_BREAK)) {
				//					return;
				//				}
				if (pc.hasSkillEffect(L1SkillId.버서크대기)) {
					int n = pc.getSkillEffectTimeSec(L1SkillId.버서크대기);
					SC_SystemMessage.send(pc, String.format("\\fY버서크 대기시간 : %d초 후에 사용가능합니다.", n));
					return;
				}


				ItemUseDurableSkills.useDurableSkillReagent(pc, 41246, 100, () -> {
					if (pc.hasSkillEffect(L1SkillId.버서크)) {
						pc.removeSkillEffect(L1SkillId.버서크);
					}
					pc.setSkillEffect(L1SkillId.버서크대기, Config.버서크대기시간 * 1000);
					pc.setSkillEffect(L1SkillId.버서크, Config.버서크시간 * 1000);
					// pc.sendPackets(SC_InventoryIcon.icoNew(L1SkillId.버서크, 3155, Config.버서크시간,
					// true));
					SC_InventoryIcon.icoNew(pc, L1SkillId.버서크, 3155, Config.버서크시간, true);
					SC_SkillSound.send(pc, pc.getId(), 8531);
					SC_SkillSound.broadcast(pc, pc.getId(), 8531);
				
					L1SkillUse.cast(pc, L1SkillId.보조버프, pc.getId(), pc.getX(),
							pc.getY(), null, 0, L1SkillUse.TYPE_SPELLSC);
				
					pc.getResistance().addSpecialResistance(eKind.ALL, 20);
				
					pc.setCurrentHp(pc.getCurrentHp() - 100);
					pc.sendPackets("버서크 효과: 모든 내성 +20, 근거리대미지 +20 증가");
				});

			} else {
				pc.sendPackets("현재 버서크를 사용할 수 없는 조건입니다.");
				return;
			}
			break;
		case 70707:
			if (pc.getType() == 7 && pc.getLevel() >= 1) {
				if (pc.getInventory().checkItem(70706)) {
					pc.sendPackets("이미 버서크 스킬이 있으므로 획득할 수 없습니다.");
					return;
				}
				ItemUseDurable.UseDurableExchange(pc, l1iteminstance, 70706, () -> {
					pc.sendPackets("\\aH전사의 인장 (버서크)를 획득하였습니다.");
				});
			} else {
				pc.sendPackets("조건이 맞지 않아 버서크를 획득 할 수 없습니다.");
			}

			break;
		case 70708:
			L1Clan clan1 = pc.getClan();

			if (MJCommons.isNonAction(pc)) {
				return;
			}
			//			if (pc.hasSkillEffect(L1SkillId.SHOCK_STUN) || pc.hasSkillEffect(L1SkillId.EMPIRE)
			//					|| pc.hasSkillEffect(L1SkillId.EARTH_BIND) || pc.hasSkillEffect(L1SkillId.BONE_BREAK)) {
			//				return;
			//			}


			if (pc.getType() == 0 && pc.getLevel() >= 85) {

				if (pc.getClanid() == 0) {
					pc.sendPackets("프라임을 사용하기 위해서는 혈맹을 창설하여야 합니다.");
					return;
				}
				if (!pc.getInventory().checkItem(41246, 1000)) {
					pc.sendPackets("결정체가 부족합니다.");
					return;
				}
				if (pc.getCurrentMp() < 50) {
					pc.sendPackets("MP가 부족합니다.");
					return;
				}
				if (pc.hasSkillEffect(L1SkillId.프라임대기시간)) {
					int n = pc.getSkillEffectTimeSec(L1SkillId.프라임대기시간);
					SC_SystemMessage.send(pc, String.format("\\fY프라임 대기시간 : %d초 후에 사용가능합니다.", n));
					return;
				}
				ItemUseDurableSkills.useDurableSkillReagent(pc, 41246, 1000, () -> {
					if (pc.hasSkillEffect(L1SkillId.프라임)) {
						pc.removeSkillEffect(L1SkillId.프라임);
					}
					if (pc.hasSkillEffect(L1SkillId.프라임1)) {
						pc.removeSkillEffect(L1SkillId.프라임1);
					}
					if (pc.hasSkillEffect(L1SkillId.프라임85)) {
						pc.removeSkillEffect(L1SkillId.프라임85);
					}
					if (pc.hasSkillEffect(L1SkillId.프라임90)) {
						pc.removeSkillEffect(L1SkillId.프라임90);
					}
					if (pc.hasSkillEffect(L1SkillId.프라임95)) {
						pc.removeSkillEffect(L1SkillId.프라임95);
					}

					if (pc.getLevel() >= 85 && pc.getLevel() < 90) {
						pc.setSkillEffect(L1SkillId.프라임85, 600 * 1000);

					} else if (pc.getLevel() >= 90 && pc.getLevel() < 95) {
						pc.setSkillEffect(L1SkillId.프라임90, 600 * 1000);

					} else if (pc.getLevel() >= 95) {
						pc.setSkillEffect(L1SkillId.프라임95, 600 * 1000);

					}

					if (!isInWarAreaAndWarTime(pc)) {
						pc.setSkillEffect(L1SkillId.프라임, 600 * 1000);
						SC_InventoryIcon.icoNew(pc, L1SkillId.프라임, 5383, 600, true);
						pc.addBowHitRate(3);
						pc.addBowDmgRate(3);
						pc.addDmgRate(3);
						pc.addHitRate(3);
						pc.getAbility().addSp(2);
						pc.addMagicHit(2);
						pc.sendPackets("프라임의 효과가 적용되었습니다.");
					} else {
						pc.setSkillEffect(L1SkillId.프라임1, 600 * 1000);
						SC_InventoryIcon.icoNew(pc, L1SkillId.프라임, 5383, 600, true);
						pc.addBowHitRate(9);
						pc.addBowDmgRate(9);
						pc.addDmgRate(9);
						pc.addHitRate(9);
						pc.getAbility().addSp(6);
						pc.addMagicHit(6);
						pc.addMaxHp(500);
						pc.sendPackets("공성존의 프라임 효과가 적용되었습니다.");
					}
					pc.setCurrentMp(pc.getCurrentMp() - 50);
					pc.setSkillEffect(L1SkillId.프라임대기시간, Config.프라임대기시간 * 1000);
					SC_OwnCharAttrDef.send(pc);
					SC_OwnCharStatus.send(pc);
				
					L1SkillUse.cast(pc, L1SkillId.보조버프, pc.getId(), pc.getX(),
							pc.getY(), null, 0, L1SkillUse.TYPE_SPELLSC);
					SC_SPMR.send(pc);
				

					// pc.sendPackets(new S_SkillSound(pc.getId(), 16422));
					// pc.broadcastPacket(new S_SkillSound(pc.getId(), 16422));
					SC_SkillSound.send(pc, pc.getId(), 12301);
					SC_SkillSound.broadcast(pc, pc.getId(), 12301);
					if (clan1 != null) {
						for (L1PcInstance player : L1World.getInstance().getVisiblePlayer(pc, 20)) {
							if (player.getClanid() == pc.getClanid()) {
								if (player.hasSkillEffect(L1SkillId.프라임)) {
									player.removeSkillEffect(L1SkillId.프라임);
								}
								if (player.hasSkillEffect(L1SkillId.프라임1)) {
									player.removeSkillEffect(L1SkillId.프라임1);
								}
								if (player.hasSkillEffect(L1SkillId.프라임85)) {
									player.removeSkillEffect(L1SkillId.프라임85);
								}
								if (player.hasSkillEffect(L1SkillId.프라임90)) {
									player.removeSkillEffect(L1SkillId.프라임90);
								}
								if (player.hasSkillEffect(L1SkillId.프라임95)) {
									player.removeSkillEffect(L1SkillId.프라임95);
								}
								if (pc.getLevel() >= 85 && pc.getLevel() < 90) {
									player.setSkillEffect(L1SkillId.프라임85, 600 * 1000);
								} else if (pc.getLevel() >= 90 && pc.getLevel() < 95) {
									player.setSkillEffect(L1SkillId.프라임90, 600 * 1000);
								} else if (pc.getLevel() >= 95) {
									player.setSkillEffect(L1SkillId.프라임95, 600 * 1000);
								}

								if (!isInWarAreaAndWarTime(pc)) {
									player.setSkillEffect(L1SkillId.프라임, 600 * 1000);
									SC_InventoryIcon.icoNew(player, L1SkillId.프라임, 5383, 600, true);
									player.addBowHitRate(3);
									player.addBowDmgRate(3);
									player.addDmgRate(3);
									player.addHitRate(3);
									player.getAbility().addSp(2);
									player.addMagicHit(2);
									player.sendPackets("프라임의 효과가 적용되었습니다.");
								} else {
									player.setSkillEffect(L1SkillId.프라임1, 600 * 1000);
									SC_InventoryIcon.icoNew(player, L1SkillId.프라임, 5383, 600, true);
									player.addBowHitRate(9);
									player.addBowDmgRate(9);
									player.addDmgRate(9);
									player.addHitRate(9);
									player.getAbility().addSp(6);
									player.addMagicHit(6);
									player.addMaxHp(500);
									player.sendPackets("공성존의 프라임 효과가 적용되었습니다.");
								}

								SC_HpUpdate.send(pc, pc.getCurrentHp(), pc.getMaxHp());
								SC_OwnCharAttrDef.send(player);
								SC_OwnCharStatus.send(player);
								SC_SPMR.send(player);
								// player.sendPackets(new S_SkillSound(player.getId(), 16422));
								// player.broadcastPacket(new S_SkillSound(player.getId(), 16422));
								SC_SkillSound.send(player, player.getId(), 12301);
								SC_SkillSound.broadcast(player, player.getId(), 12301);

							}

						}
					}

				});
			} else {
				pc.sendPackets("현재 프라임을 사용할 수 없는 조건입니다.");
			}

			break;

		case 70733:
			L1Clan clan11 = pc.getClan();
			L1Party party = pc.getParty();

			if (pc.getType() == 3 && pc.getLevel() >= 1) {

				if (!pc.getInventory().checkItem(40318, Config.매스이뮨마돌)) {
					pc.sendPackets("마력의 돌이 부족합니다.");
					return;
				}
				if (pc.getCurrentMp() < Config.매스이뮨엠피) {
					pc.sendPackets("MP가 부족합니다.");
					return;
				}
				if (MJCommons.isNonAction(pc)) {
					return;
				}
				//				if (pc.hasSkillEffect(L1SkillId.SHOCK_STUN) || pc.hasSkillEffect(L1SkillId.EMPIRE)
				//						|| pc.hasSkillEffect(L1SkillId.EARTH_BIND) || pc.hasSkillEffect(L1SkillId.BONE_BREAK)) {
				//					return;
				//				}
				if (pc.hasSkillEffect(L1SkillId.매스이뮨대기시간)) {
					int n = pc.getSkillEffectTimeSec(L1SkillId.매스이뮨대기시간);
					SC_SystemMessage.send(pc, String.format("\\fY매스 이뮨 투 함 대기시간 : %d초 후에 사용가능합니다.", n));
					return;
				}
				if (pc.getParty() == null) {
					pc.sendPackets("파티상태가 아닙니다.");
					return;
				}
				if (pc.getClanid() == 0) {
					pc.sendPackets("혈맹에 가입 후 시전이 가능합니다.");
					return;
				}
				ItemUseDurableSkills.useDurableSkillReagent(pc, 40318, Config.매스이뮨마돌, () -> {
					if (pc.hasSkillEffect(L1SkillId.IMMUNE_TO_HARM)) {
						pc.removeSkillEffect(L1SkillId.IMMUNE_TO_HARM);
					}

					pc.setSkillEffect(L1SkillId.IMMUNE_TO_HARM, 32 * 1000);
					l1j.server.server.packets.Protocol.Packet.SC_SpellBuffNoti.eNotiType notiWire_notiType = null;
					int notiWire_spellId = 0;
					int notiWire_duration = 0;
					l1j.server.server.packets.Protocol.Packet.SC_SpellBuffNoti.eDurationShowType notiWire_durationShowType = null;
					int notiWire_onIconId = 0;
					int notiWire_offIconId = 0;
					int notiWire_iconPriority = 0;
					int notiWire_tooltipStrId = 0;
					int notiWire_newStrId = 0;
					int notiWire_endStrId = 0;
					boolean notiWire_isGood = false;
					int notiWire_bit = 0;


					if (pc.hasSkillEffect(L1SkillId.세인트)) {
						pc.세인트(true);
						{ notiWire_bit |= 16; notiWire_onIconId = 2788; }
						{ notiWire_bit |= 32; notiWire_offIconId = 2788; }
						SC_SkillSound.send(pc, pc.getId(), 231);
						SC_SkillSound.broadcast(pc, pc.getId(), 231);
					} else {
						{ notiWire_bit |= 16; notiWire_onIconId = 1562; }
						{ notiWire_bit |= 32; notiWire_offIconId = 1562; }
					}
					{ notiWire_bit |= 1; notiWire_notiType = eNotiType.RESTAT; }
					{ notiWire_bit |= 2; notiWire_spellId = L1SkillId.IMMUNE_TO_HARM; }
					{ notiWire_bit |= 4; notiWire_duration = 32; }
					{ notiWire_bit |= 8; notiWire_durationShowType = eDurationShowType.TYPE_EFF_AUTO_DAY_HOUR_MIN_SEC; }

					{ notiWire_bit |= 64; notiWire_iconPriority = 10; }

					{ notiWire_bit |= 128; notiWire_tooltipStrId = 966; }
					{ notiWire_bit |= 256; notiWire_newStrId = 314; }
					{ notiWire_bit |= 512; notiWire_endStrId = 315; }
					{ notiWire_bit |= 1024; notiWire_isGood = true; }

					SC_SpellBuffNoti.sendFields(
					        pc, notiWire_notiType, notiWire_spellId, notiWire_duration, notiWire_durationShowType,
					        notiWire_onIconId, notiWire_offIconId, notiWire_iconPriority, notiWire_tooltipStrId,
					        notiWire_newStrId, notiWire_endStrId, notiWire_isGood, 0, 0, 0, notiWire_bit);
					SC_SkillSound.send(pc, pc.getId(), 21103);
					SC_SkillSound.broadcast(pc, pc.getId(), 21103);
					pc.setLastImmuneLevel(Config.IMMUNE_Level);


					pc.setCurrentMp(pc.getCurrentMp() - Config.매스이뮨엠피);
					pc.setSkillEffect(L1SkillId.매스이뮨대기시간, Config.매스이뮨대기시간 * 1000);
				
					L1SkillUse.cast(pc, L1SkillId.보조버프, pc.getId(), pc.getX(),
							pc.getY(), null, 0, L1SkillUse.TYPE_SPELLSC);
				
					pc.sendPackets("\\f:매스 이뮨 투함이 시전되었습니다.");
					if (party != null) {
						for (L1PcInstance player : L1World.getInstance().getVisiblePlayer(pc, 9)) {
							if (pc.getParty().isMember(player)) {
								if (player.getClanid() == pc.getClanid()) {
									if (player.hasSkillEffect(L1SkillId.IMMUNE_TO_HARM)) {
										player.removeSkillEffect(L1SkillId.IMMUNE_TO_HARM);
									}
									if (player.hasSkillEffect(L1SkillId.LUCIFER)) {
										player.removeSkillEffect(L1SkillId.LUCIFER);
									}

									if (player.hasSkillEffect(L1SkillId.세인트)) {
										player.세인트(true);
										{ notiWire_bit |= 16; notiWire_onIconId = 2788; }
										{ notiWire_bit |= 32; notiWire_offIconId = 2788; }
										SC_SkillSound.send(player, player.getId(), 231);
										SC_SkillSound.broadcast(player, player.getId(), 231);
									} else {
										{ notiWire_bit |= 16; notiWire_onIconId = 1562; }
										{ notiWire_bit |= 32; notiWire_offIconId = 1562; }
									}

									player.setSkillEffect(L1SkillId.IMMUNE_TO_HARM, 32 * 1000);
									player.setLastImmuneLevel(pc.getLevel());

									{ notiWire_bit |= 1; notiWire_notiType = eNotiType.RESTAT; }
									{ notiWire_bit |= 2; notiWire_spellId = L1SkillId.IMMUNE_TO_HARM; }
									{ notiWire_bit |= 4; notiWire_duration = 32; }
									{ notiWire_bit |= 8; notiWire_durationShowType = eDurationShowType.TYPE_EFF_AUTO_DAY_HOUR_MIN_SEC; }

									{ notiWire_bit |= 64; notiWire_iconPriority = 10; }

									{ notiWire_bit |= 128; notiWire_tooltipStrId = 966; }
									{ notiWire_bit |= 256; notiWire_newStrId = 314; }
									{ notiWire_bit |= 512; notiWire_endStrId = 315; }
									{ notiWire_bit |= 1024; notiWire_isGood = true; }
									SC_SpellBuffNoti.sendFields(
									        player, notiWire_notiType, notiWire_spellId, notiWire_duration,
									        notiWire_durationShowType, notiWire_onIconId, notiWire_offIconId,
									        notiWire_iconPriority, notiWire_tooltipStrId, notiWire_newStrId,
									        notiWire_endStrId, notiWire_isGood, 0, 0, 0, notiWire_bit);
									SC_SkillSound.send(player, player.getId(), 21103);
									SC_SkillSound.broadcast(player, player.getId(), 21103);
									player.sendPackets("\\f:["+pc.getName()+"]님의 매스 이뮨 투 함이 시전되었습니다.");


								}else {
									//pc.sendPackets("\\fY파티 내 혈맹원들에게 매스 이뮨 투 함이 시전되었습니다.");
									player.sendPackets("\\fY같은 혈맹이 아니므로 매스 이뮨 투 함 미적용");
								}
							}else {
								pc.sendPackets("\\fY파티 중인 혈맹원들이 없습니다.");
							}
						}
					} else {
						pc.sendPackets("\\fY파티 중인 혈맹원들이 없습니다.");
					}

				});
			} else {
				pc.sendPackets("현재 매스 이뮨 투 함을 사용할 수 없는 조건입니다.");
			}

			break;
		case 70734:
			if (pc.getInventory().checkItem(70733)) {
				pc.sendPackets("이미 매스 이뮨 투 함 스킬이 있으므로 획득할 수 없습니다.");
				return;
			}
			if (pc.getType() == 3 && pc.getLevel() >= 1) {

				ItemUseDurable.UseDurableExchange(pc, l1iteminstance, 70733, () -> {
					SC_SkillSound.send(pc, pc.getId(), 224);
					SC_SkillSound.broadcast(pc, pc.getId(), 224);
					pc.sendPackets("\\aH마법서 (매스 이뮨 투 함)을 획득하였습니다.");
				});
			} else {
				pc.sendPackets("조건이 맞지 않아 매스 이뮨 투 함을 획득 할 수 없습니다.");
			}

			break;
		case 70709:

			if (pc.getType() == 0 && pc.getLevel() >= 85) {
				if (pc.getInventory().checkItem(70708)) {
					pc.sendPackets("이미 프라임 스킬이 있으므로 획득할 수 없습니다.");
					return;
				}
				ItemUseDurable.UseDurableExchange(pc, l1iteminstance, 70708, () -> {
					SC_SkillSound.send(pc, pc.getId(), 224);
					SC_SkillSound.broadcast(pc, pc.getId(), 224);
					pc.sendPackets("\\aH마법서 (프라임)을 획득하였습니다.");
				});
			} else {
				pc.sendPackets("조건이 맞지 않아 프라임을 획득 할 수 없습니다.");
			}

			break;
		case 70710:

			if (pc.getType() == 5 && pc.getLevel() >= 1) {

				if (pc.hasSkillEffect(L1SkillId.할파스대기시간)) {
					int n = pc.getSkillEffectTimeSec(L1SkillId.할파스대기시간);
					SC_SystemMessage.send(pc, String.format("\\fY할파스 대기시간 : %d초 후에 사용가능합니다.", n));
					return;
				}
				if (MJCommons.isNonAction(pc)) {
					return;
				}
				//				if (pc.hasSkillEffect(L1SkillId.SHOCK_STUN) || pc.hasSkillEffect(L1SkillId.EMPIRE)
				//						|| pc.hasSkillEffect(L1SkillId.EARTH_BIND) || pc.hasSkillEffect(L1SkillId.BONE_BREAK)) {
				//					return;
				//				}
				if (pc.getInventory().getTypeEquipped(1, 18) < 1) {
					SC_SystemMessage.send(pc, "체인소드를 착용 후 스킬시전이 가능합니다.");
					return;
				}
				if (!pc.getInventory().checkItem(210035, 1)) {
					pc.sendPackets("각인의 뼈조각이 부족합니다.");
					return;
				}
				if (pc.getCurrentMp() < 18) {
					pc.sendPackets("MP가 부족합니다.");
					return;
				}

				ItemUseDurableSkills.useDurableSkillReagent(pc, 210035, 1, () -> {
					if (pc.hasSkillEffect(L1SkillId.할파스)) {
						pc.removeSkillEffect(L1SkillId.할파스);
					}

					pc.setSkillEffect(L1SkillId.할파스, 128 * 1000);
					pc.setSkillEffect(L1SkillId.할파스대기시간, 20 * 1000);
					pc.setCurrentMp(pc.getCurrentMp() - 18);
					//				pc.sendPackets(new S_SkillSound(pc.getId(), 16422));
					//				pc.broadcastPacket(new S_SkillSound(pc.getId(), 16422));
					SC_SkillSound.send(pc, pc.getId(), 14455);
					SC_SkillSound.broadcast(pc, pc.getId(), 14455);
					SC_InventoryIcon.icoNew(pc, L1SkillId.할파스, 5384, 128, true);
				
					L1SkillUse.cast(pc, L1SkillId.보조버프, pc.getId(), pc.getX(),
							pc.getY(), null, 0, L1SkillUse.TYPE_SPELLSC);
				
					SC_MpUpdate.send(pc, pc.getCurrentMp(), pc.getMaxMp());
					pc.sendPackets("할파스: 일정 확률로 물리데미지를 피하며 반격합니다.");
				});

			} else {
				pc.sendPackets("현재 [할파스]를 사용할 수 없는 조건입니다");

			}
			break;
		case 210122:

			if (pc.hasSkillEffect(L1SkillId.기간틱)) {
				pc.sendPackets("이미 습득한 패시브입니다.");
				return;
			}

			if (pc.getType() == 7) {
				ItemUseDurableSkills.useDurablePassive(pc, l1iteminstance, L1SkillId.기간틱, 0, () -> {

				SC_HpUpdate.send(pc, pc.getCurrentHp(), pc.getMaxHp());
				pc.기간틱(true);
				pc.setSkillEffect(L1SkillId.기간틱, -1);
				SC_SkillSound.send(pc, pc.getId(), 224);
				SC_SkillSound.broadcast(pc, pc.getId(), 224);

				SC_SystemMessage.send(pc, "\\aH[기간틱] 패시브를 습득하였습니다.");

			
				});
			} else {
				pc.sendPackets("현재 [기간틱] 패시브를 배울 수 없는 조건입니다");

			}
			break;
		case 50512:
			if (pc.hasSkillEffect(L1SkillId.엠파이어오버로드)) {
				pc.sendPackets("이미 습득한 패시브입니다.");
				return;
			}

			if (pc.getType() == 0 && pc.getLevel() >= 1) {
				ItemUseDurableSkills.useDurablePassive(pc, l1iteminstance, L1SkillId.엠파이어오버로드, 0, () -> {
				pc.엠파이어오버로드(true);
				pc.setSkillEffect(L1SkillId.엠파이어오버로드, -1);
				SC_SkillSound.send(pc, pc.getId(), 224);
				SC_SkillSound.broadcast(pc, pc.getId(), 224);

			
				});
			} else {
				pc.sendPackets("현재 [엠파이어:오버로드] 패시브를 배울 수 없는 상태입니다");

			}
			break;
		case 40228:
			if (pc.hasSkillEffect(L1SkillId.샤이닝아머)) {
				pc.sendPackets("이미 습득한 패시브입니다.");
				return;
			}

			if (pc.getType() == 0 && pc.getLevel() >= 1) {
				ItemUseDurableSkills.useDurablePassive(pc, l1iteminstance, L1SkillId.샤이닝아머, 0, () -> {
				pc.샤이닝아머(true);
				pc.setSkillEffect(L1SkillId.샤이닝아머, -1);
				SC_SkillSound.send(pc, pc.getId(), 224);
				SC_SkillSound.broadcast(pc, pc.getId(), 224);

			
				});
			} else {
				pc.sendPackets("현재 [샤이닝 아머] 패시브를 배울 수 없는 상태입니다");

			}
			break;
		case 40231:
			if (pc.hasSkillEffect(L1SkillId.마제스티)) {
				pc.sendPackets("이미 습득한 패시브입니다.");
				return;
			}

			if (pc.getType() == 0 && pc.getLevel() >= 1) {
				ItemUseDurableSkills.useDurablePassive(pc, l1iteminstance, L1SkillId.마제스티, 0, () -> {
				pc.마제스티(true);
				pc.setSkillEffect(L1SkillId.마제스티, -1);
				SC_SkillSound.send(pc, pc.getId(), 224);
				SC_SkillSound.broadcast(pc, pc.getId(), 224);

			
				});
			} else {
				pc.sendPackets("현재 [마제스티] 패시브를 배울 수 없는 상태입니다");

			}
			break;
		case 70711:

			if (pc.getType() == 5 && pc.getLevel() >= 1) {

				if (pc.getInventory().checkItem(70710)) {
					pc.sendPackets("이미 할파스 스킬이 있으므로 획득할 수 없습니다.");
					return;
				}

				ItemUseDurable.UseDurableExchange(pc, l1iteminstance, 70710, () -> {
					SC_SkillSound.send(pc, pc.getId(), 224);
					SC_SkillSound.broadcast(pc, pc.getId(), 224);
					pc.sendPackets("\\aH[할파스]를 획득하였습니다.");
				});
			} else {
				pc.sendPackets("조건이 맞지 않아 할파스를 획득 할 수 없습니다.");
			}
			break;
		case 70712:
			if (pc.hasSkillEffect(L1SkillId.포스스턴)) {
				pc.sendPackets("이미 습득한 패시브입니다.");
				return;
			}

			if (pc.getType() == 1 && pc.getLevel() >= 1) {
				ItemUseDurableSkills.useDurablePassive(pc, l1iteminstance, L1SkillId.포스스턴, 0, () -> {
				pc.포스스턴(true);
				pc.setSkillEffect(L1SkillId.포스스턴, -1);
				SC_SkillSound.send(pc, pc.getId(), 224);
				SC_SkillSound.broadcast(pc, pc.getId(), 224);

			
				});
			} else {
				pc.sendPackets("현재 [포스 스턴] 패시브를 배울 수 없는 상태입니다");

			}
			break;
		case 70713:
			if (pc.hasSkillEffect(L1SkillId.레이징포스)) {
				pc.sendPackets("이미 습득한 패시브입니다.");
				return;
			}

			if (pc.getType() == 1 && pc.getLevel() >= 1) {
				ItemUseDurableSkills.useDurablePassive(pc, l1iteminstance, L1SkillId.레이징포스, 0, () -> {
				pc.sendPackets("\\aH[레이징 포스] 패시브를 습득하였습니다.");
				pc.sendPackets("\\aH80레벨부터 4레벨마다 PVP 대미지 감소 +1 추가");

				// pc.레이징포스(true);
				pc.setSkillEffect(L1SkillId.레이징포스, -1);
				SC_InventoryIcon.iconNewUnLimit(pc, L1SkillId.레이징포스, 6082, true);
				// SC_SPECIAL_RESISTANCE_NOTI.sendCharacterInfo(pc);
				SC_SkillSound.send(pc, pc.getId(), 224);
				SC_SkillSound.broadcast(pc, pc.getId(), 224);

			
				});
			} else {
				pc.sendPackets("현재 [레이징 포스] 패시브를 배울 수 없는 상태입니다");

			}
			break;
		case 70714:

			if (pc.getType() == 6 && pc.getLevel() >= 1) {

				if (pc.hasSkillEffect(L1SkillId.포텐셜대기시간)) {
					int n = pc.getSkillEffectTimeSec(L1SkillId.포텐셜대기시간);
					SC_SystemMessage.send(pc, String.format("\\fY포텐셜 대기시간 : %d초 후에 사용가능합니다.", n));
					return;
				}
				if (MJCommons.isNonAction(pc)) {
					return;
				}
				//				if (pc.hasSkillEffect(L1SkillId.SHOCK_STUN) || pc.hasSkillEffect(L1SkillId.EMPIRE)
				//						|| pc.hasSkillEffect(L1SkillId.EARTH_BIND) || pc.hasSkillEffect(L1SkillId.BONE_BREAK)) {
				//					return;
				//				}
				if (!pc.getInventory().checkItem(210038, 2)) {
					pc.sendPackets("속성석이 부족합니다.");
					return;
				}
				if (pc.getCurrentMp() < 30) {
					pc.sendPackets("MP가 부족합니다.");
					return;
				}

				ItemUseDurableSkills.useDurableSkillReagent(pc, 210038, 2, () -> {
					if (pc.hasSkillEffect(L1SkillId.포텐셜)) {
						pc.removeSkillEffect(L1SkillId.포텐셜);
					}

					pc.setSkillEffect(L1SkillId.포텐셜, 128 * 1000);
					pc.setSkillEffect(L1SkillId.포텐셜대기시간, Config.포텐셜대기시간 * 1000);
					pc.setCurrentMp(pc.getCurrentMp() - 30);

					int addHp = (int) Math.round(pc.getMaxHp() * 0.2);
					int addMp = (int) Math.round(pc.getMaxMp() * 0.2);
					int addMR = (int) Math.round(pc.getResistance().getMr() * 0.2);
					int addSP = (int) Math.round(pc.getAbility().getSp() * 0.2);
					int addDG = (int) Math.round(pc.getDg() * 0.2);
					int addER = (int) Math.round(pc.getTotalER() * 0.2);

					pc.setMagicBuffHp(addHp);
					pc.addMaxHp(pc.getMagicBuffHp());

					pc.setMagicBuffMp(addMp);
					pc.addMaxMp(pc.getMagicBuffMp());

					pc.setMagicBuffMR(addMR);
					pc.getResistance().addMr(pc.getMagicBuffMR());

					pc.setMagicBuffSP(addSP);
					pc.getAbility().addSp(pc.getMagicBuffSP());

					pc.setMagicBuffDG(addDG);
					pc.addDg(pc.getMagicBuffDG());

					pc.setMagicBuffER(addER);
					pc.addEffectedER(pc.getMagicBuffER());

					SC_SkillSound.send(pc, pc.getId(), 16647);
					SC_SkillSound.broadcast(pc, pc.getId(), 16647);
					SC_InventoryIcon.icoNew(pc, L1SkillId.포텐셜, 5386, 128, true);
				
					L1SkillUse.cast(pc, L1SkillId.보조버프, pc.getId(), pc.getX(),
							pc.getY(), null, 0, L1SkillUse.TYPE_SPELLSC);
				

					SC_MpUpdate.send(pc, pc.getCurrentMp(), pc.getMaxMp());
					SC_HpUpdate.send(pc, pc.getCurrentHp(), pc.getMaxHp());
					SC_SPMR.send(pc);
					SC_OwnCharAttrDef.send(pc);
					SC_PacketBox.send(pc, SC_PacketBox.ER_UpDate, pc.getTotalER());
					pc.sendPackets("포텐셜의 기운이 느껴집니다.");
				});
			} else {
				pc.sendPackets("현재 [포텐셜]을 사용할 수 없는 조건입니다");

			}
			break;

		case 70715:

			if (pc.getType() == 6 && pc.getLevel() >= 85) {

				if (pc.getInventory().checkItem(70714)) {
					pc.sendPackets("이미 포텐셜 스킬이 있으므로 획득할 수 없습니다.");
					return;
				}

				ItemUseDurable.UseDurableExchange(pc, l1iteminstance, 70714, () -> {
					pc.sendPackets("\\aH[포텐셜]을 획득하였습니다.");
				});
			} else {
				pc.sendPackets("조건이 맞지 않아 포텐셜을 획득 할 수 없습니다.");
			}
			break;


		case 70717:

			if (pc.hasSkillEffect(L1SkillId.세인트)) {
				pc.sendPackets("이미 습득한 스킬입니다.");
				return;
			}
			if (!SkillsTable.getInstance().spellCheck(pc.getId(), 68)) {
				pc.sendPackets("이뮨 투 함을 습득한 후 세인트를 습득할 수 있습니다.");
				return;
			}
			if (pc.getType() == 3 && pc.getLevel() >= 80) {
				ItemUseDurableSkills.useDurablePassive(pc, l1iteminstance, L1SkillId.세인트, 0, () -> {
				// pc.세인트(true);
				pc.setSkillEffect(L1SkillId.세인트, -1);
				SC_SkillSound.send(pc, pc.getId(), 224);
				SC_SkillSound.broadcast(pc, pc.getId(), 224);

				SC_SystemMessage.send(pc, "\\aH[이뮨 투함:세인트]를 습득하였습니다.");
				SC_SystemMessage.send(pc, "\\aH이뮨 투 함을 사용 시 세인트의 효과가 지속됩니다.");
			
				});
			} else {
				pc.sendPackets("현재 [이뮨투함:세인트]를 배울 수 없는 조건입니다");

			}
			break;
		case 70718:

			if (pc.hasSkillEffect(L1SkillId.가드피어)) {
				pc.sendPackets("이미 습득한 스킬입니다.");
				return;
			}

			if (pc.hasSkillEffect(L1SkillId.가드피어호러)) {
				pc.sendPackets("상위 단계 디스트로이 패시브가 적용 중입니다.");
				return;
			}

			if (pc.getType() == 5) {
				ItemUseDurableSkills.useDurablePassive(pc, l1iteminstance, L1SkillId.가드피어, 0, () -> {
				pc.가드피어(true);
				pc.setSkillEffect(L1SkillId.가드피어, -1);
				SC_SkillSound.send(pc, pc.getId(), 224);
				SC_SkillSound.broadcast(pc, pc.getId(), 224);

				SC_SystemMessage.send(pc, "\\aH[디스트로이:피어]를 습득하였습니다.");
				SC_SystemMessage.send(pc, "\\aH가드 브레이크를 사용 시 디스트로이:피어 효과가 지속됩니다.");
			
				});
			} else {
				pc.sendPackets("현재 [디스트로이:피어]를 배울 수 없는 조건입니다");

			}
			break;

		case 70719:

			if (pc.hasSkillEffect(L1SkillId.가드피어호러)) {
				pc.sendPackets("이미 습득한 스킬입니다.");
				return;
			}
			if (!pc.hasSkillEffect(L1SkillId.가드피어)) {
				pc.sendPackets("디스트로이:피어를 습득한 후에 배울 수 있습니다.");
				return;
			}

			if (pc.getType() == 5) {
				ItemUseDurableSkills.useDurablePassive(pc, l1iteminstance, L1SkillId.가드피어호러, L1SkillId.가드피어, () -> {
				if (pc.hasSkillEffect(L1SkillId.가드피어)) {
					SC_InventoryIcon.icoEnd(pc, L1SkillId.가드피어);
					pc.removeSkillEffect(L1SkillId.가드피어);
				}

				pc.가드피어호러(true);
				pc.setSkillEffect(L1SkillId.가드피어호러, -1);
				SC_SkillSound.send(pc, pc.getId(), 224);
				SC_SkillSound.broadcast(pc, pc.getId(), 224);

				SC_SystemMessage.send(pc, "\\aH[디스트로이:호러]를 습득하였습니다.");
				SC_SystemMessage.send(pc, "\\aH가드 브레이크를 사용 시 디스트로이:호러 효과가 지속됩니다.");
			
				});
			} else {
				pc.sendPackets("현재 [디스트로이:호러]를 배울 수 없는 조건입니다");

			}
			break;

		case 70722:

			if (pc.getInventory().checkItem(70721)) {
				pc.sendPackets("이미 습득한 스킬입니다.");
				return;
			}

			if (pc.getType() == 0 && pc.getLevel() >= Config.어드밴스레벨) {

				ItemUseDurable.UseDurableExchange(pc, l1iteminstance, 70721, () -> {
					SC_SkillSound.send(pc, pc.getId(), 224);
					SC_SkillSound.broadcast(pc, pc.getId(), 224);
					SC_SystemMessage.send(pc, "\\aH[콜 클랜 어드밴스]를 습득하였습니다.");
				});

			} else {
				pc.sendPackets("현재 [콜 클랜 어드밴스]를 배울 수 없는 조건입니다");

			}
			break;
		case 44002:

			if (pc.getInventory().checkItem(44001)) {
				pc.sendPackets("이미 습득한 스킬입니다.");
				return;
			}
			if (pc.getType() == 2 && pc.getLevel() >= 85) {
				ItemUseDurable.UseDurableExchange(pc, l1iteminstance, 44001, () -> {
					SC_SkillSound.send(pc, pc.getId(), 224);
					SC_SkillSound.broadcast(pc, pc.getId(), 224);
					SC_SystemMessage.send(pc, "\\aH[버닝 샷]을 습득하였습니다.");
				});

			} else {
				pc.sendPackets("현재 [버닝 샷]을 배울 수 없는 조건입니다");

			}
			break;
		case 44001:

			if (pc.hasSkillEffect(L1SkillId.버닝샷대기)) {

				int n = pc.getSkillEffectTimeSec(L1SkillId.버닝샷대기);
				SC_SystemMessage.send(pc, String.format("\\fY버닝샷 대기시간 : %d초 후에 사용가능합니다.", n));
				return;
			}
			if (MJCommons.isNonAction(pc)) {
				return;
			}
			if (pc.isInvisble()) {
				SC_SystemMessage.send(pc, "버닝샷은 투명상태로 시전이 불가능합니다.");
				return;
			}

			if (!pc.getInventory().checkItem(40319, 2)) {
				SC_SystemMessage.send(pc, "마법재료가 부족합니다.");
				return;
			}
			//if (pc.getCurrentMp() < 30) {
			//	pc.sendPackets(new SC_ServerMessage(278)); // \f1MP가 부족해 마법을 사용할
			//	return;
			//}
			//			if (pc.isSkillDelay()) {
			//				pc.sendPackets(new SC_SystemMessage("\\f3스킬 딜레이중이므로 사용할 수 없습니다"));
			//				return;
			//			}
			if (pc.getType() == 2 && pc.getLevel() >= 85) {
				if (pc.getInventory().getTypeEquipped(1, 20) >= 1 || pc.getInventory().getTypeEquipped(1, 4) >= 1) {
					ItemUseDurableSkills.useDurableSkillReagent(pc, 40319, 2, () -> {
						if (pc.hasSkillEffect(L1SkillId.버닝샷)) {
							pc.removeSkillEffect(L1SkillId.버닝샷);
						}
						int A = (int) ((double) Config.버닝샷대미지 * 100);
						pc.setSkillEffect(L1SkillId.버닝샷대기, Config.버닝샷대기 * 1000);
						pc.setSkillEffect(L1SkillId.버닝샷, Config.버닝샷 * 1000);
						SC_InventoryIcon.icoNew(pc, L1SkillId.버닝샷, 6914, Config.버닝샷, true);
						//pc.setCurrentMp(pc.getCurrentMp() - 30);
					
						pc.setSkillEffect(STATUS_FREEZE, Config.버닝샷 * 1000);
						SC_Paralysis.send(pc, SC_Paralysis.TYPE_BIND, true);
						//				pc.sendPackets(new S_SkillSound(pc.getId(), 10909));
						//				pc.broadcastPacket(new S_SkillSound(pc.getId(), 10909));
						SC_SkillSound.send(pc, pc.getId(), 10909);
						SC_SkillSound.broadcast(pc, pc.getId(), 10909);
						pc.getResistance().addSpecialResistance(eKind.ALL, 3);
						L1EffectInstance eff1 = L1EffectSpawn.getInstance().spawnEffect(881162, Config.버닝샷 * 1000, pc.getX(), pc.getY(), pc.getMapId());
						SC_MpUpdate.send(pc, pc.getCurrentMp(), pc.getMaxMp());
						pc.sendPackets("버닝샷: 기본 데미지 +"+A+"%,전체내성 +3,PVP대미지감소+8,   지속시간 동안 이동 및 귀환 불가, 활 사거리 감소");
					
						L1SkillUse.cast(pc, L1SkillId.보조버프, pc.getId(), pc.getX(),
								pc.getY(), null, 0, L1SkillUse.TYPE_SPELLSC);
					});

				}else {
					pc.sendPackets("활을 착용 시에 사용 가능합니다.");

				}
			} else {
				pc.sendPackets("현재 [버닝샷]을 사용할 수 없는 조건입니다");

			}
			break;
		case 70735:

			//			if (pc.hasSkillEffect(L1SkillId.엘븐스트라이크대기)) {
			//
			//				int n = pc.getSkillEffectTimeSec(L1SkillId.엘븐스트라이크대기);
			//				pc.sendPackets(new SC_SystemMessage(String.format("\\fY엘븐스트라이크 쿨타임으로 인해 : %d초 후에 사용가능합니다.", n)));
			//				return;
			//			}
			if (pc.hasSkillEffect(L1SkillId.리버레이션대기)) {

				int n = pc.getSkillEffectTimeSec(L1SkillId.리버레이션대기);
				SC_SystemMessage.send(pc, String.format("\\fY리버레이션 대기시간 : %d초 후에 사용가능합니다.", n));
				return;
			}
			if (MJCommons.isNonAction(pc)) {
				return;
			}
			//			if (pc.hasSkillEffect(L1SkillId.SHOCK_STUN) || pc.hasSkillEffect(L1SkillId.EMPIRE)
			//					|| pc.hasSkillEffect(L1SkillId.EARTH_BIND) || pc.hasSkillEffect(L1SkillId.BONE_BREAK)) {
			//				return;
			//			}

			if (pc.isInvisble()) {
				SC_SystemMessage.send(pc, "리버레이션은 투명상태로 시전이 불가능합니다.");
				return;
			}

			if (!pc.getInventory().checkItem(40319, 4)) {
				SC_SystemMessage.send(pc, "마법재료가 부족합니다.");
				return;
			}
			if (pc.getCurrentMp() < 20) {
				SC_ServerMessage.send(pc, 278); // \f1MP가 부족해 마법을 사용할
				return;
			}

			if (pc.getType() == 2 && pc.getLevel() >= 85) {
				ItemUseDurableSkills.useDurableSkillReagent(pc, 40319, 4, () -> {
					if (pc.hasSkillEffect(L1SkillId.리버레이션)) {
						pc.removeSkillEffect(L1SkillId.리버레이션);
					}
					pc.setSkillEffect(L1SkillId.리버레이션대기, Config.리버레이션대기 * 1000);
					pc.setSkillEffect(L1SkillId.리버레이션, Config.리버레이션지속 * 1000);
					SC_InventoryIcon.icoNew(pc, L1SkillId.리버레이션, 5123, Config.리버레이션지속, true);
					pc.setCurrentMp(pc.getCurrentMp() - 20);
				
					SC_SkillSound.send(pc, pc.getId(), 12335);
					SC_SkillSound.broadcast(pc, pc.getId(), 12335);
					pc.sendPackets("리버레이션: 상태 이상 스킬의 시간이 감소됩니다.");
				
					L1SkillUse.cast(pc, L1SkillId.보조버프, pc.getId(), pc.getX(),
							pc.getY(), null, 0, L1SkillUse.TYPE_SPELLSC);
				});

			} else {
				pc.sendPackets("현재 [리버레이션]을 사용할 수 없는 조건입니다");

			}
			break;
		case 70730:


			if (pc.getInventory().checkItem(70735)) {
				pc.sendPackets("이미 리버레이션 스킬이 있으므로 획득할 수 없습니다.");
				return;
			}

			if (pc.getType() == 2 && pc.getLevel() >= 85) {


				ItemUseDurable.UseDurableExchange(pc, l1iteminstance, 70735, () -> {
					SC_SkillSound.send(pc, pc.getId(), 224);
					SC_SkillSound.broadcast(pc, pc.getId(), 224);
					SC_SystemMessage.send(pc, "\\aH[리버레이션]을 습득하였습니다.");
				});

			} else {
				pc.sendPackets("현재 [리버레이션]을 배울 수 없는 조건입니다");

			}
			break;
		case 220013:

			if (pc.getInventory().checkItem(220012)){
				pc.sendPackets("이미 습득한 스킬입니다.");
				return;
			}


			if (pc.getType() == 2 && pc.getLevel() >= 85) {



				ItemUseDurable.UseDurableExchange(pc, l1iteminstance, 220012, () -> {
					SC_SkillSound.send(pc, pc.getId(), 224);
					SC_SkillSound.broadcast(pc, pc.getId(), 224);
					SC_SystemMessage.send(pc, "\\aH[매직실드]를 습득하였습니다.");
				});

			} else {
				pc.sendPackets("현재 [매직실드]를 배울 수 없는 조건입니다");

			}
			break;
		case 10889:

			if (pc.hasSkillEffect(L1SkillId.카배마스터)) {
				pc.sendPackets("이미 습득한 패시브입니다.");
				return;
			}


			if (pc.getType() == 1 && pc.getLevel() >= 86) {
				ItemUseDurableSkills.useDurablePassive(pc, l1iteminstance, L1SkillId.카배마스터, 0, () -> {


				pc.setSkillEffect(L1SkillId.카배마스터, -1);
				SC_SkillSound.send(pc, pc.getId(), 224);
				SC_SkillSound.broadcast(pc, pc.getId(), 224);

				SC_SystemMessage.send(pc, "\\aH[카운터 배리어:마스터]를 습득하였습니다.");
				SC_SystemMessage.send(pc, "\\aH카운터 배리어 발동 시 HP의 일정량을 회복 합니다.");
			
				});
			} else {
				pc.sendPackets("현재 [카운터 배리어:마스터]를 배울 수 없는 조건입니다");

			}
			break;
		case 10888:

			if (pc.hasSkillEffect(L1SkillId.게일샷)) {
				pc.sendPackets("이미 습득한 패시브입니다.");
				return;
			}


			//if (pc.getType() == 2 && pc.getLevel() >= 85) {
			if (SkillsTable.getInstance().spellCheck(pc.getId(), 174) && pc.getLevel() >= 85) {
				ItemUseDurableSkills.useDurablePassive(pc, l1iteminstance, L1SkillId.게일샷, 0, () -> {

				SC_InventoryIcon.iconNewUnLimit(pc, L1SkillId.게일샷, 6913, true);
				pc.setSkillEffect(L1SkillId.게일샷, -1);
				SC_SkillSound.send(pc, pc.getId(), 224);
				SC_SkillSound.broadcast(pc, pc.getId(), 224);

				SC_SystemMessage.send(pc, "\\aH[스트라이커 게일:샷]을 습득하였습니다.");
				//pc.sendPackets(new SC_SystemMessage("\\aH스트라이커 게일 사용 시 확률:+"+Config.게일샷확률+"%, 기존 효과 및 홀드효과, 치유 회복 효과 감소가 추가됩니다."));
				SC_SystemMessage.send(pc, "\\aH스트라이커 게일 사용 시 기존 효과 및 게일 적중 확률 증가, 홀드효과, 치유 회복 효과 감소가 추가됩니다.");
			
				});
			} else {
				pc.sendPackets("현재 [스트라이커 게일:샷]을 배울 수 없는 조건입니다");

			}
			break;
		case 70731:

			if (pc.getInventory().checkItem(70888)){
				pc.sendPackets("이미 습득한 스킬입니다.");
				return;
			}


			if (pc.getType() == 2 && pc.getLevel() >= 85) {



				ItemUseDurable.UseDurableExchange(pc, l1iteminstance, 70888, () -> {
					SC_SkillSound.send(pc, pc.getId(), 224);
					SC_SkillSound.broadcast(pc, pc.getId(), 224);
					SC_SystemMessage.send(pc, "\\aH[엘븐 스트라이크]를 습득하였습니다.");
				});

			} else {
				pc.sendPackets("현재 [엘븐 스트라이크]를 배울 수 없는 조건입니다");

			}
			break;
		case 70732:
			if (pc.hasSkillEffect(L1SkillId.비욘드)) {
				pc.sendPackets("이미 습득한 스킬입니다.");
				return;
			}



			if (pc.getType() == 3 && pc.getLevel() >= 85) {
				ItemUseDurableSkills.useDurablePassive(pc, l1iteminstance, L1SkillId.비욘드, 0, () -> {


				pc.비욘드(true);
				pc.setSkillEffect(L1SkillId.비욘드, -1);
				SC_SkillSound.send(pc, pc.getId(), 224);
				SC_SkillSound.broadcast(pc, pc.getId(), 224);

				SC_SystemMessage.send(pc, "\\aH[메디테이션:비욘드]를 습득하였습니다.");

			
				});
			} else {
				pc.sendPackets("현재 [메디테이션:비욘드]를 배울 수 없는 조건입니다");

			}
			break;
		case 880800:
            ItemUseDurableSkills.usePotentialScroll(pc, l1iteminstance);
            break;
		case 707778:


			if (pc.getInventory().checkItem(707777)) {
				pc.sendPackets("이미 습득한 스킬입니다.");
				return;
			}

			if (pc.getType() == 4 && pc.getLevel() >= 80) {


				ItemUseDurable.UseDurableExchange(pc, l1iteminstance, 707777, () -> {
					SC_SkillSound.send(pc, pc.getId(), 224);
					SC_SkillSound.broadcast(pc, pc.getId(), 224);
					SC_SystemMessage.send(pc, "\\aH[쉐도우 스텝]을 습득하였습니다.");
				});

			} else {
				pc.sendPackets("현재 [쉐도우 스텝]을 배울 수 없는 조건입니다");

			}
			break;
		case 707780:


			if (pc.getInventory().checkItem(707779)) {
				pc.sendPackets("이미 습득한 스킬입니다.");
				return;
			}

			if (pc.getType() == 4 && pc.getLevel() >= 80) {


				ItemUseDurable.UseDurableExchange(pc, l1iteminstance, 707779, () -> {
					SC_SkillSound.send(pc, pc.getId(), 224);
					SC_SkillSound.broadcast(pc, pc.getId(), 224);
					SC_SystemMessage.send(pc, "\\aH[어벤저]를 습득하였습니다.");
				});

			} else {
				pc.sendPackets("현재 [어벤저]를 배울 수 없는 조건입니다");

			}
			break;
		case 707782:


			if (pc.getInventory().checkItem(707781)) {
				pc.sendPackets("이미 습득한 스킬입니다.");
				return;
			}

			if (pc.getType() == 7 && pc.getLevel() >= 85) {


				ItemUseDurable.UseDurableExchange(pc, l1iteminstance, 707781, () -> {
					SC_SkillSound.send(pc, pc.getId(), 224);
					SC_SkillSound.broadcast(pc, pc.getId(), 224);
					SC_SystemMessage.send(pc, "\\aH[데몰리션]을 습득하였습니다.");
				});

			} else {
				pc.sendPackets("현재 [데몰리션]을 배울 수 없는 조건입니다");

			}
			break;
		case 40271:

			if (pc.hasSkillEffect(L1SkillId.버닝)) {
				pc.sendPackets("이미 습득한 스킬입니다.");
				return;
			}


			if (pc.getType() == 4) {
				ItemUseDurableSkills.useDurablePassive(pc, l1iteminstance, L1SkillId.버닝, 0, () -> {


				pc.버닝(true);
				pc.setSkillEffect(L1SkillId.버닝, -1);
				SC_SkillSound.send(pc, pc.getId(), 224);
				SC_SkillSound.broadcast(pc, pc.getId(), 224);

				SC_SystemMessage.send(pc, "\\aH[버닝 스피릿츠]를 습득하였습니다.");

			
				});
			} else {
				pc.sendPackets("현재 [버닝 스피릿츠]를 배울 수 없는 조건입니다");

			}
			break;
		case 40279:

			if (pc.hasSkillEffect(L1SkillId.이베이젼)) {
				pc.sendPackets("이미 습득한 스킬입니다.");
				return;
			}


			if (pc.getType() == 4) {
				ItemUseDurableSkills.useDurablePassive(pc, l1iteminstance, L1SkillId.이베이젼, 0, () -> {


				pc.이베이젼(true);
				pc.setSkillEffect(L1SkillId.이베이젼, -1);
				SC_SkillSound.send(pc, pc.getId(), 224);
				SC_SkillSound.broadcast(pc, pc.getId(), 224);

				SC_SystemMessage.send(pc, "\\aH[드레스 이베이젼]을 습득하였습니다.");

			
				});
			} else {
				pc.sendPackets("현재 [드레스 이베이젼]을 배울 수 없는 조건입니다");

			}
			break;
		case 210008:

			if (pc.hasSkillEffect(L1SkillId.일루션리치)) {
				pc.sendPackets("이미 습득한 패시브입니다.");
				return;
			}

			if (pc.getType() == 6) {
				ItemUseDurableSkills.useDurablePassive(pc, l1iteminstance, L1SkillId.일루션리치, 0, () -> {

				pc.일루션리치(true);
				pc.setSkillEffect(L1SkillId.일루션리치, -1);
				SC_SkillSound.send(pc, pc.getId(), 224);
				SC_SkillSound.broadcast(pc, pc.getId(), 224);

				SC_SystemMessage.send(pc, "\\aH[일루션:리치]를 습득하였습니다.");

			
				});
			} else {
				pc.sendPackets("현재 [일루션:리치]를 배울 수 없는 조건입니다");

			}
			break;
		case 210013:

			if (pc.hasSkillEffect(L1SkillId.일루션골렘)) {
				pc.sendPackets("이미 습득한 패시브입니다.");
				return;
			}

			if (pc.getType() == 6) {
				ItemUseDurableSkills.useDurablePassive(pc, l1iteminstance, L1SkillId.일루션골렘, 0, () -> {

				pc.일루션골렘(true);
				pc.setSkillEffect(L1SkillId.일루션골렘, -1);
				SC_SkillSound.send(pc, pc.getId(), 224);
				SC_SkillSound.broadcast(pc, pc.getId(), 224);

				SC_SystemMessage.send(pc, "\\aH[일루션:골렘]을 습득하였습니다.");

			
				});
			} else {
				pc.sendPackets("현재 [일루션:골렘]을 배울 수 없는 조건입니다");

			}
			break;

		case 41147:

			if (pc.hasSkillEffect(L1SkillId.솔리드캐리지)) {
				pc.sendPackets("이미 습득한 패시브입니다.");
				return;
			}

			if (pc.getType() == 1) {
				ItemUseDurableSkills.useDurablePassive(pc, l1iteminstance, L1SkillId.솔리드캐리지, 0, () -> {

				pc.솔리드캐리지(true);
				pc.setSkillEffect(L1SkillId.솔리드캐리지, -1);
				SC_SkillSound.send(pc, pc.getId(), 224);
				SC_SkillSound.broadcast(pc, pc.getId(), 224);

				SC_SystemMessage.send(pc, "\\aH[솔리드 캐리지]를 습득하였습니다.");

			
				});
			} else {
				pc.sendPackets("현재 [솔리드 캐리지]을 배울 수 없는 조건입니다");

			}
			break;

		case 70720: 

			if (pc.hasSkillEffect(L1SkillId.리덕션베테랑)) {
				pc.sendPackets("이미 습득한 패시브입니다.");
				return;
			}

			if (!SkillsTable.getInstance().spellCheck(pc.getId(), 88)) {
				pc.sendPackets("리덕션 아머를 배운 후 습득가능합니다.");
				return;
			}

			if (pc.getType() == 1) {
				ItemUseDurableSkills.useDurablePassive(pc, l1iteminstance, L1SkillId.리덕션베테랑, 0, () -> {

				if (pc.hasSkillEffect(L1SkillId.REDUCTION_ARMOR)) {
					pc.removeSkillEffect(L1SkillId.REDUCTION_ARMOR);
				}

				pc.setSkillEffect(L1SkillId.리덕션베테랑, -1);
				SC_SkillSound.send(pc, pc.getId(), 224);
				SC_SkillSound.broadcast(pc, pc.getId(), 224);

				SC_SystemMessage.send(pc, "\\aH[리덕션아머:베테랑]을 습득하였습니다.");
				SC_SystemMessage.send(pc, "\\aH리덕션 아머 사용 시 공포내성 +3 효과가 적용됩니다.");
			
				});
			} else {
				pc.sendPackets("현재 [리덕션아머:베테랑]을 배울 수 없는 조건입니다");

			}
			break;
		case 40224:

			if (pc.hasSkillEffect(L1SkillId.어드밴스)) {
				pc.sendPackets("이미 습득한 패시브입니다.");
				return;
			}

			if (pc.getType() == 3) {
				ItemUseDurableSkills.useDurablePassive(pc, l1iteminstance, L1SkillId.어드밴스, 0, () -> {
				if (pc.hasSkillEffect(L1SkillId.ADVANCE_SPIRIT)) {
					pc.removeSkillEffect(L1SkillId.ADVANCE_SPIRIT);
				}

				pc.어드밴스(true);
				pc.setSkillEffect(L1SkillId.어드밴스, -1);
				SC_SkillSound.send(pc, pc.getId(), 224);
				SC_SkillSound.broadcast(pc, pc.getId(), 224);

				SC_SystemMessage.send(pc, "\\aH[어드밴스 스피릿]이 적용되었습니다.");

			
				});
			} else {
				pc.sendPackets("현재 [어드밴스 스피릿]을 배울 수 없는 조건입니다");

			}
			break;
		case 4100100:

			if (pc.hasSkillEffect(L1SkillId.프라이드)) {
				pc.sendPackets("이미 습득한 패시브입니다.");
				return;
			}

			if (pc.getType() == 1) {
				ItemUseDurableSkills.useDurablePassive(pc, l1iteminstance, L1SkillId.프라이드, 0, () -> {

				SC_HpUpdate.send(pc, pc.getCurrentHp(), pc.getMaxHp());
				pc.프라이드(true);
				pc.setSkillEffect(L1SkillId.프라이드, -1);
				SC_SkillSound.send(pc, pc.getId(), 224);
				SC_SkillSound.broadcast(pc, pc.getId(), 224);

				SC_SystemMessage.send(pc, "\\aH[프라이드]를 습득하였습니다.");

			
				});
			} else {
				pc.sendPackets("현재 [프라이드]을 배울 수 없는 조건입니다");

			}
			break;

		case 70740:

			ItemUseDurable.UseImmuneBlade(pc);

			break;
		case 70741:


			if (pc.getInventory().checkItem(70740)) {
				pc.sendPackets("이미 습득한 스킬입니다.");
				return;
			}

			if (pc.getLevel() >= Config.이뮨투함블레이드레벨) {
				if (MJCommons.isNonAction(pc)) {
					return;
				}
				//				if (pc.hasSkillEffect(L1SkillId.SHOCK_STUN) || pc.hasSkillEffect(L1SkillId.EMPIRE)
				//						|| pc.hasSkillEffect(L1SkillId.EARTH_BIND) || pc.hasSkillEffect(L1SkillId.BONE_BREAK)) {
				//					return;
				//				}

				ItemUseDurable.UseDurableExchange(pc, l1iteminstance, 70740, () -> {
					SC_SkillSound.send(pc, pc.getId(), 224);
					SC_SkillSound.broadcast(pc, pc.getId(), 224);
					SC_SystemMessage.send(pc, "\\aH[이뮨 투 함 블레이드]를 습득하였습니다.");
				});

			} else {
				pc.sendPackets("현재 [이뮨 투 함 블레이드]를 배울 수 없는 조건입니다");

			}
			break;


        }
    }

    private static boolean isInWarAreaAndWarTime(L1PcInstance pc) {
        int castleId = L1CastleLocation.getCastleIdByArea(pc);
        return castleId != 0 && MJCastleWarBusiness.getInstance().isNowWar(castleId);
    }
}
