package l1j.server.server.packets.Protocol.Packet;

import l1j.server.server.model.Instance.L1PcInstance;
import l1j.server.server.packets.Protocol.Proto;
import l1j.server.server.ThreadPool;
import l1j.server.server.model.network.core.CIOClient;
import l1j.server.server.model.network.safe.NetworkSafeLoadManager;
import l1j.server.server.packets.Protocol.ProtoMsg;
import l1j.server.server.packets.Protocol.ProtoPacket;
import l1j.server.server.packets.Protocol.ProtoWriter;

/**
 * 서버 버전 정보 — 접속 초기 핸드셰이크 (캐릭터 생성 전이라 GameClient 직접 전송)
 * 정상 : 17필드 전체 / 버전 불일치 : version_check=1만 담고 3초 후 소켓 종료
 */
public final class SC_ServerVersionInfo extends ProtoPacket {

    private static final int STATUS_START_TIME = (int) (System.currentTimeMillis() / 1000L);

    private final boolean _accept;

    private SC_ServerVersionInfo(boolean accept) { 
    	_accept = accept;
    }

    /** 버전 일치 — 정상 버전 정보 응답 */
    public static void send(CIOClient clnt) {
    //	System.out.println("[SC] 버전정보 SEND");
        SC_ServerVersionInfo.sendConstructed(clnt, true);
    }

    /** 버전 불일치 — 거절 응답 후 3초 뒤 접속 종료 */
    public static void denial(CIOClient clnt) {
    //	System.out.println("[SC] DENIAL - 3초 후 종료");
        SC_ServerVersionInfo.sendConstructed(clnt, false);
        if (ThreadPool.getInstance().schedule(() -> {
            try { clnt.close(); } catch (Exception e) {}
        }, 3000L) == null) {
            // A denied client must not remain connected when the delayed
            // close cannot be admitted. Closing is preferable to an open socket.
            clnt.close();
        }
    }

    @Override
    public int msgId() { return ProtoMsg.SC_SERVER_VERSION_INFO; }

    @Override
    protected void body(ProtoWriter w) {
        if (!_accept) {
            w.uint32(1, 1);   // version_check = 1 (거절)
            return;
        }
        w.uint32(1, 0)                                                   // version_check
         .uint32(2, 0)                                                   // server_id
         .int32(3, NetworkSafeLoadManager.NS_CLIENT_VERSION)             // build_number
         .int32(4, NetworkSafeLoadManager.NS_CLIENT_VERSION)             // cache_version
         .int32(5, NetworkSafeLoadManager.NS_AUTHSERVER_VERSION)         // auth_version
         .int32(6, NetworkSafeLoadManager.NS_CLIENT_VERSION)             // npc_server_version
         .int32(7, STATUS_START_TIME)                                    // status_start_time
         .int32(8, 0x00)                                                 // english_only_config
         .int32(9, 0x00)                                                 // country_code
         .int32(10, NetworkSafeLoadManager.NS_CLIENT_SETTING_SWITCH)     // client_setting_switch
         .int32(11, (int) (System.currentTimeMillis() / 1000L))          // game_real_time
         .int32(12, NetworkSafeLoadManager.NS_CACHESERVER_VERSION)       // global_cache_version
         .int32(13, NetworkSafeLoadManager.NS_TAMSERVER_VERSION)         // tam_server_version
         .int32(14, NetworkSafeLoadManager.NS_ARCASERVER_VERSION)        // arca_server_version
         .int32(15, NetworkSafeLoadManager.NS_HIBREED_INTERSERVER_VERSION) // hibreed_inter_server_version
         .int32(16, NetworkSafeLoadManager.NS_ARENACOSERVER_VERSION)     // arenaco_server_version
         .int32(17, 0x00);                                               // server_type
    }


    /** Direct serialization with primitive presence bits; no message instance. */
    public static void writeFields(ProtoWriter w, boolean _accept) {
        if (!_accept) {
                w.uint32(1, 1);
                return;
            }
            w.uint32(1, 0).uint32(2, 0).int32(3, NetworkSafeLoadManager.NS_CLIENT_VERSION).int32(4, NetworkSafeLoadManager.NS_CLIENT_VERSION).int32(5, NetworkSafeLoadManager.NS_AUTHSERVER_VERSION).int32(6, NetworkSafeLoadManager.NS_CLIENT_VERSION).int32(7, STATUS_START_TIME).int32(8, 0).int32(9, 0).int32(10, NetworkSafeLoadManager.NS_CLIENT_SETTING_SWITCH).int32(11, (int)(System.currentTimeMillis() / 1000L)).int32(12, NetworkSafeLoadManager.NS_CACHESERVER_VERSION).int32(13, NetworkSafeLoadManager.NS_TAMSERVER_VERSION).int32(14, NetworkSafeLoadManager.NS_ARCASERVER_VERSION).int32(15, NetworkSafeLoadManager.NS_HIBREED_INTERSERVER_VERSION).int32(16, NetworkSafeLoadManager.NS_ARENACOSERVER_VERSION).int32(17, 0);
    }

    public static boolean sendFields(L1PcInstance recipient, boolean _accept) {
        return sendFields(recipient == null ? null : recipient.getNetConnection(), _accept);
    }

    public static boolean sendFields(CIOClient recipient, boolean _accept) {
        final ProtoWriter writer = Proto.begin(recipient, ProtoMsg.SC_SERVER_VERSION_INFO, Proto.capacityBound(1024L));
        if (writer == null) return false;
        try {
            writeFields(writer, _accept);
            return Proto.commit(writer);
        } finally {
            Proto.abort(writer);
        }
    }

    public static byte[] encodeFields(boolean _accept) {
        final ProtoWriter writer = ProtoWriter.tl();
        writeFields(writer, _accept);
        return writer.finishWithTrailer(ProtoMsg.SC_SERVER_VERSION_INFO);
    }

    private static boolean sendCtor(CIOClient protoRecipient, boolean accept) {
        boolean proto57_accept = false;

            proto57_accept = accept;

        return sendFields(protoRecipient, proto57_accept);
    }
    public static boolean sendConstructed(CIOClient protoRecipient, boolean accept) { return sendCtor(protoRecipient, accept); }

    public static boolean sendConstructed(
            L1PcInstance protoRecipient, boolean accept) { return sendCtor(protoRecipient == null ? null : protoRecipient.getNetConnection(), accept); }

}
