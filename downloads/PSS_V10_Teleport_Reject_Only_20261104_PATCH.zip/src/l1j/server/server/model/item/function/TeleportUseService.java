package l1j.server.server.model.item.function;

import l1j.server.server.model.network.core.sc.packet.SC_Paralysis;
import java.util.concurrent.ThreadLocalRandom;

import l1j.server.Config;
import l1j.server.server.model.L1Location;
import l1j.server.server.model.L1World;
import l1j.server.server.model.Instance.L1ItemInstance;
import l1j.server.server.model.Instance.L1PcInstance;
import l1j.server.server.model.character.skill.L1SkillId;
import l1j.server.server.model.gametime.L1GameTimeClock;
import l1j.server.server.model.map.L1Map;
import l1j.server.server.model.map.L1WorldMap;
import l1j.server.server.model.network.core.sc.packet.SC_DoActionGFX;
import l1j.server.server.model.network.core.sc.packet.SC_ServerMessage;
import l1j.server.server.model.network.core.sc.packet.SC_SystemMessage;
import l1j.server.server.templates.L1BookMark;
import l1j.server.server.model.character.pss.ClientAutomationSession;

public final class TeleportUseService {

    private TeleportUseService() {}

    /** Ordinary GM teleport remains available; native PSS follows player map rules. */
    public static boolean canBypassMapRestrictions(L1PcInstance pc) {
        if (pc == null || !pc.isGm()) return false;
        final var client = pc.getNetConnection();
        final var session = client == null ? null : client.getAutomationSession();
        return client == null || !client.requiresPlayerTeleportRules()
                && (session == null || session == ClientAutomationSession.SERVER);
    }

    // --- allocations 제거용 상수 ---
    private static final int[] TOWER_KEYS = {
        830022,830023,830024,830025,830026,830027,830028,830029,830030,830031
    };
    private static final int EQUIP_PRECISE_TELEPORT[] = { 20288, 900111 };

    // =========================================================
    // Public API (아이템용)
    // =========================================================
    public static void clickItem(L1PcInstance pc, int itemId,
                                 int bookmarkX, int bookmarkY, short bookmarkMapId,
                                 L1ItemInstance consumeItem) {
        if (pc == null) return;

        try {
            if (!preCheckTeleportState(pc)) return;

            final boolean hasBookmark = (bookmarkX != 0);

            if (hasBookmark) {
                if (!isValidBookmark(pc, bookmarkX, bookmarkY, bookmarkMapId)) {
                    if (itemId == 40100) {
                        if (!canRandomTeleportHere(pc)) {
                            return;
                        }
                        doRandomTeleport(pc, 0, consumeItem);
                    } else {
                        SC_ServerMessage.send(pc, 79);
                        pc.tpEndFinish();
                    }
                    return;
                }

                if (!(pc.getMap().isEscapable() || TeleportUseService.canBypassMapRestrictions(pc))) {
                    SC_ServerMessage.send(pc, 79);
                    pc.tpEndFinish();
                    return;
                }
                if (consumeItem != null) {
                    ItemUseDurable.UseDurableConsume(pc, consumeItem, () -> {
                        pc.start_teleport(bookmarkX, bookmarkY, bookmarkMapId, pc.getHeading(), 169, true, false);
                        pc.cancelAbsoluteBarrier();
                        pc.cancelMoebius();
                    });
                } else {
                    pc.start_teleport(bookmarkX, bookmarkY, bookmarkMapId, pc.getHeading(), 169, true, false);
                }
                return;
            }

            if (!canRandomTeleportHere(pc)) {
                            return;
                        }
            doRandomTeleport(pc, 0, consumeItem);

        } finally {
            if (consumeItem == null) {
                pc.cancelAbsoluteBarrier();
                pc.cancelMoebius();
            }
        }
    }

    // =========================================================
    // Public API (스킬 TELEPORT/MASS_TELEPORT용)
    // =========================================================
    public static void handleSkillTeleport(L1PcInstance pc,
                                           int skillId,
                                           int bookmarkX, int bookmarkY, short bookmarkMapId) {
        if (pc == null) return;

        try {
            if (!preCheckTeleportState(pc)) 
            	return;

            final boolean hasBookmark = (bookmarkX != 0);

            if (hasBookmark) {
                if (!(pc.getMap().isEscapable() || TeleportUseService.canBypassMapRestrictions(pc))) {
                    SC_Paralysis.send(pc, SC_Paralysis.TYPE_TELEPORT_UNLOCK, false);
                    SC_ServerMessage.send(pc, 79);
                    pc.tpEndFinish();
                    return;
                }

                final L1Map map = L1WorldMap.getInstance().getMap(bookmarkMapId);

                if (skillId == L1SkillId.MASS_TELEPORT) {
                    teleportClanMembersAroundBookmarkMass(pc, bookmarkX, bookmarkY, bookmarkMapId, map);
                }
                final boolean precise = pc.getInventory().checkEquippedAtOnce(EQUIP_PRECISE_TELEPORT);
                if (precise) {
                    pc.start_teleport(bookmarkX, bookmarkY, bookmarkMapId, pc.getHeading(), 169, true, true);
                } else {
                    int nx = bookmarkX + ThreadLocalRandom.current().nextInt(15);
                    int ny = bookmarkY + ThreadLocalRandom.current().nextInt(15);
                    if (map.isInMap(nx, ny) && map.isPassable(nx, ny)) {
                        pc.start_teleport(nx, ny, bookmarkMapId, pc.getHeading(), 169, true, true);
                    } else {
                        pc.start_teleport(bookmarkX, bookmarkY, bookmarkMapId, pc.getHeading(), 169, true, true);
                    }
                }
                return;
            }

            if (!canRandomTeleportHere(pc)) {
                            return;
                        }
            doRandomTeleport(pc, skillId, null);

        } finally {
        	pc.cancelAbsoluteBarrier();
        	pc.cancelMoebius();
        }
    }

    // =========================================================
    // pre-check
    // =========================================================
    private static boolean preCheckTeleportState(L1PcInstance pc) {
        try {

    		if (pc.hasSkillEffect(L1SkillId.이터디스) || pc.hasSkillEffect(L1SkillId.쉐도우제약)) {
    		    pc.tpEndFinish();
    			return false;
    		}
    		if (pc.hasSkillEffect(L1SkillId.버닝샷)) {
    			SC_SystemMessage.send(pc, "\\fY버닝샷중에는 이동 및 귀환이 불가합니다.");
    		    pc.tpEndFinish();
    			return false;
    		}
        	// 스킬 상태나 어떠한 경우에 실패처리
        	
        } catch (Throwable ignore) {}
        return true;
    }

    // =========================================================
    // Bookmark validate
    // =========================================================
    private static boolean isValidBookmark(L1PcInstance pc, int x, int y, short mapId) {
        try {
            for (L1BookMark b : pc.getBookMarkArray()) {
                if (b.getLocX() == x && b.getLocY() == y && b.getMapId() == mapId) return true;
            }
        } catch (Throwable ignore) {}
        return false;
    }

    // =========================================================
    // Map restrictions for RANDOM teleport
    // =========================================================
    private static boolean canRandomTeleportHere(L1PcInstance pc) {
        final int mapId = pc.getMapId();

        if (mapId >= 101 && mapId <= 110) {
            L1ItemInstance need = pc.getInventory().findItemId(TOWER_KEYS[mapId - 101]);
            L1ItemInstance alt  = pc.getInventory().findItemId(560028);
            if (need != null || alt != null) return true;
            SC_ServerMessage.send(pc, 276);
            pc.tpEndFinish();
            return false;
        }

        if (mapId >= 12852 && mapId <= 12861) {
            L1ItemInstance need = pc.getInventory().findItemId(TOWER_KEYS[mapId - 12852]);
            L1ItemInstance alt  = pc.getInventory().findItemId(4100135);
            if (need != null || alt != null) return true;
            SC_ServerMessage.send(pc, 276);
            pc.tpEndFinish();
            return false;
        }

        if (mapId == 54 && !TeleportUseService.canBypassMapRestrictions(pc)) {
            if (Config.PRISONTEL) {
                long t = L1GameTimeClock.getInstance().getGameTime().getSeconds() % 86400;
                if (t >= 60 * 60 * 20 || t <= 60 * 60 * 6) {
                    pc.tpEndFinish();
                    SC_ServerMessage.send(pc, 6648);
                    return false;
                }
                if (Config.PRISONTELS) return true;
                pc.tpEndFinish();
                SC_ServerMessage.send(pc, 276);
                return false;
            }

            if (Config.PRISONTELS) return true;

            pc.tpEndFinish();
            SC_ServerMessage.send(pc, 276);
            return false;
        }

        if (mapId >= 1708 && mapId <= 1709 && !TeleportUseService.canBypassMapRestrictions(pc)) {
            pc.tpEndFinish();
            SC_ServerMessage.send(pc, 276);
            return false;
        }

        L1Map map = pc.getMap();
        if (map.isTeleportable() || TeleportUseService.canBypassMapRestrictions(pc) || (pc.getInventory().checkItem(900111) && map.isRuler())) {
            return true;
        }
        pc.tpEndFinish();
        SC_ServerMessage.send(pc, 276);
        return false;
    }

    // =========================================================
    // Random teleport execution
    // =========================================================
    private static void doRandomTeleport(L1PcInstance pc, int skillId, L1ItemInstance consumeItem) {
        final L1Location loc = pc.getLocation().randomLocation(200, true);
        final int x = loc.getX();
        final int y = loc.getY();
        final short mapId = (short) loc.getMapId();

        if (consumeItem != null) {
            ItemUseDurable.UseDurableConsume(pc, consumeItem, () -> {
                executeRandomTeleport(pc, skillId, x, y, mapId);
                pc.cancelAbsoluteBarrier();
                pc.cancelMoebius();
            });
        } else {
            executeRandomTeleport(pc, skillId, x, y, mapId);
        }
    }

    private static void executeRandomTeleport(L1PcInstance pc, int skillId,
                                              int x, int y, short mapId) {
        if (skillId == L1SkillId.MASS_TELEPORT) {
            doMassTeleportRandom(pc, x, y, mapId);
        } else if (skillId == L1SkillId.TELEPORT) {
            startAction(pc);
            pc.start_teleport(x, y, mapId, pc.getHeading(), 169, true, true);
        } else {
            pc.start_teleport(x, y, mapId, pc.getHeading(), 169, true, false);
        }
    }

    private static void doMassTeleportRandom(L1PcInstance pc, int x, int y, short mapId) {
        final int clanId = pc.getClanid();
        if (clanId == 0) { // 원본도 clan 체크 있었음
            startAction(pc);
            pc.start_teleport(x, y, mapId, pc.getHeading(), 169, true, true);
            return;
        }

        final L1Map map = L1WorldMap.getInstance().getMap(mapId);
        startAction(pc);

        for (L1PcInstance m : L1World.getInstance().getVisiblePlayer(pc, 3)) {
            if (m == null) continue;
            if (m.getClanid() != clanId) continue;
            if (m.getId() == pc.getId()) continue;
            if (m.isPrivateShop()) continue;

            int nx = x + ThreadLocalRandom.current().nextInt(3) + 1;
            int ny = y + ThreadLocalRandom.current().nextInt(3) + 1;

            if (map.isInMap(nx, ny) && map.isPassable(nx, ny)) {
                m.start_teleport(nx, ny, mapId, m.getHeading(), 169, true, true);
            } else {
                m.start_teleport(x, y, mapId, m.getHeading(), 169, true, true);
            }
        }

        int nx = x + ThreadLocalRandom.current().nextInt(3) + 1;
        int ny = y + ThreadLocalRandom.current().nextInt(3) + 1;

        if (map.isInMap(nx, ny) && map.isPassable(nx, ny)) {
            pc.start_teleport(nx, ny, mapId, pc.getHeading(), 169, true, true);
        } else {
            pc.start_teleport(x, y, mapId, pc.getHeading(), 169, true, true);
        }
    }

  
    // =========================================================
    // 스킬 북마크 MASS: 주변 분산
    // =========================================================
    private static void teleportClanMembersAroundBookmarkMass(L1PcInstance pc,
                                                             int bx, int by, short mapId,
                                                             L1Map map) {
        final int clanId = pc.getClanid();
        if (clanId == 0) return;

        for (L1PcInstance m : L1World.getInstance().getVisiblePlayer(pc, 3)) {
            if (m == null) continue;
            if (m.getClanid() != clanId) continue;
            if (m.getId() == pc.getId()) continue;
            if (m.isPrivateShop()) continue;

            int nx = bx + ThreadLocalRandom.current().nextInt(3) + 1;
            int ny = by + ThreadLocalRandom.current().nextInt(3) + 1;

            if (map.isInMap(nx, ny) && map.isPassable(nx, ny)) {
                m.start_teleport(nx, ny, mapId, m.getHeading(), 169, true, true);
            } else {
                m.start_teleport(bx, by, mapId, m.getHeading(), 169, true, true);
            }
        }
    }

    // =========================================================
    // Packets / consume
    // =========================================================
    private static void startAction(L1PcInstance pc) {
    	SC_DoActionGFX.send(
    	        pc.getNetConnection(),
    	        pc.getId(),
    	        19);

    	SC_DoActionGFX.broadcast(
    	        pc,
    	        19);
    }

}
