from pathlib import Path
import hashlib,json,subprocess

R=Path(__file__).resolve().parent
SOURCE=Path('/workspace/rkern-network-npc/work/src')
PKG='l1j/server/server/model/network/'
actual=[PKG+'core/'+n+'.java' for n in ['CIOUserSocket','CIOServer','CIOFrame','CIOBufferPool','CIOSlotPool']]
actual += [PKG+x+'.java' for x in ['buffer/ReadBuffer','buffer/WriteBuffer','codec/Cryptor','packet/WritablePacket']]
actual += ['l1j/server/server/model/character/CYieldLock.java']
stubs={
 'l1j/server/server/Opcodes.java':'package l1j.server.server; public final class Opcodes {public static final int S_ACTION=19;}',
 PKG+'utill/ConnectionConfig.java':'package l1j.server.server.model.network.utill; public final class ConnectionConfig {public static final int HEADER_SIZE=2; public static int PACKET_LIMIT_PER_SEC=100000000;}',
 PKG+'thread/CIOThreadCallback.java':'package l1j.server.server.model.network.thread; public final class CIOThreadCallback {public int shardCount(){return 1;}}',
 PKG+'safe/NetworkSafeLoadManager.java':'''package l1j.server.server.model.network.safe;
import l1j.server.server.model.network.core.CIOClient; public final class NetworkSafeLoadManager {
 public static final int RESULT_FILTER=4; public static int isFilter(CIOClient c,int op){return 2;}}
''',
 PKG+'core/CIOClient.java':'''package l1j.server.server.model.network.core;
public final class CIOClient {
 final CIOUserSocket socket; public int nextSeq,empty;
 public CIOClient(CIOUserSocket s){socket=s;} public CIOUserSocket getConnection(){return socket;}
 public boolean isConnected(){return socket.isClientConnected();} public boolean isGameSessionReady(){return true;}
 public void disconnect(){socket.close();} public int incrementEmptyPacketCount(){return ++empty;}
 public void resetEmptyPacketCount(){empty=0;} public boolean checkPacketRateLimit(long t){return false;}
}''',
 PKG+'packet/CPacketHandler.java':'''package l1j.server.server.model.network.packet;
import l1j.server.server.model.network.buffer.ReadBuffer;
import l1j.server.server.model.network.core.*;
public final class CPacketHandler {
 public interface PacketHandler {boolean execute(ReadBuffer b,CIOClient c);}
 public static final PacketHandler[] HANDLERS=new PacketHandler[256];
 static { HANDLERS[1]=(b,c)->{NettyBench.handleRKern(c,b);return true;}; }
 public static boolean isFastOpcode(int op){return op==1;}
 public static boolean isDirectOpcode(int op){return op==1;}
 public static boolean isSessionOpcode(int op){return false;}
}'''
}
for rel,data in stubs.items():
 p=R/'stubs'/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(data)
(R/'classes').mkdir(exist_ok=True)
sources=[str(SOURCE/x) for x in actual]+[str(R/'stubs'/x) for x in stubs]+[str(R/'NettyBench.java')]
cmd=['java','com.sun.tools.javac.Main','-encoding','UTF-8','-cp',':'.join(str(p) for p in sorted((R/'lib').glob('*.jar'))),'-d',str(R/'classes'),*sources]
subprocess.run(cmd,check=True)
(R/'source-manifest.json').write_text(json.dumps({'source_root':str(SOURCE),
 'actual_sha256':{x:hashlib.sha256((SOURCE/x).read_bytes()).hexdigest() for x in actual},
 'stub_sha256':{x:hashlib.sha256((R/'stubs'/x).read_bytes()).hexdigest() for x in stubs},
 'harness_sha256':hashlib.sha256((R/'NettyBench.java').read_bytes()).hexdigest(),
 'command':cmd},indent=2)+'\n')
print('Compiled actual RKern transport, common cipher/buffers, isolated game boundary, and Netty adapter/client.')
