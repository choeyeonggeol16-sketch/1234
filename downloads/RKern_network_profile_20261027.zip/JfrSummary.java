import java.nio.file.*;
import java.time.*;
import java.util.*;
import jdk.jfr.consumer.*;

public class JfrSummary {
 static void inc(Map<String,Long> m,String s,long n){m.merge(s,n,Long::sum);}
 static String method(RecordedFrame f){return f.getMethod().getType().getName()+"."+f.getMethod().getName();}
 static void print(Map<String,Long> m,int top){m.entrySet().stream().sorted(Map.Entry.<String,Long>comparingByValue().reversed()).limit(top).forEach(x->System.out.println(x.getValue()+"\t"+x.getKey()));}
 public static void main(String[] args)throws Exception{
  Instant begin=null,end=null;
  for(String line:Files.readAllLines(Path.of(args[1]))){if(line.startsWith("PROFILE_START "))begin=Instant.parse(line.substring(14));if(line.startsWith("PROFILE_END "))end=Instant.parse(line.substring(12));}
  if(begin==null||end==null)throw new IllegalStateException("missing measurement markers");
  Map<String,Long> events=new HashMap<>(),leaves=new HashMap<>(),nativeLeaves=new HashMap<>(),inclusive=new HashMap<>(),stacks=new HashMap<>(),allocation=new HashMap<>(),waits=new HashMap<>(),threads=new HashMap<>();
  try(RecordingFile file=new RecordingFile(Path.of(args[0]))){while(file.hasMoreEvents()){
   RecordedEvent e=file.readEvent();if(e.getStartTime().isBefore(begin)||e.getStartTime().isAfter(end))continue;
   String name=e.getEventType().getName();inc(events,name,1);RecordedStackTrace trace=e.getStackTrace();
   if(name.equals("jdk.ExecutionSample")||name.equals("jdk.NativeMethodSample")){
    if(trace==null||trace.getFrames().isEmpty())continue;
    if(name.equals("jdk.NativeMethodSample")){inc(nativeLeaves,method(trace.getFrames().get(0)),1);continue;}
    String state=e.hasField("state")?e.getString("state"):"unknown";
    inc(threads,e.getThread("sampledThread").getJavaName()+" ["+state+"]",1);
    List<RecordedFrame> fs=trace.getFrames();inc(leaves,method(fs.get(0)),1);
    HashSet<String> seen=new HashSet<>();StringBuilder stack=new StringBuilder();
    for(RecordedFrame f:fs){String m=method(f);seen.add(m);if(stack.length()!=0)stack.append(";");stack.append(m);}
    for(String m:seen)inc(inclusive,m,1);inc(stacks,stack.toString(),1);
   }else if(name.equals("jdk.ObjectAllocationSample")){
    RecordedThread thread=e.getThread();String threadName=thread==null?"":thread.getJavaName();
    if(!threadName.startsWith("RKern-IOCP-")&&!threadName.startsWith("epollEventLoopGroup-"))continue;
    String type=e.getClass("objectClass").getName();long weight=e.getLong("weight");
    String site=trace==null||trace.getFrames().isEmpty()?"unknown":method(trace.getFrames().get(0));inc(allocation,type+" @ "+site,weight);
   }else if(name.equals("jdk.ThreadPark")||name.equals("jdk.JavaMonitorEnter")||name.equals("jdk.SocketWrite")||name.equals("jdk.SocketRead")){
    String site=trace==null||trace.getFrames().isEmpty()?"unknown":method(trace.getFrames().get(0));inc(waits,name+" @ "+site,e.getDuration().toNanos());
   }
  }}
  System.out.println("WINDOW "+begin+" "+end);
  System.out.println("EVENTS");print(events,80);System.out.println("THREADS");print(threads,25);
  System.out.println("LEAF_SAMPLES");print(leaves,35);System.out.println("INCLUSIVE_SAMPLES");print(inclusive,60);
  System.out.println("NATIVE_METHOD_SAMPLES_SEPARATE");print(nativeLeaves,20);
  System.out.println("ALLOCATION_ESTIMATED_BYTES");print(allocation,25);System.out.println("WAIT_EVENT_NS");print(waits,20);
  System.out.println("STACKS");print(stacks,30);
 }
}
