﻿원래 PSS 시험본 도구로 게임에 먼저 연결합니다.
그 다음 client/source-link/PSS_Item_Link.cmd를 실행하고, 콘솔의 .psslink 한 줄을 게임에 한 번 입력합니다.
READY가 나오면 ID 900000901 PSS 설정서를 사용합니다. 이번 서버 소스와 SQL이 필요합니다.
설정창만 지금 열려면 PSS_Open_Now.cmd를 더블클릭합니다. 이 기능은 서버 변경이 필요 없습니다.
자세한 적용 방법은 GitHub의 PSS_ITEM_SETTINGS_WINDOW_20261104.md에 있습니다.
