package l1j.server.server.model.network.packet;
import l1j.server.server.model.network.buffer.ReadBuffer;
import l1j.server.server.model.network.core.*;
public final class CPacketHandler {
 public interface PacketHandler {boolean execute(ReadBuffer b,CIOClient c);}
 public static final PacketHandler[] HANDLERS=new PacketHandler[256];
 static { HANDLERS[1]=(b,c)->{NettyBench.handleRKern(c,b);return true;}; }
 public static boolean isFastOpcode(int op){return op==1;}
 public static boolean isDirectOpcode(int op){return op==1;}
 public static boolean isSessionOpcode(int op){return false;}
}