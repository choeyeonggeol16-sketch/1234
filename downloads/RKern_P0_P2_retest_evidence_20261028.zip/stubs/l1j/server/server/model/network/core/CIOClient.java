package l1j.server.server.model.network.core;
public final class CIOClient {
 final CIOUserSocket socket; public int nextSeq,empty; public int[] batchObjects,batchActions;
 public CIOClient(CIOUserSocket s){socket=s;} public CIOUserSocket getConnection(){return socket;}
 public boolean isConnected(){return socket.isClientConnected();} public boolean isGameSessionReady(){return true;}
 public void disconnect(){socket.close();} public int incrementEmptyPacketCount(){return ++empty;}
 public void resetEmptyPacketCount(){empty=0;} public boolean checkPacketRateLimit(long t){return false;}
}