# RKern FIFO/group/batch/READ 패치 재시험

직전 업로드 대비 기본 경로의 작은 묶음 +50.5%, 다중 연결 +30.1%, 4KiB 송신 +14.2%.
FIFO 재현 조건은 통과했지만 4KiB p99와 임시 SEND backing 회귀는 남았다.
자세한 결과와 다음 수정 위치는 RKern_P0_P2_RETEST_REPORT_20261028.md를 읽는다.
ZIP 내부 보고서의 증거 ZIP 링크는 GitHub 저장소 루트 기준이다.

## 구성

- sources/v5: 옛 v5의 실제 transport/buffer/cipher Java 10개.
- sources/before: 바로 직전 전체 업로드의 동일 경계 Java 10개.
- sources/patched: 이번 업로드의 두 파일만 덮은 동일 경계 Java 10개.
- stubs와 harness: 게임 경계를 분리한 동일 서버 adapter와 고정 원래 v5 클라이언트.
- results: 54회 주 성능 실행. tuning-: 18회 별도 설정 대조. 두 실험 표는 서로 섞지 않는다.
- fifo-*, deep-window-, full-byte-smoke-: 정합성 실행 18회 통과와 직전 버전 실패 1회.
- regressions: 통과 단언 3,296개와 기존 SEND backing 단언 1개 실패를 포함한 로그·소스.
- profile-: 프로파일 실행 명령/성능 참고 로그. 72회 성능 점수에 합산하지 않는다.
- profile-clean: 측정 구간 method/count/stack 집계만 포함한다. 원본 JFR은 포함하지 않는다.
- context: batch 호출 연결 및 cipher 수명 검토용 실제 게임 경계 두 파일. 벤치 빌드 대상은 아니다.
- SHA256SUMS.json: 이 패키지 파일의 SHA-256. dependency JAR은 포함하지 않으며 고정 URL/해시로 받는다.

## 빌드·재현

Linux x86_64, JDK 21, Python 3, taskset, CPU 0/1(서버) 및 2/3(클라이언트)가 필요하다.
환경에 맞춰 affinity를 바꾸면 결과에 변경 사항을 기록한다.

    python3 build.py --fetch-deps
    python3 run.py --mode measure --rounds 3 --warmup 5 --seconds 5 --targeted-controls --case latency-1 --case burst-128 --case many-1024 --case bulk-tx-64 --engine rkern-v5 --engine rkern-before --engine rkern-patched --engine netty-epoll --engine rkern-before-batch --engine rkern-patched-batch --label reproduction-main
    python3 run.py --mode measure --rounds 3 --warmup 5 --seconds 5 --tuning-controls --case burst-128 --case bulk-tx-64 --engine rkern-patched-batch --engine rkern-patched-batch-high256 --engine rkern-patched --engine rkern-patched-pooled32 --engine netty-epoll --label reproduction-tuning
    python3 run.py --mode measure --exact --rounds 3 --warmup 1 --seconds 1 --case fairness-16 --engine rkern-patched --engine rkern-patched-pooled32 --label reproduction-fifo
    python3 run.py --mode smoke --warmup 1 --seconds 1 --case burst-128 --engine rkern-patched-batch --label reproduction-wire

원래 결과를 덮지 않도록 항상 다른 --label을 사용한다. 각 raw.json에 실제 server/client 명령이 있다.
고정 클라이언트를 모든 서버에 동일하게 사용하며 Netty에는 common-cipher를 classpath 앞에 둔다.
패키지 stubs는 테스트 경계이며 실제 게임 구현의 속도를 증명하지 않는다.

주요 제어 회귀:

    java -ea -cp regressions/classes l1j.server.server.model.network.core.NetworkRegression regression
    java -ea -cp regressions/classes l1j.server.server.model.network.core.ReviewRegression review
    java -ea -cp regressions/classes l1j.server.server.model.network.core.PatchedBatchRegression
    java -ea -cp regressions/classes l1j.server.server.model.network.core.ActionBatchRegression action
    java -ea -cp regressions/classes l1j.server.server.model.network.core.LegacyActionCases queued-wire

마지막 두 명령은 같은 queued 조건을 다른 관점으로 검사한다. ActionBatchRegression action은 현재
의도적으로 감추지 않은 'no temporary third SEND buffer' 실패를 재현한다. LegacyActionCases queued-wire는
48KiB backing을 기록하면서 평문/암호문·부분 WRITE·배출 순서의 바이트 정합성을 별도로 통과한다.
LegacyActionCases는 burst/pool/encoder/close/concurrent/pause도 각각 실행할 수 있다.

프로파일을 재생성하려면 --profile을 사용한다. 생성되는 원본 JFR은 환경정보를 포함할 수 있으므로
외부 게시하지 않는다. 이 배포에는 정제 집계만 있다.
숫자는 해당 하네스/환경의 관찰이며 게임 동접 1만 명, Windows IOCP, WAN, 장시간 운영의 증명이 아니다.
