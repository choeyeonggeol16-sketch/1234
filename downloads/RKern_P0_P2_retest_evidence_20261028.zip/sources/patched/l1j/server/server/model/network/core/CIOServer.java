package l1j.server.server.model.network.core;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.StandardSocketOptions;
import java.nio.channels.AsynchronousChannelGroup;
import java.nio.channels.AsynchronousServerSocketChannel;
import java.nio.channels.AsynchronousSocketChannel;
import java.nio.channels.ClosedChannelException;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.locks.LockSupport;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * The listen thread owns ACCEPT and game-session admission. It waits directly
 * on the NIO.2 accept Future, without an extra completion callback/transfer slot.
 * READ/WRITE remain on the existing completion group.
 */
public final class CIOServer implements AutoCloseable, CIOUserSocket.Closed {
	
    private static final Logger LOG = Logger.getLogger(CIOServer.class.getName());
    private static final long ACCEPT_RETRY_NANOS = TimeUnit.MILLISECONDS.toNanos(50);
    private static final long ACCEPT_LOG_INTERVAL_NANOS = TimeUnit.SECONDS.toNanos(5);
    
    @FunctionalInterface
    public interface SocketFactory {
        CIOUserSocket CreateSocket(AsynchronousSocketChannel channel, CIOBufferPool pool, CIOUserSocket.Closed closedCallback) throws Exception;
    }

    private final CIOBufferPool _pool;
    private final SocketFactory _factory;
    private final AsynchronousChannelGroup _group;
    // Shared with the NIO.2 channel group: READ continuations cannot use
    // a separate/game executor without changing transport ordering.
    private final ExecutorService _ioExecutor;
    private final AsynchronousServerSocketChannel _listener;
    private final Thread _listenThread;
    private final Set<CIOUserSocket> _connections = ConcurrentHashMap.newKeySet();
    private volatile AsynchronousSocketChannel _admitting;
    private final AtomicBoolean _closed = new AtomicBoolean();
    private final AtomicBoolean _acceptStopped = new AtomicBoolean();
    private final AtomicInteger _admitted = new AtomicInteger();
    private final AtomicInteger _ioWorkerIndex = new AtomicInteger();
    private final int _maxConnections;

    private static final int SOCKET_SEND_BUFFER = Math.max(0, Integer.getInteger("cio.socketSendBuffer", 0));
    private static final int SOCKET_RECV_BUFFER = Math.max(0,  Integer.getInteger("cio.socketReceiveBuffer", 0));
    private static final boolean KEEPALIVE = Boolean.getBoolean("cio.socketKeepAlive");

    public CIOServer(InetSocketAddress address, int maxConnections, int ioThreads, int backlog, CIOBufferPool pool, SocketFactory factory)
            throws IOException {
        if (address == null || pool == null || factory == null || maxConnections < 1
                || ioThreads < 1 || backlog < 1)
            throw new IllegalArgumentException("invalid async I/O server configuration");
        _maxConnections = maxConnections;
        _pool = pool;
        _factory = factory;
        final int completionWorkers = Math.min(ioThreads,
                Math.min(8, Math.max(1, Runtime.getRuntime().availableProcessors())));
        final java.util.concurrent.ThreadFactory workerFactory = runnable -> {
            final int workerId = _ioWorkerIndex.getAndIncrement();
            final Thread thread = new Thread(runnable, "RKern-IOCP-" + workerId);
            thread.setDaemon(true);
            return thread;
        };
        // Channel-group topology is an explicit option, independent of the
        // READ fairness budget. The fixed group avoids a per-READ indirect
        // Executor task on the tested Linux/JDK 21 provider.
        final String groupMode = System.getProperty("cio.ioGroupMode", "fixed");
        final boolean pooledGroup;
        if ("fixed".equalsIgnoreCase(groupMode)) pooledGroup = false;
        else if ("pooled".equalsIgnoreCase(groupMode)) pooledGroup = true;
        else throw new IllegalArgumentException("cio.ioGroupMode must be fixed or pooled");
        if (!pooledGroup && CIOUserSocket.readFairnessEnabled())
            throw new IllegalArgumentException(
                    "READ frame budget requires -Dcio.ioGroupMode=pooled; "
                    + "use -Dcio.readFrameBudget=0 with the fixed group");
        LOG.info("[CIO] group=" + groupMode + " workers=" + completionWorkers
                + " readFairness=" + CIOUserSocket.readFairnessEnabled());
        if (pooledGroup) {
            _ioExecutor = Executors.newFixedThreadPool(completionWorkers, workerFactory);
            try {
                // The group and the continuation use the SAME worker pool.
                _group = AsynchronousChannelGroup.withThreadPool(_ioExecutor);
            } catch (IOException | RuntimeException failure) {
                _ioExecutor.shutdownNow();
                throw failure;
            }
        } else {
            // Fixed NIO.2 completion group: no custom continuation executor.
            _ioExecutor = null;
            _group = AsynchronousChannelGroup.withFixedThreadPool(completionWorkers,
                    workerFactory);
        }
        try {
            _listener = AsynchronousServerSocketChannel.open(_group).bind(address, backlog);
        } catch (IOException | RuntimeException failure) {
            _group.shutdownNow();
            throw failure;
        }
        _listenThread = new Thread(this::listen, "RKern-ListenThread");
        _listenThread.setDaemon(true);
        try {
            _listenThread.start();
        } catch (RuntimeException | Error failure) {
            close();
            throw failure;
        }
    }

    private void listen() {
        long lastErrorLog = 0L;
        try {
            while (!_acceptStopped.get()) {
                final Future<AsynchronousSocketChannel> pending;
                try {
                    pending = _listener.accept();
                } catch (RuntimeException failure) {
                    if (!_acceptStopped.get()) {
                        LOG.log(Level.SEVERE, "ACCEPT registration failed", failure);
                        close();
                    }
                    return;
                }

                AsynchronousSocketChannel socket = null;
                Throwable failure = null;
                for (;;) {
                    try {
                        socket = pending.get();
                        break;
                    } catch (InterruptedException ignored) {
                        Thread.interrupted();
                    } catch (ExecutionException completed) {
                        failure = completed.getCause();
                        break;
                    } catch (RuntimeException completed) {
                        failure = completed;
                        break;
                    }
                }

                if (failure != null) {
                    if (_acceptStopped.get()) return;
                    // A closed listener/group cannot be recovered by retrying.
                    if (!(failure instanceof IOException)
                            || failure instanceof ClosedChannelException
                            || !_listener.isOpen()) {
                        LOG.log(Level.WARNING, "ACCEPT stopped", failure);
                        close();
                        return;
                    }
                    final long now = System.nanoTime();
                    if (lastErrorLog == 0L || now - lastErrorLog >= ACCEPT_LOG_INTERVAL_NANOS) {
                        LOG.log(Level.WARNING, "ACCEPT failed; retrying on ListenThread", failure);
                        lastErrorLog = now;
                    }
                    final long deadline = System.nanoTime() + ACCEPT_RETRY_NANOS;
                    while (!_acceptStopped.get()) {
                        final long remaining = deadline - System.nanoTime();
                        if (remaining <= 0L) break;
                        LockSupport.parkNanos(this, remaining);
                        Thread.interrupted();
                    }
                    continue;
                }

                _admitting = socket;
                try {
                    if (_acceptStopped.get()) {
                        closeChannel(socket);
                        return;
                    }
                    activateAccepted(socket);
                } finally {
                    _admitting = null;
                }
            }
        } catch (Throwable failure) {
            if (!_acceptStopped.get()) {
                LOG.log(Level.SEVERE, "ListenThread failed", failure);
                close();
            }
        }
    }

    private void activateAccepted(AsynchronousSocketChannel socket) {
        if (_acceptStopped.get() || !socket.isOpen()) {
            closeChannel(socket);
            return;
        }
        if (_admitted.incrementAndGet() > _maxConnections) {
            _admitted.decrementAndGet();
            closeChannel(socket);
            return;
        }
        try {
            socket.setOption(StandardSocketOptions.TCP_NODELAY, true);
            if (SOCKET_SEND_BUFFER > 0)
                socket.setOption(StandardSocketOptions.SO_SNDBUF, SOCKET_SEND_BUFFER);
            if (SOCKET_RECV_BUFFER > 0)
                socket.setOption(StandardSocketOptions.SO_RCVBUF, SOCKET_RECV_BUFFER);
            if (KEEPALIVE)
                socket.setOption(StandardSocketOptions.SO_KEEPALIVE, true);
        } catch (Throwable failure) {
            _admitted.decrementAndGet();
            closeChannel(socket);
            return;
        }
        if (_acceptStopped.get() || !socket.isOpen()) {
            _admitted.decrementAndGet();
            closeChannel(socket);
            return;
        }
        CIOUserSocket connection = null;
        try {
            connection = _factory.CreateSocket(socket, _pool, this);
            if (connection == null) {
                _admitted.decrementAndGet();
                closeChannel(socket);
                return;
            }
            if (_ioExecutor != null) connection.bindIoExecutor(_ioExecutor);
            _connections.add(connection);
            if (connection.isCloseComplete()) {
                onClosed(connection);
                return;
            }
            if (_acceptStopped.get() || !connection.isOpen()) {
                closeAcceptedBeforeStart(connection);
                return;
            }
            connection.startRead();
        } catch (Throwable failure) {
            if (connection == null) {
                _admitted.decrementAndGet();
                closeChannel(socket);
            } else {
                closeAcceptedBeforeStart(connection);
            }
        }
    }

    private void closeAcceptedBeforeStart(CIOUserSocket connection) {
        connection.close();
        if (connection.isCloseComplete()) onClosed(connection);
    }

    @Override
    public void onClosed(CIOUserSocket connection) {
        if (_connections.remove(connection)) _admitted.decrementAndGet();
    }

    public int liveConnections() {
        return _admitted.get();
    }

    public InetSocketAddress localAddress() throws IOException {
        return (InetSocketAddress) _listener.getLocalAddress();
    }

    public boolean isOpen() {
        return !_acceptStopped.get();
    }

    public boolean isAdmissionThread() {
        return Thread.currentThread() == _listenThread;
    }

    public boolean isCompletionThread() {
        return Thread.currentThread().getName().startsWith("RKern-IOCP-");
    }

    /** Stop accepting new sockets; existing sessions remain usable for save/logout. */
    public void stopAccepting() {
        _acceptStopped.set(true);
        try { _listener.close(); } catch (IOException ignored) {}
        LockSupport.unpark(_listenThread);
    }

    /** Only waits for admission to finish, not the active I/O completion group. */
    public boolean awaitAcceptStopped(long timeout, TimeUnit unit) throws InterruptedException {
        if (timeout < 0L) throw new IllegalArgumentException("negative timeout");
        if (Thread.currentThread() == _listenThread) return false;
        if (!_listenThread.isAlive()) return true;
        if (timeout == 0L) return false;
        TimeUnit.NANOSECONDS.timedJoin(_listenThread, unit.toNanos(timeout));
        return !_listenThread.isAlive();
    }

    @Override
    public void close() {
        if (!_closed.compareAndSet(false, true)) return;
        stopAccepting();
        final AsynchronousSocketChannel admitting = _admitting;
        if (admitting != null) closeChannel(admitting);
        for (CIOUserSocket connection : _connections) connection.close();
        // For withThreadPool(), shutting down the channel group also owns
        // orderly executor shutdown after outstanding completions retire.
        _group.shutdown();
        LockSupport.unpark(_listenThread);
    }

    /** Wait for both the I/O group and the dedicated admission thread to exit. */
    public boolean awaitTermination(long timeout, TimeUnit unit) throws InterruptedException {
        if (timeout < 0L) throw new IllegalArgumentException("negative timeout");
        final long nanos = unit.toNanos(timeout);
        final long start = System.nanoTime();
        if (_listenThread.isAlive()) {
            if (Thread.currentThread() == _listenThread) return false;
            if (nanos == 0L) return false;
            TimeUnit.NANOSECONDS.timedJoin(_listenThread, nanos);
            if (_listenThread.isAlive()) return false;
        }
        final long remaining = nanos - (System.nanoTime() - start);
        return remaining <= 0L ? _group.isTerminated()
                : _group.awaitTermination(remaining, TimeUnit.NANOSECONDS);
    }

    private static void closeChannel(AsynchronousSocketChannel socket) {
        try { socket.close(); } catch (IOException ignored) {}
    }
}
