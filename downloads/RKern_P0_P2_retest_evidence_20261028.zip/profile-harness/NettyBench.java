package l1j.server.server.model.network.core;

import java.io.*;
import java.lang.management.*;
import java.net.*;
import java.nio.*;
import java.nio.channels.*;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.*;
import io.netty.bootstrap.ServerBootstrap;
import io.netty.buffer.*;
import io.netty.channel.*;
import io.netty.channel.epoll.*;
import io.netty.channel.nio.NioEventLoopGroup;
import io.netty.channel.socket.SocketChannel;
import io.netty.channel.socket.nio.NioServerSocketChannel;
import io.netty.handler.codec.ByteToMessageDecoder;
import org.HdrHistogram.Histogram;
import l1j.server.server.model.network.buffer.*;
import l1j.server.server.model.network.codec.Cryptor;
import l1j.server.server.model.network.thread.CIOThreadCallback;

/** Reproducible transport comparison, with actual RKern transport/cipher and no NPC/game/DB execution. */
public final class NettyBench {
    static final boolean ACTION_BATCH=Boolean.getBoolean("bench.actionBatch");
    static final java.lang.invoke.MethodHandle BATCH_HANDLE;
    static {
        try {
            BATCH_HANDLE=ACTION_BATCH ? java.lang.invoke.MethodHandles.lookup().findVirtual(
                    CIOUserSocket.class,"tryWriteActionBatch",java.lang.invoke.MethodType.methodType(
                    boolean.class,int[].class,int[].class,int.class,int.class)) : null;
        } catch (ReflectiveOperationException error) { throw new ExceptionInInitializerError(error); }
    }
    static String ioThreads() {
        ArrayList<String> result=new ArrayList<>();
        for(var entry:Thread.getAllStackTraces().entrySet()) {
            for(var frame:entry.getValue()) {
                String name=frame.getClassName();
                if(name.contains("EPollPort$EventHandlerTask") || name.equals("io.netty.channel.epoll.EpollEventLoop")) {
                    result.add(entry.getKey().getName()+":"+entry.getKey().getState());break;
                }
            }
        }
        Collections.sort(result);return result.toString();
    }

    static final long SEED=0x1234abcdL;
    static final int HELLO=0x13572468;
    static int requestBytes,responseBytes,replies;
    static byte[] responseTail;
    static final AtomicLong failures=new AtomicLong();
    static final com.sun.management.OperatingSystemMXBean OS=(com.sun.management.OperatingSystemMXBean)ManagementFactory.getOperatingSystemMXBean();
    static long gcCount(){long n=0;for(var b:ManagementFactory.getGarbageCollectorMXBeans())n+=Math.max(0,b.getCollectionCount());return n;}
    static long gcMs(){long n=0;for(var b:ManagementFactory.getGarbageCollectorMXBeans())n+=Math.max(0,b.getCollectionTime());return n;}
    static void config(int req,int resp,int count){
        requestBytes=req;responseBytes=resp;replies=count;
        responseTail=new byte[Math.max(0,resp-4)];
        for(int i=0;i<responseTail.length;i++)responseTail[i]=(byte)(i*13+7);
    }
    public static void handleRKern(CIOClient c,ReadBuffer b){
        int seq=b.readInt();
        if(seq!=c.nextSeq++ || b.remaining()!=requestBytes-5)throw new IllegalStateException("request order/size");
        if(ACTION_BATCH && responseBytes==6) {
            if(c.batchObjects==null) {
                c.batchObjects=new int[replies];c.batchActions=new int[replies];
                for(int n=0;n<replies;n++)c.batchActions[n]=n;
            }
            Arrays.fill(c.batchObjects,seq);
            try {
                boolean accepted=(boolean)BATCH_HANDLE.invokeExact(c.socket,c.batchObjects,c.batchActions,0,replies);
                if(!accepted)throw new IllegalStateException("action batch rejected");
            } catch(Throwable failure) {throw new IllegalStateException("action batch failed",failure);}
            return;
        }
        for(int n=0;n<replies;n++){
            if(responseBytes==6){
                if(!c.socket.tryWriteAction(seq,n))throw new IllegalStateException("action rejected");
            }else{
                CIOFrame f=c.socket.beginDirectFrame(responseBytes+2);
                if(f==null)throw new IllegalStateException("bulk rejected");
                boolean done=false;
                try {f.buffer().writeD(seq);f.buffer().writeBytes(responseTail);done=c.socket.commitDirectFrame(f);}
                finally{if(!done)c.socket.abortDirectFrame(f);}
                if(!done)throw new IllegalStateException("bulk commit failed");
            }
        }
    }
    static final class NettyProtocol extends ByteToMessageDecoder {
        final Cryptor cipher=new Cryptor();
        final ReadBuffer read=new ReadBuffer();
        final WriteBuffer write=new WriteBuffer();
        int nextSeq;
        NettyProtocol(){cipher.initKey(SEED);}
        @Override public void channelActive(ChannelHandlerContext ctx){
            ByteBuf b=ctx.alloc().directBuffer(8,8);
            b.writeShortLE(8).writeByte(19).writeIntLE(HELLO).writeByte(255);
            ctx.writeAndFlush(b);
        }
        @Override protected void decode(ChannelHandlerContext ctx,ByteBuf in,List<Object> out){
            if(in.readableBytes()<2)return;
            int at=in.readerIndex(),len=in.getUnsignedShortLE(at);
            if(len<10||len>65535)throw new IllegalStateException("wire length");
            if(in.readableBytes()<len)return;
            ByteBuffer view=in.internalNioBuffer(at+2,len-2).order(ByteOrder.LITTLE_ENDIAN);
            read.resetTrusted(view,view.position(),len-2);
            cipher.decrypt(read,0,len-2);read.limit(len-6);
            if(read.readUnsignedByte()!=1)throw new IllegalStateException("opcode");
            int seq=read.readInt();
            if(seq!=nextSeq++ || read.remaining()!=requestBytes-5)throw new IllegalStateException("request order/size");
            int total=(responseBytes+2)*replies;
            ByteBuf encoded=ctx.alloc().directBuffer(total,total);
            boolean published=false;
            try{
                ByteBuffer dest=encoded.internalNioBuffer(0,total).order(ByteOrder.LITTLE_ENDIAN);
                write.armExternal(dest,dest.position(),total);write.beginDirect();
                for(int n=0;n<replies;n++){
                    int start=write.position();write.writeH(responseBytes+2);
                    if(responseBytes==6){write.writeC(19);write.writeD(seq);write.writeC(n);}
                    else{write.writeD(seq);write.writeBytes(responseTail);}
                    cipher.encrypt(write,start+2,responseBytes);
                }
                encoded.writerIndex(total);
                // Same request-level flush boundary as RKern begin/endSendBurst.
                ctx.writeAndFlush(encoded);published=true;
            }finally{write.releaseResources();if(!published)encoded.release();}
            in.skipBytes(len);
        }
        @Override public void channelWritabilityChanged(ChannelHandlerContext ctx){
            ctx.channel().config().setAutoRead(ctx.channel().isWritable());ctx.fireChannelWritabilityChanged();
        }
        @Override public void exceptionCaught(ChannelHandlerContext ctx,Throwable t){failures.incrementAndGet();t.printStackTrace();ctx.close();}
    }
    static void server(String[] a)throws Exception{
        String engine=a[1];int workers=Integer.parseInt(a[2]),cap=Integer.parseInt(a[3]);
        config(Integer.parseInt(a[4]),Integer.parseInt(a[5]),Integer.parseInt(a[6]));
        AutoCloseable close;int port;CIOBufferPool rkPool=null;
        if(engine.equals("rkern")){
            final CIOBufferPool pool=new CIOBufferPool(cap,cap,Math.min(cap,512),Math.min(cap,256));rkPool=pool;
            CIOServer s=new CIOServer(new InetSocketAddress("127.0.0.1",0),cap,workers,1024,pool,(ch,p,closed)->{
                CIOUserSocket socket=new CIOUserSocket(ch,p,new CIOThreadCallback(),"bench",0,256,closed);
                CIOClient client=new CIOClient(socket);socket.bindClient(client);socket.initializeCipher(SEED);
                if(!socket.tryWriteAction(HELLO,255))throw new IllegalStateException("hello rejected");return socket;
            });
            port=s.localAddress().getPort();close=()->{s.close();if(!s.awaitTermination(10,TimeUnit.SECONDS))throw new IllegalStateException("RKern shutdown");};
        }else{
            boolean epoll=engine.equals("netty-epoll");
            if(epoll&&!Epoll.isAvailable())throw new IllegalStateException("epoll unavailable",Epoll.unavailabilityCause());
            EventLoopGroup boss=epoll?new EpollEventLoopGroup(1):new NioEventLoopGroup(1);
            EventLoopGroup group=epoll?new EpollEventLoopGroup(workers):new NioEventLoopGroup(workers);
            ServerBootstrap b=new ServerBootstrap().group(boss,group)
                .channel(epoll?EpollServerSocketChannel.class:NioServerSocketChannel.class)
                .option(ChannelOption.SO_BACKLOG,1024)
                .childOption(ChannelOption.TCP_NODELAY,true)
                .childOption(ChannelOption.ALLOCATOR,PooledByteBufAllocator.DEFAULT)
                .childOption(ChannelOption.WRITE_BUFFER_WATER_MARK,new WriteBufferWaterMark(128*1024,256*1024))
                .childOption(ChannelOption.RCVBUF_ALLOCATOR,new FixedRecvByteBufAllocator(4096))
                .childHandler(new ChannelInitializer<SocketChannel>(){
                    @Override protected void initChannel(SocketChannel ch){ch.pipeline().addLast(new NettyProtocol());}
                });
            io.netty.channel.Channel s=b.bind("127.0.0.1",0).sync().channel();port=((InetSocketAddress)s.localAddress()).getPort();
            close=()->{s.close().sync();group.shutdownGracefully(0,5,TimeUnit.SECONDS).sync();boss.shutdownGracefully(0,5,TimeUnit.SECONDS).sync();};
        }
        System.out.printf("READY {\"engine\":\"%s\",\"port\":%d,\"workers\":%d,\"pid\":%d}%n",engine,port,workers,ProcessHandle.current().pid());System.out.flush();
        long cpu=0,gc=0,gct=0,wall=0;
        BufferedReader reader=new BufferedReader(new InputStreamReader(System.in));String line;
        while((line=reader.readLine())!=null){
            if(line.equals("start")){System.err.println("PROFILE_START "+java.time.Instant.now());cpu=OS.getProcessCpuTime();gc=gcCount();gct=gcMs();wall=System.nanoTime();}
            else if(line.equals("stop")){System.err.println("PROFILE_END "+java.time.Instant.now());
                long alloc=engine.equals("rkern")?rkPool.allocatedDirectBytes():PooledByteBufAllocator.DEFAULT.metric().usedDirectMemory();
                long rejects=0;for(int i=1;i<=5;i++)rejects+=CIOUserSocket.sendRejections(i);
                System.out.printf(Locale.ROOT,"SERVER {\"cpu_s\":%.6f,\"wall_s\":%.6f,\"gc_count\":%d,\"gc_ms\":%d,\"direct_allocated_bytes\":%d,\"heap_used_bytes\":%d,\"failures\":%d,\"send_rejections\":%d}%n",
                    (OS.getProcessCpuTime()-cpu)/1e9,(System.nanoTime()-wall)/1e9,gcCount()-gc,gcMs()-gct,alloc,
                    ManagementFactory.getMemoryMXBean().getHeapMemoryUsage().getUsed(),failures.get(),rejects);System.out.flush();
                System.err.println("IO_THREADS "+ioThreads());
            }else if(line.equals("quit"))break;
        }
        close.close();
    }

    /** Independent C->S reference inverse; reuses all buffers. */
    static final class RequestEncoder {
        long k0=Integer.toUnsignedLong(Integer.rotateRight((int)(SEED^0x9c30d539L),13));
        long k1=0x930fd7e2L^k0^0x7c72e993L;
        void frame(ByteBuffer out,int seq){
            int start=out.position();out.putShort((short)(requestBytes+6)).put((byte)0).put((byte)0).put((byte)0).put((byte)(93^(k0>>>16)));
            int prev=93;long head=1L|((seq&0xffffffL)<<8);
            for(int i=0;i<requestBytes;i++){
                int plain=i==0?1:i<=4?(seq>>>((i-1)*8))&255:(i*7)&255;
                int key=(int)(((i&7)<4?k1:k0)>>>((i&3)*8))&255;
                int value=plain^key^prev;out.put((byte)value);prev=value;
            }
            if(out.position()-start!=requestBytes+6)throw new AssertionError();
            k0=(k0^head)&0xffffffffL;k1=Integer.toUnsignedLong((int)k1+679411651);
        }
    }
    static final class Peer {
        final java.nio.channels.SocketChannel channel;
        final RequestEncoder encoder=new RequestEncoder();
        final Cryptor cipher=new Cryptor();
        final WriteBuffer decrypt=new WriteBuffer();
        final ByteBuffer input=ByteBuffer.allocateDirect(128*1024).order(ByteOrder.LITTLE_ENDIAN);
        final ByteBuffer output=ByteBuffer.allocateDirect(128*1024).order(ByteOrder.LITTLE_ENDIAN);
        final long[] started;final byte[] phases;
        final SelectionKey key;
        int sent,received,responseIndex;boolean hello;
        Peer(Selector selector,int port,int window)throws Exception{
            channel=java.nio.channels.SocketChannel.open();channel.setOption(StandardSocketOptions.TCP_NODELAY,true);
            channel.connect(new InetSocketAddress("127.0.0.1",port));channel.configureBlocking(false);
            key=channel.register(selector,SelectionKey.OP_READ,this);output.limit(0);started=new long[window];phases=new byte[window];cipher.initKey(SEED);
        }
        void fill(int window,int phase){
            if(phase==2)return;
            if(output.hasRemaining())return;
            output.clear();
            while(sent-received<window && output.remaining()>=requestBytes+6){
                int slot=sent%window;started[slot]=System.nanoTime();phases[slot]=(byte)phase;encoder.frame(output,sent++);
            }
            output.flip();
        }
        void flush()throws Exception{
            if(output.hasRemaining())channel.write(output);
            key.interestOps(SelectionKey.OP_READ|(output.hasRemaining()?SelectionKey.OP_WRITE:0));
        }
    }
    static final class LoadWorker implements Callable<Histogram> {
        final Selector selector=Selector.open();final ArrayList<Peer> peers=new ArrayList<>();
        final int window;final boolean exact;
        final Histogram histogram=new Histogram(TimeUnit.SECONDS.toNanos(60),3);
        long completed,measured,allResponses;
        LoadWorker(int port,int count,int window,boolean exact)throws Exception{
            this.window=window;this.exact=exact;for(int i=0;i<count;i++)peers.add(new Peer(selector,port,window));
        }
        void read(Peer p)throws Exception{
            int n=p.channel.read(p.input);if(n<0)throw new EOFException("unexpected server close");
            p.input.flip();
            while(p.input.remaining()>=2){
                int base=p.input.position(),len=Short.toUnsignedInt(p.input.getShort(base));
                if(len<2||len>65535)throw new IOException("response length");
                if(p.input.remaining()<len)break;
                if(!p.hello){
                    if(len!=8||p.input.get(base+2)!=19||p.input.getInt(base+3)!=HELLO||p.input.get(base+7)!=(byte)255)throw new IOException("hello mismatch");
                    p.hello=true;HELLOS.incrementAndGet();
                }else{
                    if(len!=responseBytes+2)throw new IOException("response size");
                    int savedLimit=p.input.limit();
                    p.decrypt.armExternal(p.input,0,p.input.capacity());p.decrypt.beginDirect();
                    p.cipher.encrypt(p.decrypt,base+2,responseBytes); // XOR cipher is symmetric; independent receive instance.
                    p.decrypt.releaseResources();p.input.limit(savedLimit);p.input.position(base);
                    int seq;
                    if(responseBytes==6){
                        seq=p.input.getInt(base+3);
                        if(p.input.get(base+2)!=19 || (p.input.get(base+7)&255)!=p.responseIndex)throw new IOException("action byte/order");
                    }else{
                        seq=p.input.getInt(base+2);
                        if(exact){for(int i=0;i<responseTail.length;i++)if(p.input.get(base+6+i)!=responseTail[i])throw new IOException("bulk payload byte "+i);}
                        else if(p.input.get(base+len-1)!=responseTail[responseTail.length-1])throw new IOException("bulk payload tail");
                    }
                    if(seq!=p.received)throw new IOException("response seq expected="+p.received+" actual="+seq);
                    allResponses++;
                    if(++p.responseIndex==replies){
                        int slot=p.received%window;
                        if(p.phases[slot]==1){histogram.recordValue(System.nanoTime()-p.started[slot]);measured++;}
                        p.received++;p.responseIndex=0;completed++;
                    }
                }
                p.input.position(base+len);
            }
            p.input.compact();
        }
        @Override public Histogram call()throws Exception{
            try{
                while(!GO)step(false);
                while(PHASE<2)step(true);
                long end=System.nanoTime()+TimeUnit.SECONDS.toNanos(15);
                while(System.nanoTime()<end){
                    boolean pending=false;for(Peer p:peers)if(p.sent!=p.received||p.output.hasRemaining())pending=true;
                    if(!pending)return histogram;step(false);
                }
                throw new IOException("drain timeout");
            }finally{for(Peer p:peers)p.channel.close();selector.close();}
        }
        void step(boolean send)throws Exception{
            if(Thread.currentThread().isInterrupted())throw new InterruptedException();
            selector.select(10);
            var it=selector.selectedKeys().iterator();
            while(it.hasNext()){
                var k=it.next();it.remove();Peer p=(Peer)k.attachment();
                if(k.isReadable())read(p);
                if(send&&p.hello)p.fill(window,PHASE);
                p.flush();
            }
            // Initial send after the orchestrator starts the workload, without waiting for another socket event.
            if(send)for(Peer p:peers)if(p.hello&&p.sent==0){p.fill(window,PHASE);p.flush();}
        }
    }
    static volatile int PHASE;static volatile boolean GO;
    static final AtomicInteger HELLOS=new AtomicInteger();
    static void client(String[] a)throws Exception{
        int port=Integer.parseInt(a[1]),connections=Integer.parseInt(a[2]),window=Integer.parseInt(a[3]);
        int threads=Integer.parseInt(a[4]),warm=Integer.parseInt(a[5]),seconds=Integer.parseInt(a[6]);boolean exact=Boolean.parseBoolean(a[10]);
        config(Integer.parseInt(a[7]),Integer.parseInt(a[8]),Integer.parseInt(a[9]));
        ExecutorService executor=Executors.newFixedThreadPool(threads);ArrayList<LoadWorker> workers=new ArrayList<>();ArrayList<Future<Histogram>> futures=new ArrayList<>();
        for(int i=0;i<threads;i++){LoadWorker w=new LoadWorker(port,connections/threads+(i<connections%threads?1:0),window,exact);workers.add(w);futures.add(executor.submit(w));}
        long deadline=System.nanoTime()+TimeUnit.SECONDS.toNanos(30);
        while(HELLOS.get()!=connections){if(System.nanoTime()>deadline)throw new IOException("hello timeout "+HELLOS.get());for(var f:futures)if(f.isDone())f.get();Thread.sleep(10);}
        PHASE=0;GO=true;Thread.sleep(warm*1000L);
        long cpu=OS.getProcessCpuTime(),gcs=gcCount(),gct=gcMs(),start=System.nanoTime();
        System.out.println("MEASURE_BEGIN");System.out.flush();PHASE=1;Thread.sleep(seconds*1000L);PHASE=2;
        long elapsed=System.nanoTime()-start,cpuNs=OS.getProcessCpuTime()-cpu;
        System.out.println("MEASURE_END");System.out.flush();
        Histogram all=new Histogram(TimeUnit.SECONDS.toNanos(60),3);for(var f:futures)all.add(f.get(20,TimeUnit.SECONDS));executor.shutdown();
        long count=0,total=0,responses=0;for(var w:workers){count+=w.measured;total+=w.completed;responses+=w.allResponses;}
        System.out.printf(Locale.ROOT,"CLIENT {\"requests\":%d,\"seconds\":%.6f,\"requests_per_s\":%.3f,\"response_packets_per_s\":%.3f,\"wire_mib_per_s\":%.3f,\"p50_us\":%.3f,\"p95_us\":%.3f,\"p99_us\":%.3f,\"max_us\":%.3f,\"mean_us\":%.3f,\"client_cpu_s\":%.6f,\"client_gc_count\":%d,\"client_gc_ms\":%d,\"all_requests\":%d,\"all_responses\":%d,\"exact_bulk_validation\":%s}%n",
            count,elapsed/1e9,count/(elapsed/1e9),count*replies/(elapsed/1e9),count*((long)requestBytes+6+(long)(responseBytes+2)*replies)/(elapsed/1e9)/(1024*1024),
            all.getValueAtPercentile(50)/1e3,all.getValueAtPercentile(95)/1e3,all.getValueAtPercentile(99)/1e3,all.getMaxValue()/1e3,all.getMean()/1e3,
            cpuNs/1e9,gcCount()-gcs,gcMs()-gct,total,responses,exact);
    }
    public static void main(String[] args)throws Exception{
        if(args[0].equals("server"))server(args);
        else if(args[0].equals("client"))client(args);
        else if(args[0].equals("native-check"))System.out.println("EPOLL="+Epoll.isAvailable()+" cause="+Epoll.unavailabilityCause());
        else throw new IllegalArgumentException();
    }
}
