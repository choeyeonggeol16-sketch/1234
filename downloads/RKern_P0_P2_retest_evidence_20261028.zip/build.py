from pathlib import Path
import argparse, hashlib, json, subprocess, urllib.request

R=Path(__file__).resolve().parent
P=argparse.ArgumentParser()
P.add_argument('--fetch-deps',action='store_true')
A=P.parse_args()
lib=R/'lib';lib.mkdir(exist_ok=True)
for row in json.loads((R/'dependencies.json').read_text()):
    target=lib/row['name']
    if not target.exists():
        if not A.fetch_deps:raise SystemExit('Missing dependency: run python3 build.py --fetch-deps')
        urllib.request.urlretrieve(row['url'],target)
    if hashlib.sha256(target.read_bytes()).hexdigest()!=row['sha256']:
        raise SystemExit('Dependency hash mismatch: '+row['name'])
cp=':'.join(str(p) for p in sorted(lib.glob('*.jar')))
for label in ['v5','before','patched','client']:
    version='v5' if label=='client' else label
    manifest=json.loads((R/'sources'/(version+'-manifest.json')).read_text())
    source=R/'sources'/version
    files=[source/rel for rel in manifest['actual_sha256']]
    for rel,sha in manifest['actual_sha256'].items():
        assert hashlib.sha256((source/rel).read_bytes()).hexdigest()==sha,rel
    files+=sorted((R/'stubs').rglob('*.java'))
    files.append(R/'harness'/('client' if label=='client' else 'server')/'NettyBench.java')
    output=R/label/'classes';output.mkdir(parents=True,exist_ok=True)
    subprocess.run(['java','com.sun.tools.javac.Main','-encoding','UTF-8','-cp',cp,'-d',str(output),*[str(p) for p in files]],check=True)
common=R/'common-cipher';common.mkdir(exist_ok=True)
subprocess.run(['java','com.sun.tools.javac.Main','-encoding','UTF-8','-cp',str(R/'v5/classes'),'-d',str(common),str(R/'sources/patched/l1j/server/server/model/network/codec/Cryptor.java')],check=True)
reg=R/'regressions'
output=reg/'classes';output.mkdir(parents=True,exist_ok=True)
manifest=json.loads((R/'sources/patched-manifest.json').read_text())
files=[R/'sources/patched'/rel for rel in manifest['actual_sha256']]
files+=sorted((reg/'stubs').rglob('*.java'))+sorted(reg.glob('*.java'))
subprocess.run(['java','com.sun.tools.javac.Main','-encoding','UTF-8','-d',str(output),*[str(p) for p in files]],check=True)
profile=R/'profile-harness';output=profile/'classes';output.mkdir(parents=True,exist_ok=True)
subprocess.run(['java','com.sun.tools.javac.Main','-encoding','UTF-8','-cp',str(R/'patched/classes')+':'+cp,'-d',str(output),str(profile/'NettyBench.java'),str(profile/'JfrSummary.java')],check=True)
print('Built three actual transports, fixed original client, common Netty cipher, regression fixtures, and profiling adapter.')
