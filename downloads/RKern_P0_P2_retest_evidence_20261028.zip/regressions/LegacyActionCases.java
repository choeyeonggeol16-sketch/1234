package l1j.server.server.model.network.core;
import java.util.*;
public final class LegacyActionCases {
    static void queuedWireOnly(){
        for(boolean cipher:new boolean[]{false,true})try(var s=new NetworkRegression.Session(cipher)){
            s.channel.autoWrite=false;
            for(int i=0;i<96;i++)ActionBatchRegression.check(s.socket.tryWriteAction(i,i),"queued action accepted");
            ActionBatchRegression.check(s.socket.pendingSendBytes()==768&&!s.socket.isSendReadWritable(),"queued logical pressure");
            ActionBatchRegression.drain(s.channel);
            ActionBatchRegression.check(Arrays.equals(s.channel.output.toByteArray(),ActionBatchRegression.expected(96,cipher)),"queued partial wire exact");
            ActionBatchRegression.check(s.socket.pendingSendBytes()==0&&s.socket.isSendReadWritable(),"queued accounting resumes");
            System.out.println("QUEUED_SEND_BACKING_BYTES cipher="+cipher+" bytes="+s.pool.allocatedDirectBytes());
        }
        try(var s=new NetworkRegression.Session(true)){
            CIOUserSocket.beginSendBurst();try{for(int i=0;i<2100;i++)ActionBatchRegression.check(s.socket.tryWriteAction(i,i),"large action burst accepted");}finally{CIOUserSocket.endSendBurst();}
            ActionBatchRegression.check(Arrays.equals(s.channel.output.toByteArray(),ActionBatchRegression.expected(2100,true)),"cross-8K action wire exact");
            ActionBatchRegression.check(s.socket.isWriteIdle()&&s.pool.usedSendSlots()==0,"cross-8K cleanup");
        }
    }
    public static void main(String[] args)throws Exception{
        switch(args[0]){
            case "burst":ActionBatchRegression.burstReuse();break;
            case "pool":ActionBatchRegression.saturatedPool();break;
            case "encoder":ActionBatchRegression.pendingEncoder();break;
            case "close":ActionBatchRegression.closePacked();break;
            case "concurrent":ActionBatchRegression.concurrentActions();break;
            case "pause":ActionBatchRegression.receivePause();break;
            case "queued-wire":queuedWireOnly();break;
            default:throw new IllegalArgumentException(args[0]);
        }
        System.out.println("PASS action case "+args[0]+": "+ActionBatchRegression.checks+" assertions");
    }
}
