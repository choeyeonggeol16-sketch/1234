package l1j.server.server.model.network.core;
import java.nio.*;
import java.io.*;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.*;
import java.lang.reflect.*;
import l1j.server.server.Opcodes;
import l1j.server.server.model.network.packet.WritablePacket;
import l1j.server.server.model.network.buffer.WriteBuffer;

public final class PatchedBatchRegression {
    static int checks;
    static void check(boolean value,String label){checks++;if(!value)throw new AssertionError(label);}
    static int frames(CIOUserSocket s)throws Exception{Field f=CIOUserSocket.class.getDeclaredField("_outstandingFrames");f.setAccessible(true);return f.getInt(s);}
    static int[] ids(int count){int[] a=new int[count];for(int i=0;i<count;i++)a[i]=i;return a;}
    static void exactBatches()throws Exception{
        for(boolean cipher:new boolean[]{false,true})for(boolean burst:new boolean[]{false,true})for(int count:new int[]{0,1,2,31,32,128,257,1024,2100}){
            try(var s=new NetworkRegression.Session(cipher)){
                int[] objects=ids(count),actions=ids(count);
                if(burst)CIOUserSocket.beginSendBurst();
                try{check(s.socket.tryWriteActionBatch(objects,actions,0,count),"batch admitted "+count);}finally{if(burst)CIOUserSocket.endSendBurst();}
                check(Arrays.equals(s.channel.output.toByteArray(),ActionBatchRegression.expected(count,cipher)),"all wire bytes, headers, cipher boundaries "+count);
                check(s.socket.pendingSendBytes()==0&&frames(s.socket)==0&&s.pool.usedSendSlots()==0,"batch accounting drained "+count);
            }
        }
    }
    static void partialAndClose()throws Exception{
        for(boolean cipher:new boolean[]{false,true})try(var s=new NetworkRegression.Session(cipher)){
            s.channel.autoWrite=false;int[] a=ids(64);
            check(s.socket.tryWriteActionBatch(a,a,0,64),"partial batch admitted");
            check(s.socket.pendingSendBytes()==512&&frames(s.socket)==64,"logical frame accounting before WRITE complete");
            check(!s.socket.isSendReadWritable(),"logical high watermark reached");
            ActionBatchRegression.drain(s.channel);
            check(Arrays.equals(s.channel.output.toByteArray(),ActionBatchRegression.expected(64,cipher)),"3-byte partial completions exact cipher stream");
            check(s.socket.pendingSendBytes()==0&&frames(s.socket)==0&&s.socket.isSendReadWritable(),"partial batch low watermark restored");
        }
        try(var s=new NetworkRegression.Session(true)){
            CIOUserSocket.beginSendBurst();
            try{int[] a=ids(32);check(s.socket.tryWriteActionBatch(a,a,0,32),"close pending batch admitted");s.socket.close();}
            finally{CIOUserSocket.endSendBurst();}
            check(s.channel.output.size()==0&&s.pool.usedSendSlots()==0&&s.socket.pendingSendBytes()==0&&frames(s.socket)==0,"close unpublished packed batch releases all logical frames");
        }
    }
    static void encoderOrder()throws Exception{
        try(var s=new NetworkRegression.Session(false)){
            var entered=new CountDownLatch(1);var release=new CountDownLatch(1);var error=new AtomicReference<Throwable>();
            var packet=new WritablePacket<CIOClient>(){protected boolean write(CIOClient c,WriteBuffer b){entered.countDown();try{if(!release.await(5,TimeUnit.SECONDS))throw new AssertionError("encoder timeout");}catch(InterruptedException e){throw new AssertionError(e);}b.writeC(77);return true;}};
            Thread t=new Thread(()->{try{check(s.socket.tryWritePacket(s.client,packet),"earlier encoder admitted");}catch(Throwable e){error.set(e);}});t.setDaemon(true);t.start();
            check(entered.await(5,TimeUnit.SECONDS),"encoder reservation established");
            try{int[] a=ids(32);check(s.socket.tryWriteActionBatch(a,a,0,32),"later packed batch admitted");check(s.channel.output.size()==0,"batch cannot overtake unresolved encoder");}finally{release.countDown();}
            t.join(5000);check(!t.isAlive()&&error.get()==null,"encoder finishes");
            var expected=new ByteArrayOutputStream();expected.writeBytes(new byte[]{3,0,77});expected.writeBytes(ActionBatchRegression.expected(32,false));
            check(Arrays.equals(s.channel.output.toByteArray(),expected.toByteArray()),"encoder then packed batch FIFO exact");
            check(frames(s.socket)==0&&s.pool.usedSendSlots()==0,"encoder/batch accounting drained");
        }
    }
    static void concurrentBatches()throws Exception{
        try(var s=new NetworkRegression.Session(false)){
            s.channel.autoWrite=false;check(s.socket.tryWriteAction(-1,0),"hold initial WRITE");
            var go=new CountDownLatch(1);var error=new AtomicReference<Throwable>();var threads=new ArrayList<Thread>();
            for(int producer=0;producer<8;producer++){final int id=producer;Thread t=new Thread(()->{try{int[] objects=new int[16],actions=ids(16);for(int n=0;n<16;n++)objects[n]=(id<<20)|n;go.await();if(!s.socket.tryWriteActionBatch(objects,actions,0,16))throw new AssertionError("concurrent batch rejected");}catch(Throwable e){error.compareAndSet(null,e);}});t.setDaemon(true);threads.add(t);t.start();}
            go.countDown();for(Thread t:threads){t.join(5000);check(!t.isAlive(),"producer exits");}check(error.get()==null,"all bounded concurrent batches admitted");
            ActionBatchRegression.drain(s.channel);ByteBuffer wire=ByteBuffer.wrap(s.channel.output.toByteArray()).order(ByteOrder.LITTLE_ENDIAN);int[] next=new int[8];int total=0;
            while(wire.hasRemaining()){check(wire.remaining()>=8&&wire.getShort()==8&&(wire.get()&255)==Opcodes.S_ACTION,"concurrent batch frame header");int object=wire.getInt(),action=wire.get()&255;if(total++==0){check(object==-1,"held first frame remains first");continue;}int producer=object>>>20,n=object&0xfffff;check(producer<8&&n==next[producer]++&&action==n,"per-producer order, no duplicates/loss");}
            check(total==129&&Arrays.stream(next).allMatch(n->n==16),"all concurrent batch frames received once");
            check(frames(s.socket)==0&&s.socket.pendingSendBytes()==0&&s.pool.usedSendSlots()==0,"concurrent batch cleanup");
        }
    }
    public static void main(String[]args)throws Exception{
        exactBatches();partialAndClose();encoderOrder();concurrentBatches();
        System.out.println("PASS patched packed-batch/FIFO regression: "+checks+" assertions; independent wire reference; partial WRITE, close, encoder reservation, 8 concurrent producers");
    }
}
