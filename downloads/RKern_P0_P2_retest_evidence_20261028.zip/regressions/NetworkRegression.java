package l1j.server.server.model.network.core;

import java.io.*;
import java.net.*;
import java.nio.*;
import java.nio.channels.*;
import java.nio.channels.spi.AsynchronousChannelProvider;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.*;
import l1j.server.server.model.network.buffer.*;
import l1j.server.server.model.network.packet.WritablePacket;
import l1j.server.server.model.network.thread.CIOThreadCallback;
import l1j.server.server.model.network.utill.ConnectionConfig;

public final class NetworkRegression {
    static final long SEED=0x1234abcdL;
    static int checks;
    static void check(boolean ok,String why){checks++;if(!ok)throw new AssertionError(why);}

    // Independent client-to-server encoder, inverse of the documented rolling XOR.
    static final class ClientEncoder {
        long k0=Integer.toUnsignedLong(Integer.rotateRight((int)(SEED^0x9c30d539L),13));
        long k1=0x930fd7e2L^k0^0x7c72e993L;
        byte[] frame(int op,int length,int id){
            if(length<4||length>65529)throw new IllegalArgumentException();
            byte[] plain=new byte[length];plain[0]=(byte)op;
            for(int i=1;i<length;i++)plain[i]=(byte)(id+i*7);
            byte[] out=new byte[length+6];ByteBuffer b=ByteBuffer.wrap(out).order(ByteOrder.LITTLE_ENDIAN);
            b.putShort(0,(short)out.length);out[5]=(byte)(93^(k0>>>16));int prev=93;
            for(int i=0;i<length;i++){
                int key=(int)((i%8<4?k1:k0)>>>((i&3)*8))&255;
                int c=(plain[i]&255)^key^prev;out[i+6]=(byte)c;prev=c;
            }
            k0=(k0^Integer.toUnsignedLong(ByteBuffer.wrap(plain).order(ByteOrder.LITTLE_ENDIAN).getInt()))&0xffffffffL;
            k1=Integer.toUnsignedLong((int)k1+679411651);
            return out;
        }
    }
    // Independent byte-at-a-time reference for the outgoing cipher.
    static final class ServerCipher {
        final int[] h=new int[256];
        ServerCipher(){
            long a=Integer.toUnsignedLong(Integer.rotateRight((int)(SEED^0x9c30d539L),13));
            long b=0x930fd7e2L^a^0x7c72e993L;int k=0;
            for(int i=0;i<256;i++)h[i]=i;
            for(int i=0;i<256;i++){int key=(int)((i%8<4?a:b)>>>((i&3)*8))&255;k=(h[i]+k+key)&255;int t=h[k];h[k]=h[i];h[i]=t;}
        }
        byte[] frame(byte[] body){byte[] out=new byte[body.length+2];ByteBuffer.wrap(out).order(ByteOrder.LITTLE_ENDIAN).putShort((short)out.length);
            int k=0,j=1;for(int i=0;i<body.length;i++){int hj=h[j];k=(k+hj)&255;int hk=h[k];h[j]=hk;h[k]=hj;out[i+2]=(byte)(body[i]^h[(hj+hk)&255]);j=(j+1)&255;}return out;}
    }

    static final class FakeChannel extends AsynchronousSocketChannel {
        boolean open=true,autoWrite=true,inlineRead,delayClose,recordOutput=true;
        long outputBytes;
        ByteBuffer reading;CompletionHandler<Integer,Object> reader;Object readArg;
        Runnable writeDone;ByteBuffer[] writing;
        byte[] input;int inputPos,inputChunk=4096;
        final ByteArrayOutputStream output=new ByteArrayOutputStream();int reads,writes;
        FakeChannel(){super(AsynchronousChannelProvider.provider());}
        @Override public boolean isOpen(){return open;}
        @Override public void close(){open=false;if(delayClose)return;if(reader!=null){var r=reader;var a=readArg;reader=null;reading=null;r.failed(new ClosedChannelException(),a);}if(writeDone!=null)finishWrite(Integer.MAX_VALUE);}
        @Override public Set<SocketOption<?>> supportedOptions(){return Set.of();}
        @Override public <T>T getOption(SocketOption<T> o){return null;}
        @Override public <T>AsynchronousSocketChannel setOption(SocketOption<T>o,T v){return this;}
        @Override public AsynchronousSocketChannel bind(SocketAddress a){return this;}
        @Override public AsynchronousSocketChannel shutdownInput(){return this;}
        @Override public AsynchronousSocketChannel shutdownOutput(){return this;}
        @Override public SocketAddress getRemoteAddress(){return new InetSocketAddress("127.0.0.1",12345);}
        @Override public SocketAddress getLocalAddress(){return getRemoteAddress();}
        @Override public <A>void connect(SocketAddress a,A v,CompletionHandler<Void,? super A> h){throw new UnsupportedOperationException();}
        @Override public Future<Void> connect(SocketAddress a){throw new UnsupportedOperationException();}
        @SuppressWarnings("unchecked")
        @Override public <A>void read(ByteBuffer b,long t,TimeUnit u,A a,CompletionHandler<Integer,? super A> h){
            if(reader!=null)throw new AssertionError("overlapping READ");reads++;reading=b;readArg=a;reader=(CompletionHandler<Integer,Object>)h;
            if(inlineRead&&input!=null&&inputPos<input.length)feed(input,inputPos,Math.min(inputChunk,input.length-inputPos));
        }
        int feed(byte[] b,int off,int n){if(reader==null)return 0;int count=Math.min(n,reading.remaining());reading.put(b,off,count);inputPos+=count;
            var r=reader;var a=readArg;reader=null;reading=null;r.completed(count,a);return count;}
        void zeroRead(){var r=reader;var a=readArg;reader=null;reading=null;r.completed(0,a);}
        @Override public Future<Integer> read(ByteBuffer b){throw new UnsupportedOperationException();}
        @Override public <A>void read(ByteBuffer[]b,int o,int n,long t,TimeUnit u,A a,CompletionHandler<Long,? super A>h){throw new UnsupportedOperationException();}
        @Override public <A>void write(ByteBuffer b,long t,TimeUnit u,A a,CompletionHandler<Integer,? super A>h){
            if(writeDone!=null)throw new AssertionError("overlapping WRITE");writes++;writing=new ByteBuffer[]{b};
            writeDone=()->h.completed(lastWritten,a);if(autoWrite)finishWrite(Integer.MAX_VALUE);
        }
        int lastWritten;
        void finishWrite(int limit){if(writeDone==null)return;int n=0;for(ByteBuffer b:writing){
                if(recordOutput){while(b.hasRemaining()&&n<limit){output.write(b.get());n++;}}
                else{int count=Math.min(b.remaining(),limit-n);b.position(b.position()+count);n+=count;}
            }
            outputBytes+=n;
            lastWritten=n;var done=writeDone;writeDone=null;writing=null;done.run();}
        @Override public Future<Integer> write(ByteBuffer b){throw new UnsupportedOperationException();}
        @Override public <A>void write(ByteBuffer[]b,int o,int n,long t,TimeUnit u,A a,CompletionHandler<Long,? super A>h){
            if(writeDone!=null)throw new AssertionError("overlapping gather WRITE");writes++;writing=Arrays.copyOfRange(b,o,o+n);
            writeDone=()->h.completed((long)lastWritten,a);if(autoWrite)finishWrite(Integer.MAX_VALUE);
        }
    }
    static final class Session implements AutoCloseable {
        final FakeChannel channel=new FakeChannel();final CIOBufferPool pool=new CIOBufferPool(2,512,2,4);
        final CIOUserSocket socket;final CIOClient client;int closes;
        Session(boolean cipher){socket=new CIOUserSocket(channel,pool,new CIOThreadCallback(),"test",0,256,s->closes++);
            client=new CIOClient(socket);socket.bindClient(client);if(cipher)socket.initializeCipher(SEED);}
        void feed(byte[] bytes,int chunk){int pos=0;while(pos<bytes.length&&socket.isOpen()){
            int n=channel.feed(bytes,pos,Math.min(chunk,bytes.length-pos));if(n==0)break;pos+=n;
        }if(pos!=bytes.length&&socket.isOpen()&&socket.isSendReadWritable())throw new AssertionError("lost READ wakeup");}
        @Override public void close(){socket.close();check(pool.usedRecvSlots()==0&&pool.usedSendSlots()==0,"leases released");check(closes==1,"one close callback");}
    }
    static byte[] concat(List<byte[]> frames){var out=new ByteArrayOutputStream();for(var f:frames)out.writeBytes(f);return out.toByteArray();}
    static long payloadHash(long hash,int length,int id){for(int i=1;i<length;i++)hash=hash*31+((id+i*7)&255);return hash;}
    static WritablePacket<CIOClient> packet(byte[] body){return new WritablePacket<>(){
        protected boolean write(CIOClient c,WriteBuffer b){b.writeBytes(body);return true;}};}

    static void fragmented(){
        for(boolean ready:new boolean[]{false,true})for(int chunk:new int[]{1,2,7,4096,65536})try(var s=new Session(true)){
            s.client.ready=ready;var enc=new ClientEncoder();var frames=new ArrayList<byte[]>();var expected=new ArrayList<Integer>();var locks=new ArrayList<Boolean>();long hash=0;
            for(int i=0;i<512;i++){int op=i&255,len=4+(i%79);frames.add(enc.frame(op,len,i));if(op>=1&&op<=3){expected.add(op);locks.add(op==2||(!ready&&op!=1));hash=payloadHash(hash,len,i);}}
            for(int len:new int[]{4090,4091,8192,65529,4}){frames.add(enc.frame(1,len,len));expected.add(1);locks.add(false);hash=payloadHash(hash,len,len);}
            s.socket.startRead();s.feed(concat(frames),chunk);
            check(s.socket.isOpen(),"fragmented stream remains open");check(s.client.seen.equals(expected),"all 256 opcodes preserve routing/order");
            check(s.client.locks.equals(locks),"session synchronization preserved");check(s.client.checksum==hash,"payload survives fragmentation/promotion/compaction");
            check(s.client.filters==frames.size()&&s.client.rates==frames.size(),"every encrypted frame filtered/rate counted once");
            check(s.pool.usedRecvSlots()==1,"large receive returns to small lease");
        }
    }
    static void rejection(){
        for(int length=0;length<10;length++){if(length==2)continue;try(var s=new Session(true)){
            byte[] b=new byte[Math.max(2,length)];b[0]=(byte)length;s.socket.startRead();s.feed(b,1);check(!s.socket.isOpen(),"invalid frame closes "+length);}}
        try(var s=new Session(true)){s.client.limit=2;s.socket.startRead();var e=new ClientEncoder();s.feed(concat(List.of(e.frame(1,4,0),e.frame(99,4,1),e.frame(1,4,2))),4096);
            check(!s.socket.isOpen()&&s.client.dispatches==1&&s.client.rates==3&&s.client.filters==2,"rate limit includes unknown frames");}
        ConnectionConfig.PACKET_LIMIT_PER_SEC=2;
        try(var s=new Session(true)){s.socket.startRead();s.feed(new byte[]{2,0,2,0,2,0},6);check(!s.socket.isOpen()&&s.client.dispatches==0,"empty packet limit");}
        ConnectionConfig.PACKET_LIMIT_PER_SEC=100000000;
        try(var s=new Session(true)){s.socket.startRead();for(int i=0;i<8;i++)s.channel.zeroRead();check(!s.socket.isOpen(),"zero-read completion bound");}
        try(var s=new Session(false)){s.socket.startRead();s.feed(new byte[]{10,0,1,2,3,4,0,0,0,0},1);check(s.client.dispatches==1,"compatibility without cipher");}
        try(var s=new Session(true)){s.client.handler=(op,b)->{throw new IllegalStateException("injected handler failure");};s.socket.startRead();s.feed(new ClientEncoder().frame(1,4,0),20);check(!s.socket.isOpen(),"handler failure closes and frees decode state");}
    }
    static void inlineAndNested(){
        try(var s=new Session(true)){var e=new ClientEncoder();var frames=new ArrayList<byte[]>();for(int i=0;i<3000;i++)frames.add(e.frame(1,4,i));
            s.channel.input=concat(frames);s.channel.inputChunk=1;s.channel.inlineRead=true;s.socket.startRead();check(s.client.dispatches==3000,"inline completions trampoline without recursion");}
        try(var outer=new Session(true);var inner=new Session(true)){
            inner.socket.startRead();outer.client.handler=(op,b)->{int pos=b.position(),remaining=b.remaining();inner.feed(new ClientEncoder().frame(2,4,0),1);
                check(b.isValid()&&b.position()==pos&&b.remaining()==remaining,"nested READ keeps outer view valid");};
            outer.socket.startRead();outer.feed(new ClientEncoder().frame(1,4,0),100);check(inner.client.dispatches==1&&outer.client.dispatches==1,"nested different sockets dispatch once");}
    }
    static void sendAndPause(){
        try(var s=new Session(true)){
            s.channel.autoWrite=false;var e=new ClientEncoder();var frames=new ArrayList<byte[]>();var expected=new ByteArrayOutputStream();var cipher=new ServerCipher();
            byte[] hello={1,2,3,4};check(s.socket.tryWritePacket(s.client,packet(hello)),"plain handshake admitted");expected.writeBytes(new byte[]{6,0,1,2,3,4});
            s.client.handler=(op,b)->{byte[] body={(byte)s.client.dispatches,7,8,9};check(s.socket.tryWritePacket(s.client,packet(body)),"reply admitted");expected.writeBytes(cipher.frame(body));};
            for(int i=0;i<100;i++)frames.add(e.frame(1,4,i));s.socket.startRead();s.feed(concat(frames),4096);
            check(!s.socket.isSendReadWritable()&&s.client.dispatches<100,"SEND watermark pauses buffered input");
            int steps=0;while(s.channel.writeDone!=null&&steps++<2000)s.channel.finishWrite(3);
            check(s.client.dispatches==100&&s.socket.isSendReadWritable(),"partial WRITE resumes every buffered frame");
            check(Arrays.equals(expected.toByteArray(),s.channel.output.toByteArray()),"packed/gather encrypted SEND keeps packet order and cipher state");
            check(s.socket.isWriteIdle()&&s.pool.usedSendSlots()==0,"all sends retired");
        }
    }
    static void loopback()throws Exception{
        var pool=new CIOBufferPool(4,64,4,4);var ready=new CountDownLatch(1);AtomicReference<CIOUserSocket> socket=new AtomicReference<>();AtomicReference<CIOClient> client=new AtomicReference<>();
        try(var server=new CIOServer(new InetSocketAddress("127.0.0.1",0),4,2,8,pool,(ch,p,closed)->{
            var s=new CIOUserSocket(ch,p,new CIOThreadCallback(),"loopback",0,32,closed);var c=new CIOClient(s);s.bindClient(c);s.initializeCipher(SEED);
            c.handler=(op,b)->s.tryWritePacket(c,packet(new byte[]{11,22,33,44}));socket.set(s);client.set(c);ready.countDown();return s;})){
            try(var peer=new Socket()){peer.connect(server.localAddress());peer.setSoTimeout(5000);check(ready.await(5,TimeUnit.SECONDS),"accepted real TCP");
                var enc=new ClientEncoder();for(int i=0;i<100;i++){byte[] f=enc.frame(1,8,i);peer.getOutputStream().write(f,0,1);peer.getOutputStream().write(f,1,f.length-1);}
                byte[] actual=peer.getInputStream().readNBytes(600);var expected=new ByteArrayOutputStream();expected.writeBytes(new byte[]{6,0,11,22,33,44});var cipher=new ServerCipher();
                for(int i=1;i<100;i++)expected.writeBytes(cipher.frame(new byte[]{11,22,33,44}));
                check(Arrays.equals(actual,expected.toByteArray()),"real TCP encrypted replies byte-exact");check(client.get().dispatches==100,"real TCP 100 commands");
            }
            server.close();check(server.awaitTermination(5,TimeUnit.SECONDS),"real completion group terminated");check(pool.usedRecvSlots()==0&&pool.usedSendSlots()==0,"real TCP leases released");
        }
        System.out.println("PASS real NIO.2 loopback: "+checks+" assertions; stub game handlers");
    }
    static void benchmark(){
        final int count=200000;var e=new ClientEncoder();var out=new ByteArrayOutputStream();for(int i=0;i<count;i++)out.writeBytes(e.frame(1,8,i));byte[] input=out.toByteArray();
        long[] samples=new long[7];long sum=0;for(int run=0;run<10;run++)try(var s=new Session(true)){
            s.client.record=false;s.channel.input=input;s.channel.inputChunk=4096;s.channel.inlineRead=true;long start=System.nanoTime();s.socket.startRead();long elapsed=System.nanoTime()-start;
            check(s.client.dispatches==count,"benchmark processed all frames");sum^=s.client.checksum;if(run>=3)samples[run-3]=elapsed;
        }
        Arrays.sort(samples);System.out.printf(Locale.ROOT,"BENCH frames=%d median_ms=%.3f ns_per_frame=%.2f checksum=%d%n",count,samples[3]/1e6,(double)samples[3]/count,sum);
    }
    public static void main(String[]args)throws Exception{
        if(args[0].equals("benchmark")){benchmark();return;}if(args[0].equals("loopback")){loopback();return;}
        fragmented();rejection();inlineAndNested();sendAndPause();System.out.println("PASS actual network transport: "+checks+" assertions; controlled completions/game handlers");
    }
}
