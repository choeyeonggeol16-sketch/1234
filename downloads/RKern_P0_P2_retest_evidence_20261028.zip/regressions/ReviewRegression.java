package l1j.server.server.model.network.core;

import java.io.*;
import java.net.*;
import java.nio.*;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.*;
import java.util.function.*;
import l1j.server.server.model.network.buffer.WriteBuffer;
import l1j.server.server.model.network.packet.WritablePacket;
import l1j.server.server.model.network.thread.CIOThreadCallback;

/** Review probes: actual core classes, isolated game/SQL boundaries. */
public final class ReviewRegression {
    static int checks;
    static void check(boolean ok,String why){checks++;if(!ok)throw new AssertionError(why);}
    static void await(CountDownLatch l){try{if(!l.await(5,TimeUnit.SECONDS))throw new AssertionError("latch timeout");}catch(InterruptedException e){throw new AssertionError(e);}}
    static Thread start(AtomicReference<Throwable> error,Runnable action){Thread t=new Thread(()->{try{action.run();}catch(Throwable e){error.compareAndSet(null,e);}});t.setDaemon(true);t.start();return t;}
    static void join(Thread t,AtomicReference<Throwable> error)throws Exception{t.join(5000);check(!t.isAlive(),"producer terminated");if(error.get()!=null)throw new AssertionError(error.get());}
    static WritablePacket<CIOClient> blocked(CountDownLatch entered,CountDownLatch release,byte value){
        return new WritablePacket<>(){protected boolean write(CIOClient c,WriteBuffer b){entered.countDown();await(release);b.writeC(value);return true;}};
    }
    static void reservedFifo()throws Exception{
        try(var s=new NetworkRegression.Session(false)){
            var entered=new CountDownLatch(1);var release=new CountDownLatch(1);var error=new AtomicReference<Throwable>();var admitted=new AtomicBoolean();
            Thread t=start(error,()->admitted.set(s.socket.tryWritePacket(s.client,blocked(entered,release,(byte)11))));await(entered);
            try{
                check(s.socket.tryWritePacket(s.client,NetworkRegression.packet(new byte[]{22})),"later encoder admitted");
                check(s.channel.output.size()==0,"later encoder cannot overtake unfinished earlier reservation");
                check(s.pool.usedSendSlots()==2,"both encoders retain their SEND leases");
            }finally{release.countDown();}
            join(t,error);check(admitted.get(),"earlier encoder committed");
            check(Arrays.equals(s.channel.output.toByteArray(),new byte[]{3,0,11,3,0,22}),"reserved FIFO order preserved on wire");
            check(s.socket.isWriteIdle()&&s.pool.usedSendSlots()==0,"reserved sends drained");
        }
    }
    static void closeDuringEncode()throws Exception{
        try(var s=new NetworkRegression.Session(false)){
            var entered=new CountDownLatch(1);var release=new CountDownLatch(1);var error=new AtomicReference<Throwable>();var admitted=new AtomicBoolean(true);
            Thread t=start(error,()->admitted.set(s.socket.tryWritePacket(s.client,blocked(entered,release,(byte)11))));await(entered);
            try{s.socket.close();check(s.closes==0&&!s.socket.isCloseComplete(),"close notification waits for live encoder");check(s.pool.usedSendSlots()==1,"encoder buffer remains owned after close");}
            finally{release.countDown();}
            join(t,error);check(!admitted.get()&&s.channel.output.size()==0,"closed socket rejects encoded packet");
            check(s.closes==1&&s.pool.usedSendSlots()==0,"cancelled reservation releases once");
        }
    }
    static void delayedCompletionClose(){
        for(boolean readFirst:new boolean[]{true,false})try(var s=new NetworkRegression.Session(false)){
            s.channel.delayClose=true;s.channel.autoWrite=false;s.socket.startRead();
            check(s.socket.tryWritePacket(s.client,NetworkRegression.packet(new byte[]{1,2,3})),"pending WRITE admitted");
            s.socket.close();check(s.pool.usedRecvSlots()==1&&s.pool.usedSendSlots()==1&&s.closes==0,"pending I/O buffers retained across close");
            if(readFirst)s.channel.zeroRead();else s.channel.finishWrite(9999);
            check(s.closes==0,"first completion alone does not notify close");
            if(readFirst)s.channel.finishWrite(9999);else s.channel.zeroRead();
            check(s.closes==1&&s.socket.isCloseComplete(),"last completion notifies close exactly once");
            check(s.pool.usedRecvSlots()==0&&s.pool.usedSendSlots()==0,"both completion orders release all buffers");
        }
    }
    static void concurrentProducers()throws Exception{
        for(int round=0;round<12;round++)try(var s=new NetworkRegression.Session(false)){
            int threads=8,packets=250;var go=new CountDownLatch(1);var error=new AtomicReference<Throwable>();var workers=new ArrayList<Thread>();
            // Keep at most eight outstanding SENDs. A producer returning true
            // means admission, not delivery; an unpaced flood may legitimately
            // hit the bounded 256-frame queue even with inline completions.
            var batch=new CyclicBarrier(threads,()->{
                if(!s.socket.isWriteIdle())throw new AssertionError("batch did not fully drain");
            });
            for(int id=0;id<threads;id++){final int producer=id;workers.add(start(error,()->{await(go);for(int seq=0;seq<packets;seq++){
                byte[] body=ByteBuffer.allocate(8).order(ByteOrder.LITTLE_ENDIAN).putInt(producer).putInt(seq).array();
                if(!s.socket.tryWritePacket(s.client,NetworkRegression.packet(body)))throw new AssertionError("bounded batch admission loss");
                try{batch.await(5,TimeUnit.SECONDS);}catch(Exception e){throw new AssertionError(e);}
            }}));}
            go.countDown();for(var t:workers)join(t,error);
            check(s.socket.isOpen()&&s.socket.isWriteIdle(),"all concurrent sends drained without close");
            var wire=ByteBuffer.wrap(s.channel.output.toByteArray()).order(ByteOrder.LITTLE_ENDIAN);int[] next=new int[threads];int count=0;
            while(wire.hasRemaining()){
                if(wire.remaining()<10||Short.toUnsignedInt(wire.getShort())!=10)throw new AssertionError("corrupt wire framing");
                int id=wire.getInt(),seq=wire.getInt();if(id<0||id>=threads||next[id]++!=seq)throw new AssertionError("producer ordering or duplication");count++;
            }
            check(count==threads*packets,"all 2000 packets present once");check(Arrays.stream(next).allMatch(n->n==packets),"each producer keeps ordering");
            check(s.pool.usedSendSlots()==0,"concurrent producer leases released");
        }
    }
    static void slots()throws Exception{
        var pool=new CIOSlotPool(64,193,0);var inUse=new AtomicIntegerArray(193);var go=new CountDownLatch(1);var error=new AtomicReference<Throwable>();var workers=new ArrayList<Thread>();
        for(int id=0;id<8;id++)workers.add(start(error,()->{await(go);for(int n=0;n<10000;n++){
            int slot=pool.acquire();if(slot<0)throw new AssertionError("unexpected pool exhaustion");int generation=pool.generation(slot);
            if(!inUse.compareAndSet(slot,0,1)||!pool.validate(slot,generation))throw new AssertionError("concurrent slot alias");
            if(!inUse.compareAndSet(slot,1,0))throw new AssertionError("lost slot ownership");pool.release(slot,generation);
        }}));go.countDown();for(var t:workers)join(t,error);
        check(pool.freeCount()==193,"80000 concurrent slot lifecycles return all slots");
        int slot=pool.acquire(),generation=pool.generation(slot);pool.release(slot,generation);boolean rejected=false;
        try{pool.release(slot,generation);}catch(IllegalStateException expected){rejected=true;}check(rejected,"double release rejected");
        check(!pool.validate(slot,generation),"released generation invalid");
    }
    static void directAndExhaustion(){
        try(var s=new NetworkRegression.Session(false)){
            CIOFrame f=s.socket.beginDirectFrame(65535);check(f!=null,"maximum direct frame admitted");
            f.buffer().writeBytes(new byte[65533]);check(s.socket.commitDirectFrame(f),"maximum direct frame committed");
            check(s.channel.output.size()==65535&&s.pool.usedSendSlots()==0,"maximum SEND completes and releases large pool");
        }
        try(var s=new NetworkRegression.Session(false)){
            CIOFrame f=s.socket.beginDirectFrame(10);check(f!=null,"direct producer reserved");s.socket.close();
            check(s.closes==0&&s.pool.usedSendSlots()==1,"direct producer retains lease during close");s.socket.abortDirectFrame(f);
            check(s.closes==1&&s.pool.usedSendSlots()==0,"direct abort retires reservation and notifies close");
        }
        var channel=new NetworkRegression.FakeChannel();channel.autoWrite=false;var pool=new CIOBufferPool(1,1,1,1);var closes=new AtomicInteger();
        var socket=new CIOUserSocket(channel,pool,new CIOThreadCallback(),"pool",0,256,s->closes.incrementAndGet());var client=new CIOClient(socket);socket.bindClient(client);
        check(socket.tryWritePacket(client,NetworkRegression.packet(new byte[]{1})),"single pool slot occupied");
        check(!socket.tryWritePacket(client,NetworkRegression.packet(new byte[]{2})),"pool exhaustion returns explicit admission failure");
        socket.close();check(pool.usedSendSlots()==0&&closes.get()==1,"pool exhaustion close drains pending buffer");
    }
    static void probeCompletionBudget(){
        try(var s=new NetworkRegression.Session(true)){
            var encoder=new NetworkRegression.ClientEncoder();var frames=new ArrayList<byte[]>();for(int i=0;i<100;i++)frames.add(encoder.frame(1,4,i));
            s.socket.startRead();int readCalls=s.channel.reads;s.feed(NetworkRegression.concat(frames),4096);
            check(s.client.dispatches==100,"one 1000-byte READ completion executes all 100 handlers");
            check(s.channel.reads==readCalls+1,"one completed READ then one next READ");
            System.out.println("OBSERVED one READ completion: 100 handlers; transport has no configured frame-count yield");
        }
    }
    static void workerCap()throws Exception{
        var pool=new CIOBufferPool(1,1,1,1);
        try(var server=new CIOServer(new InetSocketAddress("127.0.0.1",0),1,32,8,pool,(ch,p,closed)->null)){
            var field=CIOServer.class.getDeclaredField("_ioWorkerIndex");field.setAccessible(true);
            int created=((AtomicInteger)field.get(server)).get();int expected=Math.min(8,Math.max(1,Runtime.getRuntime().availableProcessors()));
            check(created==expected,"requested 32 workers clamped to min(8,CPUs)");
            System.out.println("OBSERVED ioThreads requested=32; created="+created+"; CPUs="+Runtime.getRuntime().availableProcessors());
            server.close();check(server.awaitTermination(5,TimeUnit.SECONDS),"worker probe server stopped");
        }
    }
    public static void main(String[] args)throws Exception{
        if(args[0].equals("review-loopback")){workerCap();System.out.println("PASS worker configuration probe: "+checks+" assertions");return;}
        reservedFifo();closeDuringEncode();delayedCompletionClose();concurrentProducers();slots();directAndExhaustion();probeCompletionBudget();
        System.out.println("PASS additional core review: "+checks+" assertions; 24000 concurrent SENDs; 80000 concurrent slot lifecycles");
    }
}
