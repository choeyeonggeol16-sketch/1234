package l1j.server.server.model.network.safe;
import l1j.server.server.model.network.core.CIOClient;public final class NetworkSafeLoadManager {
 public static final int RESULT_FILTER=4; public static int isFilter(CIOClient c,int op){c.filters++;return op==4?4:2;}
}