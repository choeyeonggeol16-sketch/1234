package l1j.server.server.model.network.packet;
import l1j.server.server.model.network.buffer.ReadBuffer;import l1j.server.server.model.network.core.CIOClient;
public final class CPacketHandler {
 public interface PacketHandler {boolean execute(ReadBuffer b,CIOClient c);}
 public static final PacketHandler[] HANDLERS=new PacketHandler[256];
 static {for(int i=1;i<=4;i++){final int op=i;HANDLERS[i]=(b,c)->{c.receive(op,b);return true;};}}
 public static boolean isFastOpcode(int op){return HANDLERS[op]!=null;} public static boolean isDirectOpcode(int op){return op==1;}
 public static boolean isSessionOpcode(int op){return op==2;}
}