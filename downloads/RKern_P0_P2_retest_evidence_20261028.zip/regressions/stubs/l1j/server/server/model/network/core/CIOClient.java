package l1j.server.server.model.network.core;
import java.util.*;import java.util.function.*;import l1j.server.server.model.network.buffer.ReadBuffer;
public final class CIOClient {
 public final CIOUserSocket socket; public boolean connected=true,ready=true,record=true;
 public int empty,rates,filters,dispatches,limit=Integer.MAX_VALUE; public long checksum;
 public final List<Integer> seen=new ArrayList<>(); public final List<Boolean> locks=new ArrayList<>();
 public BiConsumer<Integer,ReadBuffer> handler;
 public CIOClient(CIOUserSocket s){socket=s;} public CIOUserSocket getConnection(){return socket;}
 public boolean isConnected(){return connected&&socket.isClientConnected();} public boolean isGameSessionReady(){return ready;}
 public void disconnect(){connected=false;socket.close();} public int incrementEmptyPacketCount(){return ++empty;}
 public void resetEmptyPacketCount(){empty=0;} public boolean checkPacketRateLimit(long t){return ++rates>limit;}
 public void receive(int opcode,ReadBuffer b){dispatches++;if(record){seen.add(opcode);locks.add(Thread.holdsLock(this));}
  while(b.remaining()>0)checksum=checksum*31+(b.readUnsignedByte());
  if(handler!=null)handler.accept(opcode,b);
 }
}