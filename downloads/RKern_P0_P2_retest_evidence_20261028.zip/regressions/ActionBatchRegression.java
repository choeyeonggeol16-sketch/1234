package l1j.server.server.model.network.core;

import java.io.*;
import java.net.*;
import java.nio.*;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.*;
import l1j.server.server.Opcodes;
import l1j.server.server.model.network.buffer.WriteBuffer;
import l1j.server.server.model.network.packet.WritablePacket;
import l1j.server.server.model.network.thread.CIOThreadCallback;

/** Actual socket/pool/cipher, controlled completion boundary and game handlers. */
public final class ActionBatchRegression {
    static int checks;
    static void check(boolean b,String why){checks++;if(!b)throw new AssertionError(why);}
    static byte[] body(int objectId,int action){return ByteBuffer.allocate(6).order(ByteOrder.LITTLE_ENDIAN).put((byte)Opcodes.S_ACTION).putInt(objectId).put((byte)action).array();}
    static byte[] plain(int objectId,int action){return ByteBuffer.allocate(8).order(ByteOrder.LITTLE_ENDIAN).putShort((short)8).put(body(objectId,action)).array();}
    static byte[] expected(int count,boolean cipher){var out=new ByteArrayOutputStream();var c=new NetworkRegression.ServerCipher();for(int i=0;i<count;i++)out.writeBytes(cipher&&i>0?c.frame(body(i,i)):plain(i,i));return out.toByteArray();}
    static void drain(NetworkRegression.FakeChannel ch){int steps=0;while(ch.writeDone!=null&&steps++<200000)ch.finishWrite(3);check(ch.writeDone==null,"partial completions terminate");}
    static void burstReuse(){
        for(boolean cipher:new boolean[]{false,true})try(var s=new NetworkRegression.Session(cipher)){
            CIOUserSocket.beginSendBurst();try{for(int i=0;i<32;i++)check(s.socket.tryWriteAction(i,i),"burst action admitted");
                check(s.pool.allocatedDirectBytes()==CIOBufferPool.SMALL_SEND_BYTES,"one SEND backing buffer for 32 actions");
                check(s.channel.writes==0&&s.socket.pendingSendBytes()==256,"deferred burst accounting");
            }finally{CIOUserSocket.endSendBurst();}
            check(Arrays.equals(s.channel.output.toByteArray(),expected(32,cipher)),"burst wire bytes and packet cipher boundaries");
            check(s.socket.isWriteIdle()&&s.pool.usedSendSlots()==0,"burst fully released");
        }
    }
    static void queuedAndBoundary(){
        for(boolean cipher:new boolean[]{false,true})try(var s=new NetworkRegression.Session(cipher)){
            s.channel.autoWrite=false;for(int i=0;i<96;i++)check(s.socket.tryWriteAction(i,i),"queued action admitted");
            check(s.pool.usedSendSlots()==2,"one active WRITE and one queued batch");
            check(s.pool.allocatedDirectBytes()==2L*CIOBufferPool.SMALL_SEND_BYTES,"no temporary third SEND buffer");
            check(!s.socket.isSendReadWritable()&&s.socket.pendingSendBytes()==768,"logical packed frame watermark maintained");
            drain(s.channel);check(s.socket.isSendReadWritable()&&s.socket.pendingSendBytes()==0,"watermark and bytes resume after retire");
            check(Arrays.equals(s.channel.output.toByteArray(),expected(96,cipher)),"queued partial WRITE cipher/order");
        }
        try(var s=new NetworkRegression.Session(true)){
            CIOUserSocket.beginSendBurst();try{for(int i=0;i<2100;i++)check(s.socket.tryWriteAction(i,i),"large burst action admitted");}finally{CIOUserSocket.endSendBurst();}
            check(Arrays.equals(s.channel.output.toByteArray(),expected(2100,true)),"8KiB flush threshold crossed without lost frames");
            check(s.socket.isWriteIdle()&&s.pool.usedSendSlots()==0,"large burst counters released");
        }
    }
    static final class TinySession implements AutoCloseable{
        final NetworkRegression.FakeChannel channel=new NetworkRegression.FakeChannel();final CIOBufferPool pool=new CIOBufferPool(1,1,1,1);final CIOUserSocket socket;final CIOClient client;int closes;
        TinySession(){socket=new CIOUserSocket(channel,pool,new CIOThreadCallback(),"tiny",0,256,s->closes++);client=new CIOClient(socket);socket.bindClient(client);}
        public void close(){socket.close();check(pool.usedSendSlots()==0&&closes==1,"tiny pool close releases exactly once");}
    }
    static void saturatedPool(){
        try(var s=new TinySession()){
            s.channel.autoWrite=false;CIOUserSocket.beginSendBurst();try{
                for(int i=0;i<32;i++)check(s.socket.tryWriteAction(i,i),"append succeeds with no spare SEND slot");
                check(s.pool.smallSendExhaustions()==0,"append never acquires a temporary slot");
            }finally{CIOUserSocket.endSendBurst();}
            drain(s.channel);check(Arrays.equals(s.channel.output.toByteArray(),expected(32,false)),"tiny-pool burst complete");
        }
        try(var s=new TinySession()){
            s.channel.autoWrite=false;check(s.socket.tryWriteAction(0,0),"active frame admitted");
            check(!s.socket.tryWriteAction(1,1),"active I/O buffer is never appended to when pool is full");
            drain(s.channel);check(Arrays.equals(s.channel.output.toByteArray(),plain(0,0)),"in-flight bytes unchanged");
        }
    }
    static void pendingEncoder()throws Exception{
        try(var s=new NetworkRegression.Session(false)){
            var entered=new CountDownLatch(1);var release=new CountDownLatch(1);var failure=new AtomicReference<Throwable>();
            CIOUserSocket.beginSendBurst();try{
                check(s.socket.tryWriteAction(0,0),"first batch member");
                var packet=new WritablePacket<CIOClient>(){protected boolean write(CIOClient c,WriteBuffer b){entered.countDown();try{if(!release.await(5,TimeUnit.SECONDS))throw new AssertionError("timeout");}catch(InterruptedException e){throw new AssertionError(e);}b.writeBytes(new byte[]{77,88});return true;}};
                Thread t=new Thread(()->{try{if(!s.socket.tryWritePacket(s.client,packet))throw new AssertionError("earlier encoder rejected");}catch(Throwable e){failure.set(e);}});t.setDaemon(true);t.start();check(entered.await(5,TimeUnit.SECONDS),"earlier encoder holds reservation");
                try{check(s.socket.tryWriteAction(2,2),"later action admitted through ticket path");check(s.channel.writes==0,"no wire publication ahead of reserved packet");}finally{release.countDown();}
                t.join(5000);check(!t.isAlive()&&failure.get()==null,"encoder completed");
            }finally{CIOUserSocket.endSendBurst();}
            var out=new ByteArrayOutputStream();out.writeBytes(plain(0,0));out.writeBytes(new byte[]{4,0,77,88});out.writeBytes(plain(2,2));
            check(Arrays.equals(s.channel.output.toByteArray(),out.toByteArray()),"action append cannot overtake earlier encoder");
        }
    }
    static void closePacked(){
        try(var s=new NetworkRegression.Session(false)){
            CIOUserSocket.beginSendBurst();try{for(int i=0;i<32;i++)check(s.socket.tryWriteAction(i,i),"pending packed member");s.socket.close();
                check(s.pool.usedSendSlots()==0&&s.closes==1,"close retires packed bytes/frame accounting");
            }finally{CIOUserSocket.endSendBurst();}
            check(s.channel.output.size()==0,"closed unsubmitted burst is not written");
        }
    }
    static void concurrentActions()throws Exception{
        try(var s=new NetworkRegression.Session(false)){
            s.channel.autoWrite=false;check(s.socket.tryWriteAction(-1,0),"hold first WRITE");
            var go=new CountDownLatch(1);var error=new AtomicReference<Throwable>();var threads=new ArrayList<Thread>();
            for(int id=0;id<8;id++){final int producer=id;Thread t=new Thread(()->{try{go.await();for(int n=0;n<24;n++)if(!s.socket.tryWriteAction((producer<<20)|n,n))throw new AssertionError("bounded producer admission");}catch(Throwable e){error.compareAndSet(null,e);}});t.setDaemon(true);threads.add(t);t.start();}
            go.countDown();for(var t:threads){t.join(5000);check(!t.isAlive(),"action producer terminated");}check(error.get()==null,"all bounded concurrent actions admitted");
            drain(s.channel);var b=ByteBuffer.wrap(s.channel.output.toByteArray()).order(ByteOrder.LITTLE_ENDIAN);int[] next=new int[8];int count=0;
            while(b.hasRemaining()){
                if(b.remaining()<8||b.getShort()!=8||(b.get()&255)!=Opcodes.S_ACTION)throw new AssertionError("bad action frame");int obj=b.getInt(),action=b.get()&255;
                if(count++==0){if(obj!=-1)throw new AssertionError("first frame order");continue;}
                int producer=obj>>>20,seq=obj&0xfffff;if(producer>=8||seq!=next[producer]++||action!=(seq&255))throw new AssertionError("concurrent action ordering");
            }
            check(count==193&&Arrays.stream(next).allMatch(n->n==24),"all concurrent actions once, in producer order");
            check(s.pool.usedSendSlots()==0&&s.socket.isWriteIdle(),"concurrent actions fully retired");
        }
    }
    static void receivePause(){
        try(var s=new NetworkRegression.Session(true)){
            s.channel.autoWrite=false;var enc=new NetworkRegression.ClientEncoder();var frames=new ArrayList<byte[]>();var expected=new ByteArrayOutputStream();var cipher=new NetworkRegression.ServerCipher();var sent=new AtomicInteger();
            s.client.handler=(op,b)->{for(int n=0;n<3;n++){int id=sent.getAndIncrement();if(!s.socket.tryWriteAction(id,id))throw new AssertionError("reply not admitted");expected.writeBytes(id==0?plain(id,id):cipher.frame(body(id,id)));}};
            for(int n=0;n<100;n++)frames.add(enc.frame(1,4,n));s.socket.startRead();s.feed(NetworkRegression.concat(frames),4096);
            check(!s.socket.isSendReadWritable()&&s.client.dispatches<100,"packed actions stop buffered READ at high watermark");drain(s.channel);
            check(s.client.dispatches==100&&sent.get()==300,"low watermark resumes every buffered command");
            check(Arrays.equals(s.channel.output.toByteArray(),expected.toByteArray()),"resumed controller sends preserve packet cipher state");
            check(s.socket.isSendReadWritable()&&s.socket.pendingSendBytes()==0,"all resumed accounting released");
        }
    }
    static void loopback()throws Exception{
        var pool=new CIOBufferPool(4,64,4,4);var admitted=new CountDownLatch(1);
        try(var server=new CIOServer(new InetSocketAddress("127.0.0.1",0),4,32,8,pool,(ch,p,closed)->{
            var socket=new CIOUserSocket(ch,p,new CIOThreadCallback(),"loopback",0,32,closed);var client=new CIOClient(socket);socket.bindClient(client);socket.initializeCipher(NetworkRegression.SEED);
            client.handler=(op,b)->{int base=(client.dispatches-1)*3;for(int n=0;n<3;n++)if(!socket.tryWriteAction(base+n,base+n))throw new AssertionError("TCP SEND rejected");};admitted.countDown();return socket;})){
            var workerField=CIOServer.class.getDeclaredField("_ioWorkerIndex");workerField.setAccessible(true);int workers=((AtomicInteger)workerField.get(server)).get();
            check(workers==Math.min(8,Math.max(1,Runtime.getRuntime().availableProcessors())),"reported actual worker count preserves CPU/eight cap");
            try(var peer=new Socket()){
                peer.connect(server.localAddress());peer.setSoTimeout(5000);check(admitted.await(5,TimeUnit.SECONDS),"real TCP session admitted");var enc=new NetworkRegression.ClientEncoder();
                for(int n=0;n<100;n++){var frame=enc.frame(1,4,n);peer.getOutputStream().write(frame,0,1);peer.getOutputStream().write(frame,1,frame.length-1);}
                check(Arrays.equals(peer.getInputStream().readNBytes(2400),expected(300,true)),"real TCP 300 action replies byte-exact");
            }
            server.close();check(server.awaitTermination(5,TimeUnit.SECONDS),"real TCP group stopped");check(pool.usedRecvSlots()==0&&pool.usedSendSlots()==0,"real TCP buffers all returned");
        }
        System.out.println("PASS action TCP loopback: "+checks+" assertions; stub game handlers");
    }
    static void benchmark(){
        int count=200000;long[] times=new long[7];long total=0,allocated=0;for(int run=0;run<10;run++)try(var s=new NetworkRegression.Session(false)){
            // Measure real transport work without the harness's synchronized
            // byte-at-a-time capture. Regression tests compare every wire byte.
            s.channel.recordOutput=false;
            long start=System.nanoTime();for(int i=0;i<count;i+=32){CIOUserSocket.beginSendBurst();try{for(int j=i;j<Math.min(i+32,count);j++)if(!s.socket.tryWriteAction(j,j))throw new AssertionError("benchmark dropped SEND");}finally{CIOUserSocket.endSendBurst();}}
            long elapsed=System.nanoTime()-start;if(s.channel.outputBytes!=count*8||!s.socket.isWriteIdle())throw new AssertionError("benchmark incomplete SEND");
            total+=s.channel.outputBytes;allocated=s.pool.allocatedDirectBytes();if(run>=3)times[run-3]=elapsed;
        }
        Arrays.sort(times);System.out.printf(Locale.ROOT,"ACTION_BENCH frames=%d median_ms=%.3f ns_per_frame=%.2f allocated_direct_bytes=%d total_wire=%d%n",count,times[3]/1e6,(double)times[3]/count,allocated,total);
    }
    public static void main(String[]args)throws Exception{
        if(args[0].equals("action-benchmark")){benchmark();return;}if(args[0].equals("action-loopback")){loopback();return;}
        burstReuse();queuedAndBoundary();saturatedPool();pendingEncoder();closePacked();concurrentActions();receivePause();
        System.out.println("PASS action batch regressions: "+checks+" assertions; controlled I/O/game handlers");
    }
}
