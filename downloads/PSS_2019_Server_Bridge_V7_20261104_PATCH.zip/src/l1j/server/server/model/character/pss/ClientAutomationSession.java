package l1j.server.server.model.character.pss;

/** Connection-owned immutable state; never retains a player or an item. */
public record ClientAutomationSession(int mode, int playerStamp, int mapId, long deadlineNanos) {
    public static final ClientAutomationSession SERVER = new ClientAutomationSession(0, 0, 0, 0L);

    public boolean clientDriven() { return this != SERVER; }

    public int remainingSeconds(long nowNanos) {
        long remaining = deadlineNanos - nowNanos;
        return remaining <= 0L ? 0 : (int) ((remaining + 999_999_999L) / 1_000_000_000L);
    }
}
