-- Restore backed-up values only while the applied class ID/image/name still match.
SET NAMES utf8mb4;
UPDATE npc n JOIN npc_book_classid_backup_20261104 b
 ON n.npcid=b.npc_id AND n.gfxid=b.gfxid AND CONVERT(REPLACE(REPLACE(REPLACE(REPLACE(TRIM(n.name),' ',''),CHAR(9),''),CHAR(10),''),CHAR(13),'') USING utf8mb4) COLLATE utf8mb4_bin=b.name_key
 SET n.class_id=b.old_class_id WHERE n.class_id <=> b.new_class_id;
SELECT ROW_COUNT() AS restored_npcs;
-- Keep the backup table and the optional class_id column for review.
