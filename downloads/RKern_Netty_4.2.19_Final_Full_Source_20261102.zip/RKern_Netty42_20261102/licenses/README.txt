Original game-source license headers are preserved. GPL-2.0.txt supplies the referenced GPL version 2 text.
Netty 4.2.19.Final: Apache License 2.0; NETTY-LICENSE.txt and NETTY-NOTICE.txt are copied from the exact upstream tag.
The netty-third-party directory contains all license/notice files referenced by that upstream NOTICE. Optional components listed there are not all bundled.
Pinned binary origins and SHA-256 are in lib/network-dependencies.json.
New network42 source additions are made available under GPL-2.0-or-later.
