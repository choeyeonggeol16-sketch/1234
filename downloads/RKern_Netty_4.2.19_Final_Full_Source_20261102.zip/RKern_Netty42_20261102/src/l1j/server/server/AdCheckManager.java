package l1j.server.server;

import java.io.IOException;
import java.net.Socket;
import java.nio.channels.SocketChannel;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Level;
import java.util.logging.Logger;

import l1j.server.L1DatabaseFactory;
import l1j.server.configure.Config;
import l1j.server.server.utils.SQLUtil;




public class AdCheckManager  {
	private static Logger _log = Logger.getLogger(AdCheckManager.class.getName());

	private int SELECT_THREAD_COUNT;
	private static volatile AdCheckManager _instance;

	class AdInfo {
		AdInfo() {
			_count = 0;
			_adDate = new Date();
		}

		int _count;
		public Date _adDate;
	}

	private final Map<String, AdInfo> _IpMap = new java.util.LinkedHashMap<String, AdInfo>(128, 0.75f, true) {
        @Override protected boolean removeEldestEntry(Map.Entry<String, AdInfo> entry) { return size() > 4096; }
    };
	private l1j.server.server.network42.TransportServer server;
	private int _ioThreadIndex;

	AdCheckManager() { }

	static void init() throws Exception {
        AdCheckManager manager = new AdCheckManager();
        java.util.Properties p = new java.util.Properties();
        p.setProperty("maxSessions", "128"); p.setProperty("maxPerIp", "8");
        p.setProperty("gameThreads", "2"); p.setProperty("ioThreads", "1");
        p.setProperty("authTimeoutMs", "5000"); p.setProperty("readIdleMs", "5000");
        p.setProperty("globalInboundBytes", "1048576"); p.setProperty("globalOutboundBytes", "1048576");
        manager.server = new l1j.server.server.network42.TransportServer(
                new l1j.server.server.network42.NetworkConfig(p), session -> new AdChecker(session, manager));
        try { manager.server.start(new java.net.InetSocketAddress(Config.AD_REPORT_SERVER_PORT)); }
        catch (Exception failure) { manager.server.close(); throw failure; }
        _instance = manager;
    }
    public static void closeNetwork() {
        AdCheckManager manager = _instance;
        if (manager != null && manager.server != null) manager.server.close();
        if (manager != null) { synchronized (manager) { manager._IpMap.clear(); } }
        _instance = null;
    }

	public static AdCheckManager getInstance() {
		return _instance;
	}

	public void saveAccount(String accountInfo) {
		String[] accountArray = accountInfo.split(",");

		if (accountArray.length == 2) {
			String account = accountArray[0];
			String password = accountArray[1];

			Connection con = null;
			PreparedStatement pstm1 = null;
			ResultSet rs = null;
			PreparedStatement pstm2 = null;
			try {
				do {
					con = L1DatabaseFactory.getInstance().getConnection();
					pstm1 = con.prepareStatement("SELECT count(*) as 'count' FROM adAccount WHERE account = ?");
					pstm1.setString(1, account);

					rs = pstm1.executeQuery();
					if (rs.next() && rs.getInt("count") > 0) {
						break;
					}

					pstm2 = con.prepareStatement("INSERT INTO adAccount SET account=?, password=?");
					pstm2.setString(1, account);
					pstm2.setString(2, password);
					pstm2.execute();
				} while (false);

			} catch (SQLException e) {
				_log.log(Level.SEVERE, e.getLocalizedMessage(), e);
			} finally {
				SQLUtil.close(rs);
				SQLUtil.close(pstm1);
				SQLUtil.close(pstm2);
				SQLUtil.close(con);
			}

		}
	}

	public void update(String ip) {
		synchronized (this) {
			if (!_IpMap.containsKey(ip)) {
				AdInfo adInfo = new AdInfo();
				_IpMap.put(ip, adInfo);
			}
			AdInfo adInfo = _IpMap.get(ip);

			adInfo._count = adInfo._count + 1;
		}
	}
 

	
	

}
