package l1j.server.server;
import java.nio.charset.Charset;
import l1j.server.server.network42.*;
/** Bounded LE32 body framing; account storage runs off I/O in this endpoint's game-worker lane. */
public final class AdChecker implements SessionApplication {
    private final NettySession session;
    private final AdCheckManager manager;
    private boolean handled;
    public AdChecker(NettySession session, AdCheckManager manager) { this.session = session; this.manager = manager; }
    @Override public Framing framing() { return Framing.advertisement(); }
    @Override public byte[] decode(byte[] body) { return body; }
    @Override public byte[] encode(byte[] body) { return body; }
    @Override public void onPacket(byte[] body) {
        if (handled) { session.close(CloseReason.INVALID_FRAME); return; }
        handled = true;
        int end = 0; while (end < body.length && body[end] != 0) end++;
        String account = new String(body, 0, end, Charset.forName("EUC-KR"));
        manager.update(session.remoteIp()); manager.saveAccount(account);
        session.close(CloseReason.PEER_CLOSED);
    }
    @Override public void onClosed(CloseReason reason) { }
}
