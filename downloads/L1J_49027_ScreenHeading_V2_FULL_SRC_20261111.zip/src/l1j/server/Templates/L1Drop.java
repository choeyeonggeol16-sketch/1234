/*
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2, or (at your option)
 * any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
 * 02111-1307, USA.
 *
 * http://www.gnu.org/copyleft/gpl.html
 */
package l1j.server.Templates;

public class L1Drop {
	int _mobId;
	int _itemId;
	int _min;
	int _max;
	int _chance;
	int _enchant;
	int _range;
	

	public L1Drop(int mobId, int itemId, int min, int max, int chance, int enchant, int range) {
		_mobId = mobId;
		_itemId = itemId;
		_min = min;
		_max = max;
		_chance = chance;
		_enchant = enchant;
		_range = range;
	}

	public int getChance() {
		return _chance;
	}

	public int getItemid() {
		return _itemId;
	}

	public int getMax() {
		return _max;
	}

	public int getMin() {
		return _min;
	}

	public int getMobid() {
		return _mobId;
	}
	public int getEnchant() {
		return _enchant;
	} 
	public int getRange() {
		return _range;
	}

}
