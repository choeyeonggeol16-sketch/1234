Netty 4.2.19.Final 전체 소스 통합본 — 2026-11-02

이 ZIP은 전체 src를 포함합니다. 부분 패치가 아닙니다. Java 소스 970개, 원본 소스 부속 파일, Ant build.xml, Netty JAR 5개와 network42 설정을 포함합니다. 지금까지의 네트워크 변경, 삭제 예정 숫자 래퍼 생성자 45곳 수정, 두 private XML helper의 SAXException 명시 참조 정리를 합쳤습니다.

적용 위치: C:\Users\pc\eclipse-workspace\lin310netty

1. Eclipse에서 전체 저장한 후 종료합니다.
2. 위 프로젝트의 기존 src 폴더를 프로젝트 밖에 백업합니다.
3. ZIP 안의 lin310netty/src 전체와 build.xml을 현재 프로젝트의 해당 위치에 교체합니다. 기존 lib 폴더와 DB/맵/런타임 데이터는 보존합니다. Netty JAR 5개는 lib에 병합합니다.
4. Eclipse를 다시 열고 프로젝트 F5 새로 고침 후 Ant Build를 JDK 21로 실행합니다. 성공하면 프로젝트 루트에 l1jserver.jar가 생성됩니다.

Java 21 컴파일 설정과 Eclipse의 JRE/클래스패스는 별개입니다. 이 묶음은 사용자의 .classpath나 워크스페이스 설정을 덮어쓰지 않습니다. Eclipse의 실제 SAXException 호환 오류 메시지를 받지 못해 해당 설정 문제는 미재현입니다. SAXException의 명시 참조를 없애도 DOM 파싱에는 JDK java.xml이 여전히 필요합니다.

검증용 전체 소스는 스텁 없이 Ant 1.10.15/JDK 21로 컴파일하고 JAR을 생성했습니다. 원본의 c3p0/Javolution/Gson/JAXB/SWT 등 외부 라이브러리는 기존 프로젝트 lib를 사용해야 합니다. 동봉한 lib는 Netty JAR만 포함하므로 기존 lib 전체를 삭제하면 안 됩니다. 검증에는 공식 Maven SWT 3.126.0을 사용했고 사용자 SWT 3.100.1은 미제공입니다. 전체 GUI/DB 서버 기동은 미검증입니다.

SOURCE_FILES.sha256는 전체 src 파일별 체크섬입니다. SOURCE_CHANGES.json은 최초 업로드 ZIP 대비 수정/추가/구형 NIO 파일 제거 목록입니다. 원본 ZIP은 별도로 보존돼 있습니다.
