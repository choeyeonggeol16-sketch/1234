# Windows PowerShell 5.1+, 64-bit. Run, then start the game normally via PURPLE.
# Collects LC identity, loaded-module metadata and TCP endpoints; no packet data.
[CmdletBinding()]
param([ValidateRange(10,600)][int]$Seconds = 120)

$ErrorActionPreference = 'Stop'
if (-not [Environment]::Is64BitProcess) {
    throw 'Run this script from 64-bit Windows PowerShell.'
}
$desktop = [Environment]::GetFolderPath('Desktop')
if ([string]::IsNullOrWhiteSpace($desktop)) { $desktop = $env:TEMP }
$runName = 'LC_check_' + (Get-Date -Format 'yyyyMMdd_HHmmss') + '_' + ([guid]::NewGuid().ToString('N').Substring(0,6))
$outDir = Join-Path $desktop $runName
New-Item -ItemType Directory -Path $outDir | Out-Null
$images = @{}
$modules = @{}
$connections = @{}
$notes = @{}
$started = [DateTime]::UtcNow.ToString('o')
$watch = [Diagnostics.Stopwatch]::StartNew()
Write-Host "Collecting for $Seconds seconds. Start the game normally through PURPLE now."

while ($watch.Elapsed.TotalSeconds -lt $Seconds) {
    foreach ($proc in @(Get-Process -Name LC -ErrorAction SilentlyContinue)) {
        $processId = [int]$proc.Id
        $now = [DateTime]::UtcNow.ToString('o')
        if (-not $images.ContainsKey($processId)) {
            $image = [ordered]@{ ProcessId=$processId; FirstSeenUtc=$now; FileName='LC.exe'; SHA256=$null; FileVersion=$null; ProductName=$null }
            try {
                $exePath = $proc.Path
                if ($exePath) {
                    $info = [Diagnostics.FileVersionInfo]::GetVersionInfo($exePath)
                    $image.SHA256 = (Get-FileHash -LiteralPath $exePath -Algorithm SHA256).Hash
                    $image.FileVersion = $info.FileVersion
                    $image.ProductName = $info.ProductName
                    $folder = Split-Path -LiteralPath $exePath
                    $files = @(Get-ChildItem -LiteralPath $folder -File | Sort-Object Name | Select-Object Name,Length)
                    ConvertTo-Json -InputObject $files -Depth 4 | Set-Content -LiteralPath (Join-Path $outDir "client_files_$processId.json") -Encoding UTF8
                } else { $notes["image_$processId"] = 'Executable path was unavailable.' }
            } catch { $notes["image_$processId"] = 'Some executable/file metadata was unavailable.' }
            $images[$processId] = $image
        }
        try {
            foreach ($module in $proc.Modules) {
                $moduleKey = "$processId|$($module.ModuleName)|$($module.BaseAddress.ToInt64())"
                if (-not $modules.ContainsKey($moduleKey)) {
                    $modules[$moduleKey] = [ordered]@{
                        ProcessId=$processId; Name=$module.ModuleName
                        BaseAddress=('0x{0:X}' -f $module.BaseAddress.ToInt64())
                        Size=$module.ModuleMemorySize; FirstSeenUtc=$now
                        FileVersion=$module.FileVersionInfo.FileVersion
                        CompanyName=$module.FileVersionInfo.CompanyName
                    }
                }
            }
        } catch { $notes["modules_$processId"] = 'Loaded-module metadata was unavailable; no process modification was attempted.' }
        try {
            foreach ($socket in @(Get-NetTCPConnection -OwningProcess $processId -ErrorAction Stop)) {
                $key = "$processId|$($socket.LocalPort)|$($socket.RemoteAddress)|$($socket.RemotePort)|$($socket.State)"
                if (-not $connections.ContainsKey($key)) {
                    $connections[$key] = [ordered]@{
                        ProcessId=$processId; LocalPort=$socket.LocalPort
                        RemoteAddress=$socket.RemoteAddress; RemotePort=$socket.RemotePort
                        State=[string]$socket.State; FirstSeenUtc=$now; LastSeenUtc=$now
                    }
                } else { $connections[$key].LastSeenUtc = $now }
            }
        } catch { $notes['tcp'] = 'Some samples had no accessible TCP connections.' }
    }
    Start-Sleep -Milliseconds 1000
}

$report = [ordered]@{
    StartedUtc=$started; FinishedUtc=[DateTime]::UtcNow.ToString('o')
    PowerShellVersion=$PSVersionTable.PSVersion.ToString()
    Images=@($images.Values); Modules=@($modules.Values)
    Connections=@($connections.Values); Notes=$notes
}
ConvertTo-Json -InputObject $report -Depth 7 | Set-Content -LiteralPath (Join-Path $outDir 'LC_report.json') -Encoding UTF8
if ($images.Count -eq 0) { Write-Host 'LC.exe was not observed. The report contains no client process data.' }
$zipPath = $outDir + '.zip'
Compress-Archive -Path (Join-Path $outDir '*') -DestinationPath $zipPath
Write-Host "Done. Result ZIP: $zipPath"
