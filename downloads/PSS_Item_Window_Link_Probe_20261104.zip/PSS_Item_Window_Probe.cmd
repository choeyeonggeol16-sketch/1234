@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0PSS_Item_Window_Probe.ps1" %*
pause
