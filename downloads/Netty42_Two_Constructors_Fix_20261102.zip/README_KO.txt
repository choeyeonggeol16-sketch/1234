두 생성자 경고 수정 파일

적용 위치는 로그에 찍힌 Eclipse 프로젝트입니다:
C:\Users\pc\eclipse-workspace\lin310netty

이 ZIP의 src 폴더를 위 프로젝트 폴더에 병합해 두 Java 파일을 덮어씁니다.

수정 결과:
S_AuctionSystemBoard.java: String moneyString = Double.valueOf(string).toString();
TYUtil.java: list.add(Integer.valueOf(value));

Eclipse에서 F5 새로 고침, Ctrl+Shift+S 전체 저장 후 Ant Build를 다시 실행합니다.

이 두 파일은 이전 경고 수정 패치와 같은 내용입니다. 기존 패치가 다른 폴더에 풀렸거나 파일을 저장하지 않았다면 해당 프로젝트 빌드에는 반영되지 않습니다.
이 패치는 SAXException 또는 Eclipse 클래스패스 설정을 수정하지 않습니다.
