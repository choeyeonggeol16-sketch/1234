import java.nio.file.*;import java.util.*;import javax.tools.*;
import com.sun.source.tree.*;import com.sun.source.util.*;
class Catalog {
 static String q(Object x){if(x==null)return "null";return "\""+x.toString().replace("\\","\\\\").replace("\"","\\\"").replace("\n","\\n").replace("\r","\\r").replace("\t","\\t")+"\"";}
 static String params(List<? extends VariableTree> ps){return "["+String.join(",",ps.stream().map(p->"{\"name\":"+q(p.getName())+",\"type\":"+q(p.getType())+"}").toList())+"]";}
 public static void main(String[] args)throws Exception{
  Path root=Path.of(args[0]);List<String> out=new ArrayList<>();
  try(var fm=ToolProvider.getSystemJavaCompiler().getStandardFileManager(null,null,null)){
   var fs=new ArrayList<>(Files.list(root.resolve("src/l1j/server/server/packets/Protocol/Packet")).filter(p->p.getFileName().toString().startsWith("SC_")&&p.toString().endsWith(".java")).sorted().map(Path::toFile).toList());
   if(args.length>1)fs.add(Path.of(args[1]).toFile());
   var task=(JavacTask)ToolProvider.getSystemJavaCompiler().getTask(null,fm,null,List.of("-proc:none"),null,fm.getJavaFileObjectsFromFiles(fs));
   for(var unit:task.parse()){
    String text=Files.readString(Path.of(unit.getSourceFile().toUri()));var pos=Trees.instance(task).getSourcePositions();
    ClassTree cls=(ClassTree)unit.getTypeDecls().getFirst();List<String> fields=new ArrayList<>(),methods=new ArrayList<>();
    for(var member:cls.getMembers()){
     if(member instanceof VariableTree f&&!f.getModifiers().getFlags().contains(javax.lang.model.element.Modifier.STATIC))fields.add("{\"name\":"+q(f.getName())+",\"type\":"+q(f.getType())+",\"init\":"+q(f.getInitializer())+"}");
     if(member instanceof MethodTree m){long a=pos.getStartPosition(unit,m),b=pos.getEndPosition(unit,m);methods.add("{\"name\":"+q(m.getName())+",\"returns\":"+q(m.getReturnType())+",\"params\":"+params(m.getParameters())+",\"a\":"+a+",\"b\":"+b+",\"body\":"+q(m.getBody())+"}");}
    }
    out.add("{\"name\":"+q(cls.getSimpleName())+",\"file\":"+q(root.relativize(Path.of(unit.getSourceFile().toUri())))+",\"fields\":["+String.join(",",fields)+"],\"methods\":["+String.join(",",methods)+"]}");
   }
  }System.out.println("["+String.join(",",out)+"]");
 }
}
