#!/usr/bin/env python3
"""Compare original and new serializers, using actual compiled production types.
Game-state-dependent schemas are reported rather than counted as valid packets.
"""
from pathlib import Path
import argparse,json,os,subprocess,tempfile
root=Path(__file__).resolve().parents[2]
p=argparse.ArgumentParser();p.add_argument('--classes',type=Path,default=Path('/workspace/builds/protocol-direct/classes'));a=p.parse_args()
rows=json.loads((Path(__file__).with_name('packet_fields.json')).read_text())
with tempfile.TemporaryDirectory() as td:
    d=Path(td);manifest=d/'fields.txt'
    manifest.write_text('\n'.join(name+'|'+','.join(f['name'] for f in m['fields'])+'|'+','.join(m['nullable']) for name,m in rows.items() if not m.get('staticOnly'))+'\n')
    cp=os.pathsep.join([str(a.classes),*map(str,Path(os.environ.get('ITEM_DEPS_DIR','/workspace/dependencies/item-processing')).glob('*.jar'))])
    subprocess.run(['java','-m','jdk.compiler/com.sun.tools.javac.Main','-source','21','-target','21','-encoding','UTF-8','-d',td,str(Path(__file__).with_name('ProtocolWireAudit.java'))],check=True,timeout=60)
    subprocess.run(['java','--enable-preview','-ea','-cp',td+os.pathsep+cp,'ProtocolWireAudit',str(manifest)],check=True,timeout=60,cwd=td)
