#!/usr/bin/env python3
"""Actual direct sender, CIOUserSocket, pool and deadline task; controlled I/O/clock edges."""
from pathlib import Path
import argparse, hashlib, os, re, subprocess, tempfile
root = Path(__file__).resolve().parents[2]
here = Path(__file__).resolve().parent
p = argparse.ArgumentParser()
p.add_argument('--classes',type=Path,default=Path('/workspace/builds/server-version-cleanup/classes'))
p.add_argument('--loopback',action='store_true')
a=p.parse_args()
cp=os.pathsep.join([str(a.classes),*map(str,Path(os.environ.get('ITEM_DEPS_DIR','/workspace/dependencies/item-processing')).glob('*.jar'))])
base=root/'src/l1j/server/server'
def block(source, signature):
    start=source.index(signature);at=source.index('{',start);depth=1;end=at+1
    # Frozen body / deadline class have no braces within strings that affect extraction.
    tokens=re.compile(r'"(?:\\.|[^"\\])*"|\'(?:\\.|[^\'\\])*\'|//[^\n]*|/\*[\s\S]*?\*/|[{}]|[^{}"\'/]+|.',re.S)
    for m in tokens.finditer(source,end):
        if m[0]=='{':depth+=1
        elif m[0]=='}':
            depth-=1
            if not depth:return source[start:m.end()]
    raise AssertionError(signature)
legacy=(here/'fixtures/SC_ServerVersionInfo.before.java.txt').read_text()
body=block(legacy,'protected void body(ProtoWriter w)')
message=block(legacy,'public int msgId()')
# The legacy serializer remains verbatim. A nested clock only supplies the
# measured wire timestamp so the byte comparison cannot race a second boundary.
oracle='''package l1j.server.server.model.network.core;
import l1j.server.server.packets.Protocol.*;
import l1j.server.server.model.network.safe.NetworkSafeLoadManager;
final class LegacyVersion extends ProtoPacket {
    static int STATUS_START_TIME;
    static long nowMillis;
    private final boolean _accept;
    LegacyVersion(boolean accept) { _accept=accept; }
    static final class System { static long currentTimeMillis() { return nowMillis; } }
'''+message+'\n'+body+'\n}\n'
factory=(base/'model/network/core/CIOSocketFactory.java').read_text()
deadline=block(factory,'private static final class SocketDeadline')
lift='''package l1j.server.server.model.network.core;
import java.lang.ref.WeakReference;
import l1j.server.server.model.network.thread.CIOThreadCallback;
final class ActualDeadline {
'''+deadline+'''
    static CIOUserSocket.NetworkDeadline create(CIOUserSocket socket,CIOThreadCallback scheduler) {
        return new SocketDeadline(socket,scheduler,0);
    }
}
'''
production=['model/network/core/CIOUserSocket.java','model/network/core/CIOBufferPool.java','model/network/core/CIOFrame.java',
            'model/network/buffer/WriteBuffer.java','model/network/buffer/ReadBuffer.java',
            'model/network/packet/ServerPacket.java','model/network/packet/WritablePacket.java',
            'packets/Protocol/Proto.java','packets/Protocol/ProtoWriter.java','packets/Protocol/ProtoPacket.java',
            'packets/Protocol/Packet/SC_ServerVersionInfo.java','packets/Protocol/Packet/CS_ClientVersionInfo.java']
with tempfile.TemporaryDirectory() as td:
    d=Path(td);(d/'LegacyVersion.java').write_text(oracle);(d/'ActualDeadline.java').write_text(lift)
    sources=[*map(str,(here/'stubs').rglob('*.java')),*[str(base/s) for s in production],
             str(d/'LegacyVersion.java'),str(d/'ActualDeadline.java'),str(here/'ServerVersionContract.java')]
    subprocess.run(['java','-m','jdk.compiler/com.sun.tools.javac.Main','--enable-preview','-source','21','-target','21',
                    '-encoding','UTF-8','-cp',cp,'-d',td,*sources],check=True,timeout=90)
    subprocess.run(['java','--enable-preview','-ea', '-DserverVersion.loopback='+str(a.loopback).lower(),'-cp',td+os.pathsep+cp,
                    'l1j.server.server.model.network.core.ServerVersionContract'],check=True,timeout=90,cwd=td)
