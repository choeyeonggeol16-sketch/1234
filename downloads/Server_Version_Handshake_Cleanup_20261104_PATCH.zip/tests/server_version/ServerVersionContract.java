package l1j.server.server.model.network.core;

import java.io.*;
import java.lang.reflect.*;
import java.net.*;
import java.nio.*;
import java.nio.channels.*;
import java.nio.channels.spi.AsynchronousChannelProvider;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.*;
import l1j.server.server.Opcodes;
import l1j.server.server.model.network.buffer.*;
import l1j.server.server.model.network.packet.*;
import l1j.server.server.model.network.safe.NetworkSafeLoadManager;
import l1j.server.server.model.network.thread.CIOThreadCallback;
import l1j.server.server.packets.Protocol.*;
import l1j.server.server.packets.Protocol.Packet.*;

/** Production transport/pool/encoders with deterministic partial I/O completions. */
public final class ServerVersionContract {
    static int passed;
    static void check(boolean ok,String message) { if(!ok)throw new AssertionError(message); }
    interface Checked { void run() throws Exception; }
    static void test(String name,Checked action)throws Exception {
        action.run();passed++;java.lang.System.out.println("PASS "+name);
    }
    static Field field(Class<?> type,String name)throws Exception {Field f=type.getDeclaredField(name);f.setAccessible(true);return f;}
    static long deadline(CIOUserSocket socket)throws Exception {return field(CIOUserSocket.class,"_closeNotBeforeNs").getLong(socket);}
    static void graceElapsed(CIOUserSocket socket)throws Exception {field(CIOUserSocket.class,"_closeNotBeforeNs").setLong(socket,java.lang.System.nanoTime()-1);}
    static final class Pending {
        ByteBuffer[] buffers;Object attachment;CompletionHandler handler;boolean gather;
        Pending(ByteBuffer[] b,Object a,CompletionHandler h,boolean g){buffers=b;attachment=a;handler=h;gather=g;}
    }
    static final class Channel extends AsynchronousSocketChannel {
        volatile boolean open=true;boolean inline;volatile Pending write;ByteBuffer reading;Object readAttachment;CompletionHandler<Integer,Object> readHandler;
        final ByteArrayOutputStream output=new ByteArrayOutputStream();int readRegistrations;
        Channel(){super(AsynchronousChannelProvider.provider());}
        @Override public boolean isOpen(){return open;}
        @Override public synchronized void close(){
            if(!open)return;open=false;Pending p=write;write=null;
            if(p!=null)p.handler.failed(new AsynchronousCloseException(),p.attachment);
            CompletionHandler<Integer,Object> h=readHandler;Object a=readAttachment;readHandler=null;reading=null;
            if(h!=null)h.failed(new AsynchronousCloseException(),a);
        }
        @Override public synchronized <A> void write(ByteBuffer b,long t,TimeUnit u,A a,CompletionHandler<Integer,? super A> h){
            check(write==null,"overlapping WRITE");write=new Pending(new ByteBuffer[]{b},a,h,false);if(inline)complete(Integer.MAX_VALUE);
        }
        @Override public synchronized <A> void write(ByteBuffer[] b,int o,int n,long t,TimeUnit u,A a,CompletionHandler<Long,? super A> h){
            check(write==null,"overlapping gather WRITE");write=new Pending(Arrays.copyOfRange(b,o,o+n),a,h,true);if(inline)complete(Integer.MAX_VALUE);
        }
        synchronized void complete(int maximum){
            Pending p=write;check(p!=null,"no pending WRITE");write=null;int count=0;
            for(ByteBuffer b:p.buffers)while(b.hasRemaining()&&count<maximum){output.write(b.get());count++;}
            Object result=p.gather ? (Object)Long.valueOf(count) : Integer.valueOf(count);
            p.handler.completed(result,p.attachment);
        }
        void finish(){for(int i=0;write!=null;i++){check(i<1000,"WRITE pump stuck");complete(Integer.MAX_VALUE);}}
        @Override public <A> void read(ByteBuffer b,long t,TimeUnit u,A a,CompletionHandler<Integer,? super A> h){
            check(readHandler==null,"overlapping READ");reading=b;readAttachment=a;readHandler=(CompletionHandler)h;readRegistrations++;
        }
        void receive(byte[] data){
            check(readHandler!=null,"READ not registered");reading.put(data);
            CompletionHandler<Integer,Object> h=readHandler;Object a=readAttachment;readHandler=null;reading=null;
            h.completed(data.length,a);
        }
        @Override public <A> void read(ByteBuffer[] b,int o,int n,long t,TimeUnit u,A a,CompletionHandler<Long,? super A> h){throw new UnsupportedOperationException();}
        @Override public Future<Integer> read(ByteBuffer b){throw new UnsupportedOperationException();}
        @Override public Future<Integer> write(ByteBuffer b){throw new UnsupportedOperationException();}
        @Override public AsynchronousSocketChannel bind(SocketAddress a){return this;}
        @Override public <T> AsynchronousSocketChannel setOption(SocketOption<T> n,T v){return this;}
        @Override public <T> T getOption(SocketOption<T> n){return null;}
        @Override public Set<SocketOption<?>> supportedOptions(){return Set.of();}
        @Override public AsynchronousSocketChannel shutdownInput(){return this;}
        @Override public AsynchronousSocketChannel shutdownOutput(){return this;}
        @Override public SocketAddress getRemoteAddress(){return new InetSocketAddress("127.0.0.1",55000);}
        @Override public SocketAddress getLocalAddress(){return new InetSocketAddress("127.0.0.1",2000);}
        @Override public <A> void connect(SocketAddress r,A a,CompletionHandler<Void,? super A> h){h.completed(null,a);}
        @Override public Future<Void> connect(SocketAddress r){return CompletableFuture.completedFuture(null);}
        List<byte[]> packets(){
            byte[] data=output.toByteArray();List<byte[]> result=new ArrayList<>();
            for(int p=0;p<data.length;){check(p+2<=data.length,"partial wire header");int n=(data[p]&255)|((data[p+1]&255)<<8);
                check(n>=2&&p+n<=data.length,"wire length / lost partial WRITE");result.add(Arrays.copyOfRange(data,p+2,p+n));p+=n;}
            return result;
        }
    }
    static final class Session implements AutoCloseable {
        final CIOBufferPool pool=new CIOBufferPool(4,16,2,4);
        final Channel channel=new Channel();
        final CIOThreadCallback scheduler=new CIOThreadCallback();
        final AtomicInteger closed=new AtomicInteger();
        final CIOUserSocket socket=new CIOUserSocket(channel,pool,scheduler,"fixture",0,16,s->closed.incrementAndGet());
        final CIOClient client=new CIOClient(socket);
        CIOUserSocket.NetworkDeadline task;
        Session(){socket.bindClient(client);}
        void install(){task=ActualDeadline.create(socket,scheduler);socket.bindNetworkDeadline(task);check(task.scheduleEarlier(5000),"initial deadline refused");}
        void noLeaks(){check(pool.usedSendSlots()==0,"SEND lease leak");check(pool.usedRecvSlots()==0,"READ lease leak");check(socket.pendingSendBytes()==0,"wire reservation leak");check(closed.get()==1,"close callback count "+closed.get());}
        public synchronized void close(){socket.close();}
    }
    static long varint(byte[] packet,int[] position) {
        long value=0;int shift=0,b;
        do { b=packet[position[0]++]&255;value|=(long)(b&127)<<shift;shift+=7; } while((b&128)!=0);
        return value;
    }
    static Map<Integer,Long> scalarFields(byte[] packet){
        check(packet.length>=5&&packet[0]==(byte)Opcodes.S_EXTENDED_PROTOBUF,"opcode");
        check(((packet[1]&255)|((packet[2]&255)<<8))==ProtoMsg.SC_SERVER_VERSION_INFO,"message ID");
        check(packet[packet.length-1]==0&&packet[packet.length-2]==0,"trailer");
        Map<Integer,Long> values=new LinkedHashMap<>();int[] p={3};
        while(p[0]<packet.length-2){int tag=(int)varint(packet,p);check((tag&7)==0,"wire type");
            long value=varint(packet,p);check(values.put(tag>>>3,value)==null,"duplicate field");}
        return values;
    }
    static void wire()throws Exception {
        long processStart=java.lang.System.currentTimeMillis()/1000L;
        int[] edges={0,1,-1,127,128,Integer.MIN_VALUE,Integer.MAX_VALUE,20261104};
        for(int i=0;i<64;i++)try(Session s=new Session()){
            NetworkSafeLoadManager.NS_CLIENT_VERSION=edges[i%edges.length];
            NetworkSafeLoadManager.NS_AUTHSERVER_VERSION=edges[(i+1)%edges.length];
            NetworkSafeLoadManager.NS_CLIENT_SETTING_SWITCH=edges[(i+2)%edges.length];
            NetworkSafeLoadManager.NS_CACHESERVER_VERSION=edges[(i+3)%edges.length];
            NetworkSafeLoadManager.NS_TAMSERVER_VERSION=edges[(i+4)%edges.length];
            NetworkSafeLoadManager.NS_ARCASERVER_VERSION=edges[(i+5)%edges.length];
            NetworkSafeLoadManager.NS_HIBREED_INTERSERVER_VERSION=edges[(i+6)%edges.length];
            NetworkSafeLoadManager.NS_ARENACOSERVER_VERSION=edges[(i+7)%edges.length];
            long before=java.lang.System.currentTimeMillis()/1000L;
            SC_ServerVersionInfo.send(s.client);s.channel.finish();
            byte[] actual=s.channel.packets().getFirst();Map<Integer,Long> fields=scalarFields(actual);
            check(fields.size()==17,"normal reply fields");
            long seconds=fields.get(11);check(seconds>=before&&seconds<=java.lang.System.currentTimeMillis()/1000L,"real Unix time changed");
            LegacyVersion.nowMillis=seconds*1000L;
            LegacyVersion.STATUS_START_TIME=field(SC_ServerVersionInfo.class,"STATUS_START_TIME").getInt(null);
            check(LegacyVersion.STATUS_START_TIME>=processStart,"startup clock changed");
            check(Arrays.equals(new LegacyVersion(true).encode(),actual),"normal reply differs from frozen original round "+i);
            s.install();SC_ServerVersionInfo.denial(s.client);s.channel.finish();
            byte[] denied=s.channel.packets().get(1);
            check(Arrays.equals(new LegacyVersion(false).encode(),denied),"denial bytes changed");
            check(s.channel.open&&!s.client.isConnected(),"denial must block input and retain grace");
        }
        check(SC_ServerVersionInfo.class.getSuperclass()==Object.class,"message shell retained");
        for(Method m:SC_ServerVersionInfo.class.getDeclaredMethods())
            check(!Set.of("body","writeFields","sendFields","sendCtor","sendConstructed","encodeFields").contains(m.getName()),"redundant API retained");
        java.lang.System.out.println("PASS frozen original bytes: 64 normal + 64 denial replies");
    }
    static byte[] inbound(int opcode){return new byte[]{10,0,(byte)opcode,0,0,0,0,0,0,0};}
    static byte[] concat(byte[] a,byte[] b){byte[] c=Arrays.copyOf(a,a.length+b.length);java.lang.System.arraycopy(b,0,c,a.length,b.length);return c;}
    static void lifecycle()throws Exception {
        test("inline WRITE completion still retains denial grace",()->{try(Session s=new Session()){
            s.install();s.channel.inline=true;SC_ServerVersionInfo.denial(s.client);
            check(s.channel.open&&s.channel.packets().size()==1,"inline completion closed early / lost reply");
            graceElapsed(s.socket);s.socket.onSendDrainedOwner();s.noLeaks();}});
        test("invalid grace does not alter admission; zero grace drains accepted data",()->{try(Session s=new Session()){
            s.install();for(long delay:new long[]{-1,30001,Long.MAX_VALUE}) {
                boolean refused=false;try{s.socket.requestClientCloseAfter(delay);}catch(IllegalArgumentException ok){refused=true;}
                check(refused&&s.client.isConnected(),"invalid delay altered connection");
            }
            Proto.sendRaw(s.client,new byte[]{7});s.socket.requestClientCloseAfter(0);
            check(s.channel.open,"zero grace discarded active WRITE");s.channel.finish();s.noLeaks();}});
        test("grace deadline boundary and ceil-to-millisecond scheduling",()->{try(Session s=new Session()){
            s.install();SC_ServerVersionInfo.denial(s.client);s.channel.finish();long due=deadline(s.socket);
            check(!s.socket.networkDeadlineExpired(due-1),"early close");check(s.socket.networkDeadlineExpired(due),"missed grace boundary");
            check(s.socket.nextNetworkDeadlineDelayMs(due-1,5000)==1,"rounding can close early / miss check");
            check(s.socket.nextNetworkDeadlineDelayMs(due-3_000_000_000L,5000)==3000,"3-second grace changed");
            s.socket.close();s.noLeaks();}});
        test("partial WRITE waits past grace until response completion",()->{try(Session s=new Session()){
            s.install();SC_ServerVersionInfo.denial(s.client);long due=deadline(s.socket);s.channel.complete(1);
            check(!s.socket.networkDeadlineExpired(due+1),"partial response discarded");
            graceElapsed(s.socket);s.channel.finish();check(!s.channel.open,"drained expired grace still open");
            check(s.channel.packets().size()==1,"denial lost");s.noLeaks();}});
        test("unsealed encoder reservation and accepted FIFO prefix survive closing",()->{try(Session s=new Session()){
            s.install();ProtoWriter earlier=Proto.begin(s.client,0x1234,256);earlier.uint32(1,7);
            SC_ServerVersionInfo.denial(s.client);long due=deadline(s.socket);
            check(!s.socket.networkDeadlineExpired(due+1),"reserved encoder overtaken");
            graceElapsed(s.socket);check(Proto.commit(earlier),"accepted encoder rejected while closing");s.channel.finish();
            List<byte[]> frames=s.channel.packets();check(frames.size()==2,"FIFO frame loss");
            check((frames.get(0)[1]&255)==0x34,"denial overtook prefix");scalarFields(frames.get(1));s.noLeaks();}});
        test("denial stops coalesced later inbound frames and does not rearm READ",()->{try(Session s=new Session()){
            s.install();AtomicInteger later=new AtomicInteger();
            CPacketHandler.HANDLERS[0x42]=(b,c)->SC_ServerVersionInfo.denial(c);
            CPacketHandler.HANDLERS[0x43]=(b,c)->later.incrementAndGet();
            s.socket.startRead();s.channel.receive(concat(inbound(0x42),inbound(0x43)));
            check(later.get()==0&&s.channel.readRegistrations==1,"post-denial request dispatched / READ rearmed");
            graceElapsed(s.socket);s.channel.finish();s.noLeaks();}});
        test("repeated denied requests do not add frames or deadline tasks",()->{try(Session s=new Session()){
            s.install();SC_ServerVersionInfo.denial(s.client);int scheduled=s.scheduler.tasks.size();long due=deadline(s.socket);
            for(int i=0;i<1000;i++)SC_ServerVersionInfo.denial(s.client);
            check(s.scheduler.tasks.size()==scheduled&&deadline(s.socket)==due,"repeated denial extended / allocated timers");
            s.channel.finish();check(s.channel.packets().size()==1,"repeated denial sent packets");}});
        test("missing deadline and failed earlier-deadline admission fail closed",()->{
            try(Session s=new Session()){SC_ServerVersionInfo.denial(s.client);check(!s.channel.open,"missing deadline orphaned peer");s.noLeaks();}
            try(Session s=new Session()){s.install();s.scheduler.reject=true;SC_ServerVersionInfo.denial(s.client);check(!s.channel.open,"rejected wake orphaned peer");s.noLeaks();}});
        test("pool exhaustion closes without delayed close or reservation leak",()->{try(Session s=new Session()){
            s.install();List<CIOBufferPool.Lease> held=new ArrayList<>();CIOBufferPool.Lease lease;
            while((lease=s.pool.acquireSend(256))!=null)held.add(lease);
            SC_ServerVersionInfo.denial(s.client);check(!s.channel.open&&s.scheduler.tasks.size()==1,"failed SEND scheduled delayed close");
            for(CIOBufferPool.Lease x:held)s.pool.release(x);s.noLeaks();}});
        test("peer close completes once while denial is still in flight",()->{try(Session s=new Session()){
            s.install();SC_ServerVersionInfo.denial(s.client);s.channel.close();s.socket.close();s.noLeaks();}});
        test("stalled WRITE retains hard 30-second close bound",()->{try(Session s=new Session()){
            s.install();SC_ServerVersionInfo.denial(s.client);long start=field(CIOUserSocket.class,"_gracefulCloseStartedNs").getLong(s.socket);
            check(!s.socket.networkDeadlineExpired(start+29_999_999_999L),"hard timeout too early");
            check(s.socket.networkDeadlineExpired(start+30_000_000_000L),"stalled peer can remain forever");
            check(s.socket.nextNetworkDeadlineDelayMs(start+29_999_999_999L,5000)==1,"hard close check postponed by periodic cadence");
            s.socket.close();s.noLeaks();}});
        test("ordinary final-packet graceful close has no added grace",()->{try(Session s=new Session()){
            s.install();Proto.sendRaw(s.client,new byte[]{11});AtomicInteger encoded=new AtomicInteger();
            ServerPacket finalPacket=new ServerPacket(){protected void writeImpl(CIOClient c,WriteBuffer w){encoded.incrementAndGet();w.writeC(12);}};
            s.socket.requestClientClose(finalPacket);check(encoded.get()==0,"final packet overtook prefix");s.channel.finish();
            check(encoded.get()==1&&s.channel.packets().size()==2&&!s.channel.open,"ordinary graceful close changed");s.noLeaks();}});
        test("existing deadline task is reused and stale wakeups do not branch periodic loops",()->{try(Session s=new Session()){
            s.install();Object task=s.scheduler.tasks.getFirst();check(s.task.scheduleEarlier(6000)&&s.scheduler.tasks.size()==1,"later request duplicated timer");
            SC_ServerVersionInfo.denial(s.client);check(s.scheduler.tasks.size()==2&&s.scheduler.tasks.get(1)==task,"new per-denial task object");
            field(task.getClass(),"nextCheckAtMs").setLong(task,java.lang.System.nanoTime()/1_000_000L);
            ((CIOThreadCallback.WheelTask)task).run();int count=s.scheduler.tasks.size();
            ((CIOThreadCallback.WheelTask)task).run();check(s.scheduler.tasks.size()==count,"stale periodic event created second loop");}});
        test("real 3-second grace closes through the existing deadline task",()->{try(Session s=new Session()){
            s.install();long before=java.lang.System.nanoTime();SC_ServerVersionInfo.denial(s.client);s.channel.finish();
            check(s.channel.open,"closed before grace");Thread.sleep(3050);
            ((CIOThreadCallback.WheelTask)s.task).run();check(!s.channel.open,"deadline did not close idle denied peer");
            check(java.lang.System.nanoTime()-before>=3_000_000_000L,"3-second grace shortened");s.noLeaks();}});
        test("concurrent WRITE completion, deadline and forced close release once",()->{
            for(int i=0;i<100;i++)try(Session s=new Session()){
                s.install();SC_ServerVersionInfo.denial(s.client);graceElapsed(s.socket);
                AtomicReference<Throwable> failure=new AtomicReference<>();CountDownLatch start=new CountDownLatch(1);
                Thread completed=new Thread(()->{try{start.await();s.channel.finish();}catch(Throwable e){failure.set(e);}});
                Thread expired=new Thread(()->{try{start.await();if(s.socket.networkDeadlineExpired(java.lang.System.nanoTime()))s.socket.close();}catch(Throwable e){failure.set(e);}});
                completed.start();expired.start();start.countDown();completed.join(2000);expired.join(2000);
                check(!completed.isAlive()&&!expired.isAlive(),"close race deadlocked");if(failure.get()!=null)throw new AssertionError(failure.get());
                s.socket.close();s.noLeaks();
            }});
    }
    static void loopback()throws Exception {
        test("real localhost TCP delivers refusal before graceful EOF",()->{
            CIOBufferPool pool=new CIOBufferPool(2,8,1,1);CIOThreadCallback scheduler=new CIOThreadCallback();AtomicInteger closed=new AtomicInteger();
            try(ServerSocketChannel listener=ServerSocketChannel.open();AsynchronousSocketChannel sender=AsynchronousSocketChannel.open()) {
                listener.bind(new InetSocketAddress(InetAddress.getLoopbackAddress(),0));
                Future<Void> connected=sender.connect(listener.getLocalAddress());
                try(SocketChannel peer=listener.accept()) {
                    connected.get(2,TimeUnit.SECONDS);peer.configureBlocking(false);
                    CIOUserSocket socket=new CIOUserSocket(sender,pool,scheduler,"loopback",0,8,c->closed.incrementAndGet());
                    socket.bindClient(new CIOClient(socket));CIOUserSocket.NetworkDeadline task=ActualDeadline.create(socket,scheduler);
                    socket.bindNetworkDeadline(task);check(task.scheduleEarlier(5000),"loopback deadline refused");
                    long began=java.lang.System.nanoTime();SC_ServerVersionInfo.denial(socket.client());
                    ByteBuffer bytes=ByteBuffer.allocate(32);long until=began+2_000_000_000L;
                    while(bytes.position()<9&&java.lang.System.nanoTime()<until){peer.read(bytes);java.util.concurrent.locks.LockSupport.parkNanos(1_000_000L);}
                    check(bytes.position()==9,"refusal did not reach real TCP peer");
                    check(Arrays.equals(Arrays.copyOfRange(bytes.array(),2,9),new LegacyVersion(false).encode()),"real TCP refusal changed");
                    check(socket.isOpen(),"real TCP closed before grace");
                    long wait=3_050_000_000L-(java.lang.System.nanoTime()-began);
                    if(wait>0)TimeUnit.NANOSECONDS.sleep(wait);
                    ((CIOThreadCallback.WheelTask)task).run();
                    until=java.lang.System.nanoTime()+2_000_000_000L;int read=0;
                    while(read!=-1&&java.lang.System.nanoTime()<until){read=peer.read(bytes);java.util.concurrent.locks.LockSupport.parkNanos(1_000_000L);}
                    check(read==-1&&!socket.isOpen()&&closed.get()==1,"real TCP EOF/close incomplete");
                    check(pool.usedSendSlots()==0&&socket.pendingSendBytes()==0,"real TCP lease/reservation leak");
                }
            }
        });
    }
    public static void main(String[] args)throws Exception {wire();lifecycle();if(Boolean.getBoolean("serverVersion.loopback"))loopback();java.lang.System.out.println("RESULT lifecycle groups="+passed+", byte comparisons=128, race iterations=100");}
}
