package l1j.server.server.model.network.thread;
import java.util.*;
public final class CIOThreadCallback {
    public interface WheelTask { void run(); boolean isCancelled(); }
    public final List<WheelTask> tasks = new ArrayList<>();
    public final List<Long> delays = new ArrayList<>();
    public boolean reject;
    public int shardCount() { return 1; }
    public boolean scheduleNetworkTimeout(int shard, WheelTask task, long delay) {
        if (reject) return false;
        tasks.add(task); delays.add(delay); return true;
    }
}
