package l1j.server.server.model.network.safe;
import l1j.server.server.model.network.core.CIOClient;
public final class NetworkSafeLoadManager {
    public static int NS_CLIENT_VERSION, NS_AUTHSERVER_VERSION, NS_CLIENT_SETTING_SWITCH,
        NS_CACHESERVER_VERSION, NS_TAMSERVER_VERSION, NS_ARCASERVER_VERSION,
        NS_HIBREED_INTERSERVER_VERSION, NS_ARENACOSERVER_VERSION;
    public static final int RESULT_FILTER = -1;
    public static int isFilter(CIOClient client, int opcode) { return 0; }
}
