package l1j.server.server.model.network.core;
import l1j.server.server.model.network.buffer.*;
import l1j.server.server.model.network.packet.ServerPacket;
public final class CIOClient {
    private final CIOUserSocket socket;
    private int empty;
    public CIOClient(CIOUserSocket socket) { this.socket = socket; }
    public boolean isConnected() { return socket.isClientConnected(); }
    public CIOUserSocket getConnection() { return socket; }
    public boolean encrypt(WriteBuffer b, int off, int len) { return socket.encrypt(b,off,len); }
    public boolean decrypt(ReadBuffer b, int off, int len) { return socket.decrypt(b,off,len); }
    public void sendPacket(ServerPacket packet) { socket.enqueuePacket(packet); }
    public void disconnect() { socket.close(); }
    public void close() { socket.close(); }
    public int incrementEmptyPacketCount() { return ++empty; }
    public void resetEmptyPacketCount() { empty = 0; }
    public boolean checkPacketRateLimit(long now) { return false; }
    public boolean isGameSessionReady() { return true; }
}
